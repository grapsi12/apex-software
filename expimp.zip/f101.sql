set define off
set verify off
set serveroutput on size 1000000
set feedback off
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
begin wwv_flow.g_import_in_progress := true; end; 
/
 
 
--application/set_environment
prompt  APPLICATION 101 - Data Load/Unload tool
--
-- Application Export:
--   Application:     101
--   Name:            Data Load/Unload tool
--   Date and Time:   21:09 Sunday August 9, 2009
--   Exported By:     EXPIMP
--   Flashback:       0
--   Export Type:     Application Export
--   Version: 3.2.0.00.27
 
-- Import:
--   Using application builder
--   or
--   Using SQL*Plus as the Oracle user APEX_030200 or as the owner (parsing schema) of the application.
 
-- Application Statistics:
--   Pages:                34
--     Items:             115
--     Computations:       27
--     Validations:        75
--     Processes:          42
--     Regions:           135
--     Buttons:            75
--   Shared Components
--     Breadcrumbs:         1
--        Entries          32
--     Items:               6
--     Computations:        1
--     Processes:           1
--     Parent Tabs:         0
--     Tab Sets:            0
--        Tabs:             0
--     NavBars:             2
--     Lists:              13
--     Shortcuts:           1
--     Themes:              1
--     Templates:
--        Page:             4
--        List:             7
--        Report:           2
--        Label:            3
--        Region:          10
--     Messages:            0
--     Build Options:       1
 
 
--       AAAA       PPPPP   EEEEEE  XX      XX
--      AA  AA      PP  PP  EE       XX    XX
--     AA    AA     PP  PP  EE        XX  XX
--    AAAAAAAAAA    PPPPP   EEEE       XXXX
--   AA        AA   PP      EE        XX  XX
--  AA          AA  PP      EE       XX    XX
--  AA          AA  PP      EEEEEE  XX      XX
prompt  Set Credentials...
 
begin
 
  -- Assumes you are running the script connected to SQL*Plus as the Oracle user APEX_030200 or as the owner (parsing schema) of the application.
  wwv_flow_api.set_security_group_id(p_security_group_id=>1037728024820170);
 
end;
/

begin wwv_flow.g_import_in_progress := true; end;
/
begin 

select value into wwv_flow_api.g_nls_numeric_chars from nls_session_parameters where parameter='NLS_NUMERIC_CHARACTERS';

end;

/
begin execute immediate 'alter session set nls_numeric_characters=''.,''';

end;

/
begin wwv_flow.g_browser_language := 'en-us'; end;
/
prompt  Check Compatibility...
 
begin
 
-- This date identifies the minimum version required to import this file.
wwv_flow_api.set_version(p_version_yyyy_mm_dd=>'2009.01.12');
 
end;
/

prompt  Set Application ID...
 
begin
 
   -- SET APPLICATION ID
   wwv_flow.g_flow_id := 101;
   wwv_flow_api.g_id_offset := 0;
null;
 
end;
/

--application/delete_application
 
begin
 
   -- Remove Application
wwv_flow_api.remove_flow(101);
 
end;
/

 
begin
 
wwv_flow_audit.remove_audit_trail(101);
null;
 
end;
/

--application/create_application
 
begin
 
wwv_flow_api.create_flow(
  p_id    => 101,
  p_display_id=> 101,
  p_owner => 'EXPIMP',
  p_name  => 'Data Load/Unload tool',
  p_alias => '101',
  p_page_view_logging => 'YES',
  p_default_page_template=> 4537010500402583 + wwv_flow_api.g_id_offset,
  p_printer_friendly_template=> 1060517913932420 + wwv_flow_api.g_id_offset,
  p_default_region_template=> 1060517925932426 + wwv_flow_api.g_id_offset,
  p_error_template    => 4537010500402583 + wwv_flow_api.g_id_offset,
  p_charset           => 'utf-8',
  p_page_protection_enabled_y_n=> 'N',
  p_checksum_salt_last_reset => '20090807233839',
  p_max_session_length_sec=> 28800,
  p_home_link         => 'f?p=&APP_ID.:1:&SESSION.',
  p_flow_language     => 'en-us',
  p_flow_language_derived_from=> 'BROWSER',
  p_flow_image_prefix => '/i/',
  p_documentation_banner=> '  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_FND_USER" FOR "APEX_030200"."WWV_FLOW_FND_USER";'||chr(10)||
'  GRANT SELECT ON "APEX_030200"."WWV_FLOW_FND_USER" TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_COMPANY_SCHEMAS" FOR "APEX_030200"."WWV_FLOW_COMPANY_SCHEMAS";'||chr(10)||
'  GRANT SELECT ON "APEX_030200"."WWV_FLOW_COMPANY_SCHEMAS" TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_SW_API" FOR "APEX_030200"."WWV_FLOW_SW_API";'||chr(10)||
'  GRANT EXECUTE ON "APEX_030200"."WWV_FLOW_SW_API" TO EXPIMP;'||chr(10)||
'  GRANT SELECT ON sys.dba_tables TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_LOAD_DATA" FOR "APEX_030200"."WWV_FLOW_LOAD_DATA";'||chr(10)||
'  GRANT EXECUTE ON "APEX_030200"."WWV_FLOW_LOAD_DATA" TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_LOAD_EXCEL_DATA" FOR "APEX_030200"."WWV_FLOW_LOAD_EXCEL_DATA";'||chr(10)||
'  GRANT EXECUTE ON "APEX_030200"."WWV_FLOW_LOAD_EXCEL_DATA" TO EXPIMP;'||chr(10)||
'  GRANT SELECT ON sys.dba_tab_columns TO EXPIMP;'||chr(10)||
'  GRANT SELECT ON sys.dba_triggers TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_DATA_LOAD_UNLOAD" FOR "APEX_030200"."WWV_FLOW_DATA_LOAD_UNLOAD";'||chr(10)||
'  GRANT SELECT, DELETE, INSERT ON "APEX_030200"."WWV_FLOW_DATA_LOAD_UNLOAD" TO EXPIMP;'||chr(10)||
'  GRANT SELECT ON sys.dba_objects TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_F4000_UTIL" FOR "APEX_030200"."WWV_FLOW_F4000_UTIL";'||chr(10)||
'  GRANT EXECUTE ON "APEX_030200"."WWV_FLOW_F4000_UTIL" TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_DATALOAD_XML" FOR "APEX_030200"."WWV_FLOW_DATALOAD_XML";'||chr(10)||
'  GRANT EXECUTE ON "APEX_030200"."WWV_FLOW_DATALOAD_XML" TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_SW_UTIL" FOR "APEX_030200"."WWV_FLOW_SW_UTIL";'||chr(10)||
'  GRANT EXECUTE ON "APEX_030200"."WWV_FLOW_SW_UTIL" TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP"."WWV_FLOW_BUILDER" FOR "APEX_030200"."WWV_FLOW_BUILDER";'||chr(10)||
'  GRANT EXECUTE ON "APEX_030200"."WWV_FLOW_BUILDER" TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP".wwv_flow_data_load_bad_log FOR "APEX_030200".wwv_flow_data_load_bad_log;'||chr(10)||
'  GRANT SELECT ON "APEX_030200".wwv_flow_data_load_bad_log TO EXPIMP;'||chr(10)||
'  GRANT SELECT ON sys.dba_sys_privs TO EXPIMP;'||chr(10)||
'  CREATE OR REPLACE SYNONYM "EXPIMP".wwv_flow_file_objects$ FOR flows_files.wwv_flow_file_objects$;'||chr(10)||
'  GRANT SELECT, DELETE ON flows_files.wwv_flow_file_objects$ TO EXPIMP;',
  p_authentication    => 'CUSTOM2',
  p_login_url         => '',
  p_logout_url        => 'wwv_flow_custom_auth_std.logout?p_this_flow=&APP_ID.&p_next_flow_page_sess=&APP_ID.:208',
  p_application_tab_set=> 1,
  p_logo_image => '#WORKSPACE_IMAGES#ico_import_export.gif',
  p_logo_image_attributes => 'width="30" height="30" alt="&PRODUCT_NAME."',
  p_public_url_prefix => '',
  p_public_user       => 'APEX_PUBLIC_USER',
  p_dbauth_url_prefix => '',
  p_proxy_server      => '',
  p_cust_authentication_process=> '.'||to_char(1071108219005204 + wwv_flow_api.g_id_offset)||'.',
  p_cust_authentication_page=> '',
  p_custom_auth_login_url=> '',
  p_flow_version      => '&PRODUCT_NAME. ',
  p_flow_status       => 'AVAILABLE_W_EDIT_LINK',
  p_flow_unavailable_text=> 'This application is currently unavailable.',
  p_build_status      => 'RUN_AND_BUILD',
  p_exact_substitutions_only=> 'Y',
  p_vpd               => '',
  p_csv_encoding    => 'Y',
  p_theme_id => 3,
  p_default_label_template => 104961228191988915 + wwv_flow_api.g_id_offset,
  p_default_report_template => 11634930157712121 + wwv_flow_api.g_id_offset,
  p_default_list_template => 120886429240393865 + wwv_flow_api.g_id_offset,
  p_default_menu_template => 7732025850477443 + wwv_flow_api.g_id_offset,
  p_substitution_string_01 => 'LOGOUT',
  p_substitution_value_01  => 'Logout',
  p_substitution_string_02 => 'PRODUCT_NAME',
  p_substitution_value_02  => 'Data Load/Unload tool',
  p_substitution_string_03 => 'MSG_COMPANY',
  p_substitution_value_03  => 'Workspace: &COMPANY.',
  p_substitution_string_04 => 'MSG_LANGUAGE',
  p_substitution_value_04  => 'Language',
  p_substitution_string_05 => 'MSG_COPYRIGHT',
  p_substitution_value_05  => 'Copyright &copy;. All rights reserved.',
  p_substitution_string_06 => 'MSG_USER',
  p_substitution_value_06  => 'User',
  p_substitution_string_07 => 'MSG_JSCRIPT',
  p_substitution_value_07  => 'You must run this product with JavaScript enabled.',
  p_substitution_string_08 => 'MSG_TBL_SUMMARY',
  p_substitution_value_08  => 'Page Layout Table',
  p_substitution_string_09 => 'DONE',
  p_substitution_value_09  => 'Done',
  p_substitution_string_10 => 'TOP',
  p_substitution_value_10  => 'Top',
  p_substitution_string_11 => 'CLOSE',
  p_substitution_value_11  => 'Close',
  p_substitution_string_12 => 'DATE_FORMAT',
  p_substitution_value_12  => 'mm/dd/yyyy',
  p_substitution_string_13 => 'LONG_DATE_FORMAT',
  p_substitution_value_13  => 'fmDay, Month dd, yyyy',
  p_substitution_string_14 => 'TIME_FORMAT',
  p_substitution_value_14  => 'hh:mi:ss AM',
  p_substitution_string_15 => 'DATE_TIME_FORMAT',
  p_substitution_value_15  => 'mm/dd/yyyy hh:mi:ss AM',
  p_substitution_string_16 => 'RETURN_TO_APPLICATION',
  p_substitution_value_16  => 'Return to Application',
  p_substitution_string_17 => 'DELETE_MSG',
  p_substitution_value_17  => 'Would you like to perform this delete action?',
  p_substitution_string_18 => 'FIND',
  p_substitution_value_18  => 'Find',
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss=> '20090807233839',
  p_required_roles=> wwv_flow_utilities.string_to_table2(''));
 
 
end;
/

prompt  ...authorization schemes
--
 
begin
 
null;
 
end;
/

--application/shared_components/navigation/navigation_bar
prompt  ...navigation bar entries
--
 
begin
 
wwv_flow_api.create_icon_bar_item(
  p_id             => 40942705842018838 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_icon_sequence  => 1,
  p_icon_image     => '',
  p_icon_subtext   => 'Help',
  p_icon_target    => 'javascript:popupURL(''wwv_flow_help.show_help?p_lang=&BROWSER_LANGUAGE.&p_session=&APP_SESSION.&p_flow_id=&APP_TRANSLATION_ID.&p_step_id=&APP_TRANSLATION_PAGE_ID.'');',
  p_icon_image_alt => 'Help',
  p_icon_height    => null,
  p_icon_width     => null,
  p_icon_height2   => null,
  p_icon_width2    => null,
  p_icon_bar_disp_cond      => '280',
  p_icon_bar_disp_cond_type => 'CURRENT_PAGE_NOT_IN_CONDITION',
  p_begins_on_new_line=> 'NO',
  p_cell_colspan      => 1,
  p_onclick=> '',
  p_icon_bar_comment=> '');
 
wwv_flow_api.create_icon_bar_item(
  p_id             => 41006928361451201 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_icon_sequence  => 10,
  p_icon_image     => '',
  p_icon_subtext   => 'Logout',
  p_icon_target    => 'wwv_flow_custom_auth_std.logout?p_this_flow=&APP_ID.&p_next_flow_page_sess=&APP_ID.:280:&SESSION.',
  p_icon_image_alt => 'Logout',
  p_icon_height    => null,
  p_icon_width     => null,
  p_icon_height2   => null,
  p_icon_width2    => null,
  p_icon_bar_disp_cond      => '280',
  p_icon_bar_disp_cond_type => 'CURRENT_PAGE_NOT_IN_CONDITION',
  p_begins_on_new_line=> 'NO',
  p_cell_colspan      => 1,
  p_onclick=> '',
  p_icon_bar_comment=> '');
 
 
end;
/

prompt  ...application processes
--
--application/shared_components/logic/application_processes/ajax_collect_clob
 
begin
 
declare
    p varchar2(32767) := null;
    l_clob clob;
    l_length number := 1;
begin
p:=p||'declare'||chr(10)||
'    l_code clob := empty_clob;'||chr(10)||
'begin'||chr(10)||
'   dbms_lob.createtemporary( l_code, false, dbms_lob.SESSION );'||chr(10)||
'   for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'        dbms_lob.writeappend(l_code,length(wwv_flow.g_f01(i)),wwv_flow.g_f01(i));'||chr(10)||
'    end loop;'||chr(10)||
'apex_collection.create_or_truncate_collection(p_collection_name=>''CLOB_CONTENT'');'||chr(10)||
'apex_collection.add_member(p_collection_name=>''CLOB_CONTENT'',p_clob001=>';

p:=p||'l_code);'||chr(10)||
'htp.prn(''SUCCESS'');'||chr(10)||
'end;';

wwv_flow_api.create_flow_process(
  p_id => 50957718755870179 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_process_sequence=> 1,
  p_process_point => 'ON_DEMAND',
  p_process_type=> 'PLSQL',
  p_process_name=> 'AJAX_COLLECT_CLOB',
  p_process_sql_clob=> p,
  p_process_error_message=> '',
  p_process_when=> '',
  p_process_when_type=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_process_comment=> '');
end;
 
null;
 
end;
/

prompt  ...application items
--
--application/shared_components/logic/application_items/company
 
begin
 
wwv_flow_api.create_flow_item(
  p_id=> 1051409378933363 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'COMPANY',
  p_data_type=> 'VARCHAR',
  p_is_persistent=> 'Y',
  p_protection_level=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_item_comment=> 'name of company for mutli company oracle platform');
 
null;
 
end;
/

--application/shared_components/logic/application_items/f4300_imex_batch_id
 
begin
 
wwv_flow_api.create_flow_item(
  p_id=> 26391335693568621 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'F4300_IMEX_BATCH_ID',
  p_data_type=> 'NUMBER',
  p_is_persistent=> 'Y',
  p_protection_level=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_item_comment=> '');
 
null;
 
end;
/

--application/shared_components/logic/application_items/f4300_last_view
 
begin
 
wwv_flow_api.create_flow_item(
  p_id=> 49654520224294306 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'F4300_LAST_VIEW',
  p_data_type=> 'VARCHAR',
  p_is_persistent=> 'Y',
  p_protection_level=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_item_comment=> '');
 
null;
 
end;
/

--application/shared_components/logic/application_items/f4300_load_job
 
begin
 
wwv_flow_api.create_flow_item(
  p_id=> 1051646801981499 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'F4300_LOAD_JOB',
  p_data_type=> 'NUMBER',
  p_is_persistent=> 'Y',
  p_protection_level=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_item_comment=> '');
 
null;
 
end;
/

--application/shared_components/logic/application_items/fsp_after_login_url
 
begin
 
wwv_flow_api.create_flow_item(
  p_id=> 148081013549234694 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'FSP_AFTER_LOGIN_URL',
  p_data_type=> 'VARCHAR',
  p_is_persistent=> 'Y',
  p_protection_level=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_item_comment=> 'Used by Custom2 authentication for deep linking support');
 
null;
 
end;
/

--application/shared_components/logic/application_items/last_view
 
begin
 
wwv_flow_api.create_flow_item(
  p_id=> 49661600894907176 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'LAST_VIEW',
  p_data_type=> 'VARCHAR',
  p_is_persistent=> 'Y',
  p_protection_level=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_item_comment=> '');
 
null;
 
end;
/

prompt  ...application level computations
--
 
begin
 
--application/shared_components/logic/application_computations/company
wwv_flow_api.create_flow_computation (
  p_id => 1051409380937090 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_computation_sequence => 10,
  p_computation_item => 'COMPANY',
  p_computation_point    => 'ON_NEW_INSTANCE',
  p_computation_type => 'FUNCTION_BODY',
  p_computation_processed=> 'ON_NEW_INSTANCE',
  p_computation => 'return wwv_flow.get_company_name;',
  p_compute_when=> '',
  p_compute_when_type=> '',
  p_computation_error_message=>'',
  p_computation_comment=> '',
  p_required_patch=> null + wwv_flow_api.g_id_offset);
 
 
end;
/

prompt  ...Application Tabs
--
 
begin
 
null;
 
end;
/

prompt  ...Application Parent Tabs
--
 
begin
 
null;
 
end;
/

prompt  ...Shared Lists of values
--
--application/shared_components/user_interface/lov/case_sensitive_y
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88974921613396877 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'CASE.SENSITIVE.Y',
  p_lov_query=> '.'||to_char(88974921613396877 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88975126157396877 + wwv_flow_api.g_id_offset,
  p_lov_id=>88974921613396877 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Case Sensitive',
  p_lov_return_value=>'Y',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/create_table_schemas
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 24598221099495610 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'CREATE_TABLE_SCHEMAS',
  p_lov_query=> 'declare'||chr(10)||
'  q varchar2(32767) := null;'||chr(10)||
'begin'||chr(10)||
'  q:=q||''select htf.escape_sc(c.schema) d, c.schema v '';'||chr(10)||
'  q:=q||''from   wwv_flow_company_schemas c, '';'||chr(10)||
'  q:=q||''       wwv_flow_fnd_user u '';'||chr(10)||
'  q:=q||''where  c.security_group_id = :flow_security_group_id and '';'||chr(10)||
'  q:=q||''       u.security_group_id = :flow_security_group_id and '';'||chr(10)||
'  q:=q||''       u.user_name = :flow_user and '';'||chr(10)||
'  q:=q||''       (u.ALLOW_ACCESS_TO_SCHEMAS is null or '';'||chr(10)||
'  q:=q||''        instr('''':''''||u.ALLOW_ACCESS_TO_SCHEMAS||'''':'''','''':''''||c.schema||'''':'''')>0) '';'||chr(10)||
'  if wwv_flow_global.g_xe then'||chr(10)||
'    q:=q||''  and exists (select null '';'||chr(10)||
'    q:=q||''              from sys.dba_sys_privs '';'||chr(10)||
'    q:=q||''              where privilege = ''''CREATE TABLE'''' '';'||chr(10)||
'    q:=q||''              and grantee = c.schema '';'||chr(10)||
'    q:=q||''              union all '';'||chr(10)||
'    q:=q||''              select null '';'||chr(10)||
'    q:=q||''              from sys.dba_sys_privs s, sys.dba_role_privs r '';'||chr(10)||
'    q:=q||''              where r.granted_role=s.grantee '';'||chr(10)||
'    q:=q||''              and r.grantee = c.schema '';'||chr(10)||
'    q:=q||''              and s.privilege = ''''CREATE TABLE'''') '';'||chr(10)||
'  else'||chr(10)||
'    q:=q||''  and exists (select null '';'||chr(10)||
'    q:=q||''               from sys.dba_sys_privs '';'||chr(10)||
'    q:=q||''               where privilege = ''''CREATE TABLE'''' '';'||chr(10)||
'    q:=q||''                 and grantee = c.schema)     '';'||chr(10)||
'  end if;         '||chr(10)||
'  q:=q||''  and exists (select null '';'||chr(10)||
'  q:=q||''                from sys.dba_users '';'||chr(10)||
'  q:=q||''               where username = c.schema) '';'||chr(10)||
'  q:=q||''order by 1 '';'||chr(10)||
'  '||chr(10)||
'  return q;'||chr(10)||
'end;');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/export_as_file_y
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88995410248613750 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'EXPORT.AS.FILE.Y',
  p_lov_query=> '.'||to_char(88995410248613750 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88995633282613750 + wwv_flow_api.g_id_offset,
  p_lov_id=>88995410248613750 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Export As File',
  p_lov_return_value=>'Y',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/export_file_format
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 144234407205622759 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'EXPORT.FILE_FORMAT',
  p_lov_query=> '.'||to_char(144234407205622759 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>144234724051622766 + wwv_flow_api.g_id_offset,
  p_lov_id=>144234407205622759 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>1,
  p_lov_disp_value=>'Unix',
  p_lov_return_value=>'UNIX',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>144234915927622769 + wwv_flow_api.g_id_offset,
  p_lov_id=>144234407205622759 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>2,
  p_lov_disp_value=>'DOS',
  p_lov_return_value=>'DOS',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/i18n_iana_charset
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 136450730164180959 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'I18N_IANA_CHARSET',
  p_reference_id=> 144796827445692396,
  p_lov_query=> '.'||to_char(136450730164180959 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72033708468259637 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Arabic ISO-8859-6',
  p_lov_return_value=>'iso-8859-6',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72033906595259637 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>20,
  p_lov_disp_value=>'Arabic Windows 1256',
  p_lov_return_value=>'windows-1256',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72034126232259637 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>30,
  p_lov_disp_value=>'Chinese Big5',
  p_lov_return_value=>'big5',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72034308885259637 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>40,
  p_lov_disp_value=>'Chinese GBK',
  p_lov_return_value=>'gbk',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72034535799259637 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>50,
  p_lov_disp_value=>'Cyrilic ISO-8859-5',
  p_lov_return_value=>'iso-8859-5',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72034707342259638 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>60,
  p_lov_disp_value=>'Cyrilic KOI8-R',
  p_lov_return_value=>'koi8-r',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72034920329259638 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>70,
  p_lov_disp_value=>'Cyrilic KOI8-U',
  p_lov_return_value=>'koi8-u',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72035114172259638 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>80,
  p_lov_disp_value=>'Cyrilic Windows 1251',
  p_lov_return_value=>'windows-1251',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72035322664259638 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>90,
  p_lov_disp_value=>'Eastern European ISO-8859-2',
  p_lov_return_value=>'iso-8859-2',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72035527335259639 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>100,
  p_lov_disp_value=>'Eastern European Windows 1250',
  p_lov_return_value=>'windows-1250',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72035711089259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>110,
  p_lov_disp_value=>'Greek ISO-8859-7',
  p_lov_return_value=>'iso-8859-7',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72035936725259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>120,
  p_lov_disp_value=>'Greek Windows 1253',
  p_lov_return_value=>'windows-1253',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72036132106259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>130,
  p_lov_disp_value=>'Hebrew ISO-8859-8-i',
  p_lov_return_value=>'iso-8859-8-i',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72036304618259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>140,
  p_lov_disp_value=>'Hebrew Windows 1255',
  p_lov_return_value=>'windows-1255',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72036520911259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>150,
  p_lov_disp_value=>'Japanese EUC',
  p_lov_return_value=>'euc-jp',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72036724959259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>160,
  p_lov_disp_value=>'Japanese Shift JIS',
  p_lov_return_value=>'shift_jis',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72036906830259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>170,
  p_lov_disp_value=>'Korean EUC',
  p_lov_return_value=>'euc-kr',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72037126182259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>180,
  p_lov_disp_value=>'Northern European ISO-8859-4',
  p_lov_return_value=>'iso-8859-4',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72037327712259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>190,
  p_lov_disp_value=>'Northern European Windows 1257',
  p_lov_return_value=>'windows-1257',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72037517906259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>200,
  p_lov_disp_value=>'Southern European ISO-8859-3',
  p_lov_return_value=>'iso-8859-3',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72037735488259640 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>210,
  p_lov_disp_value=>'Thai TIS-620',
  p_lov_return_value=>'tis-620',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72037916955259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>220,
  p_lov_disp_value=>'Turkish ISO-8859-9',
  p_lov_return_value=>'iso-8859-9',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72038131178259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>230,
  p_lov_disp_value=>'Turkish Windows 1254',
  p_lov_return_value=>'windows-1254',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72038329563259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>240,
  p_lov_disp_value=>'Unicode UTF-8',
  p_lov_return_value=>'utf-8',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72038508720259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>242,
  p_lov_disp_value=>'Unicode UTF-16 Big Endian',
  p_lov_return_value=>'utf-16be',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72038717907259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>244,
  p_lov_disp_value=>'Unicode UTF-16 Little Endian',
  p_lov_return_value=>'utf-16le',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72038916164259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>248,
  p_lov_disp_value=>'US-ASCII',
  p_lov_return_value=>'us-ascii',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72039120088259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>250,
  p_lov_disp_value=>'Vietnamese Windows 1258',
  p_lov_return_value=>'windows-1258',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72039311523259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>260,
  p_lov_disp_value=>'Western European ISO-8859-1',
  p_lov_return_value=>'iso-8859-1',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72039536446259641 + wwv_flow_api.g_id_offset,
  p_lov_id=>136450730164180959 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>270,
  p_lov_disp_value=>'Western European Windows 1252',
  p_lov_return_value=>'windows-1252',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/i18n_iana_db_charset
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 140992806202544090 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'I18N_IANA_DB_CHARSET',
  p_reference_id=> 144802427115692411,
  p_lov_query=> '.'||to_char(140992806202544090 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72014833271257386 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Arabic ISO-8859-6',
  p_lov_return_value=>'AR8ISO8859P6',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72015011555257386 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>20,
  p_lov_disp_value=>'Arabic Windows 1256',
  p_lov_return_value=>'AR8MSWIN1256',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72015206015257386 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>30,
  p_lov_disp_value=>'Chinese Big5',
  p_lov_return_value=>'ZHT16MSWIN950',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72015407020257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>40,
  p_lov_disp_value=>'Chinese GBK',
  p_lov_return_value=>'ZHS16GBK',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72015622162257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>50,
  p_lov_disp_value=>'Cyrilic ISO-8859-5',
  p_lov_return_value=>'CL8ISO8859P5',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72015813436257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>60,
  p_lov_disp_value=>'Cyrilic KOI8-R',
  p_lov_return_value=>'CL8KOI8R',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72016008713257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>70,
  p_lov_disp_value=>'Cyrilic KOI8-U',
  p_lov_return_value=>'CL8KOI8U',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72016209173257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>80,
  p_lov_disp_value=>'Cyrilic Windows 1251',
  p_lov_return_value=>'CL8MSWIN1251',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72016435612257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>90,
  p_lov_disp_value=>'Eastern European ISO-8859-2',
  p_lov_return_value=>'EE8ISO8859P2',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72016635859257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>100,
  p_lov_disp_value=>'Eastern European Windows 1250',
  p_lov_return_value=>'EE8MSWIN1250',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72016828370257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>110,
  p_lov_disp_value=>'Greek ISO-8859-7',
  p_lov_return_value=>'EL8ISO8859P7',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72017007280257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>120,
  p_lov_disp_value=>'Greek Windows 1253',
  p_lov_return_value=>'EL8MSWIN1253',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72017222673257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>130,
  p_lov_disp_value=>'Hebrew ISO-8859-8-i',
  p_lov_return_value=>'IW8ISO8859P8',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72017419277257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>140,
  p_lov_disp_value=>'Hebrew Windows 1255',
  p_lov_return_value=>'IW8MSWIN1255',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72017623517257387 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>150,
  p_lov_disp_value=>'Japanese EUC',
  p_lov_return_value=>'JA16EUC',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72017825769257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>160,
  p_lov_disp_value=>'Japanese Shift JIS',
  p_lov_return_value=>'JA16SJIS',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72018011944257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>170,
  p_lov_disp_value=>'Korean EUC',
  p_lov_return_value=>'KO16MSWIN949',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72018227605257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>180,
  p_lov_disp_value=>'Northern European ISO-8859-4',
  p_lov_return_value=>'NEE8ISO8859P4',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72018427339257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>190,
  p_lov_disp_value=>'Northern European Windows 1257',
  p_lov_return_value=>'BLT8MSWIN1257',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72018624011257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>200,
  p_lov_disp_value=>'Southern European ISO-8859-3',
  p_lov_return_value=>'SE8ISO8859P3',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72018820593257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>210,
  p_lov_disp_value=>'Thai TIS-620',
  p_lov_return_value=>'TH8TISASCII',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72019015846257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>220,
  p_lov_disp_value=>'Turkish ISO-8859-9',
  p_lov_return_value=>'WE8ISO8859P9',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72019231903257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>230,
  p_lov_disp_value=>'Turkish Windows 1254',
  p_lov_return_value=>'TR8MSWIN1254',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72019404339257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>240,
  p_lov_disp_value=>'Unicode UTF-8',
  p_lov_return_value=>'AL32UTF8',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72019605675257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>242,
  p_lov_disp_value=>'Unicode UTF-16 Big Endian',
  p_lov_return_value=>'AL16UTF16',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72019804822257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>244,
  p_lov_disp_value=>'Unicode UTF-16 Little Endian',
  p_lov_return_value=>'AL16UTF16LE',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72020018609257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>248,
  p_lov_disp_value=>'US-ASCII',
  p_lov_return_value=>'US7ASCII',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72020206453257388 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>250,
  p_lov_disp_value=>'Vietnamese Windows 1258',
  p_lov_return_value=>'VN8MSWIN1258',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72020420584257389 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>260,
  p_lov_disp_value=>'Western European ISO-8859-1',
  p_lov_return_value=>'WE8ISO8859P1',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>72020618916257389 + wwv_flow_api.g_id_offset,
  p_lov_id=>140992806202544090 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>270,
  p_lov_disp_value=>'Western European Windows 1252',
  p_lov_return_value=>'WE8MSWIN1252',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/include_col_names_y
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88997219729625956 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'INCLUDE.COL.NAMES.Y',
  p_lov_query=> '.'||to_char(88997219729625956 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88997406971625957 + wwv_flow_api.g_id_offset,
  p_lov_id=>88997219729625956 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Include Column Names',
  p_lov_return_value=>'Y',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/iscolumn_name_text
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 89004730212685725 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'ISCOLUMN.NAME.TEXT',
  p_lov_query=> 'select ''<span class="instructiontext">''||'||chr(10)||
'wwv_flow_lang.system_message(''F4300_INSTRUCT_TEXT'')||''</span>'' d, ''Y'' r from dual');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/list_schema_owners
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 1051587029555548 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'LIST_SCHEMA_OWNERS',
  p_lov_query=> 'select htf.escape_sc(c.schema) d, c.schema v'||chr(10)||
'from   wwv_flow_company_schemas c,'||chr(10)||
'       wwv_flow_fnd_user u'||chr(10)||
'where  c.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.user_name = :flow_user and'||chr(10)||
'       (u.ALLOW_ACCESS_TO_SCHEMAS is null or'||chr(10)||
'        instr('':''||u.ALLOW_ACCESS_TO_SCHEMAS||'':'','':''||c.schema||'':'')>0)'||chr(10)||
'order by 1'||chr(10)||
'');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/load_option
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88972821135387296 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'LOAD.OPTION',
  p_lov_query=> '.'||to_char(88972821135387296 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88973014092387296 + wwv_flow_api.g_id_offset,
  p_lov_id=>88972821135387296 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Upload file (comma separated or tab delimited)',
  p_lov_return_value=>'UPLOAD',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88973205642387297 + wwv_flow_api.g_id_offset,
  p_lov_id=>88972821135387296 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>20,
  p_lov_disp_value=>'Copy and paste',
  p_lov_return_value=>'PASTE',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/load_data_types
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 21879719196547372 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'LOAD_DATA_TYPES',
  p_lov_query=> '.'||to_char(21879719196547372 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>21880028482547385 + wwv_flow_api.g_id_offset,
  p_lov_id=>21879719196547372 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>1,
  p_lov_disp_value=>'NUMBER',
  p_lov_return_value=>'NUMBER',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>21880212350547387 + wwv_flow_api.g_id_offset,
  p_lov_id=>21879719196547372 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>2,
  p_lov_disp_value=>'VARCHAR2',
  p_lov_return_value=>'VARCHAR2',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>21880430806547387 + wwv_flow_api.g_id_offset,
  p_lov_id=>21879719196547372 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>3,
  p_lov_disp_value=>'DATE',
  p_lov_return_value=>'DATE',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>21880617199547387 + wwv_flow_api.g_id_offset,
  p_lov_id=>21879719196547372 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>4,
  p_lov_disp_value=>'CLOB',
  p_lov_return_value=>'CLOB',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>21880826202547387 + wwv_flow_api.g_id_offset,
  p_lov_id=>21879719196547372 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>5,
  p_lov_disp_value=>'BINARY_FLOAT',
  p_lov_return_value=>'BINARY_FLOAT',
  p_lov_disp_cond_type=>'FUNCTION_BODY',
  p_lov_disp_cond=> 'return wwv_flow_utilities.db_version_is_at_least(''10.1'');',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>21881016378547388 + wwv_flow_api.g_id_offset,
  p_lov_id=>21879719196547372 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>6,
  p_lov_disp_value=>'BINARY_DOUBLE',
  p_lov_return_value=>'BINARY_DOUBLE',
  p_lov_disp_cond_type=>'FUNCTION_BODY',
  p_lov_disp_cond=> 'return wwv_flow_utilities.db_version_is_at_least(''10.1'');',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/p16_tables
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 163768314539282355 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'P16_TABLES',
  p_lov_query=> 'select table_name a, table_name b'||chr(10)||
'from sys.dba_tables'||chr(10)||
'where owner=:F4300_P14_TARGET_SCHEMA'||chr(10)||
'and table_name not like ''BIN$%'''||chr(10)||
'order by 1');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/p2_load
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 238007432584970983 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'P2_LOAD',
  p_lov_query=> '.'||to_char(238007432584970983 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>238007719820970990 + wwv_flow_api.g_id_offset,
  p_lov_id=>238007432584970983 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>1,
  p_lov_disp_value=>'My Import',
  p_lov_return_value=>'MY',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>238007936447970996 + wwv_flow_api.g_id_offset,
  p_lov_id=>238007432584970983 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>2,
  p_lov_disp_value=>'All Import',
  p_lov_return_value=>'ALL',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/pk_types
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 30284028271088477 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'PK_TYPES',
  p_reference_id=> 20561306137429854,
  p_lov_query=> '.'||to_char(30284028271088477 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>52679025523988701 + wwv_flow_api.g_id_offset,
  p_lov_id=>30284028271088477 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>2,
  p_lov_disp_value=>'Generated from a new sequence',
  p_lov_return_value=>'NEW_SEQUENCE',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>52679235317988701 + wwv_flow_api.g_id_offset,
  p_lov_id=>30284028271088477 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>3,
  p_lov_disp_value=>'Generated from an existing sequence',
  p_lov_return_value=>'EXISTING_SEQUENCE',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>52679416646988702 + wwv_flow_api.g_id_offset,
  p_lov_id=>30284028271088477 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>5,
  p_lov_disp_value=>'Not generated',
  p_lov_return_value=>'NOT_GENERATED',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/preserve_case_y
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88982915435499165 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'PRESERVE.CASE.Y',
  p_lov_query=> '.'||to_char(88982915435499165 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88983134912499165 + wwv_flow_api.g_id_offset,
  p_lov_id=>88982915435499165 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Preserve Case',
  p_lov_return_value=>'Y',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/restrict_load_files
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88970107105345348 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'RESTRICT.LOAD.FILES',
  p_lov_query=> '.'||to_char(88970107105345348 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88970306150345349 + wwv_flow_api.g_id_offset,
  p_lov_id=>88970107105345348 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'My Import Files',
  p_lov_return_value=>'MY',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88970513459345349 + wwv_flow_api.g_id_offset,
  p_lov_id=>88970107105345348 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>20,
  p_lov_disp_value=>'All Import Files',
  p_lov_return_value=>'ALL',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/table_option
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88973833256390726 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'TABLE.OPTION',
  p_lov_query=> '.'||to_char(88973833256390726 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88974006544390727 + wwv_flow_api.g_id_offset,
  p_lov_id=>88973833256390726 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Existing table',
  p_lov_return_value=>'EXIST',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88974225009390727 + wwv_flow_api.g_id_offset,
  p_lov_id=>88973833256390726 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>20,
  p_lov_disp_value=>'New table',
  p_lov_return_value=>'NEW',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/use_existing_col
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88984827687512138 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'USE.EXISTING.COL',
  p_lov_query=> '.'||to_char(88984827687512138 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88985006876512138 + wwv_flow_api.g_id_offset,
  p_lov_id=>88984827687512138 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'Use an existing column',
  p_lov_return_value=>'EXISTING_KEY',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88985226447512139 + wwv_flow_api.g_id_offset,
  p_lov_id=>88984827687512138 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>20,
  p_lov_disp_value=>'Create new column',
  p_lov_return_value=>'NEW_KEY',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/yes_no_returns_y_or_n
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 88981829849493837 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'YES.NO.RETURNS_Y_OR_N',
  p_lov_query=> '.'||to_char(88981829849493837 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88982013574493838 + wwv_flow_api.g_id_offset,
  p_lov_id=>88981829849493837 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>10,
  p_lov_disp_value=>'No',
  p_lov_return_value=>'N',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>88982206634493838 + wwv_flow_api.g_id_offset,
  p_lov_id=>88981829849493837 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>20,
  p_lov_disp_value=>'Yes',
  p_lov_return_value=>'Y',
  p_lov_data_comment=> '');
 
null;
 
end;
/

--application/shared_components/user_interface/lov/yes_no
 
begin
 
wwv_flow_api.create_list_of_values (
  p_id       => 1051587035763132 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_lov_name => 'YES_NO',
  p_lov_query=> '.'||to_char(1051587035763132 + wwv_flow_api.g_id_offset)||'.');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>1051587038763161 + wwv_flow_api.g_id_offset,
  p_lov_id=>1051587035763132 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>1,
  p_lov_disp_value=>'Yes',
  p_lov_return_value=>'Y',
  p_lov_data_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_static_lov_data (
  p_id=>1051587040763161 + wwv_flow_api.g_id_offset,
  p_lov_id=>1051587035763132 + wwv_flow_api.g_id_offset,
  p_lov_disp_sequence=>2,
  p_lov_disp_value=>'No',
  p_lov_return_value=>'N',
  p_lov_data_comment=> '');
 
null;
 
end;
/

prompt  ...Application Trees
--
--application/pages/page_groups
prompt  ...page groups
--
 
begin
 
wwv_flow_api.create_page_group(
  p_id=>218001909973670188 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_group_name=>'Home / Common / About / Nav',
  p_group_desc=>'');
 
wwv_flow_api.create_page_group(
  p_id=>216780929601417380 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_group_name=>'Import Spreadsheet',
  p_group_desc=>'Allow for a spreadsheet to be uploaded and then converted into a database table.');
 
wwv_flow_api.create_page_group(
  p_id=>216783110339421284 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_group_name=>'Plain Text Upload',
  p_group_desc=>'');
 
wwv_flow_api.create_page_group(
  p_id=>216782707569420532 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_group_name=>'XML Upload',
  p_group_desc=>'');
 
null;
 
end;
/

--application/comments
prompt  ...comments: requires application express 2.2 or higher
--
 
--application/pages/page_00000
prompt  ...PAGE 0: Page Zero
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h := null;
ph := null;
wwv_flow_api.create_page(
  p_id     => 0,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Page Zero',
  p_step_title=> '',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 218001909973670188+ wwv_flow_api.g_id_offset,
  p_help_text => '',
  p_html_page_header => '',
  p_step_template => 8556812635064095+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806141229',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'1452315428006354';

wwv_flow_api.create_page_plug (
  p_id=> 2508018903861157 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 0,
  p_plug_name=> 'Application Tabs',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_07',
  p_plug_source=> s,
  p_plug_source_type=> 2503719680842491 + wwv_flow_api.g_id_offset,
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => 'NEVER',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
null;
 
end;
/

 
begin
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 0
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00001
prompt  ...PAGE 1: Data Load/Unload
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt_imprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 1,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Data Load/Unload',
  p_step_title=> 'Data Load/Unload',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 218001909973670188+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => '',
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125927',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>1,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'2202106852499122';

wwv_flow_api.create_page_plug (
  p_id=> 3260933184360632 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 1,
  p_plug_name=> 'Data Workshop',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 3262816000365056 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 1,
  p_plug_name=> 'menu',
  p_region_name=>'',
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
null;
 
end;
/

 
begin
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 1
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00002
prompt  ...PAGE 2: Spreadsheet Load Details
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 2,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Spreadsheet Load Details',
  p_step_title=> 'Spreadsheet Load Details',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 8556812635064095+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806154900',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>2,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>This page displays information about the Spreadsheet import. If any rows failed while importing, this page displays an error message.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 237959612112877352 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 2,
  p_plug_name=> 'Spreadsheet Load',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 50,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_05',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_no_data_found=>'No failed rows found.',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'select ''<span class="htmldbError">'' || errm || ''</span>'' Error,'||chr(10)||
'          data Data'||chr(10)||
'   from wwv_flow_data_load_bad_log'||chr(10)||
'  where load_id = :P2_LOAD_ID';

wwv_flow_api.create_report_region (
  p_id=> 237960028537877353 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 2,
  p_name=> 'Failed Rows',
  p_region_name=>'',
  p_template=> 102787020102073196+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 30,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_plug_caching=> 'NOT_CACHED',
  p_customized=> '0',
  p_translate_title=> 'Y',
  p_query_row_template=> 11634930157712121+ wwv_flow_api.g_id_offset,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '15',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> '(null)',
  p_query_break_cols=> '0',
  p_query_no_data_found=> 'No failed rows found.',
  p_query_num_rows_type=> 'ROW_RANGES',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_csv_output=> 'N',
  p_query_asc_image=> 'blue_arrow_down.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'blue_arrow_up.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237960415205877355 + wwv_flow_api.g_id_offset,
  p_region_id=> 237960028537877353 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'ERROR',
  p_column_display_sequence=> 1,
  p_column_heading=> 'Error',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237960515772877355 + wwv_flow_api.g_id_offset,
  p_region_id=> 237960028537877353 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'DATA',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Data',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 237960636055877355 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 2,
  p_plug_name=> 'button bar',
  p_region_name=>'',
  p_plug_template=> 4970025974596251+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'N',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'Select CREATED_ON Load_Date, CREATED_BY Loaded_By, DATA_SCHEMA Schema2, DATA_TABLE Table2, SUCCESS_ROWS Rows_Loaded, FAILED_ROWS Rows_Failed from wwv_flow_data_load_unload where id=:P2_LOAD_ID';

wwv_flow_api.create_report_region (
  p_id=> 237961427497877359 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 2,
  p_name=> 'Overview',
  p_region_name=>'',
  p_template=> 102787020102073196+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 25,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_plug_caching=> 'NOT_CACHED',
  p_customized=> '0',
  p_query_row_template=> 3,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '15',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> ' - ',
  p_query_break_cols=> '0',
  p_query_no_data_found=> 'No data found.',
  p_query_num_rows_type=> '0',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_csv_output=> 'N',
  p_query_asc_image=> 'blue_arrow_down.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'blue_arrow_up.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_plug_query_strip_html=> 'Y',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237962025985877362 + wwv_flow_api.g_id_offset,
  p_region_id=> 237961427497877359 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'LOAD_DATE',
  p_column_display_sequence=> 1,
  p_column_heading=> 'Import Date',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237962109045877362 + wwv_flow_api.g_id_offset,
  p_region_id=> 237961427497877359 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'LOADED_BY',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Imported By',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237962229877877362 + wwv_flow_api.g_id_offset,
  p_region_id=> 237961427497877359 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 3,
  p_form_element_id=> null,
  p_column_alias=> 'SCHEMA2',
  p_column_display_sequence=> 3,
  p_column_heading=> 'Schema',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237962315476877362 + wwv_flow_api.g_id_offset,
  p_region_id=> 237961427497877359 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 4,
  p_form_element_id=> null,
  p_column_alias=> 'TABLE2',
  p_column_display_sequence=> 4,
  p_column_heading=> 'Table',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237961809268877362 + wwv_flow_api.g_id_offset,
  p_region_id=> 237961427497877359 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 5,
  p_form_element_id=> null,
  p_column_alias=> 'ROWS_LOADED',
  p_column_display_sequence=> 5,
  p_column_heading=> 'Rows Imported',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 237961928384877362 + wwv_flow_api.g_id_offset,
  p_region_id=> 237961427497877359 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 6,
  p_form_element_id=> null,
  p_column_alias=> 'ROWS_FAILED',
  p_column_display_sequence=> 6,
  p_column_heading=> 'Rows Failed',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 237968126342893495 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 2,
  p_plug_name=> 'menu',
  p_region_name=>'',
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 237962422440877363 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 2,
  p_button_sequence=> 10,
  p_button_plug_id => 237960636055877355+wwv_flow_api.g_id_offset,
  p_button_name    => 'BACK',
  p_button_image_alt=> 'Back to Repository',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>237963713544877392 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 2,
  p_branch_action=> 'f?p=&FLOW_ID.:11:&SESSION.::&DEBUG.:::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_sequence=> 30,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 14-JUL-2004 18:04 by CBCHO');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>237962813172877373 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 2,
  p_name=>'P2_LOAD_ID',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_use_cache_before_default=> 'YES',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 2
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00004
prompt  ...PAGE 4: Unload
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 4,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload',
  p_step_title=> 'Unload',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 218001909973670188+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 8556812635064095+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>4,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 3271333670395350 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 4,
  p_plug_name=> 'Data Unload',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 2,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 76637294131660469 + wwv_flow_api.g_id_offset,
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_customized_name=>'Data unloading icons',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Extract data from database schemas online to files on your computer.');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 3277229684406895 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 4,
  p_plug_name=> 'menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
null;
 
end;
/

 
begin
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 4
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00007
prompt  ...PAGE 7: Text Data Load Details
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 7,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Text Data Load Details',
  p_step_title=> 'Text Data Load Details',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 8556812635064095+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>7,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 4964608215581257 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 7,
  p_plug_name=> 'button bar',
  p_region_name=>'',
  p_plug_template=> 4970025974596251+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'N',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'select ''<span class="htmldbError">'' || errm || ''</span>'' Error,'||chr(10)||
'          data Data'||chr(10)||
'   from wwv_flow_data_load_bad_log'||chr(10)||
'  where load_id = :F4300_P7_LOAD_ID';

wwv_flow_api.create_report_region (
  p_id=> 56163744822214133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 7,
  p_name=> 'Failed Rows',
  p_region_name=>'',
  p_template=> 102787020102073196+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 30,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_plug_caching=> 'NOT_CACHED',
  p_customized=> '0',
  p_translate_title=> 'Y',
  p_query_row_template=> 25585420365352950+ wwv_flow_api.g_id_offset,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '15',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> '(null)',
  p_query_break_cols=> '0',
  p_query_no_data_found=> 'No failed rows found.',
  p_query_num_rows_type=> 'ROW_RANGES',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_csv_output=> 'N',
  p_query_asc_image=> 'blue_arrow_down.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'blue_arrow_up.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_plug_query_strip_html=> 'Y',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 27447714417688005 + wwv_flow_api.g_id_offset,
  p_region_id=> 56163744822214133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'ERROR',
  p_column_display_sequence=> 1,
  p_column_heading=> 'Error',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 27447817857688005 + wwv_flow_api.g_id_offset,
  p_region_id=> 56163744822214133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'DATA',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Data',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 76450320959547681 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 7,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'Select CREATED_ON Load_Date, CREATED_BY Loaded_By, DATA_SCHEMA Schema2, DATA_TABLE Table2, SUCCESS_ROWS Rows_Loaded, FAILED_ROWS Rows_Failed from wwv_flow_data_load_unload where id=:F4300_P7_LOAD_ID';

wwv_flow_api.create_report_region (
  p_id=> 235791912827096172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 7,
  p_name=> 'Overview',
  p_region_name=>'',
  p_template=> 102787020102073196+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 25,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_plug_caching=> 'NOT_CACHED',
  p_header=> '<p>This page displays information about text data file import. If any rows failed while importing, this page displays an error message.</p>',
  p_customized=> '0',
  p_translate_title=> 'Y',
  p_query_row_template=> 3,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '15',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> ' - ',
  p_query_break_cols=> '0',
  p_query_no_data_found=> 'No data found.',
  p_query_num_rows_type=> '0',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_csv_output=> 'N',
  p_sort_null=> 'F',
  p_query_asc_image=> 'blue_arrow_down.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'blue_arrow_up.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_plug_query_strip_html=> 'Y',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235792524842096188 + wwv_flow_api.g_id_offset,
  p_region_id=> 235791912827096172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'LOAD_DATE',
  p_column_display_sequence=> 1,
  p_column_heading=> 'Import Date',
  p_column_format=> '&DATE_TIME_FORMAT.',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235792613634096188 + wwv_flow_api.g_id_offset,
  p_region_id=> 235791912827096172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'LOADED_BY',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Imported By',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235792712601096188 + wwv_flow_api.g_id_offset,
  p_region_id=> 235791912827096172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 3,
  p_form_element_id=> null,
  p_column_alias=> 'SCHEMA2',
  p_column_display_sequence=> 3,
  p_column_heading=> 'Schema',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235792829788096188 + wwv_flow_api.g_id_offset,
  p_region_id=> 235791912827096172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 4,
  p_form_element_id=> null,
  p_column_alias=> 'TABLE2',
  p_column_display_sequence=> 4,
  p_column_heading=> 'Table',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235792912121096189 + wwv_flow_api.g_id_offset,
  p_region_id=> 235791912827096172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 5,
  p_form_element_id=> null,
  p_column_alias=> 'ROWS_LOADED',
  p_column_display_sequence=> 5,
  p_column_heading=> 'Rows Imported',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235793033062096189 + wwv_flow_api.g_id_offset,
  p_region_id=> 235791912827096172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 6,
  p_form_element_id=> null,
  p_column_alias=> 'ROWS_FAILED',
  p_column_display_sequence=> 6,
  p_column_heading=> 'Rows Failed',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 193156008941653672 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 7,
  p_button_sequence=> 10,
  p_button_plug_id => 4964608215581257+wwv_flow_api.g_id_offset,
  p_button_name    => 'BACK',
  p_button_image_alt=> 'Back to Repository',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>236049605405283271 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 7,
  p_branch_action=> 'f?p=&FLOW_ID.:8:&SESSION.::&DEBUG.:::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_sequence=> 30,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 14-JUL-2004 18:04 by CBCHO');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>28223418052115831 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 7,
  p_name=>'F4300_P7_LOAD_ID',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_use_cache_before_default=> 'YES',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>236032314315229059 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 7,
  p_name=>'P7_PREV_PAGE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 4964608215581257+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> null,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'LEFT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 7
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00008
prompt  ...PAGE 8: Text Data Load Repository
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_imprt_rep.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 8,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Text Data Load Repository',
  p_step_title=> 'Text Data Load Repository',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 8556812635064095+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806150744',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>8,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 4972417134602737 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 8,
  p_plug_name=> 'Button Bar',
  p_region_name=>'',
  p_plug_template=> 109257010113732748+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 5,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'N',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7888316605574456 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 8,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'declare'||chr(10)||
'    q           varchar2(4000);    '||chr(10)||
'begin    '||chr(10)||
'  q:= q || ''select '';'||chr(10)||
'  q:= q || ''''''<label for="f01_''''||rownum||''''" class="hideMe508">Select Import</label><input id="f01_''''||rownum||''''" type="checkbox" name="f01" value="''''||dat.id||''''">'''' cb,'';'||chr(10)||
'  q:= q || ''htf.anchor(''''f?p=&APP_ID.:2:''||:flow_session||''::::P2_LOAD_ID:'''' || dat.id, '';'||chr(10)||
'  q:= q || '' htf.img (''''#IMAGE_PREFIX#24find.gif'''', NULL, ';

s:=s||'NULL, NULL,''''border="0" alt="''||wwv_flow_lang.system_message(''DETAILS_FOR_ALT_TAG'')||''" height="24" width="24"'''')) "Details",'';'||chr(10)||
'  q:= q || '' dat.created_by "Created By", '';'||chr(10)||
'  q:= q || '' dat.created_on  "Created on", '';'||chr(10)||
'  q:= q || '' decode (data_type, ''''EXCEL IMPORT'''', wwv_flow_lang.system_message(''''F4300.SPREADSHEET_IMPORT'''')) "Type", '';'||chr(10)||
'  q:= q || ''data_Schema "Schema", '';'||chr(10)||
''||chr(10)||
'q := q||''data_table "T';

s:=s||'able", '';'||chr(10)||
''||chr(10)||
'  q:= q || '' success_rows "Succeeded",'';'||chr(10)||
'  q:= q || '' decode(failed_rows,0,''''0'''',htf.anchor(''''f?p=&APP_ID.:2:''||:flow_session||''::::P2_LOAD_ID:'''' || dat.id,'';'||chr(10)||
'  q:= q || '' failed_rows))     "Failed"'';'||chr(10)||
'  q:= q || '' from wwv_flow_data_load_unload dat, sys.dba_objects o '';  '||chr(10)||
'  q:= q || '' where o.owner = dat.data_schema '';'||chr(10)||
'  q:= q || '' and o.object_name = dat.data_table '';'||chr(10)||
'  q:= q || '' and ';

s:=s||'o.object_type = ''''TABLE'''' '';'||chr(10)||
'  q:= q || '' and dat.security_group_id =:FLOW_SECURITY_GROUP_ID '';'||chr(10)||
'  q:= q || '' and data_type = ''''EXCEL IMPORT'''''';'||chr(10)||
''||chr(10)||
'  if (:F4300_P8_RESTRICT_BY = ''MY'' or :F4300_P8_RESTRICT_BY is NULL)  then'||chr(10)||
'      q:= q || '' and dat.created_by = :FLOW_USER '';'||chr(10)||
'  end if;  '||chr(10)||
'return q;'||chr(10)||
'end;';

wwv_flow_api.create_report_region (
  p_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 8,
  p_name=> 'Spreadsheet Loads',
  p_region_name=>'',
  p_template=> 102787020102073196+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 50,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'FUNCTION_RETURNING_SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_display_condition_type=> 'NEVER',
  p_plug_caching=> 'NOT_CACHED',
  p_customized=> '0',
  p_translate_title=> 'Y',
  p_query_row_template=> 25585420365352950+ wwv_flow_api.g_id_offset,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '15',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> ' - ',
  p_query_break_cols=> '0',
  p_query_no_data_found=> 'No data found.',
  p_query_num_rows_type=> 'ROW_RANGES',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_csv_output=> 'N',
  p_query_asc_image=> 'arrow_down_gray_dark.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'arrow_up_gray_dark.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_plug_query_strip_html=> 'Y',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25590722378367530 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'CB',
  p_column_display_sequence=> 1,
  p_column_heading=> '&nbsp;',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'Y',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25590834716367530 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'Details',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Details',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25590931374367530 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 3,
  p_form_element_id=> null,
  p_column_alias=> 'Created By',
  p_column_display_sequence=> 3,
  p_column_heading=> 'Imported By',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25591033864367530 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 4,
  p_form_element_id=> null,
  p_column_alias=> 'Created on',
  p_column_display_sequence=> 4,
  p_column_heading=> 'Imported On',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>1,
  p_default_sort_dir=>'desc',
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25591126463367531 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 5,
  p_form_element_id=> null,
  p_column_alias=> 'Type',
  p_column_display_sequence=> 5,
  p_column_heading=> 'Type',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25591214862367531 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 6,
  p_form_element_id=> null,
  p_column_alias=> 'Schema',
  p_column_display_sequence=> 6,
  p_column_heading=> 'Schema',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25591305288367531 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 7,
  p_form_element_id=> null,
  p_column_alias=> 'Table',
  p_column_display_sequence=> 7,
  p_column_heading=> 'Table',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25591406852367531 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 8,
  p_form_element_id=> null,
  p_column_alias=> 'Succeeded',
  p_column_display_sequence=> 8,
  p_column_heading=> 'Succeeded',
  p_column_alignment=>'RIGHT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 25591526464367531 + wwv_flow_api.g_id_offset,
  p_region_id=> 25590521424367526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 9,
  p_form_element_id=> null,
  p_column_alias=> 'Failed',
  p_column_display_sequence=> 9,
  p_column_heading=> 'Failed',
  p_column_alignment=>'RIGHT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>This page displays the status of loaded Text data.</p> '||chr(10)||
'<p>To access the loaded file, select the file name.</p> '||chr(10)||
'<p>To remove a status entry, select it and click <b>Delete Checked</b>.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 221776726022557729 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 8,
  p_plug_name=> 'Repository',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 60,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'3648913903408259';

wwv_flow_api.create_page_plug (
  p_id=> 221792821277688745 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 8,
  p_plug_name=> 'Tasks',
  p_region_name=>'',
  p_plug_template=> 4528817837362977+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 70,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 4700318156244396 + wwv_flow_api.g_id_offset,
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'declare'||chr(10)||
'    q      varchar2(4000);'||chr(10)||
'begin'||chr(10)||
'  q := ''select '';'||chr(10)||
'  q:= q || ''''''<label for="f01_''''||rownum||''''" title="Select File"><input type="checkbox" id="f01_''''||rownum||''''" name="f01" value="''''||f.id||''''" /></label>'''' cb,'';'||chr(10)||
'  q:= q || ''htf.anchor(''''f?p=&APP_ID.:7:''||:flow_session||''::::F4300_P7_LOAD_ID:'''' || dat.id, '';'||chr(10)||
'  q:= q || '' htf.img (''''#IMAGE_PREFIX#24find.gif'''', NULL, NULL, NULL,''''border="0';

s:=s||'" alt="''||wwv_flow_lang.system_message(''F4500.FIND'')||''" height="24" width="24"'''')) "Details",'';'||chr(10)||
'  q:= q || '' htf.anchor (''''wwv_flow_file_mgr.get_file?p_id='''' || to_char(f.id), f.filename) "File", '';'||chr(10)||
'  q:= q || '' dat.created_by "Created By", '';'||chr(10)||
'  q:= q || '' dat.created_on  "Created on", '';'||chr(10)||
'  q:= q || '' decode(data_type,''''ASCII IMPORT'''',wwv_flow_lang.system_message(''''F4300_TEXT_IMPORT'''')) "Type", ''';

s:=s||';'||chr(10)||
'  q:= q || ''data_Schema "Schema", '';'||chr(10)||
'  q:= q || ''data_table "Table", '';'||chr(10)||
'  q:= q || '' nvl(dbms_lob.getlength (f.blob_content),0) "Bytes",'';'||chr(10)||
'  q:= q || '' success_rows "Succeeded",'';  '||chr(10)||
'  q:= q || '' decode(failed_rows,0,''''0'''',htf.anchor(''''f?p=&APP_ID.:7:''||:flow_session||''::::F4300_P7_LOAD_ID:'''' || dat.id,'';'||chr(10)||
'  q:= q || '' failed_rows))     "Failed"'';'||chr(10)||
'  q:= q || '' from wwv_flow_files f, wwv_flow_data_';

s:=s||'load_unload dat '';'||chr(10)||
'  q:= q || '' where f.id=dat.data_id'' ;'||chr(10)||
'  q:= q || '' and dat.security_group_id =:FLOW_SECURITY_GROUP_ID '';'||chr(10)||
''||chr(10)||
'  if (:F4300_P8_RESTRICT_BY = ''MY'' or :F4300_P8_RESTRICT_BY is NULL)  then'||chr(10)||
'      q:= q || '' and dat.created_by = :FLOW_USER '';'||chr(10)||
'  end if;  '||chr(10)||
'return q;'||chr(10)||
'end;';

wwv_flow_api.create_report_region (
  p_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 8,
  p_name=> 'Repository',
  p_region_name=>'',
  p_template=> 102787020102073196+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 40,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'FUNCTION_RETURNING_SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_plug_caching=> 'NOT_CACHED',
  p_customized=> '0',
  p_translate_title=> 'Y',
  p_query_row_template=> 25585420365352950+ wwv_flow_api.g_id_offset,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '15',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> ' - ',
  p_query_break_cols=> '0',
  p_query_no_data_found=> 'No files found',
  p_query_num_rows_type=> 'ROW_RANGES',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_csv_output=> 'N',
  p_query_asc_image=> 'arrow_down_gray_dark.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'arrow_up_gray_dark.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_plug_query_strip_html=> 'Y',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236012620683174145 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'CB',
  p_column_display_sequence=> 1,
  p_column_heading=> '&nbsp;',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236012713100174145 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'Details',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Details',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236012807402174145 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 3,
  p_form_element_id=> null,
  p_column_alias=> 'File',
  p_column_display_sequence=> 3,
  p_column_heading=> 'File',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236012935782174145 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 4,
  p_form_element_id=> null,
  p_column_alias=> 'Created By',
  p_column_display_sequence=> 4,
  p_column_heading=> 'Imported By',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236013015147174145 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 5,
  p_form_element_id=> null,
  p_column_alias=> 'Created on',
  p_column_display_sequence=> 5,
  p_column_heading=> 'Imported On',
  p_column_format=> 'SINCE',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>1,
  p_default_sort_dir=>'desc',
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236013136143174147 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 6,
  p_form_element_id=> null,
  p_column_alias=> 'Type',
  p_column_display_sequence=> 6,
  p_column_heading=> 'Type',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236013209189174147 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 7,
  p_form_element_id=> null,
  p_column_alias=> 'Schema',
  p_column_display_sequence=> 7,
  p_column_heading=> 'Schema',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236013328777174148 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 8,
  p_form_element_id=> null,
  p_column_alias=> 'Table',
  p_column_display_sequence=> 8,
  p_column_heading=> 'Table',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'ESCAPE_SC',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236013431067174148 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 9,
  p_form_element_id=> null,
  p_column_alias=> 'Bytes',
  p_column_display_sequence=> 9,
  p_column_heading=> 'Bytes',
  p_column_format=> '999G999G999G999G990',
  p_column_alignment=>'RIGHT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236013506321174148 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 10,
  p_form_element_id=> null,
  p_column_alias=> 'Succeeded',
  p_column_display_sequence=> 10,
  p_column_heading=> 'Succeeded',
  p_column_alignment=>'RIGHT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 236013617559174148 + wwv_flow_api.g_id_offset,
  p_region_id=> 236012020455174133 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 11,
  p_form_element_id=> null,
  p_column_alias=> 'Failed',
  p_column_display_sequence=> 11,
  p_column_heading=> 'Failed',
  p_column_alignment=>'RIGHT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 131539013495843215 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 8,
  p_button_sequence=> 30,
  p_button_plug_id => 4972417134602737+wwv_flow_api.g_id_offset,
  p_button_name    => 'Delete',
  p_button_image_alt=> 'Delete Checked',
  p_button_position=> 'REGION_TEMPLATE_DELETE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_condition=> 'select 1'||chr(10)||
'from wwv_flow_files f, wwv_flow_data_load_unload dat'||chr(10)||
'where f.id=dat.data_id'||chr(10)||
'and dat.security_group_id =:FLOW_SECURITY_GROUP_ID',
  p_button_condition_type=> 'EXISTS',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>131539623424843299 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 8,
  p_branch_action=> '8',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>52855893196644535 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 8,
  p_name=>'F4300_P8_GO',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 4972417134602737+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default => 'GO',
  p_prompt=>'Go',
  p_source=>'GO',
  p_source_type=> 'STATIC',
  p_display_as=> 'BUTTON',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'LEFT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'N',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Specify to show your files or all files';

wwv_flow_api.create_page_item(
  p_id=>52872798442700180 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 8,
  p_name=>'F4300_P8_RESTRICT_BY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 4972417134602737+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Show',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'RESTRICT.LOAD.FILES',
  p_lov => '.'||to_char(88970107105345348 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 347635414377293549+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 166185024947967398 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 8,
  p_validation_name => 'SelectAtLeastOne',
  p_validation_sequence=> 10,
  p_validation => 'wwv_flow.g_f01.count > 0',
  p_validation_type => 'PLSQL_EXPRESSION',
  p_error_message => 'Must select at least one file to delete.',
  p_when_button_pressed=> 131539013495843215 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'reset_pagination';

wwv_flow_api.create_page_process(
  p_id     => 52875223808034943 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 8,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'RESET_PAGINATION',
  p_process_name=> 'rest pagination',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_when=>'GO',
  p_process_when_type=>'REQUEST_EQUALS_CONDITION',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'    delete from wwv_flow_file_objects$'||chr(10)||
'     where id = wwv_flow.g_f01(i)'||chr(10)||
'     and security_group_id = :flow_security_group_id;'||chr(10)||
''||chr(10)||
'    delete from wwv_flow_data_load_unload'||chr(10)||
'    where data_id = wwv_flow.g_f01(i)'||chr(10)||
'    and security_group_id = :flow_security_group_id;'||chr(10)||
'end loop;';

wwv_flow_api.create_page_process(
  p_id     => 131859131562967334 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 8,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'delete file',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error deleting file(s).',
  p_process_when_button_id=>131539013495843215 + wwv_flow_api.g_id_offset,
  p_process_when=>'wwv_flow.g_f01.count > 0',
  p_process_when_type=>'PLSQL_EXPRESSION',
  p_process_success_message=> 'File(s) deleted.',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 8
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00009
prompt  ...PAGE 9: Load
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_imprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 9,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load',
  p_step_title=> 'Load',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 218001909973670188+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 8556812635064095+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125928',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>9,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7732329313478417 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 9,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 52881420050512280 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 9,
  p_plug_name=> 'Data Load',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 75759075581086176 + wwv_flow_api.g_id_offset,
  p_translate_title=> 'Y',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_customized_name=>'Data Loading Icons',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Load data from your computer from various file formats into your online database.');
end;
/
 
begin
 
null;
 
end;
/

 
begin
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 9
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00011
prompt  ...PAGE 11: Spreadsheet Repository
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 11,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Spreadsheet Repository',
  p_step_title=> 'Spreadsheet Repository',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 8556812635064095+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806175351',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>11,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'3648913903408259';

wwv_flow_api.create_page_plug (
  p_id=> 4706423744274342 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 11,
  p_plug_name=> 'Tasks',
  p_region_name=>'',
  p_plug_template=> 4528817837362977+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 4700318156244396 + wwv_flow_api.g_id_offset,
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 4977030771616149 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 11,
  p_plug_name=> 'button bar',
  p_region_name=>'',
  p_plug_template=> 109257010113732748+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 5,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'N',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 10441815965109998 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 11,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>This page displays the status of imported Spreadsheet data.</p> '||chr(10)||
'<p>To remove a status entry, select it and click <b>Delete Checked</b>.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 115756827087860075 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 11,
  p_plug_name=> 'Spreadsheet Repository',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'declare'||chr(10)||
'    q           varchar2(4000);    '||chr(10)||
'begin    '||chr(10)||
'  q:= q || ''select '';'||chr(10)||
'  q:= q || ''''''<label for="f01_''''||rownum||''''" class="hideMe508">Select Import</label><input id="f01_''''||rownum||''''" type="checkbox" name="f01" value="''''||dat.id||''''">'''' cb,'';'||chr(10)||
'  q:= q || ''htf.anchor(''''f?p=&APP_ID.:2:''||:flow_session||''::::P2_LOAD_ID:'''' || dat.id, '';'||chr(10)||
'  q:= q || '' htf.img (''''#IMAGE_PREFIX#24find.gif'''', NULL, ';

s:=s||'NULL, NULL,''''border="0" alt="''||wwv_flow_lang.system_message(''DETAILS_FOR_ALT_TAG'')||''" title="''||wwv_flow_lang.system_message(''DETAILS_FOR_ALT_TAG'')||''" height="24" width="24"'''')) "Details",'';'||chr(10)||
'  q:= q || '' dat.created_by "Created By", '';'||chr(10)||
'  q:= q || '' dat.created_on  "Created on", '';'||chr(10)||
'  q:= q || '' decode (data_type, ''''EXCEL IMPORT'''', wwv_flow_lang.system_message(''''F4300.SPREADSHEET_IMPORT'''')) "Type';

s:=s||'", '';'||chr(10)||
'  q:= q || ''data_Schema "Schema", '';'||chr(10)||
''||chr(10)||
''||chr(10)||
'  q:= q || ''data_table "TABLE", '';  '||chr(10)||
'  q:= q || '' success_rows "Succeeded",'';'||chr(10)||
'  q:= q || '' decode(failed_rows,0,''''0'''',htf.anchor(''''f?p=&APP_ID.:2:''||:flow_session||''::::P2_LOAD_ID:'''' || dat.id,'';'||chr(10)||
'  q:= q || '' failed_rows))     "Failed", '';'||chr(10)||
'  q:= q || '' o.object_id object_id, o.owner object_owner '';'||chr(10)||
'  q:= q || '' from wwv_flow_data_load_unload dat, sys.db';

s:=s||'a_objects o '';  '||chr(10)||
'  q:= q || '' where o.owner = dat.data_schema '';'||chr(10)||
'  q:= q || '' and o.object_name = dat.data_table '';'||chr(10)||
'  q:= q || '' and o.object_type = ''''TABLE'''' '';'||chr(10)||
'  q:= q || '' and dat.security_group_id =:FLOW_SECURITY_GROUP_ID '';'||chr(10)||
'  q:= q || '' and data_type = ''''EXCEL IMPORT'''''';'||chr(10)||
''||chr(10)||
'  if (:F4300_P11_RESTRICT_BY = ''MY'' or :F4300_P11_RESTRICT_BY is NULL)  then'||chr(10)||
'      q:= q || '' and dat.created_by = :FLOW_U';

s:=s||'SER '';'||chr(10)||
'  end if;  '||chr(10)||
'return q;'||chr(10)||
'end;';

wwv_flow_api.create_report_region (
  p_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 11,
  p_name=> 'Loads',
  p_region_name=>'',
  p_template=> 0+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 40,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'FUNCTION_RETURNING_SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_plug_caching=> 'NOT_CACHED',
  p_customized=> '0',
  p_translate_title=> 'Y',
  p_ajax_enabled=> 'N',
  p_query_row_template=> 11634930157712121+ wwv_flow_api.g_id_offset,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '15',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> ' - ',
  p_query_break_cols=> '0',
  p_query_no_data_found=> 'No data found.',
  p_query_num_rows_type=> 'ROW_RANGES',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_csv_output=> 'N',
  p_sort_null=> 'F',
  p_query_asc_image=> 'arrow_down_gray_dark.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'arrow_up_gray_dark.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_plug_query_strip_html=> 'Y',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235769436525045149 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'CB',
  p_column_display_sequence=> 1,
  p_column_heading=> '&nbsp;',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235769516971045149 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'Details',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Details',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235769611125045149 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 3,
  p_form_element_id=> null,
  p_column_alias=> 'Created By',
  p_column_display_sequence=> 3,
  p_column_heading=> 'Imported By',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235769715179045150 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 4,
  p_form_element_id=> null,
  p_column_alias=> 'Created on',
  p_column_display_sequence=> 4,
  p_column_heading=> 'Imported On',
  p_column_format=> 'SINCE',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>1,
  p_default_sort_dir=>'desc',
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235769833276045150 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 5,
  p_form_element_id=> null,
  p_column_alias=> 'Type',
  p_column_display_sequence=> 5,
  p_column_heading=> 'Type',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235769930497045150 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 6,
  p_form_element_id=> null,
  p_column_alias=> 'Schema',
  p_column_display_sequence=> 6,
  p_column_heading=> 'Schema',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235770035353045150 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 7,
  p_form_element_id=> null,
  p_column_alias=> 'TABLE',
  p_column_display_sequence=> 7,
  p_column_heading=> 'Table',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_lov_show_nulls=> 'NO',
  p_pk_col_source=> s,
  p_lov_display_extra=> 'YES',
  p_include_in_export=> 'Y',
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235770116401045150 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 8,
  p_form_element_id=> null,
  p_column_alias=> 'Succeeded',
  p_column_display_sequence=> 8,
  p_column_heading=> 'Succeeded',
  p_column_alignment=>'RIGHT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 235770208711045150 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 9,
  p_form_element_id=> null,
  p_column_alias=> 'Failed',
  p_column_display_sequence=> 9,
  p_column_heading=> 'Failed',
  p_column_alignment=>'RIGHT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'N',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 269546914169088989 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 10,
  p_form_element_id=> null,
  p_column_alias=> 'OBJECT_ID',
  p_column_display_sequence=> 10,
  p_column_heading=> 'Object',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'Y',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 269553726337120918 + wwv_flow_api.g_id_offset,
  p_region_id=> 235768832819045137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 11,
  p_form_element_id=> null,
  p_column_alias=> 'OBJECT_OWNER',
  p_column_display_sequence=> 11,
  p_column_heading=> 'Object Owner',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'CENTER',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'Y',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 193206721350603484 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 11,
  p_button_sequence=> 10,
  p_button_plug_id => 4977030771616149+wwv_flow_api.g_id_offset,
  p_button_name    => 'DELETE',
  p_button_image_alt=> 'Delete Checked',
  p_button_position=> 'REGION_TEMPLATE_DELETE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_condition=> 'select 1'||chr(10)||
'from wwv_flow_data_load_unload dat, sys.dba_objects o '||chr(10)||
'where o.owner = dat.data_schema'||chr(10)||
'and o.object_name = dat.data_table'||chr(10)||
'and o.object_type = ''TABLE'''||chr(10)||
'and dat.security_group_id =:FLOW_SECURITY_GROUP_ID'||chr(10)||
'and data_type = ''EXCEL IMPORT''',
  p_button_condition_type=> 'EXISTS',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>115754724436860058 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 11,
  p_branch_action=> '11',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>115755632617860066 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 11,
  p_name=>'F4300_P11_GO',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 4977030771616149+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default => 'GO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Go',
  p_source=>'GO',
  p_source_type=> 'STATIC',
  p_display_as=> 'BUTTON',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'LEFT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'N',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Specify to show your Spreadsheet import or all Spreadsheet imports.';

wwv_flow_api.create_page_item(
  p_id=>115755932754860067 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 11,
  p_name=>'F4300_P11_RESTRICT_BY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 4977030771616149+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Show',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'RESTRICT.LOAD.FILES',
  p_lov => '.'||to_char(88970107105345348 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 347635414377293549+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 166180007847952934 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 11,
  p_validation_name => 'SelectAtLeastOne',
  p_validation_sequence=> 10,
  p_validation => 'wwv_flow.g_f01.count > 0',
  p_validation_type => 'PLSQL_EXPRESSION',
  p_error_message => 'Must select at least one file to delete.',
  p_when_button_pressed=> 193206721350603484 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'reset_pagination';

wwv_flow_api.create_page_process(
  p_id     => 115756215867860069 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 11,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'RESET_PAGINATION',
  p_process_name=> 'rest pagination',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_when=>'GO',
  p_process_when_type=>'REQUEST_EQUALS_CONDITION',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'forall i in 1..wwv_flow.g_f01.count'||chr(10)||
'    delete from wwv_flow_data_load_unload'||chr(10)||
'     where id = wwv_flow.g_f01(i)'||chr(10)||
'     and security_group_id = :flow_security_group_id;'||chr(10)||
'commit;';

wwv_flow_api.create_page_process(
  p_id     => 193211011981610151 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 11,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'delete load_unload detail',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error deleting.',
  p_process_when_button_id=>193206721350603484 + wwv_flow_api.g_id_offset,
  p_process_success_message=> 'Spreadsheet data load detail(s) deleted.',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 11
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00014
prompt  ...PAGE 14: Load XML Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_imprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 14,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load XML Data',
  p_step_title=> 'Load XML Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216782707569420532+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125928',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>14,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7738134770498920 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 14,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 185063507024490975 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 14,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 185325332067236431 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 185063819065490980 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 14,
  p_plug_name=> 'Load XML Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database schema that owns the table you would like load data into.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 221860807536243081 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 14,
  p_plug_name=> 'Load XML Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:18');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 185064728890490998 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 14,
  p_button_sequence=> 10,
  p_button_plug_id => 185063819065490980+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 185064434101490997 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 14,
  p_button_sequence=> 20,
  p_button_plug_id => 185063819065490980+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>185065329614491053 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 14,
  p_branch_action=> '16',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>185064434101490997+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database schema that owns the table you would like load data into.';

wwv_flow_api.create_page_item(
  p_id=>185065019155491013 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 14,
  p_name=>'F4300_P14_TARGET_SCHEMA',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 185063819065490980+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema',
  p_source=>'wwv_flow_user_api.get_default_schema',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'LIST_SCHEMA_OWNERS',
  p_lov => 'select htf.escape_sc(c.schema) d, c.schema v'||chr(10)||
'from   wwv_flow_company_schemas c,'||chr(10)||
'       wwv_flow_fnd_user u'||chr(10)||
'where  c.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.user_name = :flow_user and'||chr(10)||
'       (u.ALLOW_ACCESS_TO_SCHEMAS is null or'||chr(10)||
'        instr('':''||u.ALLOW_ACCESS_TO_SCHEMAS||'':'','':''||c.schema||'':'')>0)'||chr(10)||
'order by 1'||chr(10)||
'',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Schema - ',
  p_lov_null_value=> '',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 185066235543491103 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 14,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_LAST_VIEW',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> '14',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 185066524646491114 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 14,
  p_validation_name => 'owner req',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P14_TARGET_SCHEMA',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Schema owner must be specified.',
  p_associated_item=> 185065019155491013 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 14
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00016
prompt  ...PAGE 16: Load XML Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 16,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load XML Data',
  p_step_title=> 'Load XML Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216782707569420532+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'SSPADAFO',
  p_last_upd_yyyymmddhh24miss => '20081110150351',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>16,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 76452418320556349 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 16,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 185069318866493155 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 16,
  p_plug_name=> 'Load XML Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 185071115942493175 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 16,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 185325332067236431 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database table you would like load data into.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 221862825890248422 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 16,
  p_plug_name=> 'Load XML Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 185070206430493164 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 16,
  p_button_sequence=> 10,
  p_button_plug_id => 185069318866493155+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 185069935131493163 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 16,
  p_button_sequence=> 10,
  p_button_plug_id => 185069318866493155+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 185069608163493160 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 16,
  p_button_sequence=> 1,
  p_button_plug_id => 185069318866493155+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREV',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>185071415430493177 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 16,
  p_branch_action=> '17',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>185071717830493181 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 16,
  p_branch_action=> '14',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>185069608163493160+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 06-MAR-2001 16:15 by FLOWS');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>78562927739801250 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 16,
  p_name=>'P16_CASE_SENSITIVE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 185069318866493155+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'CASE.SENSITIVE.Y',
  p_lov => '.'||to_char(88974921613396877 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database table you would like load data into. By default, all table names are converted to upper case. Select <span class="fielddatabold">Preserve Case</span> override this default behavior.';

wwv_flow_api.create_page_item(
  p_id=>185070517655493165 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 16,
  p_name=>'F4300_P16_TARGET_TABLE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 185069318866493155+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table',
  p_source_type=> 'STATIC',
  p_display_as=> 'POPUP',
  p_named_lov=> 'P16_TABLES',
  p_lov => 'select table_name a, table_name b'||chr(10)||
'from sys.dba_tables'||chr(10)||
'where owner=:F4300_P14_TARGET_SCHEMA'||chr(10)||
'and table_name not like ''BIN$%'''||chr(10)||
'order by 1',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the schema to choose a table from';

wwv_flow_api.create_page_item(
  p_id=>186019417872847620 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 16,
  p_name=>'F4300_P16_SCHEMA',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 5,
  p_item_plug_id => 185069318866493155+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema:',
  p_source=>'F4300_P14_TARGET_SCHEMA',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 78567415534816618 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 16,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P16_TARGET_TABLE',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'upper(:F4300_P16_TARGET_TABLE)',
  p_compute_when => 'P16_CASE_SENSITIVE',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 78565018866808175 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 16,
  p_validation_name => 'table exists',
  p_validation_sequence=> 10,
  p_validation => 'select 1'||chr(10)||
'from sys.dba_objects'||chr(10)||
'where owner = :F4300_P14_TARGET_SCHEMA'||chr(10)||
'and object_name = :F4300_P16_TARGET_TABLE'||chr(10)||
'and object_type in (''TABLE'')',
  p_validation_type => 'EXISTS',
  p_error_message => 'Table does not exist.',
  p_validation_condition=> 'F4300_P16_TARGET_TABLE',
  p_validation_condition_type=> 'ITEM_IS_NOT_NULL',
  p_when_button_pressed=> 185069935131493163 + wwv_flow_api.g_id_offset,
  p_associated_item=> 185070517655493165 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 185072009641493182 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 16,
  p_validation_name => 'table required',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P16_TARGET_TABLE',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Table must be specified.',
  p_associated_item=> 185070517655493165 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P14_TARGET_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 70981408556734826 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 16,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 16
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00017
prompt  ...PAGE 17: Load XML Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 17,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load XML Data',
  p_step_title=> 'Load XML Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216782707569420532+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806173622',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>17,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 76454024900558247 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 17,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 185074817025496087 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 17,
  p_plug_name=> 'Load XML Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 185076908005496098 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 17,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 185325332067236431 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Locate the XML document to be uploaded.</p> '||chr(10)||
'';

wwv_flow_api.create_page_plug (
  p_id=> 221863912169253931 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 17,
  p_plug_name=> 'Load XML Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:17');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 185075704487496091 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 17,
  p_button_sequence=> 10,
  p_button_plug_id => 185074817025496087+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 185075418314496089 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 17,
  p_button_sequence=> 10,
  p_button_plug_id => 185074817025496087+wwv_flow_api.g_id_offset,
  p_button_name    => 'LOAD',
  p_button_image_alt=> 'Load Data',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 185075127589496088 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 17,
  p_button_sequence=> 1,
  p_button_plug_id => 185074817025496087+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREV',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>185077205697496100 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 17,
  p_branch_action=> '9',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>185075418314496089+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>185077532837496101 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 17,
  p_branch_action=> '16',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>185075127589496088+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 06-MAR-2001 16:15 by FLOWS');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Click <span class="fielddatabold">Browse</span> to locate the XML file you wish to upload.';

wwv_flow_api.create_page_item(
  p_id=>185076336857496094 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 17,
  p_name=>'F4300_P17_FILE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 185074817025496087+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'File',
  p_source_type=> 'STATIC',
  p_display_as=> 'FILE',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 60,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>':F4300_P17_FILE is NULL',
  p_display_when_type=>'FLOW_ITEM_IS_NULL',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the schema for the table';

wwv_flow_api.create_page_item(
  p_id=>186027733172855764 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 17,
  p_name=>'F4300_P17_SCHEMA',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 185074817025496087+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema:',
  p_source=>'F4300_P14_TARGET_SCHEMA',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the table to upload data into';

wwv_flow_api.create_page_item(
  p_id=>186031024977859484 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 17,
  p_name=>'F4300_P17_TABLE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 185074817025496087+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name:',
  p_source=>'F4300_P16_TARGET_TABLE',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 185077831719496102 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 17,
  p_validation_name => 'file required',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P17_FILE',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'File name must be specified.',
  p_associated_item=> 185076336857496094 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 289778032730776868 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 17,
  p_validation_name => 'file not 0 byte',
  p_validation_sequence=> 20,
  p_validation => 'declare'||chr(10)||
'  l_doc_size number := 0;'||chr(10)||
'begin'||chr(10)||
'  for c1 in (select doc_size                     '||chr(10)||
'             from wwv_flow_files'||chr(10)||
'             where name = :F4300_P17_FILE)'||chr(10)||
'  loop'||chr(10)||
'    l_doc_size := c1.doc_size;'||chr(10)||
'  end loop;'||chr(10)||
'  if l_doc_size = 0 then'||chr(10)||
'    return false;'||chr(10)||
'  end if;'||chr(10)||
'  return true;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The uploaded file is invalid or does not have any content.  Please upload the valid file.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare'||chr(10)||
'  l_blob blob;'||chr(10)||
'  l_clob clob;'||chr(10)||
'  l_sql  varchar2(32767) := null;'||chr(10)||
'  n      wwv_flow_global.vc_arr2;'||chr(10)||
'  r      wwv_flow_global.vc_arr2;'||chr(10)||
'begin'||chr(10)||
'  for c1 in (select blob_content'||chr(10)||
'             from  wwv_flow_files'||chr(10)||
'              where  name = :F4300_P17_FILE) loop'||chr(10)||
'    l_blob := c1.blob_content;'||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
'  declare'||chr(10)||
'    l_dest_offset  number := 1;'||chr(10)||
'    l_src_offset   number := 1;'||chr(10)||
'    l_lang_context ';

p:=p||'number := dbms_lob.default_lang_ctx;'||chr(10)||
'    l_warning      number;'||chr(10)||
'  begin     '||chr(10)||
'    dbms_lob.createtemporary ( l_clob, FALSE, dbms_lob.SESSION );'||chr(10)||
'    dbms_lob.open( l_blob, dbms_lob.lob_readonly );'||chr(10)||
''||chr(10)||
'    dbms_lob.convertToCLOB('||chr(10)||
'        dest_lob      => l_clob,'||chr(10)||
'        src_blob      => l_blob,'||chr(10)||
'        amount        => dbms_lob.lobmaxsize,'||chr(10)||
'        dest_offset   => l_dest_offset,'||chr(10)||
'        src_offset    =>';

p:=p||' l_src_offset,'||chr(10)||
'        blob_csid     => nls_charset_id(''AL32UTF8''),'||chr(10)||
'        lang_context  => l_lang_context,'||chr(10)||
'        warning       => l_warning );'||chr(10)||
''||chr(10)||
'    dbms_lob.close( l_blob );'||chr(10)||
'  end;'||chr(10)||
''||chr(10)||
'  wwv_flow_utilities.g_xml_clob := l_clob;'||chr(10)||
' '||chr(10)||
'  l_sql := ''declare '';'||chr(10)||
'  l_sql := l_sql||''insCtx DBMS_XMLSave.ctxType; '';'||chr(10)||
'  l_sql := l_sql||''rows number; '';'||chr(10)||
'  l_sql := l_sql||''begin '';'||chr(10)||
'  l_sql := l_sql||''insCtx := DBM';

p:=p||'S_XMLSave.newContext(''''''||:F4300_P14_TARGET_SCHEMA;'||chr(10)||
'  l_sql := l_sql||''.''||:F4300_P16_TARGET_TABLE||''''''); '';'||chr(10)||
'  l_sql := l_sql||''DBMS_XMLSave.setDateFormat(insCtx,''''yyyy-MM-dd''''''''T''''''''HH:mm:ss.SSS''''); '';  '||chr(10)||
'  l_sql := l_sql||''rows := DBMS_XMLSave.insertXML(insCtx,wwv_flow_utilities.g_xml_clob); '';'||chr(10)||
'  l_sql := l_sql||''DBMS_XMLSave.closeContext(insCtx); '';'||chr(10)||
'  l_sql := l_sql||''end;'';'||chr(10)||
'  '||chr(10)||
'  wwv_flow_f4000_';

p:=p||'util.run_block'||chr(10)||
'          ( p_sql    => l_sql,'||chr(10)||
'            p_user   => :F4300_P14_TARGET_SCHEMA);'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 8924914415987560 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 17,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'create_load_xml',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error loading XML.',
  p_process_when_button_id=>185075418314496089 + wwv_flow_api.g_id_offset,
  p_process_when=>'not wwv_flow_utilities.db_version_is_at_least(''10.1'')',
  p_process_when_type=>'PLSQL_EXPRESSION',
  p_process_success_message=> 'XML loaded.',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare'||chr(10)||
'  l_blob blob;'||chr(10)||
'  l_clob clob;'||chr(10)||
'  l_sql  varchar2(32767) := null;'||chr(10)||
'  n      wwv_flow_global.vc_arr2;'||chr(10)||
'  r      wwv_flow_global.vc_arr2;'||chr(10)||
'begin'||chr(10)||
'  for c1 in (select blob_content'||chr(10)||
'             from  wwv_flow_files'||chr(10)||
'              where  name = :F4300_P17_FILE) loop'||chr(10)||
'    l_blob := c1.blob_content;'||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
'  declare'||chr(10)||
'    l_dest_offset  number := 1;'||chr(10)||
'    l_src_offset   number := 1;'||chr(10)||
'    l_lang_context ';

p:=p||'number := dbms_lob.default_lang_ctx;'||chr(10)||
'    l_warning      number;'||chr(10)||
'  begin     '||chr(10)||
'    dbms_lob.createtemporary ( l_clob, FALSE, dbms_lob.SESSION );'||chr(10)||
'    dbms_lob.open( l_blob, dbms_lob.lob_readonly );'||chr(10)||
''||chr(10)||
'    dbms_lob.convertToCLOB('||chr(10)||
'        dest_lob      => l_clob,'||chr(10)||
'        src_blob      => l_blob,'||chr(10)||
'        amount        => dbms_lob.lobmaxsize,'||chr(10)||
'        dest_offset   => l_dest_offset,'||chr(10)||
'        src_offset    =>';

p:=p||' l_src_offset,'||chr(10)||
'        blob_csid     => nls_charset_id(''AL32UTF8''),'||chr(10)||
'        lang_context  => l_lang_context,'||chr(10)||
'        warning       => l_warning );'||chr(10)||
''||chr(10)||
'    dbms_lob.close( l_blob );'||chr(10)||
'  end;'||chr(10)||
''||chr(10)||
'  wwv_flow_utilities.g_xml_clob := l_clob;'||chr(10)||
' '||chr(10)||
'  l_sql := ''declare '';'||chr(10)||
'  l_sql := l_sql||''insCtx dbms_xmlstore.ctxType; '';'||chr(10)||
'  l_sql := l_sql||''rows number; '';'||chr(10)||
'  l_sql := l_sql||''l_nls_date_format      varchar2(255) := ';

p:=p||'null; '';'||chr(10)||
'  l_sql := l_sql||''l_nls_timestamp_format varchar2(255) := null; '';'||chr(10)||
'  l_sql := l_sql||''c_nls_date_format      varchar2(255) := ''''rrrr-MM-dd"T"HH24:mi:ss."000"''''; '';  '||chr(10)||
'  l_sql := l_sql||''c_nls_timestamp_format varchar2(255) := ''''rrrr-MM-dd"T"HH24:mi:ss.FF3''''; '';  '||chr(10)||
'  l_sql := l_sql||''begin '';'||chr(10)||
'  l_sql := l_sql||''for c1 in (select parameter, value '';'||chr(10)||
'  l_sql := l_sql||''           from nls_ses';

p:=p||'sion_parameters '';'||chr(10)||
'  l_sql := l_sql||''           where PARAMETER in (''''NLS_DATE_FORMAT'''',''''NLS_TIMESTAMP_FORMAT'''')) loop '';'||chr(10)||
'  l_sql := l_sql||''  if c1.parameter = ''''NLS_DATE_FORMAT'''' then '';'||chr(10)||
'  l_sql := l_sql||''    l_nls_date_format := c1.value; '';'||chr(10)||
'  l_sql := l_sql||''  elsif c1.parameter = ''''NLS_TIMESTAMP_FORMAT'''' then '';'||chr(10)||
'  l_sql := l_sql||''    l_nls_timestamp_format := c1.value; '';'||chr(10)||
'  l_sql := l_sq';

p:=p||'l||''  end if; '';'||chr(10)||
'  l_sql := l_sql||''end loop; '';'||chr(10)||
'  l_sql := l_sql||''dbms_session.set_nls(''''NLS_DATE_FORMAT'''',''''''''''''''''||c_nls_date_format||''''''''''''''''); '';'||chr(10)||
'	l_sql := l_sql||''dbms_session.set_nls(''''NLS_TIMESTAMP_FORMAT'''',''''''''''''''''||c_nls_timestamp_format||''''''''''''''''); '';'||chr(10)||
'  l_sql := l_sql||''insCtx := dbms_xmlstore.newContext(''''''||:F4300_P14_TARGET_SCHEMA;'||chr(10)||
'  l_sql := l_sql||''.''||:F4300_P16_TARGET_TABLE||''''''';

p:=p||'); '';  '||chr(10)||
'  l_sql := l_sql||''dbms_xmlstore.setRowTag(insCtx,''''ROW''''); '';'||chr(10)||
'  l_sql := l_sql||''rows := dbms_xmlstore.insertXML(insCtx,wwv_flow_utilities.g_xml_clob); '';'||chr(10)||
'  l_sql := l_sql||''dbms_xmlstore.closeContext(insCtx); '';'||chr(10)||
'  l_sql := l_sql||''dbms_session.set_nls(''''NLS_DATE_FORMAT'''',''''''''''''''''||l_nls_date_format||''''''''''''''''); '';'||chr(10)||
'  l_sql := l_sql||''dbms_session.set_nls(''''NLS_TIMESTAMP_FORMAT'''',''''''''''''''''||';

p:=p||'l_nls_timestamp_format||''''''''''''''''); '';'||chr(10)||
'  l_sql := l_sql||''end;'';'||chr(10)||
'  '||chr(10)||
'  wwv_flow_f4000_util.run_block'||chr(10)||
'          ( p_sql    => l_sql,'||chr(10)||
'            p_user   => :F4300_P14_TARGET_SCHEMA);'||chr(10)||
'/*exception when others then'||chr(10)||
'  wwv_flow.show_error_message(p_message  => '||chr(10)||
'         wwv_flow_lang.system_message(p_name=>''XML_LOAD_ERROR''), '||chr(10)||
'         p_footer   => null); '||chr(10)||
'*/'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 185078130934496110 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 17,
  p_process_sequence=> 20,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> '10.1 or greater:  create_load_xml',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error loading XML.',
  p_process_when_button_id=>185075418314496089 + wwv_flow_api.g_id_offset,
  p_process_when=>'wwv_flow_utilities.db_version_is_at_least(''10.1'')',
  p_process_when_type=>'PLSQL_EXPRESSION',
  p_process_success_message=> 'XML loaded.',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P14_TARGET_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 70984034529742283 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 17,
  p_process_sequence=> 30,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 17
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00018
prompt  ...PAGE 18: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_imprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 18,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806152453',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>18,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 3208524730639269 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 18,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_header=> 'The file to be uploaded must be text-based.  To upload a .XLS file, first save it as CSV. <p />'||chr(10)||
'',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:17');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'List:  Plain Text Data Import';

wwv_flow_api.create_page_plug (
  p_id=> 4991315197687382 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 18,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 4983219175650688 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7879206253524164 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 18,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 22335016581287568 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 18,
  p_plug_name=> 'Globalization',
  p_region_name=>'',
  p_plug_template=> 22227029497924836+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 3209423596639272 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 18,
  p_button_sequence=> 10,
  p_button_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_button_name    => 'CANCEL',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 3209715711639272 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 18,
  p_button_sequence=> 30,
  p_button_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 3209623180639272 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 18,
  p_button_sequence=> 20,
  p_button_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>3638313885497165 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_branch_action=> '18',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_branch_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_branch_condition=> 'F4300_P18_REUPLOAD',
  p_branch_condition_text=>'Y',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 24-SEP-2002 09:16 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>3211127590639277 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_branch_action=> '19',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3209715711639272+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 20,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
wwv_flow_api.create_page_branch(
  p_id=>3210112139639274 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_branch_action=> '9',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3209423596639272+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 1,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
wwv_flow_api.create_page_branch(
  p_id=>3210625507639276 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_branch_action=> '230',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3209623180639272+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Click <span class="fielddatabold">Browse</span> to locate the file to be uploaded.';

wwv_flow_api.create_page_item(
  p_id=>3209218497639271 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'F4300_P13_FILE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Text File',
  p_source_type=> 'STATIC',
  p_display_as=> 'FILE',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 60,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P13_FILE',
  p_display_when_type=>'ITEM_IS_NULL',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'N',
  p_help_text   => h,
  p_item_comment => 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Select this box if your data contains column names in the first row.</p>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'<pre>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Name     Salary     Commission'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Clark    1000       10'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Scott    2000       20'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'</pre>';

wwv_flow_api.create_page_item(
  p_id=>3295131568904387 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'F4300_P13_IS_COLUMN_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'Y',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'ISCOLUMN.NAME.TEXT',
  p_lov => 'select ''<span class="instructiontext">''||'||chr(10)||
'wwv_flow_lang.system_message(''F4300_INSTRUCT_TEXT'')||''</span>'' d, ''Y'' r from dual',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identify a column separator character. Use <code>\t</code> for tab separators.';

wwv_flow_api.create_page_item(
  p_id=>3381019316591579 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'F4300_P13_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => ',',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Separator: (\t for tab)',
  p_source_type=> 'ALWAYS_NULL',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the file to upload';

wwv_flow_api.create_page_item(
  p_id=>3635316955469604 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'F4300_P18_FILE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'File Name:',
  p_source=>'substr(:F4300_P13_FILE,instr(:F4300_P13_FILE,''/'')+1)',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P13_FILE',
  p_display_when_type=>'ITEM_IS_NOT_NULL',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Specify to reupload the file ';

wwv_flow_api.create_page_item(
  p_id=>3637731070492694 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'F4300_P18_REUPLOAD',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 25,
  p_item_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default => 'N',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Reupload File',
  p_display_as=> 'COMBOBOX_WITH_SUBMIT',
  p_named_lov=> 'YES.NO.RETURNS_Y_OR_N',
  p_lov => '.'||to_char(88981829849493837 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P13_FILE',
  p_display_when_type=>'ITEM_IS_NOT_NULL',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<div class="htmldbInfoBodyP">Enter a delimiter character. You can use this character to delineate the starting and ending boundary of a data value. If you specify a delimiter character, Data Workshop ingores whitespace occurring before the starting and ending boundary of a data value. You can also use this option to enclose a data value with the specified delimiter character.</div>'||chr(10)||
'<div class="htm';

h:=h||'ldbInfoBodyP">If the first row contains column names, select <span class="fielddatabold">First row contains column names.</span></div>'||chr(10)||
'';

wwv_flow_api.create_page_item(
  p_id=>3815407481633790 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'F4300_P13_ENCLOSED_BY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 35,
  p_item_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Optionally Enclosed By',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>If your data contains international currency symbol, enter it here.</p>'||chr(10)||
'<p>For example, if your data has "&euro;1,234.56" or "&yen;1,234.56", enter "&euro;" or "&yen;".  Otherwise the data will not load correctly.</p>';

wwv_flow_api.create_page_item(
  p_id=>22335723507289531 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'P18_CURRENCY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 50,
  p_item_plug_id => 22335016581287568+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'declare'||chr(10)||
'    l_return_val varchar2(30) := ''$'';'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select value'||chr(10)||
'                 from nls_session_parameters'||chr(10)||
'                where parameter = ''NLS_CURRENCY'') loop'||chr(10)||
'        l_return_val := c1.value;'||chr(10)||
'        exit;'||chr(10)||
'    end loop;'||chr(10)||
'    --'||chr(10)||
'    return l_return_val;'||chr(10)||
'end;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Currency Symbol',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>A group separator is a character that separates integer groups, for example to show thousands and millions.</p>'||chr(10)||
'<p>Any character can be the group separator. The character specified must be single-byte, and the group separator must be different from any other decimal character. The character can be a space, but cannot be a numeric character or any of the following:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>';

h:=h||'plus (+)</li>'||chr(10)||
'<li>hyphen (-)</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>22982525946310302 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'P18_GROUP_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 60,
  p_item_plug_id => 22335016581287568+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_group_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Group Separator',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>The decimal character separates the integer and decimal parts of a number.</p>'||chr(10)||
'<p> Any character can be the decimal character. The character specified must be single-byte, and the decimal character must be different from group separator. The character can be a space, but cannot be any numeric character or any of the following characters:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>plus (+)</li>'||chr(10)||
'<li>hyphen (-';

h:=h||')</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>22983433218312365 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'P18_DECIMAL_CHARACTER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 70,
  p_item_plug_id => 22335016581287568+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_decimal_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Decimal Character',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose the character set in which the text file is encoded';

wwv_flow_api.create_page_item(
  p_id=>144119907897605438 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_name=>'P18_FILE_CHARSET',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 45,
  p_item_plug_id => 3208524730639269+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'nvl(lower(trim(owa_util.get_cgi_env(''REQUEST_IANA_CHARSET''))),''utf-8'')',
  p_item_default_type => 'PLSQL_EXPRESSION',
  p_prompt=>'File Character Set',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'I18N_IANA_CHARSET',
  p_lov => '.'||to_char(136450730164180959 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 50583013538525762 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_computation_sequence => 20,
  p_computation_item=> 'F4300_P13_IS_COLUMN_NAME',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'N',
  p_compute_when => 'F4300_P13_IS_COLUMN_NAME',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 3652633091739233 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 18,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P18_REUPLOAD',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'N',
  p_compute_when => '',
  p_compute_when_type=>'%null%');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4010520349791835 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 18,
  p_validation_name => 'file name not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P13_FILE',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'File Name must be specified.',
  p_when_button_pressed=> 3209715711639272 + wwv_flow_api.g_id_offset,
  p_associated_item=> 3209218497639271 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 166164223814910293 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 18,
  p_validation_name => 'SeparatorMand',
  p_validation_sequence=> 20,
  p_validation => 'F4300_P13_SEPARATOR',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Separator must be specified.',
  p_when_button_pressed=> 3209715711639272 + wwv_flow_api.g_id_offset,
  p_associated_item=> 3381019316591579 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53266118212817456 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 18,
  p_validation_name => 'file not 0 byte',
  p_validation_sequence=> 30,
  p_validation => 'declare'||chr(10)||
'  l_doc_size number := 0;'||chr(10)||
'begin'||chr(10)||
'  for c1 in (select doc_size                     '||chr(10)||
'             from wwv_flow_files'||chr(10)||
'             where name = :F4300_P13_FILE)'||chr(10)||
'  loop'||chr(10)||
'    l_doc_size := c1.doc_size;'||chr(10)||
'  end loop;'||chr(10)||
'  if l_doc_size = 0 then'||chr(10)||
'    return false;'||chr(10)||
'  end if;'||chr(10)||
'  return true;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The uploaded file is invalid or does not have any content.  Please upload the valid file.',
  p_when_button_pressed=> 3209715711639272 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 246311025288686674 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 18,
  p_validation_name => 'not valid file extension',
  p_validation_sequence=> 40,
  p_validation => 'return wwv_flow_load_data.valid_file_extension (p_filename => :F4300_P13_FILE)',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The file contains invalid file extension.  No binary file types are supported.',
  p_when_button_pressed=> 3209715711639272 + wwv_flow_api.g_id_offset,
  p_associated_item=> 3635316955469604 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare  '||chr(10)||
'  l_first_row_is_col_name boolean := false;'||chr(10)||
'  l_file_id               number := 0;'||chr(10)||
'begin'||chr(10)||
'  for c1 in (select id             '||chr(10)||
'             from wwv_flow_files'||chr(10)||
'             where name = :F4300_P13_FILE)'||chr(10)||
'  loop'||chr(10)||
'    l_file_id := c1.id;'||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
'  if l_file_id != 0 then'||chr(10)||
'    if :F4300_P13_IS_COLUMN_NAME = ''Y'' then'||chr(10)||
'      l_first_row_is_col_name := true;'||chr(10)||
'    end if;'||chr(10)||
'    wwv_flow_load_data.cr';

p:=p||'eate_csv_collection ('||chr(10)||
'     p_file_id                => l_file_id,'||chr(10)||
'     p_separator              => lower(:F4300_P13_SEPARATOR),'||chr(10)||
'     p_enclosed_by            => :F4300_P13_ENCLOSED_BY,  '||chr(10)||
'     p_first_row_is_col_name  => l_first_row_is_col_name,'||chr(10)||
'     p_currency               => :P18_CURRENCY,'||chr(10)||
'     p_numeric_chars          => :P18_DECIMAL_CHARACTER||:P18_GROUP_SEPARATOR,'||chr(10)||
'     p_charset              ';

p:=p||'  => :P18_FILE_CHARSET'||chr(10)||
'     );'||chr(10)||
'  end if;'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 3375407317521890 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 18,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'create table info collection',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error creating collection using loaded data.',
  p_process_when_button_id=>3209715711639272 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'delete from wwv_flow_files'||chr(10)||
'where name = :F4300_P13_FILE;'||chr(10)||
''||chr(10)||
':F4300_P13_FILE := null;';

wwv_flow_api.create_page_process(
  p_id     => 24926630668491301 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 18,
  p_process_sequence=> 20,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'delete file and reupload',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Unable to delete file.',
  p_process_when=>'F4300_P18_REUPLOAD',
  p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_process_when2=>'Y',
  p_process_when_type2=>'',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 18
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00019
prompt  ...PAGE 19: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph:=ph||'<script type="text/javascript">'||chr(10)||
'<!--'||chr(10)||
''||chr(10)||
'function f_ImportDataTypeOnload(){'||chr(10)||
'var lRow = html_GetElement(''importData'').rows[1];'||chr(10)||
'var lSelects = lRow.getElementsByTagName(''SELECT'');'||chr(10)||
'var lLength = lSelects.length;'||chr(10)||
'for(var i=0;i<lLength;i++){lSelects[i].onchange()}'||chr(10)||
'return;'||chr(10)||
'}'||chr(10)||
''||chr(10)||
''||chr(10)||
'function f_ImportDataType(pThis,pThat){  '||chr(10)||
'var lCheckValues = new Array(''NUMBER'',''CLOB'',''DATE'',''BINARY_FLOAT'',''BINARY_DOUBLE'');'||chr(10)||
'  va';

ph:=ph||'r lTest2 = html_DisableOnValue(pThis,lCheckValues,pThat);'||chr(10)||
'  html_GetElement(pThat).disabled = false;'||chr(10)||
'  if(lTest2){'||chr(10)||
'    html_GetElement(pThat).setAttribute(''onfocus'',''this.blur()'');'||chr(10)||
'    }else{'||chr(10)||
'    html_GetElement(pThat).setAttribute(''onfocus'','''');'||chr(10)||
'  }'||chr(10)||
''||chr(10)||
'}'||chr(10)||
'//-->'||chr(10)||
'</script>';

wwv_flow_api.create_page(
  p_id     => 19,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_html_page_onload=>'onload="f_ImportDataTypeOnload()"',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => ' ',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>19,p_text=>h);
wwv_flow_api.set_html_page_header(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>19,p_text=>ph);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 3211723979639279 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 19,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:17');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'wwv_flow_load_data.display_ntable_property(p_collection_name => ''CSV_IMPORT'' );';

wwv_flow_api.create_page_plug (
  p_id=> 3304222741939624 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 19,
  p_plug_name=> 'Set Table Properties',
  p_region_name=>'',
  p_plug_template=> 280800227642320099+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'PLSQL_PROCEDURE',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'List:  Plain Text Data Import';

wwv_flow_api.create_page_plug (
  p_id=> 4992120045688708 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 19,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 4983219175650688 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7880631187531312 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 19,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>This page previews how your new table will look.  Enter a table name, change column names or data types, and specify which columns to include.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222531727722131902 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 19,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 3212626450639282 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 19,
  p_button_sequence=> 10,
  p_button_plug_id => 3211723979639279+wwv_flow_api.g_id_offset,
  p_button_name    => 'CANCEL',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 3212916222639282 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 19,
  p_button_sequence=> 30,
  p_button_plug_id => 3211723979639279+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 3212805865639282 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 19,
  p_button_sequence=> 20,
  p_button_plug_id => 3211723979639279+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>3214334749639288 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_branch_action=> '21',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3212916222639282+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 20,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
wwv_flow_api.create_page_branch(
  p_id=>3213331140639283 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_branch_action=> '9',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3212626450639282+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 1,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
wwv_flow_api.create_page_branch(
  p_id=>3213834840639287 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_branch_action=> '18',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3212805865639282+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose the database schema you would like to create and load data into.';

wwv_flow_api.create_page_item(
  p_id=>3212416303639282 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_name=>'F4300_P13_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 3211723979639279+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema',
  p_source=>'wwv_flow_user_api.get_default_schema',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'CREATE_TABLE_SCHEMAS',
  p_lov => 'declare'||chr(10)||
'  q varchar2(32767) := null;'||chr(10)||
'begin'||chr(10)||
'  q:=q||''select htf.escape_sc(c.schema) d, c.schema v '';'||chr(10)||
'  q:=q||''from   wwv_flow_company_schemas c, '';'||chr(10)||
'  q:=q||''       wwv_flow_fnd_user u '';'||chr(10)||
'  q:=q||''where  c.security_group_id = :flow_security_group_id and '';'||chr(10)||
'  q:=q||''       u.security_group_id = :flow_security_group_id and '';'||chr(10)||
'  q:=q||''       u.user_name = :flow_user and '';'||chr(10)||
'  q:=q||''       (u.ALLOW_ACCESS_TO_SCHEMAS is null or '';'||chr(10)||
'  q:=q||''        instr('''':''''||u.ALLOW_ACCESS_TO_SCHEMAS||'''':'''','''':''''||c.schema||'''':'''')>0) '';'||chr(10)||
'  if wwv_flow_global.g_xe then'||chr(10)||
'    q:=q||''  and exists (select null '';'||chr(10)||
'    q:=q||''              from sys.dba_sys_privs '';'||chr(10)||
'    q:=q||''              where privilege = ''''CREATE TABLE'''' '';'||chr(10)||
'    q:=q||''              and grantee = c.schema '';'||chr(10)||
'    q:=q||''              union all '';'||chr(10)||
'    q:=q||''              select null '';'||chr(10)||
'    q:=q||''              from sys.dba_sys_privs s, sys.dba_role_privs r '';'||chr(10)||
'    q:=q||''              where r.granted_role=s.grantee '';'||chr(10)||
'    q:=q||''              and r.grantee = c.schema '';'||chr(10)||
'    q:=q||''              and s.privilege = ''''CREATE TABLE'''') '';'||chr(10)||
'  else'||chr(10)||
'    q:=q||''  and exists (select null '';'||chr(10)||
'    q:=q||''               from sys.dba_sys_privs '';'||chr(10)||
'    q:=q||''               where privilege = ''''CREATE TABLE'''' '';'||chr(10)||
'    q:=q||''                 and grantee = c.schema)     '';'||chr(10)||
'  end if;         '||chr(10)||
'  q:=q||''  and exists (select null '';'||chr(10)||
'  q:=q||''                from sys.dba_users '';'||chr(10)||
'  q:=q||''               where username = c.schema) '';'||chr(10)||
'  q:=q||''order by 1 '';'||chr(10)||
'  '||chr(10)||
'  return q;'||chr(10)||
'end;',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_read_only_when=>'return wwv_flow_global.g_xe',
  p_read_only_when_type=>'FUNCTION_BODY',
  p_read_only_disp_attr=>'class="fielddatabold"',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identify the table name you would like to create. By default, all table names are converted to upper case. Select <span class="fielddatabold">Preserve Case</span> override this default behavior.';

wwv_flow_api.create_page_item(
  p_id=>3318514787013060 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_name=>'F4300_P13_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 3211723979639279+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name',
  p_source_type=> 'ALWAYS_NULL',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>3321134872018869 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_name=>'F4300_P19_DUMMY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 3211723979639279+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_prompt=>'Dummy',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>78824006612845484 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_name=>'P19_PRESERVE_CASE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 25,
  p_item_plug_id => 3211723979639279+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'PRESERVE.CASE.Y',
  p_lov => '.'||to_char(88982915435499165 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 78830121981859346 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_computation_sequence => 5,
  p_computation_item=> 'F4300_P13_TABLE_NAME',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'upper(replace(wwv_flow_utilities.remove_spaces(:F4300_P13_TABLE_NAME),chr(32),''_''))',
  p_compute_when => 'P19_PRESERVE_CASE',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 3662931517975351 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 19,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P19_DUMMY',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'  l_col_name varchar2(4000) := null;'||chr(10)||
'begin'||chr(10)||
'for i in 1..wwv_flow.g_f06.count loop'||chr(10)||
'  if :P19_PRESERVE_CASE is null then'||chr(10)||
'    l_col_name := upper(wwv_flow_utilities.remove_spaces(wwv_flow.g_f01(i)));'||chr(10)||
'  else'||chr(10)||
'    l_col_name := wwv_flow_utilities.remove_spaces(wwv_flow.g_f01(i));'||chr(10)||
'  end if;'||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 1,'||chr(10)||
'     p_attr_value => l_col_name'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 2,'||chr(10)||
'     p_attr_value => wwv_flow.g_f02(i)'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 4,'||chr(10)||
'     p_attr_value => wwv_flow.g_f04(i)'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 5,'||chr(10)||
'     p_attr_value => wwv_flow.g_f05(i)'||chr(10)||
'     );'||chr(10)||
'     '||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 6,'||chr(10)||
'     p_attr_value => wwv_flow.g_f07(i)'||chr(10)||
'     );  '||chr(10)||
'end loop;'||chr(10)||
''||chr(10)||
'return ''true'';'||chr(10)||
''||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3667306762006088 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'column name not null, not > 30',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
'begin'||chr(10)||
'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
''||chr(10)||
'  if wwv_flow.g_f04(i) = ''Y'' '||chr(10)||
'    then'||chr(10)||
'    if wwv_flow.g_f01(i) is not null then'||chr(10)||
'      if length(wwv_flow.g_f01(i)) > 30 then'||chr(10)||
'        return wwv_flow_lang.system_message(''F4300.COL_NAMES_NOT_LONGER_THAN_30'');'||chr(10)||
'      end if;'||chr(10)||
'    else'||chr(10)||
'      return wwv_flow_lang.system_message(''F4300.COL_NAMES_NOT_NULL'');'||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Column Name Error.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3668429272012593 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'table name not > 30',
  p_validation_sequence=> 20,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'if length(:F4300_P13_TABLE_NAME) > 30 then'||chr(10)||
''||chr(10)||
'  return wwv_flow_lang.system_message(''F4300.TABLE_NAMES_NOT_LONGER_THAN_30'');'||chr(10)||
''||chr(10)||
'end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Table name too long.',
  p_associated_item=> 3318514787013060 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3669216243018226 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'at least one upload selected',
  p_validation_sequence=> 30,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'  l_no_count number := 0;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f04.count loop'||chr(10)||
''||chr(10)||
'    if wwv_flow.g_f04(i) = ''N'' then'||chr(10)||
''||chr(10)||
'      l_no_count := l_no_count + 1;'||chr(10)||
''||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_no_count = wwv_flow.g_f04.count then'||chr(10)||
''||chr(10)||
'    return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'    return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'At least one column must be specified to include in new table. ',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3670235983023913 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'cannot have same table name',
  p_validation_sequence=> 40,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'if wwv_flow_load_excel_data.table_exists('||chr(10)||
''||chr(10)||
'  p_schema => :F4300_P13_OWNER,'||chr(10)||
''||chr(10)||
'  p_table_name => wwv_flow_utilities.remove_spaces(:F4300_P13_TABLE_NAME)'||chr(10)||
''||chr(10)||
'  ) then'||chr(10)||
''||chr(10)||
'  return wwv_flow_lang.system_message(''F4300.F4500.TABLE_ALREADY_EXISTS'');'||chr(10)||
''||chr(10)||
'end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Name is already used by an existing object.',
  p_associated_item=> 3318514787013060 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3671615682027565 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'table name not null',
  p_validation_sequence=> 50,
  p_validation => 'F4300_P13_TABLE_NAME',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Table name must be specifeid.',
  p_associated_item=> 3318514787013060 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3673422739039072 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'column length not zero or null',
  p_validation_sequence=> 70,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f05.count loop'||chr(10)||
''||chr(10)||
'    if wwv_flow.g_f05(i) is not null then'||chr(10)||
''||chr(10)||
'      if wwv_flow.g_f05(i) = 0 then'||chr(10)||
''||chr(10)||
'        return wwv_flow_lang.system_message(''F4300.COL_LENGTH_NOT_ZERO'');'||chr(10)||
''||chr(10)||
'      end if;'||chr(10)||
''||chr(10)||
'    else'||chr(10)||
''||chr(10)||
'      return wwv_flow_lang.system_message(''F4300.COL_LENGTH_NOT_NULL'');'||chr(10)||
''||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error in Column Length.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 291940532747696314 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'reserved name',
  p_validation_sequence=> 80,
  p_validation => 'if wwv_flow_sw_util.is_database_reserved_word(p_word=>:F4300_P13_TABLE_NAME) then'||chr(10)||
'  return false;'||chr(10)||
'else'||chr(10)||
'  return true;'||chr(10)||
'end if;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The identified table name is an Oracle reserved word.  Please choose another name.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 292112915159646863 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'column name reserved word',
  p_validation_sequence=> 90,
  p_validation => 'for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'  if wwv_flow_sw_util.is_database_reserved_word(p_word=>upper(wwv_flow.g_f01(i))) then'||chr(10)||
'    return false;'||chr(10)||
'  end if;'||chr(10)||
'end loop;'||chr(10)||
'return true;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The identified column name is an Oracle reserved word.  Please choose another name.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 26668607329025721 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_validation_name => 'F4300_P13_OWNER',
  p_validation_sequence=> 100,
  p_validation => 'F4300_P13_OWNER',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Schema must be specified.',
  p_when_button_pressed=> 3212916222639282 + wwv_flow_api.g_id_offset,
  p_associated_item=> 3212416303639282 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'if :F4300_P13_OWNER is not null then'||chr(10)||
'wwv_flow_sw_api.check_priv(:F4300_P13_OWNER);'||chr(10)||
'end if;';

wwv_flow_api.create_page_process(
  p_id     => 71101722070514625 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 19,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 19
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00021
prompt  ...PAGE 21: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph:=ph||'<script language="JavaScript" type="text/javascript">'||chr(10)||
'<!--'||chr(10)||
'function displayPrimaryKey(theItem)'||chr(10)||
'{'||chr(10)||
'  if (theItem.value == ''EXISTING_KEY'')'||chr(10)||
'  {'||chr(10)||
'     disableItems(''document.getElementById(\''P13_PK1_OPTION\'').value = \''EXISTING_KEY\'''','||chr(10)||
'                  ''P13_PK1_2'');  '||chr(10)||
'     disableItems(''document.getElementById(\''P13_PK1_OPTION\'').value != \''EXISTING_KEY\'''','||chr(10)||
'                  ''P13_PK1'');                ';

ph:=ph||'      '||chr(10)||
'  }'||chr(10)||
'  else if (theItem.value == ''NEW_KEY'')'||chr(10)||
'  {'||chr(10)||
'     disableItems(''document.getElementById(\''P13_PK1_OPTION\'').value = \''NEW_KEY\'''','||chr(10)||
'                  ''P13_PK1'');     '||chr(10)||
'     disableItems(''document.getElementById(\''P13_PK1_OPTION\'').value != \''NEW_KEY\'''','||chr(10)||
'                  ''P13_PK1_2'');                                      '||chr(10)||
'  }  '||chr(10)||
'}'||chr(10)||
''||chr(10)||
'//-->'||chr(10)||
'</script>';

wwv_flow_api.create_page(
  p_id     => 21,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => ' ',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806172347',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>21,p_text=>h);
wwv_flow_api.set_html_page_header(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>21,p_text=>ph);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 3214911760639290 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 21,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_footer=> '<script language="JavaScript" type="text/javascript">'||chr(10)||
'<!--'||chr(10)||
'displayPrimaryKey(document.getElementById(''P13_PK1_OPTION''));'||chr(10)||
'//-->'||chr(10)||
'</script>',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:17');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'List:  Plain Text Data Import';

wwv_flow_api.create_page_plug (
  p_id=> 4992825240690274 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 21,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 4983219175650688 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7881808808534318 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 21,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Use this page to identify the primary key of the table. If no single column in your data set is appropriate as a primary key then identify a new column as the primary key. A primary key is used to uniquely identify a row in a table.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222535906860144740 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 21,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 3215831046639291 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 21,
  p_button_sequence=> 10,
  p_button_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_button_name    => 'CANCEL',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 3216129012639291 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 21,
  p_button_sequence=> 30,
  p_button_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_button_name    => 'FINISH',
  p_button_image_alt=> 'Load Data',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 3216030990639291 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 21,
  p_button_sequence=> 20,
  p_button_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>3217531098639299 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_branch_action=> '8',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3216129012639291+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 20,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
wwv_flow_api.create_page_branch(
  p_id=>30951106236487307 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_branch_action=> '21',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 30,
  p_branch_condition_type=> 'REQUEST_EQUALS_CONDITION',
  p_branch_condition=> 'P13_PK_TYPE',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 05-FEB-2003 11:30 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>53542607196259578 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_branch_action=> 'f?p=&FLOW_ID.:21:&SESSION.::&DEBUG.:::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_sequence=> 99,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 02-JUN-2003 11:08 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>3217009689639294 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_branch_action=> '19',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3216030990639291+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Schema that owns the table you would like to load data into.';

wwv_flow_api.create_page_item(
  p_id=>3215616569639291 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'F4300_P21_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema:',
  p_source=>'F4300_P13_OWNER',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_AND_SAVE',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the table to load data into';

wwv_flow_api.create_page_item(
  p_id=>3341423716110207 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'F4300_P21_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name:',
  p_source=>'F4300_P13_TABLE_NAME',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Specify which column is the primary key of your table.  A primary key is a column which uniquely identifies a row.  Oracle does not require that your table have a primary key, however this wizard requires you identify a primary key.';

wwv_flow_api.create_page_item(
  p_id=>30917206741373999 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P13_PK1',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Primary Key',
  p_source_type=> 'ALWAYS_NULL',
  p_display_as=> 'COMBOBOX',
  p_lov => 'select htf.escape_sc(c001)||''(''||c002||'')'' a, c001'||chr(10)||
'  from wwv_flow_collections'||chr(10)||
' where collection_name = ''CSV_IMPORT'' and c001 is not null'||chr(10)||
' order by seq_id'||chr(10)||
'',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Primary Key -',
  p_lov_null_value=> '0',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'P13_PK1_OPTION',
  p_display_when2=>'EXISTING_KEY',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name the primary key constraint name.';

wwv_flow_api.create_page_item(
  p_id=>30920334446381977 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P13_PK1_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 50,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'PK Constraint Name',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose how you would like to have your primary key computed.  Or; choose to not have your primary key''s value set.';

wwv_flow_api.create_page_item(
  p_id=>30923324188388493 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P13_PK_TYPE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 60,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'NEW_SEQUENCE',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Primary Key Population:',
  p_source_type=> 'STATIC',
  p_display_as=> 'RADIOGROUP_WITH_SUBMIT',
  p_named_lov=> 'PK_TYPES',
  p_lov => '.'||to_char(30284028271088477 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT-TOP',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identify the name of an existing database sequence which will be used to populate the primary key value.';

wwv_flow_api.create_page_item(
  p_id=>30925630552399773 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P13_EXISTING_SEQUENCE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 70,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Sequence',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_lov => 'select htf.escape_sc(sequence_name) d, sequence_name v'||chr(10)||
' from sys.dba_sequences '||chr(10)||
'where sequence_owner = :F4300_P13_OWNER'||chr(10)||
'order by sequence_name',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Sequence -',
  p_lov_null_value=> '0',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'P13_PK_TYPE',
  p_display_when2=>'EXISTING_SEQUENCE',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identify the name of new database sequence which will be created for the purpose of populating this new tables primary key.';

wwv_flow_api.create_page_item(
  p_id=>30927417524405418 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P13_NEW_SEQUENCE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 80,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Sequence',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'P13_PK_TYPE',
  p_display_when2=>'NEW_SEQUENCE',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>52798132197465231 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P21_X',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source=>'&nbsp;',
  p_source_type=> 'STATIC',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'You can either select existing column or add new column as primary key.';

wwv_flow_api.create_page_item(
  p_id=>53530821001235176 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P13_PK1_OPTION',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 35,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'NEW_KEY',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Primary Key From:',
  p_source_type=> 'STATIC',
  p_display_as=> 'RADIOGROUP_WITH_SUBMIT',
  p_named_lov=> 'USE.EXISTING.COL',
  p_lov => '.'||to_char(88984827687512138 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT-TOP',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Enter the name of new primary key column.';

wwv_flow_api.create_page_item(
  p_id=>53535311089241742 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_name=>'P13_PK1_2',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 45,
  p_item_plug_id => 3214911760639290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'ID',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'New Primary Key Column',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'P13_PK1_OPTION',
  p_display_when2=>'NEW_KEY',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 30935211898422703 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_computation_sequence => 10,
  p_computation_item=> 'P13_PK1_NAME',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'wwv_flow_sw_util.generate_pk_name(replace(:F4300_P13_TABLE_NAME,'' '',''_''));',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 30936826790427024 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_computation_sequence => 10,
  p_computation_item=> 'P13_NEW_SEQUENCE',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'wwv_flow_sw_util.generate_seq_name(replace(:F4300_P13_TABLE_NAME,'' '',''_''));',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 30939126574436486 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_computation_sequence => 10,
  p_computation_item=> 'P13_PK1',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'begin'||chr(10)||
'   for c1 in ('||chr(10)||
'     select c001'||chr(10)||
'     from wwv_flow_collections'||chr(10)||
'     where collection_name = ''CSV_IMPORT'''||chr(10)||
'     and upper(c001) = ''ID'''||chr(10)||
'   ) loop'||chr(10)||
'     return c1.c001;'||chr(10)||
'   end loop;'||chr(10)||
'   for c1 in ('||chr(10)||
'     select c001'||chr(10)||
'     from wwv_flow_collections'||chr(10)||
'     where collection_name = ''CSV_IMPORT'''||chr(10)||
'     and upper(c001) like ''%ID'''||chr(10)||
'   ) loop'||chr(10)||
'     return c1.c001;'||chr(10)||
'   end loop;'||chr(10)||
'end;',
  p_compute_when => 'P13_PK1',
  p_compute_when_type=>'ITEM_IS_NULL_OR_ZERO');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 49836029235150128 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 21,
  p_computation_sequence => 10,
  p_computation_item=> 'P13_PK1_2',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'    l_pk    varchar2(40) := null;'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select c001'||chr(10)||
'                 from wwv_flow_collections'||chr(10)||
'                where collection_name = ''CSV_IMPORT'''||chr(10)||
'                  and upper(c001) = ''ID'') '||chr(10)||
'    loop'||chr(10)||
'        for i in 1..10 loop'||chr(10)||
'            for c2 in (select c001'||chr(10)||
'                         from wwv_flow_collections'||chr(10)||
'                        where collection_name = ''CSV_IMPORT'''||chr(10)||
'                          and upper(c001) = ''ID''||i) '||chr(10)||
'            loop'||chr(10)||
'                l_pk := ''ID'';'||chr(10)||
'            end loop;--c2'||chr(10)||
'            if l_pk is null then'||chr(10)||
'                return ''ID''||i;'||chr(10)||
'            else'||chr(10)||
'                l_pk := null;'||chr(10)||
'            end if;'||chr(10)||
'        end loop;--i'||chr(10)||
'    end loop;--c1'||chr(10)||
'    return ''ID'';'||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30941727052446087 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'ExSEQUENCE not null',
  p_validation_sequence=> 10,
  p_validation => 'P13_EXISTING_SEQUENCE',
  p_validation_type => 'ITEM_NOT_ZERO',
  p_error_message => 'Sequence must be specified.',
  p_validation_condition=> 'P13_PK_TYPE',
  p_validation_condition2=> 'EXISTING_SEQUENCE',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30925630552399773 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30945625105454950 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'PK_NAME available',
  p_validation_sequence=> 20,
  p_validation => 'begin'||chr(10)||
''||chr(10)||
'if not wwv_flow_builder.is_valid_identifier(''"''||:P13_PK1_NAME||''"'') '||chr(10)||
'   then return '||chr(10)||
'        wwv_flow_lang.system_message(''F4300.NOT_VALID_PK_NAME'',:P13_PK1_NAME);'||chr(10)||
'end if;'||chr(10)||
'    '||chr(10)||
'if not wwv_flow_sw_util.is_available_name(:P13_PK1_NAME, :F4300_P21_OWNER ) '||chr(10)||
'   then return '||chr(10)||
'    wwv_flow_lang.system_message(''F4300.F4500.NAME_ALREADY_USED'',:P13_PK1_NAME);'||chr(10)||
'    end if;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error.',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30920334446381977 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30946721773463492 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'ExistingPK not null',
  p_validation_sequence=> 30,
  p_validation => 'P13_PK1',
  p_validation_type => 'ITEM_NOT_NULL_OR_ZERO',
  p_error_message => 'Primary key must be specified.',
  p_validation_condition=> 'P13_PK1_OPTION',
  p_validation_condition2=> 'EXISTING_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30917206741373999 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53568824904293093 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'NewPK not null',
  p_validation_sequence=> 35,
  p_validation => 'P13_PK1_2',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Primary key must be specified.',
  p_validation_condition=> 'P13_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 53535311089241742 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53572719841301023 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'PK not > 30 chars',
  p_validation_sequence=> 38,
  p_validation => 'if length(:P13_PK1_2) > 30 then'||chr(10)||
'  return false;'||chr(10)||
'end if;'||chr(10)||
'return true;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Primary Key column name cannot be longer than 30 characters.',
  p_validation_condition=> 'P13_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 53535311089241742 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53573817894309986 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'PK gen option needs to be auto',
  p_validation_sequence=> 39,
  p_validation => 'if :P13_PK_TYPE = ''NOT_GENERATED'' then'||chr(10)||
'  return false;'||chr(10)||
'end if;'||chr(10)||
'return true;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Primary Key must be generated from a sequence when creating a new primary key.',
  p_validation_condition=> 'P13_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30923324188388493 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30948109090469229 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'PK_NAME not null',
  p_validation_sequence=> 40,
  p_validation => 'P13_PK1_NAME',
  p_validation_type => 'ITEM_NOT_NULL_OR_ZERO',
  p_error_message => 'PK name must be specified.',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30920334446381977 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30949820996482175 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'SEQ_NAME available',
  p_validation_sequence=> 50,
  p_validation => 'if not wwv_flow_builder.is_valid_identifier(''"''||:P13_NEW_SEQUENCE||''"'') then'||chr(10)||
'   return wwv_flow_lang.system_message(''F4300.F4500.NOT_VALID_SEQ_NAME'',:P13_NEW_SEQUENCE);'||chr(10)||
'end if;'||chr(10)||
'    '||chr(10)||
'if not wwv_flow_sw_util.is_available_name(:P13_NEW_SEQUENCE, :F4300_P21_OWNER) then'||chr(10)||
'   return wwv_flow_lang.system_message(''F4300.F4500.NAME_ALREADY_USED'',:P13_NEW_SEQUENCE);'||chr(10)||
'end if;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error.',
  p_validation_condition=> 'P13_PK_TYPE',
  p_validation_condition2=> 'NEW_SEQUENCE',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30927417524405418 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 49837610928173204 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_validation_name => 'no duplicate PK',
  p_validation_sequence=> 60,
  p_validation => 'declare'||chr(10)||
'    l_cnt pls_integer := 0;'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select count(c001) cnt'||chr(10)||
'               from wwv_flow_collections'||chr(10)||
'               where collection_name = ''CSV_IMPORT'''||chr(10)||
'               and upper(c001) = upper(:P13_PK1_2))'||chr(10)||
'    loop'||chr(10)||
'      l_cnt := c1.cnt;'||chr(10)||
'    end loop;'||chr(10)||
'    if l_cnt > 0 then'||chr(10)||
'      return wwv_flow_lang.system_message(''F4500.P602.DUP_COL_NAME'',:P13_PK1_2);'||chr(10)||
'    end if;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error.',
  p_validation_condition=> 'P13_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 3216129012639291 + wwv_flow_api.g_id_offset,
  p_associated_item=> 53535311089241742 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare    '||chr(10)||
'  l_cnames     wwv_flow_global.vc_arr2;  '||chr(10)||
'  l_data_type  wwv_flow_global.vc_arr2;  '||chr(10)||
'  l_upload     wwv_flow_global.vc_arr2;'||chr(10)||
'  l_max_length wwv_flow_global.vc_arr2;'||chr(10)||
'  l_seq_name   varchar2(255) := null;'||chr(10)||
'  l_pk1        varchar2(255) := :P13_PK1;'||chr(10)||
'  l_pk1_name   varchar2(255) := null;'||chr(10)||
'  i            pls_integer := 0;'||chr(10)||
'begin     '||chr(10)||
'   if :P13_PK1_OPTION = ''NEW_KEY'' then'||chr(10)||
'      i := i+1;'||chr(10)||
'      l';

p:=p||'_pk1 := replace(wwv_flow_utilities.remove_spaces(:P13_PK1_2),chr(32),''_'');      '||chr(10)||
'      if :P19_PRESERVE_CASE is null then'||chr(10)||
'        l_pk1 := upper(l_pk1);'||chr(10)||
'      end if;'||chr(10)||
'      l_cnames(i) := l_pk1;'||chr(10)||
'      l_data_type(i) := ''NUMBER'';'||chr(10)||
'      l_upload(i) := ''Y'';'||chr(10)||
'      l_max_length(i) := 30;'||chr(10)||
'   end if;'||chr(10)||
''||chr(10)||
'   for c in (select * '||chr(10)||
'             from wwv_flow_collections '||chr(10)||
'             where collection_name=''CSV_I';

p:=p||'MPORT'') loop'||chr(10)||
'     i := i+1; '||chr(10)||
'     l_cnames(i) := c.c001;'||chr(10)||
'     l_data_type(i) := c.c002;'||chr(10)||
'     l_upload(i) := c.c004;'||chr(10)||
'     l_max_length(i) := c.c005;    '||chr(10)||
'   end loop;  '||chr(10)||
'  '||chr(10)||
'  if :P13_PK_TYPE = ''NEW_SEQUENCE'' then'||chr(10)||
'    l_seq_name := :P13_NEW_SEQUENCE;'||chr(10)||
'    if :P19_PRESERVE_CASE is null then'||chr(10)||
'      l_seq_name := upper(l_seq_name);'||chr(10)||
'    end if;'||chr(10)||
'  elsif :P13_PK_TYPE = ''EXISTING_SEQUENCE'' then'||chr(10)||
'    l_seq_name ';

p:=p||':= :P13_EXISTING_SEQUENCE;'||chr(10)||
'  else'||chr(10)||
'    l_seq_name := NULL;'||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
' l_pk1_name := :P13_PK1_NAME;'||chr(10)||
' if :P19_PRESERVE_CASE is null then'||chr(10)||
'   l_pk1_name := upper(l_pk1_name);'||chr(10)||
' end if;'||chr(10)||
' wwv_flow_load_excel_data.create_table ('||chr(10)||
'  p_schema        => :F4300_P13_OWNER,'||chr(10)||
'  p_table_name    => wwv_flow_utilities.remove_spaces(:F4300_P13_TABLE_NAME),'||chr(10)||
'  p_pk1           => l_pk1,'||chr(10)||
'  p_pk1_name      => l_pk1_name,'||chr(10)||
' ';

p:=p||' p_pk1_type      => :P13_PK_TYPE,'||chr(10)||
'  p_seq_name      => l_seq_name,'||chr(10)||
'  --'||chr(10)||
'  p_cnames        => l_cnames,'||chr(10)||
'  p_data_type     => l_data_type,  '||chr(10)||
'  p_upload        => l_upload,'||chr(10)||
'  p_max_length    => l_max_length '||chr(10)||
'  ); '||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 3684120193104557 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'create table',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_when_button_id=>3216129012639291 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare'||chr(10)||
'  l_file_id                number := 0;'||chr(10)||
'  l_first_row_is_col_name  boolean := false;  '||chr(10)||
'  l_cnames                 wwv_flow_global.vc_arr2;      '||chr(10)||
'  l_upload                 wwv_flow_global.vc_arr2;  '||chr(10)||
'  i                        number := 0;'||chr(10)||
'  --'||chr(10)||
'  l_data_type              wwv_flow_global.vc_arr2;'||chr(10)||
'  l_data_format            wwv_flow_global.vc_arr2;'||chr(10)||
'  l_parsed_data_format     wwv_flow_global.v';

p:=p||'c_arr2;'||chr(10)||
'begin'||chr(10)||
'  select id'||chr(10)||
'  into l_file_id'||chr(10)||
'  from wwv_flow_files'||chr(10)||
'  where name = :F4300_P13_FILE;'||chr(10)||
'  '||chr(10)||
'  for c in (select * '||chr(10)||
'            from wwv_flow_collections '||chr(10)||
'            where collection_name=''CSV_IMPORT'') loop'||chr(10)||
'    i := i + 1;'||chr(10)||
'    l_cnames(i) := c.c001;    '||chr(10)||
'    l_upload(i) := c.c004; '||chr(10)||
'    l_data_type(i) := c.c002;  '||chr(10)||
'    l_data_format(i) := c.c006;'||chr(10)||
'    l_parsed_data_format(i) := c.c027; '||chr(10)||
'  end l';

p:=p||'oop;  '||chr(10)||
''||chr(10)||
'  if :F4300_P13_IS_COLUMN_NAME = ''Y'' then'||chr(10)||
'    l_first_row_is_col_name := true;'||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'  wwv_flow_load_data.load_csv_data ('||chr(10)||
'   p_file_id    => l_file_id,'||chr(10)||
'   p_cnames     => l_cnames,'||chr(10)||
'   p_upload     => l_upload,'||chr(10)||
'   p_schema     => :F4300_P13_OWNER,'||chr(10)||
'   p_table      => wwv_flow_utilities.remove_spaces(:F4300_P13_TABLE_NAME),'||chr(10)||
'   p_data_type             => l_data_type,'||chr(10)||
'   p_data_format     ';

p:=p||'      => l_data_format,'||chr(10)||
'   p_parsed_data_format    => l_parsed_data_format,'||chr(10)||
'   p_separator             => lower(:F4300_P13_SEPARATOR),'||chr(10)||
'   p_enclosed_by           => :F4300_P13_ENCLOSED_BY,'||chr(10)||
'   p_first_row_is_col_name => l_first_row_is_col_name,'||chr(10)||
'   p_load_to               => ''NEW'','||chr(10)||
'   p_currency              => :P18_CURRENCY,'||chr(10)||
'   p_numeric_chars         => :P18_DECIMAL_CHARACTER||:P18_GROUP_SEPARATOR';

p:=p||','||chr(10)||
'   p_charset               => :P18_FILE_CHARSET'||chr(10)||
'   );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 3685425865115644 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'insert data',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_when_button_id=>3216129012639291 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P13_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 70991424879767854 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_process_sequence=> 20,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P13_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 124003207707474021 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 21,
  p_process_sequence=> 20,
  p_process_point=> 'ON_SUBMIT_BEFORE_COMPUTATION',
  p_process_type=> 'PLSQL',
  p_process_name=> 'validate schema',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 21
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00022
prompt  ...PAGE 22: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 22,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>22,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 3218307659639310 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 22,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:18');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database schema that owns the table you would like load data into.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 3218608108639312 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 22,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:18');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'List:  Plain Text Data Import2';

wwv_flow_api.create_page_plug (
  p_id=> 4993633897692715 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 22,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24407927164467449 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 22,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 3219134873639313 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 22,
  p_button_sequence=> 10,
  p_button_plug_id => 3218307659639310+wwv_flow_api.g_id_offset,
  p_button_name    => 'CANCEL',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 3219219114639313 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 22,
  p_button_sequence=> 40,
  p_button_plug_id => 3218307659639310+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 5168423076476522 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 22,
  p_button_sequence=> 10,
  p_button_plug_id => 3218307659639310+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>3220808944639319 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 22,
  p_branch_action=> '23',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>3219219114639313+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 1,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:18');
 
wwv_flow_api.create_page_branch(
  p_id=>5168732963476526 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 22,
  p_branch_action=> '230',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>5168423076476522+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Select the database schema that owns the table you would like load data into.</p>';

wwv_flow_api.create_page_item(
  p_id=>3218923638639312 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 22,
  p_name=>'F4300_P22_TABLE_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 3218307659639310+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema',
  p_source=>'wwv_flow_user_api.get_default_schema',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'LIST_SCHEMA_OWNERS',
  p_lov => 'select htf.escape_sc(c.schema) d, c.schema v'||chr(10)||
'from   wwv_flow_company_schemas c,'||chr(10)||
'       wwv_flow_fnd_user u'||chr(10)||
'where  c.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.user_name = :flow_user and'||chr(10)||
'       (u.ALLOW_ACCESS_TO_SCHEMAS is null or'||chr(10)||
'        instr('':''||u.ALLOW_ACCESS_TO_SCHEMAS||'':'','':''||c.schema||'':'')>0)'||chr(10)||
'order by 1'||chr(10)||
'',
  p_lov_columns=> null,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Schema - ',
  p_lov_null_value=> '',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_read_only_when=>'return wwv_flow_global.g_xe',
  p_read_only_when_type=>'FUNCTION_BODY',
  p_read_only_disp_attr=>'class="fielddatabold"',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => 'Generated 20-SEP-2002 14:00:18');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4426604482085141 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 22,
  p_validation_name => 'F4300_P22_TABLE_OWNER Not Null',
  p_validation_sequence=> 1,
  p_validation => 'F4300_P22_TABLE_OWNER',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Schema must be specified.',
  p_associated_item=> 3218923638639312 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> 'generated 25-SEP-2002 14:41');
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 22
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00023
prompt  ...PAGE 23: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 23,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'SSPADAFO',
  p_last_upd_yyyymmddhh24miss => '20081110154110',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>23,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 4393421966052382 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 23,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database table you would like load data into.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 4394932009055266 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 23,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'List:  Plain Text Data Import2';

wwv_flow_api.create_page_plug (
  p_id=> 4994205631694062 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 23,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24409205478470666 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 23,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 4396513093059282 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 23,
  p_button_sequence=> 10,
  p_button_plug_id => 4393421966052382+wwv_flow_api.g_id_offset,
  p_button_name    => 'CANCEL',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 4399028677063787 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 23,
  p_button_sequence=> 10,
  p_button_plug_id => 4393421966052382+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 4397722097061813 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 23,
  p_button_sequence=> 10,
  p_button_plug_id => 4393421966052382+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>4399306417063788 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 23,
  p_branch_action=> '24',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>4399028677063787+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>4398010514061816 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 23,
  p_branch_action=> '22',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>4397722097061813+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Select the database table you would like to load data into.</p>';

wwv_flow_api.create_page_item(
  p_id=>4422107468076533 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 23,
  p_name=>'F4300_P22_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 4393421966052382+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_lov => 'select htf.escape_sc(table_name) d, table_name r'||chr(10)||
'from sys.dba_tables'||chr(10)||
'where owner = :F4300_P22_TABLE_OWNER'||chr(10)||
'and table_name not like ''BIN$%'''||chr(10)||
'order by 1',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Table -',
  p_lov_null_value=> '',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4423719242079962 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 23,
  p_validation_name => 'F4300_P22_TABLE_NAME Not Null',
  p_validation_sequence=> 1,
  p_validation => 'F4300_P22_TABLE_NAME',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Table Name must be specified.',
  p_associated_item=> 4422107468076533 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> 'generated 25-SEP-2002 14:40');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P22_TABLE_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 72468732056831287 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 23,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Verify Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 23
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00024
prompt  ...PAGE 24: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 24,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806145732',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>24,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 4881326347270024 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 24,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_header=> '<label for="file-upload" class="hideMe508">File Upload</label>',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:17');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Use this page to locate the file to be uploaded.</p> '||chr(10)||
'<p>If the first row contains columns names, select <b>First row contains column names.</b></p>'||chr(10)||
'';

wwv_flow_api.create_page_plug (
  p_id=> 4884623092270051 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 24,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:17');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'List:  Plain Text Data Import2';

wwv_flow_api.create_page_plug (
  p_id=> 4995111518695768 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 24,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 22300829469196689 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 24,
  p_plug_name=> 'Globalization',
  p_region_name=>'',
  p_plug_template=> 22227029497924836+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24410312404472697 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 24,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 4881511170270029 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 24,
  p_button_sequence=> 10,
  p_button_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_button_name    => 'CANCEL',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 4882110890270032 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 24,
  p_button_sequence=> 30,
  p_button_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 4881806795270032 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 24,
  p_button_sequence=> 20,
  p_button_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>4886114059270060 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_branch_action=> '24',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_branch_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_branch_condition=> 'F4300_P24_REUPLOAD',
  p_branch_condition_text=>'Y',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 24-SEP-2002 09:16 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>4885814721270060 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_branch_action=> '25',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>4882110890270032+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 20,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
wwv_flow_api.create_page_branch(
  p_id=>4885505563270058 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_branch_action=> '23',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>4881806795270032+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Specify to reupload the file ';

wwv_flow_api.create_page_item(
  p_id=>4882508442270037 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'F4300_P24_REUPLOAD',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 25,
  p_item_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default => 'N',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Reupload File',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX_WITH_SUBMIT',
  p_named_lov=> 'YES.NO.RETURNS_Y_OR_N',
  p_lov => '.'||to_char(88981829849493837 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P22_FILE',
  p_display_when_type=>'ITEM_IS_NOT_NULL',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the file to upload';

wwv_flow_api.create_page_item(
  p_id=>4882828903270041 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'F4300_P24_FILE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'File Name',
  p_source=>'F4300_P22_FILE',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P22_FILE',
  p_display_when_type=>'ITEM_IS_NOT_NULL',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Click <strong>Browse</strong> to locate the file to be uploaded.</p>';

wwv_flow_api.create_page_item(
  p_id=>4883411502270046 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'F4300_P22_FILE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'File',
  p_source_type=> 'STATIC',
  p_display_as=> 'FILE',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_tag_attributes  => 'id="file-upload"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P22_FILE',
  p_display_when_type=>'ITEM_IS_NULL',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => 'Generated 20-SEP-2002 14:00:17');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Select this option if your data contains column names in the first row. Consider the following example:</p>'||chr(10)||
'<pre>'||chr(10)||
'Name     Salary     Commission'||chr(10)||
'Clark    1000       10'||chr(10)||
'Scott    2000       20'||chr(10)||
'</pre>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'<pre>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Name     Salary     Commission'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Clark    1000       10'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Scott    2000       20'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'</pre>';

wwv_flow_api.create_page_item(
  p_id=>4883720326270047 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'F4300_P22_IS_COLUMN_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'Y',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'ISCOLUMN.NAME.TEXT',
  p_lov => 'select ''<span class="instructiontext">''||'||chr(10)||
'wwv_flow_lang.system_message(''F4300_INSTRUCT_TEXT'')||''</span>'' d, ''Y'' r from dual',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Identify a column separator character. Use <strong>\t</strong> for tab separators.</p>';

wwv_flow_api.create_page_item(
  p_id=>4884018850270049 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'F4300_P22_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => ',',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Separator',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Identify optional enclosed by character.</p>';

wwv_flow_api.create_page_item(
  p_id=>4884306573270049 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'F4300_P22_ENCLOSED_BY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 35,
  p_item_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Optionally Enclosed By',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>If your data contains international currency symbol, enter it here.</p>'||chr(10)||
'<p>For example, if your data has "&euro;1,234.56" or "&yen;1,234.56", enter "&euro;" or "&yen;".  Otherwise the data will not load correctly.</p>';

wwv_flow_api.create_page_item(
  p_id=>22301805705199285 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'P24_CURRENCY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 50,
  p_item_plug_id => 22300829469196689+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'declare'||chr(10)||
'    l_return_val varchar2(30) := ''$'';'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select value'||chr(10)||
'                 from nls_session_parameters'||chr(10)||
'                where parameter = ''NLS_CURRENCY'') loop'||chr(10)||
'        l_return_val := c1.value;'||chr(10)||
'        exit;'||chr(10)||
'    end loop;'||chr(10)||
'    --'||chr(10)||
'    return l_return_val;'||chr(10)||
'end;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Currency Symbol',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>A group separator is a character that separates integer groups, for example to show thousands and millions.</p>'||chr(10)||
'<p>Any character can be the group separator. The character specified must be single-byte, and the group separator must be different from any other decimal character. The character can be a space, but cannot be a numeric character or any of the following:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>';

h:=h||'plus (+)</li>'||chr(10)||
'<li>hyphen (-)</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>23030808818418892 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'P24_GROUP_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 60,
  p_item_plug_id => 22300829469196689+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_group_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Group Separator',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>The decimal character separates the integer and decimal parts of a number.</p>'||chr(10)||
'<p> Any character can be the decimal character. The character specified must be single-byte, and the decimal character must be different from group separator. The character can be a space, but cannot be any numeric character or any of the following characters:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>plus (+)</li>'||chr(10)||
'<li>hyphen (-';

h:=h||')</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>23034617391440216 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'P24_DECIMAL_CHARACTER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 70,
  p_item_plug_id => 22300829469196689+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_decimal_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Decimal Character',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose the characterset in which the text file is encoded.';

wwv_flow_api.create_page_item(
  p_id=>144116405080576290 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_name=>'P24_FILE_CHARSET',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 45,
  p_item_plug_id => 4881326347270024+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'nvl(lower(trim(owa_util.get_cgi_env(''REQUEST_IANA_CHARSET''))),''utf-8'')',
  p_item_default_type => 'PLSQL_EXPRESSION',
  p_prompt=>'File Character Set',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'I18N_IANA_CHARSET',
  p_lov => '.'||to_char(136450730164180959 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 4886415272270066 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P22_FILE',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> '',
  p_compute_when => 'F4300_P24_REUPLOAD',
  p_compute_when_text=>'Y',
  p_compute_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 50586426136538890 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_computation_sequence => 20,
  p_computation_item=> 'F4300_P22_IS_COLUMN_NAME',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'N',
  p_compute_when => 'F4300_P22_IS_COLUMN_NAME',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 4886718322270066 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 24,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P24_REUPLOAD',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'N',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4887312340270069 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 24,
  p_validation_name => 'file name not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P22_FILE',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'File must be specified.',
  p_when_button_pressed=> 4882110890270032 + wwv_flow_api.g_id_offset,
  p_associated_item=> 4883411502270046 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare  '||chr(10)||
'  l_first_row_is_col_name boolean := false;'||chr(10)||
'  l_file_id               number := 0;'||chr(10)||
'begin'||chr(10)||
'  select id'||chr(10)||
'  into l_file_id'||chr(10)||
'  from wwv_flow_files'||chr(10)||
'  where name = :F4300_P22_FILE;'||chr(10)||
'  '||chr(10)||
'  '||chr(10)||
'  if :F4300_P22_IS_COLUMN_NAME = ''Y'' then'||chr(10)||
'    l_first_row_is_col_name := true;'||chr(10)||
'  end if;'||chr(10)||
'  wwv_flow_load_data.create_csv_collection ('||chr(10)||
'   p_file_id                => l_file_id,'||chr(10)||
'   p_separator              => lower';

p:=p||'(:F4300_P22_SEPARATOR),'||chr(10)||
'   p_enclosed_by            => :F4300_P22_ENCLOSED_BY,  '||chr(10)||
'   p_first_row_is_col_name  => l_first_row_is_col_name,'||chr(10)||
'   p_currency               => :P24_CURRENCY,'||chr(10)||
'   p_numeric_chars          => :P24_DECIMAL_CHARACTER||:P24_GROUP_SEPARATOR,'||chr(10)||
'   p_charset                => :P24_FILE_CHARSET'||chr(10)||
'   );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 4887930204270074 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 24,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'create table info collection',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error creating collection using loaded data.',
  p_process_when_button_id=>4882110890270032 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 24
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00025
prompt  ...PAGE 25: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 25,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806145926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>25,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 4430432187093157 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 25,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>This page previews how your data will be loaded. Match the database column names with columns in the data. To upload columns, select <b>Yes</b> or <b>No</b>. An asterisk (*) indicates a required column.</p>'||chr(10)||
'<p>To upload data to the selected table, click <b>Import Data</b>.</p> '||chr(10)||
'<p>Use SQL Workshop to modify table attributes such as changing the column length, making not null columns, or changin';

s:=s||'g the column type.</p> '||chr(10)||
'';

wwv_flow_api.create_page_plug (
  p_id=> 4432120889099391 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 25,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'wwv_flow_load_data.display_etable_property ('||chr(10)||
'    p_table_owner     => :F4300_P22_TABLE_OWNER,'||chr(10)||
'    p_table_name      => :F4300_P22_TABLE_NAME,'||chr(10)||
'    p_collection_name => ''CSV_IMPORT'''||chr(10)||
'    );';

wwv_flow_api.create_page_plug (
  p_id=> 4433836127103757 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 25,
  p_plug_name=> 'Define Column Mapping',
  p_region_name=>'',
  p_plug_template=> 280800227642320099+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'PLSQL_PROCEDURE',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'List:  Plain Text Data Import2';

wwv_flow_api.create_page_plug (
  p_id=> 4996016020697087 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 25,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24411729373477571 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 25,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 4799118304912396 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 25,
  p_button_sequence=> 10,
  p_button_plug_id => 4430432187093157+wwv_flow_api.g_id_offset,
  p_button_name    => 'CANCEL',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 4801208046918824 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 25,
  p_button_sequence=> 10,
  p_button_plug_id => 4430432187093157+wwv_flow_api.g_id_offset,
  p_button_name    => 'FINISH',
  p_button_image_alt=> 'Load Data',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 4800026615914732 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 25,
  p_button_sequence=> 10,
  p_button_plug_id => 4430432187093157+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>4801530081918826 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 25,
  p_branch_action=> '8',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>4801208046918824+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 30,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>4799411331912402 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 25,
  p_branch_action=> '9',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>4799118304912396+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>4800306155914733 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 25,
  p_branch_action=> '24',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>4800026615914732+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 20,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Schema that owns the table to load the data into.';

wwv_flow_api.create_page_item(
  p_id=>4804810601929077 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 25,
  p_name=>'F4300_P25_TABLE_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 4430432187093157+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema:',
  p_source=>'F4300_P22_TABLE_OWNER',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the table to load data into';

wwv_flow_api.create_page_item(
  p_id=>4805623068932687 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 25,
  p_name=>'F4300_P25_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 4430432187093157+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name:',
  p_source=>'F4300_P22_TABLE_NAME',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_ESCAPE_SC',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>4924211959402572 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 25,
  p_name=>'F4300_P25_DUMMY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 4430432187093157+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_prompt=>'Dummy',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 4925731005408047 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 25,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P25_DUMMY',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'begin'||chr(10)||
'for i in 1..wwv_flow.g_f04.count loop'||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f04(i),'||chr(10)||
'     p_attr_number => 1,'||chr(10)||
'     p_attr_value => wwv_flow_utilities.remove_spaces(wwv_flow.g_f01(i))'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f04(i),'||chr(10)||
'     p_attr_number => 4,'||chr(10)||
'     p_attr_value => wwv_flow.g_f02(i)'||chr(10)||
'     );'||chr(10)||
'     '||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''CSV_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f04(i),'||chr(10)||
'     p_attr_number => 6,'||chr(10)||
'     p_attr_value => wwv_flow.g_f05(i)'||chr(10)||
'     );     '||chr(10)||
'end loop;'||chr(10)||
''||chr(10)||
'return ''true'';'||chr(10)||
''||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4809831164944430 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 25,
  p_validation_name => 'column name not null',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'  l_null_found number := 0;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
''||chr(10)||
'    if wwv_flow.g_f02(i)=''Y'' then'||chr(10)||
''||chr(10)||
'      if replace(wwv_flow.g_f01(i),''%''||''null%'',null) is null then'||chr(10)||
''||chr(10)||
'        l_null_found := l_null_found + 1;'||chr(10)||
''||chr(10)||
'      end if;'||chr(10)||
''||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_null_found > 0 then'||chr(10)||
''||chr(10)||
'    return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'    return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Column names cannot be null.',
  p_when_button_pressed=> 4801208046918824 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4810926101952404 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 25,
  p_validation_name => 'at least one upload selected',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'  l_no_count number := 0;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f02.count loop'||chr(10)||
''||chr(10)||
'    if wwv_flow.g_f02(i) = ''N'' then'||chr(10)||
''||chr(10)||
'      l_no_count := l_no_count + 1;'||chr(10)||
''||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_no_count = wwv_flow.g_f02.count then'||chr(10)||
''||chr(10)||
'    return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'    return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'At least one column must be specified to upload the data.',
  p_when_button_pressed=> 4801208046918824 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4813425670971213 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 25,
  p_validation_name => 'not null columns must be loaded',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'  l_not_null_error number := 0;'||chr(10)||
''||chr(10)||
'  l_columns        varchar2(32767) := null;'||chr(10)||
''||chr(10)||
'  l_not_null_cols  varchar2(32767) := null;'||chr(10)||
''||chr(10)||
'  l_trigger_body   long;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  l_columns := wwv_flow_utilities.table_to_string2(wwv_flow.g_f01);'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  -- get trigger body if it is before insert trigger on the selected table'||chr(10)||
''||chr(10)||
'  for c1 in (select trigger_body'||chr(10)||
''||chr(10)||
'             from sys.dba_triggers'||chr(10)||
''||chr(10)||
'             where table_name = :F4300_P22_TABLE_NAME'||chr(10)||
''||chr(10)||
'             and table_owner = :F4300_P22_TABLE_OWNER'||chr(10)||
''||chr(10)||
'             and trigger_type like ''%BEFORE%'''||chr(10)||
''||chr(10)||
'             and triggering_event like ''%INSERT%'')'||chr(10)||
''||chr(10)||
'  loop'||chr(10)||
''||chr(10)||
'     l_trigger_body := c1.trigger_body;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  -- get all not null columns'||chr(10)||
''||chr(10)||
'  for c1 in (select column_name'||chr(10)||
''||chr(10)||
'             from sys.dba_tab_columns'||chr(10)||
''||chr(10)||
'             where table_name = :F4300_P22_TABLE_NAME'||chr(10)||
''||chr(10)||
'             and owner = :F4300_P22_TABLE_OWNER'||chr(10)||
''||chr(10)||
'             and nullable = ''N'''||chr(10)||
''||chr(10)||
'             ) loop'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'      for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
''||chr(10)||
'        -- If column names user selected is equal to not null columns,'||chr(10)||
''||chr(10)||
'        -- user didn''t include to upload'||chr(10)||
''||chr(10)||
'        -- and the column doesn''t have trigger, raise an error.'||chr(10)||
''||chr(10)||
'        if (wwv_flow.g_f01(i) = c1.column_name) then'||chr(10)||
''||chr(10)||
'          if wwv_flow.g_f02(i) = ''N'' then'||chr(10)||
''||chr(10)||
'            if instr(nvl(UPPER(l_trigger_body),'' ''),c1.column_name) = 0 then'||chr(10)||
''||chr(10)||
'              l_not_null_error := l_not_null_error + 1;'||chr(10)||
''||chr(10)||
'              l_not_null_cols := l_not_null_cols||'',''||c1.column_name;'||chr(10)||
''||chr(10)||
'            end if;'||chr(10)||
''||chr(10)||
'          end if;'||chr(10)||
''||chr(10)||
'        else'||chr(10)||
''||chr(10)||
'          -- If user did not select not null columns,'||chr(10)||
''||chr(10)||
'          -- and the column doesn''t have trigger'||chr(10)||
''||chr(10)||
'          -- raise an error.'||chr(10)||
''||chr(10)||
'          if instr(l_columns,c1.column_name) = 0 then'||chr(10)||
''||chr(10)||
'            if instr(nvl(UPPER(l_trigger_body),'' ''),c1.column_name) = 0 then'||chr(10)||
''||chr(10)||
'              l_not_null_error := l_not_null_error + 1;'||chr(10)||
''||chr(10)||
'              l_not_null_cols := l_not_null_cols||'',''||c1.column_name;'||chr(10)||
''||chr(10)||
'            end if;'||chr(10)||
''||chr(10)||
'          end if;'||chr(10)||
''||chr(10)||
'        end if;'||chr(10)||
''||chr(10)||
'      end loop;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_not_null_error > 0 then'||chr(10)||
''||chr(10)||
'      return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'      return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'There are NOT NULL columns in &F4300_P22_TABLE_OWNER..&F4300_P22_TABLE_NAME..  Select to upload the data without an error.',
  p_when_button_pressed=> 4801208046918824 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 4855818895130126 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 25,
  p_validation_name => 'duplicate column names',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
'  l_col       varchar2(32767) := null;'||chr(10)||
'  l_duplicate boolean := true;'||chr(10)||
'begin'||chr(10)||
'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'    -- if column selected is to be uploaded, check for duplicate column selection'||chr(10)||
'    if wwv_flow.g_f02(i) = ''Y'' then'||chr(10)||
'        if instr(nvl(l_col,'' ''), ('':'' || wwv_flow.g_f01(i) || '':'')) > 0 then'||chr(10)||
'          l_duplicate := false;'||chr(10)||
'        end if;'||chr(10)||
'        if i > 1 then'||chr(10)||
'            l_col := l_col || wwv_flow.g_f01(i) || '':'';'||chr(10)||
'        else'||chr(10)||
'            l_col := '':'' || wwv_flow.g_f01(i) || '':'' ;'||chr(10)||
'        end if;'||chr(10)||
'    end if;'||chr(10)||
'  end loop;'||chr(10)||
'  return l_duplicate;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Duplicate column names selected.',
  p_when_button_pressed=> 4801208046918824 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare'||chr(10)||
'  l_file_id                number := 0;'||chr(10)||
'  l_first_row_is_col_name  boolean := false;'||chr(10)||
'  l_cnames                 wwv_flow_global.vc_arr2;'||chr(10)||
'  --'||chr(10)||
'  l_data_types             wwv_flow_global.vc_arr2;'||chr(10)||
'  l_parsed_data_format     wwv_flow_global.vc_arr2;'||chr(10)||
'  j                        pls_integer := 0;'||chr(10)||
'begin'||chr(10)||
'  select id'||chr(10)||
'  into l_file_id'||chr(10)||
'  from wwv_flow_files'||chr(10)||
'  where name = :F4300_P22_FILE;'||chr(10)||
''||chr(10)||
'  if :F4300';

p:=p||'_P22_IS_COLUMN_NAME = ''Y'' then'||chr(10)||
'    l_first_row_is_col_name := true;'||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'    l_cnames(i) := wwv_flow.g_f01(i);'||chr(10)||
'    '||chr(10)||
'    for c1 in (select data_type'||chr(10)||
'               from sys.dba_tab_columns'||chr(10)||
'               where owner = :F4300_P22_TABLE_OWNER'||chr(10)||
'               and table_name = :F4300_P22_TABLE_NAME'||chr(10)||
'               and column_name = wwv_flow.g_f01(i)'||chr(10)||
'         ';

p:=p||'      order by column_id)'||chr(10)||
'    loop'||chr(10)||
'       l_data_types(i) := c1.data_type;    	'||chr(10)||
'    end loop;    '||chr(10)||
'  end loop;'||chr(10)||
'  '||chr(10)||
'  for c in (select * '||chr(10)||
'            from wwv_flow_collections '||chr(10)||
'            where collection_name=''CSV_IMPORT'') loop'||chr(10)||
'    j := j + 1;    '||chr(10)||
'    l_parsed_data_format(j) := c.c027; '||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
'  wwv_flow_load_data.load_csv_data ('||chr(10)||
'   p_file_id    => l_file_id,'||chr(10)||
'   p_cnames     => l_cnames,'||chr(10)||
'   p';

p:=p||'_upload     => wwv_flow.g_f02,'||chr(10)||
'   p_schema     => :F4300_P22_TABLE_OWNER,'||chr(10)||
'   p_table      => :F4300_P22_TABLE_NAME,'||chr(10)||
'   p_data_type  => l_data_types,'||chr(10)||
'   p_data_format => wwv_flow.g_f05,'||chr(10)||
'   p_parsed_data_format => l_parsed_data_format,'||chr(10)||
'   p_separator  => lower(:F4300_P22_SEPARATOR),'||chr(10)||
'   p_enclosed_by => :F4300_P22_ENCLOSED_BY,'||chr(10)||
'   p_first_row_is_col_name => l_first_row_is_col_name,'||chr(10)||
'   p_load_to       ';

p:=p||'        => ''EXIST'','||chr(10)||
'   p_currency              => :P24_CURRENCY,'||chr(10)||
'   p_numeric_chars         => :P24_DECIMAL_CHARACTER||:P24_GROUP_SEPARATOR,'||chr(10)||
'   p_charset               => :P24_FILE_CHARSET'||chr(10)||
'   );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 4865111332232044 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 25,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'insert data',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error inserting data.',
  p_process_when_button_id=>4801208046918824 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P22_TABLE_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 124000330947433341 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 25,
  p_process_sequence=> 20,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'security check',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P22_TABLE_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 124001431555452460 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 25,
  p_process_sequence=> 1,
  p_process_point=> 'ON_SUBMIT_BEFORE_COMPUTATION',
  p_process_type=> 'PLSQL',
  p_process_name=> 'security check',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 25
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00070
prompt  ...PAGE 70: Unload to XML
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 70,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload to XML',
  p_step_title=> 'Unload to XML',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216782707569420532+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>70,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 1051647128013126 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 70,
  p_plug_name=> 'Unload to XML',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 1051647135041546 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 70,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 105468428380073513 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7740517585503413 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 70,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>You can export the contents of a table to an XML document.</p>'||chr(10)||
'<p>Select the database schema that owns the table you would like export.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222245318758681593 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 70,
  p_plug_name=> 'Unload to XML',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 110137809709235404 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 70,
  p_button_sequence=> 10,
  p_button_plug_id => 1051647128013126+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 1051647138054209 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 70,
  p_button_sequence=> 10,
  p_button_plug_id => 1051647128013126+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>1051647141054219 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 70,
  p_branch_action=> '80',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>1051647138054209+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database schema that owns the object you would like to export.';

wwv_flow_api.create_page_item(
  p_id=>1051647130018425 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 70,
  p_name=>'F4300_P70_SCHEMA',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 1051647128013126+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema',
  p_source=>'wwv_flow_user_api.get_default_schema',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'LIST_SCHEMA_OWNERS',
  p_lov => 'select htf.escape_sc(c.schema) d, c.schema v'||chr(10)||
'from   wwv_flow_company_schemas c,'||chr(10)||
'       wwv_flow_fnd_user u'||chr(10)||
'where  c.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.user_name = :flow_user and'||chr(10)||
'       (u.ALLOW_ACCESS_TO_SCHEMAS is null or'||chr(10)||
'        instr('':''||u.ALLOW_ACCESS_TO_SCHEMAS||'':'','':''||c.schema||'':'')>0)'||chr(10)||
'order by 1'||chr(10)||
'',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 62227210707637212 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 70,
  p_validation_name => 'schema not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P70_SCHEMA',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Schema must be specified.',
  p_when_button_pressed=> 1051647138054209 + wwv_flow_api.g_id_offset,
  p_associated_item=> 1051647130018425 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 70
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00080
prompt  ...PAGE 80: Unload to XML
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 80,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload to XML',
  p_step_title=> 'Unload to XML',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216782707569420532+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'SSPADAFO',
  p_last_upd_yyyymmddhh24miss => '20081110154317',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>80,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 1051647150061437 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 80,
  p_plug_name=> 'Unload to XML',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 1051647154061439 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 80,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 105468428380073513 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7894736260599100 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 80,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database table you would like export to an XML document.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222251733087695225 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 80,
  p_plug_name=> 'Unload to XML',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 110146336374243031 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 80,
  p_button_sequence=> 10,
  p_button_plug_id => 1051647150061437+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 1051647144061404 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 80,
  p_button_sequence=> 10,
  p_button_plug_id => 1051647150061437+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 1051647161084520 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 80,
  p_button_sequence=> 5,
  p_button_plug_id => 1051647150061437+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>1051647146061406 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 80,
  p_branch_action=> '90',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>1051647144061404+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>1051647164084530 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 80,
  p_branch_action=> '70',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>1051647161084520+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database object name you would like to export to an XML file format.';

wwv_flow_api.create_page_item(
  p_id=>1051647148061413 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 80,
  p_name=>'F4300_P80_XML_EXPORT_TABLE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 1051647150061437+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_lov => 'select htf.escape_sc(table_name) d, table_name v'||chr(10)||
'from sys.dba_tables'||chr(10)||
'where owner=:F4300_P70_SCHEMA'||chr(10)||
'and table_name not like ''BIN$%'''||chr(10)||
'order by 1',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Table -',
  p_lov_null_value=> '',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 62230130231652350 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 80,
  p_validation_name => 'export table not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P80_XML_EXPORT_TABLE',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Export Table must be specified.',
  p_when_button_pressed=> 1051647144061404 + wwv_flow_api.g_id_offset,
  p_associated_item=> 1051647148061413 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P70_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 70978315697727364 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 80,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 80
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00090
prompt  ...PAGE 90: Unload to XML
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 90,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload to XML',
  p_step_title=> 'Unload to XML',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216782707569420532+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806151820',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>90,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 1051647181099858 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 90,
  p_plug_name=> 'Unload to XML',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 1051647185099859 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 90,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 105468428380073513 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7895812842601765 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 90,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the columns you would like to be part of this XML document.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222259712702717670 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 90,
  p_plug_name=> 'Unload to XML',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 110155005815253120 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 90,
  p_button_sequence=> 10,
  p_button_plug_id => 1051647181099858+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 1051647207274614 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 90,
  p_button_sequence=> 10,
  p_button_plug_id => 1051647181099858+wwv_flow_api.g_id_offset,
  p_button_name    => 'EXPORTDATA',
  p_button_image_alt=> 'Unload Data',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'javascript:doSubmit(''EXPORTDATA'');',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 1051647173099843 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 90,
  p_button_sequence=> 5,
  p_button_plug_id => 1051647181099858+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>1051647175099846 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 90,
  p_branch_action=> '90',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>1051647177099846 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 90,
  p_branch_action=> '80',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>1051647173099843+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database object columns you would like to export to an XML document.';

wwv_flow_api.create_page_item(
  p_id=>1051647179099849 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 90,
  p_name=>'F4300_P90_XML_EXPORT_COLUMNS',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 1051647181099858+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Columns',
  p_source_type=> 'STATIC',
  p_display_as=> 'MULTIPLESELECT',
  p_lov => 'select htf.escape_sc(column_name) d, column_name r'||chr(10)||
''||chr(10)||
'from sys.dba_tab_columns'||chr(10)||
''||chr(10)||
'where table_name= :F4300_P80_XML_EXPORT_TABLE'||chr(10)||
''||chr(10)||
'and owner =:F4300_P70_SCHEMA',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 10,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'LEFT-TOP',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>74537508872251201 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 90,
  p_name=>'P90_FILE_EXPORT',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 1051647181099858+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'EXPORT.AS.FILE.Y',
  p_lov => '.'||to_char(88995410248613750 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>197731232029175764 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 90,
  p_name=>'P90_X',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 1051647181099858+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_display_as=> 'STOP_AND_START_HTML_TABLE',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Enter SQL WHERE clause to limit the rows that are selected.  For example:'||chr(10)||
'<pre>'||chr(10)||
'DEPTNO = 10'||chr(10)||
'</pre>';

wwv_flow_api.create_page_item(
  p_id=>197732008958178601 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 90,
  p_name=>'P90_WHERE_CLAUSE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 1051647181099858+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Where Clause',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXTAREA',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 60,
  p_cMaxlength=> 4000,
  p_cHeight=> 5,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'ABOVE',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 242243907803371941 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 90,
  p_computation_sequence => 10,
  p_computation_item=> 'P90_WHERE_CLAUSE',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare '||chr(10)||
'  w varchar2(30000);'||chr(10)||
'begin'||chr(10)||
'  w := :p90_where_clause;'||chr(10)||
'  for i in 1..10 loop'||chr(10)||
'    w := rtrim(rtrim(rtrim(trim(w),'';/ ''),chr(10)),chr(13));'||chr(10)||
'  end loop;'||chr(10)||
'  return w;'||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 62232012701656765 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 90,
  p_validation_name => 'export cols not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P90_XML_EXPORT_COLUMNS',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Export Columns must be specified.',
  p_when_button_pressed=> 1051647207274614 + wwv_flow_api.g_id_offset,
  p_associated_item=> 1051647179099849 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 100863708106391790 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 90,
  p_validation_name => 'no row exists',
  p_validation_sequence=> 20,
  p_validation => 'declare'||chr(10)||
'  l_cnt    number := 0;  '||chr(10)||
'  l_sql    varchar2(32767) := null;'||chr(10)||
'begin    '||chr(10)||
'  l_sql := ''select count(*) from "''||:F4300_P80_XML_EXPORT_TABLE||''"'';'||chr(10)||
'                                             '||chr(10)||
'  l_cnt := wwv_flow_f4000_util.select_num (p_sql => l_sql, p_user => :F4300_P70_SCHEMA);'||chr(10)||
'  '||chr(10)||
'  if l_cnt = 0 then'||chr(10)||
'    return false;'||chr(10)||
'  else'||chr(10)||
'    return true;'||chr(10)||
'  end if;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The selected table does not have any records to export.  Please populate the table with data before doing an export.',
  p_when_button_pressed=> 1051647207274614 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare'||chr(10)||
'   xml_cols wwv_flow_global.vc_arr2;'||chr(10)||
'begin'||chr(10)||
'  insert into wwv_flow_data_load_unload (DATA_TYPE,  DATA_SCHEMA, DATA_TABLE)'||chr(10)||
'  values'||chr(10)||
'        (''XML EXPORT'', :F4300_P70_SCHEMA, :F4300_P80_XML_EXPORT_TABLE);'||chr(10)||
'  '||chr(10)||
'  --'||chr(10)||
'  -- if XML file export, define mime header'||chr(10)||
'  --'||chr(10)||
'  wwv_flow_init_htp_buffer;'||chr(10)||
'  wwv_flow.g_page_text_generated := true;'||chr(10)||
'  wwv_flow.g_unrecoverable_error := true;'||chr(10)||
'  owa_util.mime_heade';

p:=p||'r (''text/xml'',false, ''utf-8'');  '||chr(10)||
'  if :P90_FILE_EXPORT = ''Y'' then'||chr(10)||
'    htp.p(''Content-Disposition: attachment; filename=''|| wwv_flow_utilities.escape_url( p_url => lower(:F4300_P80_XML_EXPORT_TABLE), p_url_charset => ''utf-8'')||''.xml'');'||chr(10)||
'  else'||chr(10)||
'    htp.p(''Content-Disposition: inline '' );'||chr(10)||
'  end if;'||chr(10)||
'  owa_util.http_header_close;'||chr(10)||
''||chr(10)||
'  xml_cols:= wwv_flow_utilities.string_to_table2(:F4300_P90_XML_EXPORT_CO';

p:=p||'LUMNS);'||chr(10)||
'  '||chr(10)||
'  wwv_flow_dataload_xml.GETQUERYXMLPAGE (p_schema=>:F4300_P70_SCHEMA, '||chr(10)||
'                  p_table=>:F4300_P80_XML_EXPORT_TABLE, '||chr(10)||
'                  p_columns=> xml_cols,'||chr(10)||
'                  p_where => :P90_WHERE_CLAUSE ); '||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 1051647243259047 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 90,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'start_xml_download',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_when_button_id=>1051647207274614 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P70_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 124049436385652584 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 90,
  p_process_sequence=> 1,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'validate schema',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P70_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 124050721624657785 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 90,
  p_process_sequence=> 20,
  p_process_point=> 'ON_SUBMIT_BEFORE_COMPUTATION',
  p_process_type=> 'PLSQL',
  p_process_name=> 'validate schema',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 90
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00150
prompt  ...PAGE 150: Unload to Text
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 150,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload to Text',
  p_step_title=> 'Unload to Text',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>150,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7741724165505356 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 150,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28206717711661655 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 150,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28207120615661656 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 150,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>You can unload the contents of a table to a structured text file.  For example you can export an entire table to a comma delimited file (.CSV).</p>'||chr(10)||
'<p>Select the database schema that owns the table you would like unload to Text.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 221894512328490442 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 150,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> 'Unable to display page region #SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> 'Region generated 20-SEP-2002 14:00:18');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 110113025938211620 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 150,
  p_button_sequence=> 10,
  p_button_plug_id => 28206717711661655+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 28206104485661637 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 150,
  p_button_sequence=> 10,
  p_button_plug_id => 28206717711661655+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>28206329170661642 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 150,
  p_branch_action=> '160',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>28206104485661637+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database schema that owns the object you would like to export.';

wwv_flow_api.create_page_item(
  p_id=>28206527664661645 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 150,
  p_name=>'F4300_P150_SCHEMA',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 28206717711661655+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema',
  p_source=>'wwv_flow_user_api.get_default_schema',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'LIST_SCHEMA_OWNERS',
  p_lov => 'select htf.escape_sc(c.schema) d, c.schema v'||chr(10)||
'from   wwv_flow_company_schemas c,'||chr(10)||
'       wwv_flow_fnd_user u'||chr(10)||
'where  c.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.user_name = :flow_user and'||chr(10)||
'       (u.ALLOW_ACCESS_TO_SCHEMAS is null or'||chr(10)||
'        instr('':''||u.ALLOW_ACCESS_TO_SCHEMAS||'':'','':''||c.schema||'':'')>0)'||chr(10)||
'order by 1'||chr(10)||
'',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 66652013014009695 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 150,
  p_validation_name => 'schema not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P150_SCHEMA',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Schema must be specified.',
  p_when_button_pressed=> 28206104485661637 + wwv_flow_api.g_id_offset,
  p_associated_item=> 28206527664661645 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 150
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00160
prompt  ...PAGE 160: Unload to Text
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 160,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload to Text',
  p_step_title=> 'Unload to Text',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'SSPADAFO',
  p_last_upd_yyyymmddhh24miss => '20081110154816',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>160,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7897429119606410 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 160,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28209233156686004 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 160,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28209605053686006 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 160,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database table you would like unload to a plain text format.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 221934021042597091 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 160,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top" align="right"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 110118711871217065 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 160,
  p_button_sequence=> 10,
  p_button_plug_id => 28209233156686004+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 28208228100685999 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 160,
  p_button_sequence=> 10,
  p_button_plug_id => 28209233156686004+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 28208427169686000 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 160,
  p_button_sequence=> 5,
  p_button_plug_id => 28209233156686004+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>28208830359686002 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 160,
  p_branch_action=> '170',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>28208228100685999+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>28208627860686001 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 160,
  p_branch_action=> '150',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>28208427169686000+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database table you would like export to a plain text format.';

wwv_flow_api.create_page_item(
  p_id=>28209023993686003 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 160,
  p_name=>'F4300_P160_ASC_EXPORT_TABLE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 28209233156686004+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_lov => 'select htf.escape_sc(table_name) a, table_name b'||chr(10)||
'from sys.dba_tables'||chr(10)||
'where owner=:F4300_P150_SCHEMA'||chr(10)||
'and table_name not like ''BIN$%'''||chr(10)||
'order by table_name',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Table -',
  p_lov_null_value=> '',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 66654429637014415 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 160,
  p_validation_name => 'export table not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P160_ASC_EXPORT_TABLE',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Export table must be specified.',
  p_when_button_pressed=> 28208228100685999 + wwv_flow_api.g_id_offset,
  p_associated_item=> 28209023993686003 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P150_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 70976528379721584 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 160,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 160
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00170
prompt  ...PAGE 170: Unload to Text
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 170,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload to Text',
  p_step_title=> 'Unload to Text',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'SSPADAFO',
  p_last_upd_yyyymmddhh24miss => '20081110203648',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>170,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7898806740609503 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 170,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28212528301717953 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 170,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28212908823717954 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 170,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'select owner, '||chr(10)||
'table_name, '||chr(10)||
'column_name,'||chr(10)||
'data_type'||chr(10)||
'from sys.dba_tab_columns'||chr(10)||
'where owner = :F4300_P150_SCHEMA'||chr(10)||
'and table_name = :F4300_P160_ASC_EXPORT_TABLE'||chr(10)||
'and data_type in (''SDO_GEOMETRY'',''BLOB'',''BFILE'',''ORDAUDIO'',''ORDIMAGE'',''ORDIMAGESIGNATURE'',''ORDVIDEO'',''ORDDOC'',''URITYPE'',''DBURITYPE'',''XDBURITYPE'',''HTTPURITYPE'',''XMLTYPE'')';

wwv_flow_api.create_report_region (
  p_id=> 58341617723961092 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 170,
  p_name=> 'Columns Unable to Unload',
  p_region_name=>'',
  p_template=> 22227029497924836+ wwv_flow_api.g_id_offset,
  p_display_sequence=> 50,
  p_display_column=> 1,
  p_display_point=> 'AFTER_SHOW_ITEMS',
  p_source=> s,
  p_source_type=> 'SQL_QUERY',
  p_display_error_message=> '#SQLERRM#',
  p_display_when_condition=> 'select 1'||chr(10)||
'from sys.dba_tab_columns'||chr(10)||
'where owner = :F4300_P150_SCHEMA'||chr(10)||
'and table_name = :F4300_P160_ASC_EXPORT_TABLE'||chr(10)||
'and data_type in (''SDO_GEOMETRY'',''BLOB'',''BFILE'',''ORDAUDIO'',''ORDIMAGE'',''ORDIMAGESIGNATURE'',''ORDVIDEO'',''ORDDOC'',''URITYPE'',''DBURITYPE'',''XDBURITYPE'',''HTTPURITYPE'',''XMLTYPE'')',
  p_display_condition_type=> 'EXISTS',
  p_plug_caching=> 'NOT_CACHED',
  p_customized=> '0',
  p_translate_title=> 'Y',
  p_query_row_template=> 11634930157712121+ wwv_flow_api.g_id_offset,
  p_query_headings_type=> 'COLON_DELMITED_LIST',
  p_query_num_rows=> '500',
  p_query_options=> 'DERIVED_REPORT_COLUMNS',
  p_query_show_nulls_as=> ' - ',
  p_query_break_cols=> '1:2',
  p_query_no_data_found=> 'No data found.',
  p_query_num_rows_type=> 'NEXT_PREVIOUS_LINKS',
  p_query_row_count_max=> '500',
  p_pagination_display_position=> 'BOTTOM_RIGHT',
  p_break_type_flag=> 'DEFAULT_BREAK_FORMATTING',
  p_csv_output=> 'N',
  p_query_asc_image=> 'arrow_down_gray_dark.gif',
  p_query_asc_image_attr=> 'width="13" height="12"',
  p_query_desc_image=> 'arrow_up_gray_dark.gif',
  p_query_desc_image_attr=> 'width="13" height="12"',
  p_plug_query_strip_html=> 'Y',
  p_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 58341916010961103 + wwv_flow_api.g_id_offset,
  p_region_id=> 58341617723961092 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 1,
  p_form_element_id=> null,
  p_column_alias=> 'OWNER',
  p_column_display_sequence=> 1,
  p_column_heading=> 'Schema',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 58342006854961103 + wwv_flow_api.g_id_offset,
  p_region_id=> 58341617723961092 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 2,
  p_form_element_id=> null,
  p_column_alias=> 'TABLE_NAME',
  p_column_display_sequence=> 2,
  p_column_heading=> 'Table',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 58342126345961103 + wwv_flow_api.g_id_offset,
  p_region_id=> 58341617723961092 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 3,
  p_form_element_id=> null,
  p_column_alias=> 'COLUMN_NAME',
  p_column_display_sequence=> 3,
  p_column_heading=> 'Column',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
begin
s := null;
wwv_flow_api.create_report_columns (
  p_id=> 58363908121015131 + wwv_flow_api.g_id_offset,
  p_region_id=> 58341617723961092 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_query_column_id=> 4,
  p_form_element_id=> null,
  p_column_alias=> 'DATA_TYPE',
  p_column_display_sequence=> 4,
  p_column_heading=> 'Data Type',
  p_column_alignment=>'LEFT',
  p_heading_alignment=>'LEFT',
  p_default_sort_column_sequence=>0,
  p_disable_sort_column=>'Y',
  p_sum_column=> 'N',
  p_hidden_column=> 'N',
  p_display_as=>'WITHOUT_MODIFICATION',
  p_pk_col_source=> s,
  p_column_comment=>'');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the columns you would like to be part of this plain text file.  Only Oracle built in data types except BLOB and BFILE are supported to unload.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 221943719703625116 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 170,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 110126228147221772 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 170,
  p_button_sequence=> 10,
  p_button_plug_id => 28212528301717953+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 28211125976717944 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 170,
  p_button_sequence=> 10,
  p_button_plug_id => 28212528301717953+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 28211316463717945 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 170,
  p_button_sequence=> 5,
  p_button_plug_id => 28212528301717953+wwv_flow_api.g_id_offset,
  p_button_name    => 'PREVIOUS',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>28211734842717946 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 170,
  p_branch_action=> '180',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>28211125976717944+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>28211915700717947 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 170,
  p_branch_action=> '160',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>28211316463717945+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the columns you would like to be part of this plain text file. Only Oracle built in data types except BLOB and BFILE are supported to unload.';

wwv_flow_api.create_page_item(
  p_id=>28212131214717948 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 170,
  p_name=>'F4300_P170_ASC_EXPORT_COLUMNS',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 28212528301717953+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Columns',
  p_source_type=> 'STATIC',
  p_display_as=> 'MULTIPLESELECT',
  p_lov => 'select htf.escape_sc(column_name) a, column_name b'||chr(10)||
'from sys.dba_tab_columns'||chr(10)||
'where table_name= :F4300_P160_ASC_EXPORT_TABLE'||chr(10)||
'and owner =:F4300_P150_SCHEMA'||chr(10)||
'and data_type not in (''SDO_GEOMETRY'',''BLOB'',''BFILE'',''ORDAUDIO'',''ORDIMAGE'',''ORDIMAGESIGNATURE'',''ORDVIDEO'',''ORDDOC'',''URITYPE'',''DBURITYPE'',''XDBURITYPE'',''HTTPURITYPE'',''XMLTYPE'')',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 10,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT-TOP',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identifies selected table.';

wwv_flow_api.create_page_item(
  p_id=>197711311888065889 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 170,
  p_name=>'P170_TABLE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 2,
  p_item_plug_id => 28212528301717953+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default => '&F4300_P160_ASC_EXPORT_TABLE.',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table:',
  p_source=>'F4300_P160_ASC_EXPORT_TABLE',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_ESCAPE_SC',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap',
  p_cattributes_element=>'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Enter SQL WHERE clause to limit the rows that are selected.  For example:'||chr(10)||
'<pre>'||chr(10)||
'DEPTNO = 10'||chr(10)||
'</pre>';

wwv_flow_api.create_page_item(
  p_id=>197715213750075919 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 170,
  p_name=>'P170_WHERE_CLAUSE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 28212528301717953+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Where Clause',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXTAREA',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 60,
  p_cMaxlength=> 2000,
  p_cHeight=> 6,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 2,
  p_rowspan => 1,
  p_label_alignment  => 'ABOVE',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>197716634182081826 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 170,
  p_name=>'P170_X',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 11,
  p_item_plug_id => 28212528301717953+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_display_as=> 'STOP_AND_START_HTML_TABLE',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 242241611351354121 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 170,
  p_computation_sequence => 10,
  p_computation_item=> 'P170_WHERE_CLAUSE',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare w varchar2(30000);'||chr(10)||
'begin'||chr(10)||
'w := :P170_WHERE_CLAUSE;'||chr(10)||
'for i in 1..10 loop'||chr(10)||
'  w := rtrim(rtrim(rtrim(trim(w),'';/ ''),chr(10)),chr(13));'||chr(10)||
'end loop;'||chr(10)||
'return w;'||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 66656211068018504 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 170,
  p_validation_name => 'export col not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P170_ASC_EXPORT_COLUMNS',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Export columns must be specified.',
  p_when_button_pressed=> 28211125976717944 + wwv_flow_api.g_id_offset,
  p_associated_item=> 28212131214717948 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P150_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 197708311757056408 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 170,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'validate schema',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 170
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00180
prompt  ...PAGE 180: Unload to Text
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 180,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Unload to Text',
  p_step_title=> 'Unload to Text',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216783110339421284+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'JOEL',
  p_last_upd_yyyymmddhh24miss => '20080930135448',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>180,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7899913666611503 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 180,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28214407848750928 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 180,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 28215311946817336 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 180,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => '(null)',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'Specify the type of separator to be used to separate column values on each line and how to identify text strings in a column.';

wwv_flow_api.create_page_plug (
  p_id=> 221947834379638760 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 180,
  p_plug_name=> 'Unload to Text',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 110132111656226458 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 180,
  p_button_sequence=> 10,
  p_button_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 28214908893807774 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 180,
  p_button_sequence=> 10,
  p_button_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_button_name    => 'EXPORTDATA',
  p_button_image_alt=> 'Unload Data',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'javascript:doSubmit(''EXPORTDATA'');',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 28215635081826921 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 180,
  p_button_sequence=> 10,
  p_button_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_button_name    => 'previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>152140013661025653 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_branch_action=> 'f?p=&APP_ID.:180:&SESSION.::&DEBUG.:::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_when_button_id=>28214908893807774+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 14-AUG-2003 17:18 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>28215926322826925 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_branch_action=> '170',
  p_branch_point=> 'BEFORE_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>28215635081826921+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'If you wish to export the data with column names, check mark this item.';

wwv_flow_api.create_page_item(
  p_id=>6632125108952026 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_name=>'F4300_P180_INC_COLUMN_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'INCLUDE.COL.NAMES.Y',
  p_lov => '.'||to_char(88997219729625956 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<div class="htmldbInfoBodyP">Specify the type of separator used to separate the column values on each line.</div> '||chr(10)||
'<div class="htmldbInfoBodyP">The default value is a comma (<code>,</code>). To use a tab as a column separator, enter a backslash followed by the letter "t" (<code>	</code>).</div>';

wwv_flow_api.create_page_item(
  p_id=>28214807201801619 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_name=>'F4300_P180_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => ',',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Separator',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the character set to encode the export file.'||chr(10)||
'';

wwv_flow_api.create_page_item(
  p_id=>143879229190060655 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_name=>'P180_FILE_CHARSET',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 50,
  p_item_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default => 'nvl(lower(trim(owa_util.get_cgi_env(''REQUEST_IANA_CHARSET''))),''utf-8'')',
  p_item_default_type => 'PLSQL_EXPRESSION',
  p_prompt=>'File Character Set',
  p_source_type=> 'ALWAYS_NULL',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'I18N_IANA_CHARSET',
  p_lov => '.'||to_char(136450730164180959 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_cattributes_element=>'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 3,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose DOS to have the lines in the resulting file terminated by carriage returns and line feeds.  Choose UNIX to have the lines in the resulting file contain terminated by line feeds.  ';

wwv_flow_api.create_page_item(
  p_id=>144236027637628636 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_name=>'P180_FILE_FORMAT',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'File Format',
  p_source=>'wwv_flow_lang.system_message(p_name=>''F4300.P180_FILE_FORMAT'')',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'EXPORT.FILE_FORMAT',
  p_lov => '.'||to_char(144234407205622759 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Use this option to specify how to identify text strings in a column. You can specify single or double quotation marks.';

wwv_flow_api.create_page_item(
  p_id=>163936229263228689 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_name=>'F4300_P180_ENCLOSED',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Optionally Enclosed By',
  p_source_type=> 'ALWAYS_NULL',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identifies selected table.';

wwv_flow_api.create_page_item(
  p_id=>197718708818093340 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 180,
  p_name=>'P180_TABLE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 1,
  p_item_plug_id => 28214407848750928+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default => '&F4300_P160_ASC_EXPORT_TABLE.',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table:',
  p_source=>'F4300_P160_ASC_EXPORT_TABLE',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_ESCAPE_SC',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap',
  p_cattributes_element=>'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare'||chr(10)||
'   ascii_cols  wwv_flow_global.vc_arr2;'||chr(10)||
'   l_query     varchar2(4000);'||chr(10)||
'   l_sep       varchar2(1):=NULL;'||chr(10)||
'   l_cnt       number;'||chr(10)||
'   w           varchar2(4000); '||chr(10)||
'begin'||chr(10)||
'  ascii_cols:= wwv_flow_utilities.string_to_table2(:F4300_P170_ASC_EXPORT_COLUMNS);'||chr(10)||
'  l_query:=''select '';'||chr(10)||
'  for i in 1..ascii_cols.count'||chr(10)||
'  loop  	'||chr(10)||
'    l_query:=l_query || l_sep || ''"''|| ascii_cols(i) ||''"'';'||chr(10)||
'    l_sep   :='',''; ';

p:=p||'  '||chr(10)||
'  end loop;'||chr(10)||
'  l_query := l_query || '' from "'' || :F4300_P150_SCHEMA || ''"."'' ||:F4300_P160_ASC_EXPORT_TABLE||''"'';'||chr(10)||
''||chr(10)||
'  if :P170_WHERE_CLAUSE is not null then'||chr(10)||
'     w := trim(:P170_WHERE_CLAUSE);'||chr(10)||
'     if upper(substr(w,1,5)) = ''WHERE'' then'||chr(10)||
'        w := substr(w,6);'||chr(10)||
'     end if;'||chr(10)||
'     l_query := l_query||'' where ''||:P170_WHERE_CLAUSE;'||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'  l_cnt:=wwv_flow_load_data.dump_ascii ('||chr(10)||
'             p';

p:=p||'_schema => :F4300_P150_SCHEMA,'||chr(10)||
'             p_separator=> :F4300_P180_SEPARATOR,'||chr(10)||
'             p_enclosed_by => :F4300_P180_ENCLOSED,'||chr(10)||
'             p_inc_col_names => :F4300_P180_INC_COLUMN_NAME,'||chr(10)||
'             p_query => l_query,'||chr(10)||
'             p_mime_charset => :P180_FILE_CHARSET,'||chr(10)||
'             p_file_format => :P180_FILE_FORMAT,'||chr(10)||
'             p_file_name => lower(:F4300_P160_ASC_EXPORT_TABLE));'||chr(10)||
'  wwv_f';

p:=p||'low.g_excel_format := true;'||chr(10)||
'  wwv_flow.g_page_text_generated := true;'||chr(10)||
'  wwv_flow.g_unrecoverable_error := true;'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 28216308711066488 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 180,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'export data process',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Unable to export data.',
  p_process_when_button_id=>28214908893807774 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P150_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 197721713451104172 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 180,
  p_process_sequence=> 20,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'validate schema',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P150_SCHEMA);';

wwv_flow_api.create_page_process(
  p_id     => 197735612383226854 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 180,
  p_process_sequence=> 30,
  p_process_point=> 'ON_SUBMIT_BEFORE_COMPUTATION',
  p_process_type=> 'PLSQL',
  p_process_name=> 'validate schema',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 180
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00200
prompt  ...PAGE 200: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_imprt.htm';

ph:=ph||'<script type="text/javascript">'||chr(10)||
'	function p200_ClobUpload(){'||chr(10)||
'		var clob = new apex.ajax.clob(p200_ClobFinish);'||chr(10)||
'		clob._set($x(''F4300_P200_EXCEL_DATA'').value);'||chr(10)||
'		return;'||chr(10)||
'	}'||chr(10)||
'	function p200_ClobFinish(){'||chr(10)||
'			if(p.readyState == 1){'||chr(10)||
'			}else if(p.readyState == 2){'||chr(10)||
'			}else if(p.readyState == 3){'||chr(10)||
'			}else if(p.readyState == 4){'||chr(10)||
'					$x(''F4300_P200_EXCEL_DATA'').value=" "'||chr(10)||
'					doSubmit(''NEXT'');'||chr(10)||
'					return';

ph:=ph||';'||chr(10)||
'			}else{return false;}'||chr(10)||
'	}'||chr(10)||
'</script>'||chr(10)||
''||chr(10)||
'';

wwv_flow_api.create_page(
  p_id     => 200,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => ' ',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806154532',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>200,p_text=>h);
wwv_flow_api.set_html_page_header(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>200,p_text=>ph);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7743809405510530 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 200,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 22324227831252965 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 200,
  p_plug_name=> 'Globalization',
  p_region_name=>'',
  p_plug_template=> 22227029497924836+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 113777313353056887 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 200,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 113781729731064441 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 200,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Copy the data you want to load from a spreadsheet program, such as Microsoft Excel, and paste it into the Data field.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222558424184225510 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 200,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 113785132508068902 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 200,
  p_button_sequence=> 10,
  p_button_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 113787607705071204 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 200,
  p_button_sequence=> 10,
  p_button_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_button_name    => 'NEXT',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'javascript:p200_ClobUpload();',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205425709522146933 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 200,
  p_button_sequence=> 10,
  p_button_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_button_name    => 'Previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>52937410191395625 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_branch_action=> '210',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>113787607705071204+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 30-MAY-2003 14:04 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>205426131075146935 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_branch_action=> '230',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>205425709522146933+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Identify a column separator character. Use <strong>\t</strong> for tab separators.</p>';

wwv_flow_api.create_page_item(
  p_id=>5259614688918858 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'F4300_P200_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => ',',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Separator',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P230_LOAD_TYPE',
  p_display_when2=>'CSV',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_reference_id => 3832614597433912,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Identify optional enclosed by character.</p>';

wwv_flow_api.create_page_item(
  p_id=>5260931311923607 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'F4300_P200_ENCLOSED_BY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Enclosed By',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P230_LOAD_TYPE',
  p_display_when2=>'CSV',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_reference_id => 3832902320433912,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>If your data contains international currency symbol, enter it here.</p>'||chr(10)||
'<p>For example, if your data has "&euro;1,234.56" or "&yen;1,234.56", enter "&euro;" or "&yen;".  Otherwise the data will not load correctly.</p>';

wwv_flow_api.create_page_item(
  p_id=>22326735450255137 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'P200_CURRENCY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 60,
  p_item_plug_id => 22324227831252965+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'declare'||chr(10)||
'    l_return_val varchar2(30) := ''$'';'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select value'||chr(10)||
'                 from nls_session_parameters'||chr(10)||
'                where parameter = ''NLS_CURRENCY'') loop'||chr(10)||
'        l_return_val := c1.value;'||chr(10)||
'        exit;'||chr(10)||
'    end loop;'||chr(10)||
'    --'||chr(10)||
'    return l_return_val;'||chr(10)||
'end;     ',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Currency Symbol',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>A group separator is a character that separates integer groups, for example to show thousands and millions.</p>'||chr(10)||
'<p>Any character can be the group separator. The character specified must be single-byte, and the group separator must be different from any other decimal character. The character can be a space, but cannot be a numeric character or any of the following:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>';

h:=h||'plus (+)</li>'||chr(10)||
'<li>hyphen (-)</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>22762118797191631 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'P200_GROUP_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 70,
  p_item_plug_id => 22324227831252965+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_group_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Group Separator',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>The decimal character separates the integer and decimal parts of a number.</p>'||chr(10)||
'<p> Any character can be the decimal character. The character specified must be single-byte, and the decimal character must be different from group separator. The character can be a space, but cannot be any numeric character or any of the following characters:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>plus (+)</li>'||chr(10)||
'<li>hyphen (-';

h:=h||')</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>22765011309198922 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'P200_DECIMAL_CHARACTER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 80,
  p_item_plug_id => 22324227831252965+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_decimal_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Decimal Character',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'You can paste up to 30KB of spreadsheet data into this field.';

wwv_flow_api.create_page_item(
  p_id=>113791521524083468 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'F4300_P200_EXCEL_DATA',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Data',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXTAREA',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 60,
  p_cMaxlength=> 32000,
  p_cHeight=> 10,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'ABOVE',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Select this option if your data contains column names in the first row. Consider the following example:</p>'||chr(10)||
'<pre>'||chr(10)||
'Name     Salary     Commission'||chr(10)||
'Clark    1000       10'||chr(10)||
'Scott    2000       20'||chr(10)||
'</pre>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'<pre>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Name     Salary     Commission'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Clark    1000       10'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Scott    2000       20'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'</pre>';

wwv_flow_api.create_page_item(
  p_id=>113801306846105452 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'F4300_P200_IS_FIELD_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 50,
  p_item_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'Y',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'ISCOLUMN.NAME.TEXT',
  p_lov => 'select ''<span class="instructiontext">''||'||chr(10)||
'wwv_flow_lang.system_message(''F4300_INSTRUCT_TEXT'')||''</span>'' d, ''Y'' r from dual',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddataboldl"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>113806224949112291 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_name=>'F4300_P200_X',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 113777313353056887+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_display_as=> 'STOP_AND_START_HTML_TABLE',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 50579414315507064 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 200,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P200_IS_FIELD_NAME',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'N',
  p_compute_when => 'F4300_P200_IS_FIELD_NAME',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 119442034568283877 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 200,
  p_validation_name => 'data not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P200_EXCEL_DATA',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Data must be specified.',
  p_associated_item=> 113791521524083468 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53729706792205667 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 200,
  p_validation_name => 'cannot be greater than 30KB',
  p_validation_sequence=> 20,
  p_validation => 'if length(:F4300_P200_EXCEL_DATA) > 30000 then'||chr(10)||
'  return false;'||chr(10)||
'else'||chr(10)||
'  return true;'||chr(10)||
'end if;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Data pasted is greater than 30KB.  Save the file in a comma delimited (csv) or tab delimted format. Then upload the file to load the data.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 5262125209931355 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 200,
  p_validation_name => 'separator not null',
  p_validation_sequence=> 30,
  p_validation => 'F4300_P200_SEPARATOR',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Separator must be specified.',
  p_validation_condition=> 'F4300_P230_LOAD_TYPE',
  p_validation_condition2=> 'CSV',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 113787607705071204 + wwv_flow_api.g_id_offset,
  p_associated_item=> 5259614688918858 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare  '||chr(10)||
'  l_first_row_is_col_name boolean := false;'||chr(10)||
'  q varchar2(32767) := null;'||chr(10)||
'  l_data clob := empty_clob();'||chr(10)||
'begin'||chr(10)||
'  select clob001 into l_data from apex_collections where collection_name=''CLOB_CONTENT'';'||chr(10)||
'  if :F4300_P200_IS_FIELD_NAME = ''Y'' then'||chr(10)||
'    l_first_row_is_col_name := true;'||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'  wwv_flow_load_excel_data.get_table_info ('||chr(10)||
'   p_string                 => l_data,'||chr(10)||
'   p_separator    ';

p:=p||'          => lower(nvl(:F4300_P200_SEPARATOR,''\t'')),'||chr(10)||
'   p_enclosed_by            => :F4300_P200_ENCLOSED_BY,   '||chr(10)||
'   p_first_row_is_col_name  => l_first_row_is_col_name,'||chr(10)||
'   p_currency               => :P200_CURRENCY,'||chr(10)||
'   p_numeric_chars          => :P200_DECIMAL_CHARACTER||:P200_GROUP_SEPARATOR,'||chr(10)||
'   p_load_type              => ''EXCEL'''||chr(10)||
'   );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 118676335014491101 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 200,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'create collection',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error loading excel data.',
  p_process_when_button_id=>113787607705071204 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 200
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00210
prompt  ...PAGE 210: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph:=ph||'<script type="text/javascript">'||chr(10)||
'<!--'||chr(10)||
''||chr(10)||
'function f_ImportDataTypeOnload(){'||chr(10)||
'var lRow = html_GetElement(''importData'').rows[1];'||chr(10)||
'var lSelects = lRow.getElementsByTagName(''SELECT'');'||chr(10)||
'var lLength = lSelects.length;'||chr(10)||
'for(var i=0;i<lLength;i++){lSelects[i].onchange()}'||chr(10)||
'return;'||chr(10)||
'}'||chr(10)||
''||chr(10)||
''||chr(10)||
'function f_ImportDataType(pThis,pThat){  '||chr(10)||
'var lCheckValues = new Array(''NUMBER'',''CLOB'',''DATE'',''BINARY_FLOAT'',''BINARY_DOUBLE'');'||chr(10)||
'  va';

ph:=ph||'r lTest2 = html_DisableOnValue(pThis,lCheckValues,pThat);'||chr(10)||
'  html_GetElement(pThat).disabled = false;'||chr(10)||
'  if(lTest2){'||chr(10)||
'    html_GetElement(pThat).setAttribute(''onfocus'',''this.blur()'');'||chr(10)||
'    }else{'||chr(10)||
'    html_GetElement(pThat).setAttribute(''onfocus'','''');'||chr(10)||
'  }'||chr(10)||
''||chr(10)||
'}'||chr(10)||
'//-->'||chr(10)||
'</script>';

wwv_flow_api.create_page(
  p_id     => 210,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_html_page_onload=>'onload="f_ImportDataTypeOnload()"',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => ' ',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>210,p_text=>h);
wwv_flow_api.set_html_page_header(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>210,p_text=>ph);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7745319794513541 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 210,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'wwv_flow_load_data.display_ntable_property(p_collection_name => ''EXCEL_IMPORT'');';

wwv_flow_api.create_page_plug (
  p_id=> 113819930963139822 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 210,
  p_plug_name=> 'Set Table Properties',
  p_region_name=>'',
  p_plug_template=> 280800227642320099+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'PLSQL_PROCEDURE',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 113822515651146990 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 210,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 113836822959173914 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 210,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>This page previews how your table will look. Enter a table name, change the column names or data types, and specify which columns to include.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222560324315234937 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 210,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 113826730571153459 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 210,
  p_button_sequence=> 10,
  p_button_plug_id => 113836822959173914+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 117991820073731045 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 210,
  p_button_sequence=> 10,
  p_button_plug_id => 113836822959173914+wwv_flow_api.g_id_offset,
  p_button_name    => 'Next',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 113828607846156388 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 210,
  p_button_sequence=> 10,
  p_button_plug_id => 113836822959173914+wwv_flow_api.g_id_offset,
  p_button_name    => 'Previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>117992234106731049 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_branch_action=> '220',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>117991820073731045+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>113829031243156391 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_branch_action=> '200',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>113828607846156388+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>78835705058882899 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_name=>'P210_PRESERVE_CASE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 25,
  p_item_plug_id => 113836822959173914+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'PRESERVE.CASE.Y',
  p_lov => '.'||to_char(88982915435499165 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>101103018097313247 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_name=>'F4300_P210_DUMMY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 113836822959173914+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_prompt=>'Dummy',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Select the database schema you would like to create and load data into.';

wwv_flow_api.create_page_item(
  p_id=>113843528123186777 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_name=>'F4300_P200_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 113836822959173914+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema',
  p_source=>'wwv_flow_user_api.get_default_schema',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'CREATE_TABLE_SCHEMAS',
  p_lov => 'declare'||chr(10)||
'  q varchar2(32767) := null;'||chr(10)||
'begin'||chr(10)||
'  q:=q||''select htf.escape_sc(c.schema) d, c.schema v '';'||chr(10)||
'  q:=q||''from   wwv_flow_company_schemas c, '';'||chr(10)||
'  q:=q||''       wwv_flow_fnd_user u '';'||chr(10)||
'  q:=q||''where  c.security_group_id = :flow_security_group_id and '';'||chr(10)||
'  q:=q||''       u.security_group_id = :flow_security_group_id and '';'||chr(10)||
'  q:=q||''       u.user_name = :flow_user and '';'||chr(10)||
'  q:=q||''       (u.ALLOW_ACCESS_TO_SCHEMAS is null or '';'||chr(10)||
'  q:=q||''        instr('''':''''||u.ALLOW_ACCESS_TO_SCHEMAS||'''':'''','''':''''||c.schema||'''':'''')>0) '';'||chr(10)||
'  if wwv_flow_global.g_xe then'||chr(10)||
'    q:=q||''  and exists (select null '';'||chr(10)||
'    q:=q||''              from sys.dba_sys_privs '';'||chr(10)||
'    q:=q||''              where privilege = ''''CREATE TABLE'''' '';'||chr(10)||
'    q:=q||''              and grantee = c.schema '';'||chr(10)||
'    q:=q||''              union all '';'||chr(10)||
'    q:=q||''              select null '';'||chr(10)||
'    q:=q||''              from sys.dba_sys_privs s, sys.dba_role_privs r '';'||chr(10)||
'    q:=q||''              where r.granted_role=s.grantee '';'||chr(10)||
'    q:=q||''              and r.grantee = c.schema '';'||chr(10)||
'    q:=q||''              and s.privilege = ''''CREATE TABLE'''') '';'||chr(10)||
'  else'||chr(10)||
'    q:=q||''  and exists (select null '';'||chr(10)||
'    q:=q||''               from sys.dba_sys_privs '';'||chr(10)||
'    q:=q||''               where privilege = ''''CREATE TABLE'''' '';'||chr(10)||
'    q:=q||''                 and grantee = c.schema)     '';'||chr(10)||
'  end if;         '||chr(10)||
'  q:=q||''  and exists (select null '';'||chr(10)||
'  q:=q||''                from sys.dba_users '';'||chr(10)||
'  q:=q||''               where username = c.schema) '';'||chr(10)||
'  q:=q||''order by 1 '';'||chr(10)||
'  '||chr(10)||
'  return q;'||chr(10)||
'end;',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_read_only_when=>'return wwv_flow_global.g_xe',
  p_read_only_when_type=>'FUNCTION_BODY',
  p_read_only_disp_attr=>'class="fielddatabold"',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<div class="htmldbInfoBodyP">Identify the table name you would like to create. By default, all table names are converted to upper case. Select <span class="fielddatabold">Preserve Case</span> override this default behavior.</div>';

wwv_flow_api.create_page_item(
  p_id=>113845419065190980 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_name=>'F4300_P200_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 113836822959173914+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name',
  p_source_type=> 'ALWAYS_NULL',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 78838519603887068 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_computation_sequence => 5,
  p_computation_item=> 'F4300_P200_TABLE_NAME',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'upper(replace(wwv_flow_utilities.remove_spaces(:F4300_P200_TABLE_NAME),chr(32),''_''))',
  p_compute_when => 'P210_PRESERVE_CASE',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 101104410117316937 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 210,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P210_DUMMY',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'  l_col_name varchar2(4000) := null;'||chr(10)||
'  '||chr(10)||
'  function primary_key('||chr(10)||
'    p_primary_key_value in number,'||chr(10)||
'    p_index             in number )'||chr(10)||
'    return varchar2'||chr(10)||
'  is'||chr(10)||
'    l_return_value varchar2(4000) := NULL;'||chr(10)||
'  begin'||chr(10)||
'    if p_primary_key_value is not null then'||chr(10)||
'      if p_primary_key_value = p_index then'||chr(10)||
'        l_return_value := ''<INPUT TYPE="radio" NAME="f03" VALUE="''||p_primary_key_value||''" checked>'';'||chr(10)||
'      else'||chr(10)||
'        l_return_value := ''<INPUT TYPE="radio" NAME="f03" VALUE="''||p_index||''">'';'||chr(10)||
'      end if;'||chr(10)||
'    end if;'||chr(10)||
'    return l_return_value;'||chr(10)||
'  exception'||chr(10)||
'    when others then'||chr(10)||
'        return ''<INPUT TYPE="radio" NAME="f03" VALUE="''||p_index||''">'';'||chr(10)||
'  end;'||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'for i in 1..wwv_flow.g_f06.count loop'||chr(10)||
'  if :P210_PRESERVE_CASE is null then'||chr(10)||
'    l_col_name := upper(wwv_flow_utilities.remove_spaces(wwv_flow.g_f01(i)));'||chr(10)||
'  else'||chr(10)||
'    l_col_name := wwv_flow_utilities.remove_spaces(wwv_flow.g_f01(i));'||chr(10)||
'  end if;'||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 1,'||chr(10)||
'     p_attr_value => l_col_name'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 2,'||chr(10)||
'     p_attr_value => wwv_flow.g_f02(i)'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
'  --wwv_flow_collection.update_member_attribute ('||chr(10)||
'  --   p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'  --   p_seq => wwv_flow.g_f06(i),'||chr(10)||
'  --   p_attr_number => 3,'||chr(10)||
'  --   p_attr_value => primary_key(wwv_flow.g_f03(1),i)'||chr(10)||
'  --   );'||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 4,'||chr(10)||
'     p_attr_value => wwv_flow.g_f04(i)'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 5,'||chr(10)||
'     p_attr_value => wwv_flow.g_f05(i)'||chr(10)||
'     );'||chr(10)||
'     '||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f06(i),'||chr(10)||
'     p_attr_number => 6,'||chr(10)||
'     p_attr_value => wwv_flow.g_f07(i)'||chr(10)||
'     ); '||chr(10)||
'end loop;'||chr(10)||
''||chr(10)||
'return ''true'';'||chr(10)||
'exception when others then'||chr(10)||
'	raise_application_error (-20001,''f05=''||wwv_flow_utilities.table_to_string2(wwv_flow.g_f05)||'' f06=''||'||chr(10)||
'	wwv_flow_utilities.table_to_string2(wwv_flow.g_f06));'||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 115945331306024929 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'column name not null, not > 30',
  p_validation_sequence=> 1,
  p_validation => 'declare'||chr(10)||
'begin'||chr(10)||
'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'    if wwv_flow.g_f01(i) is not null then'||chr(10)||
'      if length(wwv_flow.g_f01(i)) > 30 then'||chr(10)||
'        return wwv_flow_lang.system_message(''F4300.COL_NAMES_NOT_LONGER_THAN_30'');'||chr(10)||
'      end if;'||chr(10)||
'    else'||chr(10)||
'      return wwv_flow_lang.system_message(''F4300.COL_NAMES_NOT_NULL'');'||chr(10)||
'    end if;'||chr(10)||
'  end loop;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Column Name Error.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 119206135538356603 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'table name not > 30',
  p_validation_sequence=> 2,
  p_validation => 'if length(:F4300_P200_TABLE_NAME) > 30 then'||chr(10)||
''||chr(10)||
'  return wwv_flow_lang.system_message(''F4300.TABLE_NAMES_NOT_LONGER_THAN_30'');'||chr(10)||
''||chr(10)||
'end if;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Table name too long.',
  p_associated_item=> 113845419065190980 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 92436906797831396 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'column length not zero or null',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
'begin'||chr(10)||
'  for i in 1..wwv_flow.g_f05.count loop'||chr(10)||
'    if wwv_flow.g_f05(i) is not null then'||chr(10)||
'      if wwv_flow.g_f05(i) = 0 then'||chr(10)||
'        return wwv_flow_lang.system_message(''F4300.COL_LENGTH_NOT_ZERO'');'||chr(10)||
'      end if;'||chr(10)||
'    else'||chr(10)||
'      return wwv_flow_lang.system_message(''F4300.COL_LENGTH_NOT_NULL'');'||chr(10)||
'    end if;'||chr(10)||
'  end loop;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error in Column Length.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 115947223542028568 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'table name not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P200_TABLE_NAME',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Table name must be specified.',
  p_associated_item=> 113845419065190980 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 116098629296375317 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'cannot have same table name',
  p_validation_sequence=> 10,
  p_validation => 'if wwv_flow_load_excel_data.table_exists('||chr(10)||
'  p_schema => :F4300_P200_OWNER,'||chr(10)||
'  p_table_name => wwv_flow_utilities.remove_spaces(:F4300_P200_TABLE_NAME)'||chr(10)||
'  ) then'||chr(10)||
'  return wwv_flow_lang.system_message(''F4300.F4500.TABLE_ALREADY_EXISTS'');'||chr(10)||
'end if;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Name already used by an existing object.',
  p_associated_item=> 113845419065190980 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 118010829650775569 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'primary key not null',
  p_validation_sequence=> 10,
  p_validation => 'wwv_flow_utilities.table_to_string2(wwv_flow.g_f03) is not null',
  p_validation_type => 'PLSQL_EXPRESSION',
  p_error_message => 'Primary key column must be specified.  To add a primary key column, click on Next button.',
  p_when_button_pressed=> 113832011440166828 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 118923710832128076 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'at least one upload selected',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'  l_no_count number := 0;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f04.count loop'||chr(10)||
''||chr(10)||
'    if wwv_flow.g_f04(i) = ''N'' then'||chr(10)||
''||chr(10)||
'      l_no_count := l_no_count + 1;'||chr(10)||
''||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_no_count = wwv_flow.g_f04.count then'||chr(10)||
''||chr(10)||
'    return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'    return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'At least one column must be specified to be included in new table. ',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 290780122508136493 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'reserved name',
  p_validation_sequence=> 20,
  p_validation => 'if wwv_flow_sw_util.is_database_reserved_word(p_word=>:F4300_P200_TABLE_NAME) then'||chr(10)||
'  return false;'||chr(10)||
'else'||chr(10)||
'  return true;'||chr(10)||
'end if;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The identified table name is an Oracle reserved word.  Please choose another name.',
  p_associated_item=> 113845419065190980 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_IN_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 292106736930624804 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'column name reserved word',
  p_validation_sequence=> 30,
  p_validation => 'for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'  if wwv_flow_sw_util.is_database_reserved_word(p_word=>upper(wwv_flow.g_f01(i))) then'||chr(10)||
'    return false;'||chr(10)||
'  end if;'||chr(10)||
'end loop;'||chr(10)||
'return true;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'The identified column name is an Oracle reserved word.  Please choose another name.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 26782313706402613 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_validation_name => 'F4300_P200_OWNER',
  p_validation_sequence=> 40,
  p_validation => 'F4300_P200_OWNER',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Schema must be specified.',
  p_when_button_pressed=> 117991820073731045 + wwv_flow_api.g_id_offset,
  p_associated_item=> 113843528123186777 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'if :F4300_P200_OWNER is not null then'||chr(10)||
'wwv_flow_sw_api.check_priv(:F4300_P200_OWNER);'||chr(10)||
'end if;';

wwv_flow_api.create_page_process(
  p_id     => 71104921986533459 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 210,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 210
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00220
prompt  ...PAGE 220: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 220,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>220,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7746329144516238 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 220,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 118108008643891696 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 220,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 118110632354895873 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 220,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Use this page to identify the primary key of the table. If no single column in your data set is appropriate as a primary key then identify a new column as the primary key. A primary key is used to uniquely identify a row in a table.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222567013627260296 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 220,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 118120327410912929 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 220,
  p_button_sequence=> 10,
  p_button_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 118124417151919488 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 220,
  p_button_sequence=> 10,
  p_button_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_button_name    => 'Finish',
  p_button_image_alt=> 'Load Data',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 118122205031915913 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 220,
  p_button_sequence=> 10,
  p_button_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_button_name    => 'Previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>118124817138919491 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_branch_action=> '11',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>118124417151919488+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 1,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>30329632285282108 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_branch_action=> '220',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 2,
  p_branch_condition_type=> 'REQUEST_EQUALS_CONDITION',
  p_branch_condition=> 'P200_PK_TYPE',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 04-FEB-2003 15:30 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>53061418481997114 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_branch_action=> 'f?p=&FLOW_ID.:220:&SESSION.::&DEBUG.:::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_sequence=> 99,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 30-MAY-2003 18:31 by MIKE');
 
wwv_flow_api.create_page_branch(
  p_id=>118122607783915915 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_branch_action=> '210',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>118122205031915913+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name the primary key constraint name.';

wwv_flow_api.create_page_item(
  p_id=>30276630657064070 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P200_PK1_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 22,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Constraint Name',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose how you would like to have your primary key computed.  Or; choose to not have your primary key''s value set.';

wwv_flow_api.create_page_item(
  p_id=>30282707501085726 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P200_PK_TYPE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 23,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'NEW_SEQUENCE',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Primary Key Population:',
  p_source_type=> 'STATIC',
  p_display_as=> 'RADIOGROUP_WITH_SUBMIT',
  p_named_lov=> 'PK_TYPES',
  p_lov => '.'||to_char(30284028271088477 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT-TOP',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identify the name of an existing database sequence which will be used to populate the primary key value.';

wwv_flow_api.create_page_item(
  p_id=>30287729450101583 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P200_EXISTING_SEQUENCE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 60,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Sequence',
  p_source_type=> 'STATIC',
  p_display_as=> 'COMBOBOX',
  p_lov => 'select htf.escape_sc(sequence_name) a, sequence_name b from sys.dba_sequences '||chr(10)||
'where sequence_owner = :F4300_P200_OWNER'||chr(10)||
'order by sequence_name',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Sequence -',
  p_lov_null_value=> '0',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>':P200_PK_TYPE = ''EXISTING_SEQUENCE''',
  p_display_when_type=>'PLSQL_EXPRESSION',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Identify the name of new database sequence which will be created for the purpose of populating this new tables primary key.';

wwv_flow_api.create_page_item(
  p_id=>30292636292122495 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P200_NEW_SEQUENCE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 70,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Sequence',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>':P200_PK_TYPE = ''NEW_SEQUENCE''',
  p_display_when_type=>'PLSQL_EXPRESSION',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>52674514049956992 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P220_X',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 16,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => '&nbsp;',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'You can either select existing column or add new column as primary key.';

wwv_flow_api.create_page_item(
  p_id=>53059109907975753 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P200_PK1_OPTION',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'NEW_KEY',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Primary Key From:',
  p_source_type=> 'STATIC',
  p_display_as=> 'RADIOGROUP_WITH_SUBMIT',
  p_named_lov=> 'USE.EXISTING.COL',
  p_lov => '.'||to_char(88984827687512138 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT-TOP',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Enter the name of the new column to identify the row in the table';

wwv_flow_api.create_page_item(
  p_id=>53064306670041092 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P200_PK1_2',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 21.5,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'ID',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'New Primary Key Column',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'P200_PK1_OPTION',
  p_display_when2=>'NEW_KEY',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Schema that owns the table.';

wwv_flow_api.create_page_item(
  p_id=>118146433179941022 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P220_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema:',
  p_source=>'F4300_P200_OWNER',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_AND_SAVE',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the table to load the data into';

wwv_flow_api.create_page_item(
  p_id=>118149124769944999 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P220_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 15,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'NO',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name:',
  p_source=>'F4300_P200_TABLE_NAME',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Specify which column is the primary key of your table.  A primary key is a column which uniquely identifies a row.  Oracle does not require that your table have a primary key, however this wizard requires you identify a primary key.';

wwv_flow_api.create_page_item(
  p_id=>118154232089956801 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_name=>'P200_PK1',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 21,
  p_item_plug_id => 118108008643891696+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Primary Key',
  p_source_type=> 'ALWAYS_NULL',
  p_display_as=> 'COMBOBOX',
  p_lov => 'select htf.escape_sc(c001)||''(''||c002||'')'' a, c001'||chr(10)||
'  from wwv_flow_collections'||chr(10)||
' where collection_name = ''EXCEL_IMPORT'' and c001 is not null'||chr(10)||
' order by seq_id'||chr(10)||
'',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'- Select Primary Key -',
  p_lov_null_value=> '0',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'P200_PK1_OPTION',
  p_display_when2=>'EXISTING_KEY',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 14641425354825211 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_computation_sequence => 10,
  p_computation_item=> 'P200_PK1_2',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'    l_pk    varchar2(40) := null;'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select c001'||chr(10)||
'                 from wwv_flow_collections'||chr(10)||
'                where collection_name = ''EXCEL_IMPORT'''||chr(10)||
'                  and upper(c001) = ''ID'') '||chr(10)||
'    loop'||chr(10)||
'        for i in 1..10 loop'||chr(10)||
'            for c2 in (select c001'||chr(10)||
'                         from wwv_flow_collections'||chr(10)||
'                        where collection_name = ''EXCEL_IMPORT'''||chr(10)||
'                          and upper(c001) = ''ID''||i) '||chr(10)||
'            loop'||chr(10)||
'                l_pk := ''ID'';'||chr(10)||
'            end loop;--c2'||chr(10)||
'            if l_pk is null then'||chr(10)||
'                return ''ID''||i;'||chr(10)||
'            else'||chr(10)||
'                l_pk := null;'||chr(10)||
'            end if;'||chr(10)||
'        end loop;--i'||chr(10)||
'    end loop;--c1'||chr(10)||
'    return ''ID'';'||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'%null%');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 30299411751143757 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_computation_sequence => 10,
  p_computation_item=> 'P200_PK1_NAME',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'wwv_flow_sw_util.generate_pk_name(replace(:F4300_P200_TABLE_NAME,'' '',''_''));',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 30301617423154803 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_computation_sequence => 10,
  p_computation_item=> 'P200_NEW_SEQUENCE',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'wwv_flow_sw_util.generate_seq_name(replace(:F4300_P200_TABLE_NAME,'' '',''_''));',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 30304418508183576 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 220,
  p_computation_sequence => 10,
  p_computation_item=> 'P200_PK1',
  p_computation_point=> 'BEFORE_HEADER',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'begin'||chr(10)||
'   for c1 in ('||chr(10)||
'     select c001'||chr(10)||
'     from wwv_flow_collections'||chr(10)||
'     where collection_name = ''EXCEL_IMPORT'''||chr(10)||
'     and upper(c001) = ''ID'''||chr(10)||
'   ) loop'||chr(10)||
'     return c1.c001;'||chr(10)||
'   end loop;'||chr(10)||
'   for c1 in ('||chr(10)||
'     select c001'||chr(10)||
'     from wwv_flow_collections'||chr(10)||
'     where collection_name = ''EXCEL_IMPORT'''||chr(10)||
'     and upper(c001) like ''%ID'''||chr(10)||
'   ) loop'||chr(10)||
'     return c1.c001;'||chr(10)||
'   end loop;'||chr(10)||
'end;',
  p_compute_when => 'P200_PK1',
  p_compute_when_type=>'ITEM_IS_NULL_OR_ZERO');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30305822449194166 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'SEQUENCE not null',
  p_validation_sequence=> 10,
  p_validation => 'P200_EXISTING_SEQUENCE',
  p_validation_type => 'ITEM_NOT_ZERO',
  p_error_message => 'Sequence must be specified.',
  p_validation_condition=> 'P200_PK_TYPE',
  p_validation_condition2=> 'EXISTING_SEQUENCE',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30287729450101583 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30317723534222898 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'PK_NAME available',
  p_validation_sequence=> 20,
  p_validation => 'begin'||chr(10)||
''||chr(10)||
'if not wwv_flow_builder.is_valid_identifier(''"''||:P200_PK1_NAME||''"'') then'||chr(10)||
'   return '||chr(10)||
'       wwv_flow_lang.system_message(''F4300.NOT_VALID_PK_NAME'',:P200_PK1_NAME);'||chr(10)||
'end if;'||chr(10)||
'    '||chr(10)||
'if not wwv_flow_sw_util.is_available_name(:P200_PK1_NAME, :P220_OWNER ) then'||chr(10)||
'   return '||chr(10)||
'   wwv_flow_lang.system_message(''F4300.F4500.NAME_ALREADY_USED'',:P200_PK1_NAME);'||chr(10)||
'end if;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error.',
  p_associated_item=> 30276630657064070 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53468835237841869 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'PK not null',
  p_validation_sequence=> 30,
  p_validation => 'P200_PK1',
  p_validation_type => 'ITEM_NOT_ZERO',
  p_error_message => 'Primary key must be specified.',
  p_validation_condition=> 'P200_PK1_OPTION',
  p_validation_condition2=> 'EXISTING_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_associated_item=> 118154232089956801 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53470422555847606 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'PK not null',
  p_validation_sequence=> 35,
  p_validation => 'P200_PK1_2',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Primary key must be specified.',
  p_validation_condition=> 'P200_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_associated_item=> 53064306670041092 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53472212643854303 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'PK not > 30 chars',
  p_validation_sequence=> 38,
  p_validation => 'if length(:P200_PK1_2) > 30 then'||chr(10)||
'  return false;'||chr(10)||
'end if;'||chr(10)||
'return true;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Primary Key column name cannot be longer than 30 characters.',
  p_validation_condition=> 'P200_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 53476208318890886 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'PK gen option needs to be auto',
  p_validation_sequence=> 39,
  p_validation => 'if :P200_PK_TYPE = ''NOT_GENERATED'' then'||chr(10)||
'  return false;'||chr(10)||
'end if;'||chr(10)||
'return true;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Primary Key must be generated from a sequence when creating a new primary key.',
  p_validation_condition=> 'P200_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30282707501085726 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30321805012255306 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'PK_NAME not null',
  p_validation_sequence=> 40,
  p_validation => 'P200_PK1_NAME',
  p_validation_type => 'ITEM_NOT_NULL_OR_ZERO',
  p_error_message => 'PK name must be specified.',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30276630657064070 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 30325506181265176 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'SEQ_NAME available',
  p_validation_sequence=> 50,
  p_validation => 'begin'||chr(10)||
'if not wwv_flow_builder.is_valid_identifier(''"''||:P200_NEW_SEQUENCE||''"'') then'||chr(10)||
'   return wwv_flow_lang.system_message(''F4300.F4500.NOT_VALID_SEQ_NAME'',:P200_NEW_SEQUENCE);'||chr(10)||
'end if;'||chr(10)||
'    '||chr(10)||
'if not wwv_flow_sw_util.is_available_name(:P200_NEW_SEQUENCE, :P220_OWNER ) then'||chr(10)||
'   return wwv_flow_lang.system_message(''F4300.F4500.NAME_ALREADY_USED'',:P200_NEW_SEQUENCE);'||chr(10)||
'end if;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error.',
  p_validation_condition=> 'P200_PK_TYPE',
  p_validation_condition2=> 'NEW_SEQUENCE',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_associated_item=> 30292636292122495 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 49755630743734173 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_validation_name => 'no duplicate PK col',
  p_validation_sequence=> 60,
  p_validation => 'declare'||chr(10)||
'    l_cnt pls_integer := 0;'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select count(c001) cnt'||chr(10)||
'               from wwv_flow_collections'||chr(10)||
'               where collection_name = ''EXCEL_IMPORT'''||chr(10)||
'               and upper(c001) = upper(:P200_PK1_2))'||chr(10)||
'    loop'||chr(10)||
'      l_cnt := c1.cnt;'||chr(10)||
'    end loop;'||chr(10)||
'    if l_cnt > 0 then'||chr(10)||
'      return wwv_flow_lang.system_message(''F4500.P602.DUP_COL_NAME'',:P200_PK1_2);'||chr(10)||
'    end if;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_ERR_TEXT',
  p_error_message => 'Error.',
  p_validation_condition=> 'P200_PK1_OPTION',
  p_validation_condition2=> 'NEW_KEY',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_when_button_pressed=> 118124417151919488 + wwv_flow_api.g_id_offset,
  p_associated_item=> 53064306670041092 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare    '||chr(10)||
'  l_cnames     wwv_flow_global.vc_arr2;  '||chr(10)||
'  l_data_type  wwv_flow_global.vc_arr2;  '||chr(10)||
'  l_upload     wwv_flow_global.vc_arr2;'||chr(10)||
'  l_max_length wwv_flow_global.vc_arr2;'||chr(10)||
'  l_seq_name   varchar2(255) := null;'||chr(10)||
'  l_pk1        varchar2(255) := :P200_PK1;'||chr(10)||
'  l_pk1_name   varchar2(255) := null;'||chr(10)||
'  i            pls_integer := 0;'||chr(10)||
'begin   '||chr(10)||
'   if :P200_PK1_OPTION = ''NEW_KEY'' then'||chr(10)||
'      i := i+1;'||chr(10)||
'      l';

p:=p||'_pk1 := replace(wwv_flow_utilities.remove_spaces(:P200_PK1_2),chr(32),''_'');	'||chr(10)||
'      if :P210_PRESERVE_CASE is null then'||chr(10)||
'        l_pk1 := upper(l_pk1);'||chr(10)||
'      end if;'||chr(10)||
'      l_cnames(i) := l_pk1;'||chr(10)||
'      l_data_type(i) := ''NUMBER'';'||chr(10)||
'      l_upload(i) := ''Y'';'||chr(10)||
'      l_max_length(i) := 30;'||chr(10)||
'   end if;	 '||chr(10)||
'    '||chr(10)||
'   for c in (select * '||chr(10)||
'             from wwv_flow_collections '||chr(10)||
'             where collection_name=''EX';

p:=p||'CEL_IMPORT'') loop'||chr(10)||
'     i := i+1; '||chr(10)||
'     l_cnames(i) := c.c001;'||chr(10)||
'     l_data_type(i) := c.c002;'||chr(10)||
'     l_upload(i) := c.c004;'||chr(10)||
'     l_max_length(i) := c.c005;    '||chr(10)||
'   end loop;  '||chr(10)||
' '||chr(10)||
'  if :P200_PK_TYPE = ''NEW_SEQUENCE'' then    '||chr(10)||
'    l_seq_name := :P200_NEW_SEQUENCE;'||chr(10)||
'    if :P210_PRESERVE_CASE is null then'||chr(10)||
'      l_seq_name := upper(l_seq_name);'||chr(10)||
'    end if;'||chr(10)||
'  elsif :P200_PK_TYPE = ''EXISTING_SEQUENCE'' then'||chr(10)||
'   ';

p:=p||' l_seq_name := :P200_EXISTING_SEQUENCE;'||chr(10)||
'  else'||chr(10)||
'    l_seq_name := NULL;'||chr(10)||
'  end if;'||chr(10)||
'  '||chr(10)||
' l_pk1_name := :P200_PK1_NAME;'||chr(10)||
' if :P210_PRESERVE_CASE is null then'||chr(10)||
'   l_pk1_name := upper(l_pk1_name);'||chr(10)||
' end if;'||chr(10)||
' wwv_flow_load_excel_data.create_table ('||chr(10)||
'  p_schema        => :F4300_P200_OWNER,'||chr(10)||
'  p_table_name    => wwv_flow_utilities.remove_spaces(:F4300_P200_TABLE_NAME),'||chr(10)||
'  p_pk1           => l_pk1,'||chr(10)||
'  p_pk1_name   ';

p:=p||'   => l_pk1_name,'||chr(10)||
'  p_pk1_type      => :P200_PK_TYPE,'||chr(10)||
'  p_seq_name      => l_seq_name,'||chr(10)||
'  --'||chr(10)||
'  p_cnames        => l_cnames,'||chr(10)||
'  p_data_type     => l_data_type,  '||chr(10)||
'  p_upload        => l_upload,'||chr(10)||
'  p_max_length    => l_max_length '||chr(10)||
'  );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 118164419760008085 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'create table with new primary key',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error creating table.',
  p_process_when_button_id=>118124417151919488 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare      '||chr(10)||
'  l_first_row_is_col_name boolean := false;  '||chr(10)||
'  l_cnames        wwv_flow_global.vc_arr2;      '||chr(10)||
'  l_upload        wwv_flow_global.vc_arr2;  '||chr(10)||
'  i               number := 0;'||chr(10)||
'  --'||chr(10)||
'  l_data_type     wwv_flow_global.vc_arr2;'||chr(10)||
'  l_data_format   wwv_flow_global.vc_arr2;'||chr(10)||
'  l_parsed_data_format wwv_flow_global.vc_arr2;'||chr(10)||
'  l_data               clob := empty_clob();'||chr(10)||
'begin  '||chr(10)||
'  for c in (select * '||chr(10)||
' ';

p:=p||'           from wwv_flow_collections '||chr(10)||
'            where collection_name=''EXCEL_IMPORT'') loop'||chr(10)||
'    i := i + 1;'||chr(10)||
'    l_cnames(i) := c.c001;    '||chr(10)||
'    l_upload(i) := c.c004; '||chr(10)||
'    l_data_type(i) := c.c002;  '||chr(10)||
'    l_data_format(i) := c.c006;'||chr(10)||
'    l_parsed_data_format(i) := c.c027;   '||chr(10)||
'  end loop;  '||chr(10)||
''||chr(10)||
'  if :F4300_P200_IS_FIELD_NAME = ''Y'' then'||chr(10)||
'    l_first_row_is_col_name := true;'||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'  select clob001 into';

p:=p||' l_data from apex_collections where collection_name=''CLOB_CONTENT'';'||chr(10)||
''||chr(10)||
'  wwv_flow_load_excel_data.load_excel_data ('||chr(10)||
'   p_string      => l_data,'||chr(10)||
'   p_cnames      => l_cnames,'||chr(10)||
'   p_upload      => l_upload,'||chr(10)||
'   p_schema      => :F4300_P200_OWNER,'||chr(10)||
'   p_table       => wwv_flow_utilities.remove_spaces(:F4300_P200_TABLE_NAME),'||chr(10)||
'   p_data_type   => l_data_type,'||chr(10)||
'   p_data_format => l_data_format,'||chr(10)||
'   p_parsed_d';

p:=p||'ata_format => l_parsed_data_format,'||chr(10)||
'   p_separator   => lower(nvl(:F4300_P200_SEPARATOR,''\t'')),'||chr(10)||
'   p_enclosed_by => :F4300_P200_ENCLOSED_BY,'||chr(10)||
'   p_first_row_is_col_name => l_first_row_is_col_name,'||chr(10)||
'   p_load_to               => :F4300_P230_LOAD_TO,'||chr(10)||
'   p_currency              => :P200_CURRENCY,'||chr(10)||
'   p_numeric_chars         => :P200_DECIMAL_CHARACTER||:P200_GROUP_SEPARATOR,'||chr(10)||
'   p_load_type             =>';

p:=p||' :F4300_P230_LOAD_TYPE'||chr(10)||
'   );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 118935430420164595 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_process_sequence=> 20,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'insert data',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_when_button_id=>118124417151919488 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P200_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 70986528772750088 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 220,
  p_process_sequence=> 30,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 220
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00230
prompt  ...PAGE 230: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_imprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 230,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125928',
  p_page_is_public_y_n=> 'N',
  p_protection_level=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>230,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 7733309358482129 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 230,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24289907110460397 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 230,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205393709447092679 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 230,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 205409328868124156 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 230,
  p_button_sequence=> 10,
  p_button_plug_id => 205393709447092679+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&FLOW_ID.:9:&SESSION.::&DEBUG.:::',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205411608221127707 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 230,
  p_button_sequence=> 10,
  p_button_plug_id => 205393709447092679+wwv_flow_api.g_id_offset,
  p_button_name    => 'Next',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>5158811255444790 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_branch_action=> 'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18,19,21::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_when_button_id=>205411608221127707+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_branch_condition_type=> 'PLSQL_EXPRESSION',
  p_branch_condition=> ':F4300_P230_LOAD_TO = ''NEW'' and :F4300_P230_LOAD_FROM = ''UPLOAD''',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 26-SEP-2002 13:54 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>102416534135105538 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_branch_action=> 'f?p=&APP_ID.:22:&SESSION.:::22,23,24,25',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_when_button_id=>205411608221127707+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_branch_condition_type=> 'PLSQL_EXPRESSION',
  p_branch_condition=> ':F4300_P230_LOAD_TO = ''EXIST'' and :F4300_P230_LOAD_FROM = ''UPLOAD''',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 21-AUG-2002 15:49 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>8269912870205091 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_branch_action=> 'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:200,210,220,230,240,250,260,270::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_when_button_id=>205411608221127707+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 20,
  p_branch_condition_type=> 'PLSQL_EXPRESSION',
  p_branch_condition=> ':F4300_P230_LOAD_TO = ''NEW'' and :F4300_P230_LOAD_FROM = ''PASTE''',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 23-JAN-2006 15:49 by CBCHO');
 
wwv_flow_api.create_page_branch(
  p_id=>8273734688211348 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_branch_action=> 'f?p=&APP_ID.:240:&SESSION.::&DEBUG.:200,210,220,230,240,250,260,270::',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'REDIRECT_URL',
  p_branch_when_button_id=>205411608221127707+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 30,
  p_branch_condition_type=> 'PLSQL_EXPRESSION',
  p_branch_condition=> ':F4300_P230_LOAD_TO = ''EXIST'' and :F4300_P230_LOAD_FROM = ''PASTE''',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> 'Created 23-JAN-2006 15:50 by CBCHO');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>5129035843101722 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_name=>'F4300_P230_LOAD_TYPE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 205393709447092679+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_prompt=>'Load Type',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose what you want to load your data into.  If your database table exists choose "existing table".  If you would like to have a new table created choose "new table".';

wwv_flow_api.create_page_item(
  p_id=>5137119183144238 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_name=>'F4300_P230_LOAD_TO',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 205393709447092679+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'NEW',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Load To:',
  p_source_type=> 'STATIC',
  p_display_as=> 'RADIOGROUP',
  p_named_lov=> 'TABLE.OPTION',
  p_lov => '.'||to_char(88973833256390726 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'ABOVE',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Specify if the data is to be uploaded from a file to copy and pasted from a spreadsheet';

wwv_flow_api.create_page_item(
  p_id=>5139016890153097 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_name=>'F4300_P230_LOAD_FROM',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 205393709447092679+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'PASTE',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Load From:',
  p_source_type=> 'STATIC',
  p_display_as=> 'RADIOGROUP',
  p_named_lov=> 'LOAD.OPTION',
  p_lov => '.'||to_char(88972821135387296 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'ABOVE',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'No help text available';

wwv_flow_api.create_page_item(
  p_id=>6981431604000080 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_name=>'P230_X',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 35,
  p_item_plug_id => 205393709447092679+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'&nbsp;',
  p_source_type=> 'STATIC',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 145973615691831443 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 230,
  p_computation_sequence => 40,
  p_computation_item=> 'F4300_P230_LOAD_TYPE',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'EXCEL',
  p_compute_when => 'F4300_P230_LOAD_FROM',
  p_compute_when_text=>'PASTE',
  p_compute_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2');
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 230
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00240
prompt  ...PAGE 240: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 240,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>240,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24414017561521475 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 240,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205452626410175962 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 240,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205767607788807602 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 240,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database schema that owns the table you would like load data into.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222569905231276751 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 240,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 205469706021193255 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 240,
  p_button_sequence=> 10,
  p_button_plug_id => 205452626410175962+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205472015025195864 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 240,
  p_button_sequence=> 10,
  p_button_plug_id => 205452626410175962+wwv_flow_api.g_id_offset,
  p_button_name    => 'Next',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205474623683198331 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 240,
  p_button_sequence=> 10,
  p_button_plug_id => 205452626410175962+wwv_flow_api.g_id_offset,
  p_button_name    => 'Previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>205472420409195866 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 240,
  p_branch_action=> '250',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>205472015025195864+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>205475022410198332 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 240,
  p_branch_action=> '230',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>205474623683198331+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose the database schema that owns the table you would like load Excel data into.';

wwv_flow_api.create_page_item(
  p_id=>205481622922223180 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 240,
  p_name=>'F4300_P240_TABLE_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 205452626410175962+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema',
  p_source=>'wwv_flow_user_api.get_default_schema',
  p_source_type=> 'FUNCTION',
  p_display_as=> 'COMBOBOX',
  p_named_lov=> 'LIST_SCHEMA_OWNERS',
  p_lov => 'select htf.escape_sc(c.schema) d, c.schema v'||chr(10)||
'from   wwv_flow_company_schemas c,'||chr(10)||
'       wwv_flow_fnd_user u'||chr(10)||
'where  c.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.security_group_id = :flow_security_group_id and'||chr(10)||
'       u.user_name = :flow_user and'||chr(10)||
'       (u.ALLOW_ACCESS_TO_SCHEMAS is null or'||chr(10)||
'        instr('':''||u.ALLOW_ACCESS_TO_SCHEMAS||'':'','':''||c.schema||'':'')>0)'||chr(10)||
'order by 1'||chr(10)||
'',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_read_only_when=>'return wwv_flow_global.g_xe',
  p_read_only_when_type=>'FUNCTION_BODY',
  p_read_only_disp_attr=>'class="fielddatabold"',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_escape_on_http_input => 'Y',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 205496521616238972 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 240,
  p_validation_name => 'F4300_P240_TABLE_OWNER Not Null',
  p_validation_sequence=> 1,
  p_validation => 'F4300_P240_TABLE_OWNER',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Table Owner must be specified.',
  p_associated_item=> 205481622922223180 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> 'generated 16-APR-2002 11:44');
 
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 240
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00250
prompt  ...PAGE 250: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 250,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'SSPADAFO',
  p_last_upd_yyyymmddhh24miss => '20081110155318',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>250,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 76456215334564953 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 250,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205507314918257290 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 250,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205771136674809386 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 250,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Select the database table you would like load data into.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222571231897284467 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 250,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 205510813172261582 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 250,
  p_button_sequence=> 10,
  p_button_plug_id => 205507314918257290+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205515728409265950 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 250,
  p_button_sequence=> 10,
  p_button_plug_id => 205507314918257290+wwv_flow_api.g_id_offset,
  p_button_name    => 'Next',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205513121483263911 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 250,
  p_button_sequence=> 10,
  p_button_plug_id => 205507314918257290+wwv_flow_api.g_id_offset,
  p_button_name    => 'Previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>205516121471265952 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 250,
  p_branch_action=> '270',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>205513506763263914 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 250,
  p_branch_action=> '240',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>205513121483263911+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>78492329143602970 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 250,
  p_name=>'P250_CASE_SENSITIVE',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 205507314918257290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'CASE.SENSITIVE.Y',
  p_lov => '.'||to_char(88974921613396877 + wwv_flow_api.g_id_offset)||'.',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes2=> 'class="fielddata"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the owner of the table';

wwv_flow_api.create_page_item(
  p_id=>78494625119611278 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 250,
  p_name=>'P250_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 5,
  p_item_plug_id => 205507314918257290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema:',
  p_source=>'F4300_P240_TABLE_OWNER',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Choose the database table you would like load data into. By default, all table names are converted to upper case. Select <span class="fielddatabold">Preserve Case</span> override this default behavior.';

wwv_flow_api.create_page_item(
  p_id=>205525035597278082 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 250,
  p_name=>'F4300_P250_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 205507314918257290+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name',
  p_source_type=> 'STATIC',
  p_display_as=> 'POPUP',
  p_lov => 'select table_name a, table_name b'||chr(10)||
'from sys.dba_tables'||chr(10)||
'where owner = :F4300_P240_TABLE_OWNER'||chr(10)||
'and table_name not like ''BIN$%'''||chr(10)||
'order by 1',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 78493414037608074 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 250,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P250_TABLE_NAME',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'PLSQL_EXPRESSION',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'upper(:F4300_P250_TABLE_NAME)',
  p_compute_when => 'P250_CASE_SENSITIVE',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 205526830852280235 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 250,
  p_validation_name => 'F4300_P250_TABLE_NAME Not Null',
  p_validation_sequence=> 1,
  p_validation => 'F4300_P250_TABLE_NAME',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Table Name must be specified.',
  p_associated_item=> 205525035597278082 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> 'generated 16-APR-2002 11:51');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 78523407504634533 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 250,
  p_validation_name => 'table exits',
  p_validation_sequence=> 10,
  p_validation => 'select 1'||chr(10)||
'from sys.dba_objects'||chr(10)||
'where owner = :F4300_P240_TABLE_OWNER'||chr(10)||
'and object_name = :F4300_P250_TABLE_NAME'||chr(10)||
'and object_type in (''TABLE'')',
  p_validation_type => 'EXISTS',
  p_error_message => 'Table does not exist.',
  p_validation_condition=> 'Previous',
  p_validation_condition_type=> 'REQUEST_NOT_EQUAL_CONDITION',
  p_associated_item=> 205525035597278082 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P240_TABLE_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 72519225176857668 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 250,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 250
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00260
prompt  ...PAGE 260: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph := null;
wwv_flow_api.create_page(
  p_id     => 260,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => '',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>260,p_text=>h);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24417212497529498 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 260,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205542430396310879 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 260,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'wwv_flow_load_data.display_etable_property ('||chr(10)||
'    p_table_owner     => :F4300_P240_TABLE_OWNER,'||chr(10)||
'    p_table_name      => :F4300_P250_TABLE_NAME,'||chr(10)||
'    p_collection_name => ''EXCEL_IMPORT'''||chr(10)||
'    );';

wwv_flow_api.create_page_plug (
  p_id=> 205554029090326653 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 260,
  p_plug_name=> 'Define Column Mapping',
  p_region_name=>'',
  p_plug_template=> 280800227642320099+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'PLSQL_PROCEDURE',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 8133813371086874+ wwv_flow_api.g_id_offset,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_num_rows => 15,
  p_plug_query_num_rows_type => 'ROWS_X_TO_Y_OF_Z',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_query_show_nulls_as => ' - ',
  p_plug_query_col_allignments => 'L:L:L:L:L:L:L',
  p_plug_query_sum_cols => '::::::',
  p_plug_query_number_formats => '::::::',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205774432361811368 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 260,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>This page previews how your data will be loaded. Match the database column names with columns in the data. To upload columns, select <b>Yes</b> or <b>No</b>. An asterisk (*) indicates a required column.</p>'||chr(10)||
'<p>To upload data to the selected table, click <b>Import Data</b>.</p>'||chr(10)||
'<p>Use SQL Workshop to modify table attributes such as changing the column length, making not null columns, or changing';

s:=s||' the column type.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222577432982313188 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 260,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 50,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 205545936683315648 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 260,
  p_button_sequence=> 10,
  p_button_plug_id => 205542430396310879+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205551327810322579 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 260,
  p_button_sequence=> 10,
  p_button_plug_id => 205542430396310879+wwv_flow_api.g_id_offset,
  p_button_name    => 'Import',
  p_button_image_alt=> 'Load Data',
  p_button_position=> 'REGION_TEMPLATE_CREATE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205548216382319245 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 260,
  p_button_sequence=> 10,
  p_button_plug_id => 205542430396310879+wwv_flow_api.g_id_offset,
  p_button_name    => 'Previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>205551705173322581 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 260,
  p_branch_action=> '11',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>205551327810322579+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>205548616949319247 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 260,
  p_branch_action=> '270',
  p_branch_point=> 'BEFORE_VALIDATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>205548216382319245+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>4927529059416954 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 260,
  p_name=>'F4300_P260_DUMMY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 205542430396310879+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_prompt=>'Dummy',
  p_display_as=> 'HIDDEN',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the owner of the table';

wwv_flow_api.create_page_item(
  p_id=>205627426594479743 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 260,
  p_name=>'F4300_P260_TABLE_OWNER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 205542430396310879+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Schema:',
  p_source=>'F4300_P240_TABLE_OWNER',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'Name of the table to load the data into';

wwv_flow_api.create_page_item(
  p_id=>205631915380484915 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 260,
  p_name=>'F4300_P260_TABLE_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 205542430396310879+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Table Name:',
  p_source=>'F4300_P250_TABLE_NAME',
  p_source_type=> 'ITEM',
  p_display_as=> 'DISPLAY_ONLY_HTML',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddatabold"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 4928409104420646 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 260,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P260_DUMMY',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'FUNCTION_BODY',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'declare'||chr(10)||
'begin'||chr(10)||
'for i in 1..wwv_flow.g_f04.count loop'||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f04(i),'||chr(10)||
'     p_attr_number => 1,'||chr(10)||
'     p_attr_value => wwv_flow_utilities.remove_spaces(wwv_flow.g_f01(i))'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f04(i),'||chr(10)||
'     p_attr_number => 4,'||chr(10)||
'     p_attr_value => wwv_flow.g_f02(i)'||chr(10)||
'     );'||chr(10)||
''||chr(10)||
'  wwv_flow_collection.update_member_attribute ('||chr(10)||
'     p_collection_name => ''EXCEL_IMPORT'','||chr(10)||
'     p_seq => wwv_flow.g_f04(i),'||chr(10)||
'     p_attr_number => 6,'||chr(10)||
'     p_attr_value => wwv_flow.g_f05(i)'||chr(10)||
'     );'||chr(10)||
'end loop;'||chr(10)||
'return ''true'';'||chr(10)||
''||chr(10)||
'end;',
  p_compute_when => '',
  p_compute_when_type=>'');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3022314574536566 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 260,
  p_validation_name => 'column name not null',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  l_null_found number := 0;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
''||chr(10)||
'    if wwv_flow.g_f02(i)=''Y'' then'||chr(10)||
''||chr(10)||
'      if replace(wwv_flow.g_f01(i),''%''||''null%'',null) is null then'||chr(10)||
''||chr(10)||
'        l_null_found := l_null_found + 1;'||chr(10)||
''||chr(10)||
'      end if;'||chr(10)||
''||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_null_found > 0 then'||chr(10)||
''||chr(10)||
'    return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'    return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Column names cannot be null.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3027818215565249 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 260,
  p_validation_name => 'at least one upload selected',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'  l_no_count number := 0;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  for i in 1..wwv_flow.g_f02.count loop'||chr(10)||
''||chr(10)||
'    if wwv_flow.g_f02(i) = ''N'' then'||chr(10)||
''||chr(10)||
'      l_no_count := l_no_count + 1;'||chr(10)||
''||chr(10)||
'    end if;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_no_count = wwv_flow.g_f02.count then'||chr(10)||
''||chr(10)||
'    return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'    return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'At least one column must be specified to be included to upload the data.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3298131744753321 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 260,
  p_validation_name => 'not null columns must be loaded',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
''||chr(10)||
'  l_not_null_error number := 0;'||chr(10)||
''||chr(10)||
'  l_columns        varchar2(32767) := null;'||chr(10)||
''||chr(10)||
'  l_not_null_cols  varchar2(32767) := null;'||chr(10)||
''||chr(10)||
'  l_trigger_body   long;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
''||chr(10)||
'  l_columns := wwv_flow_utilities.table_to_string2(wwv_flow.g_f01);'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  -- get trigger body if it is before insert trigger on the selected table'||chr(10)||
''||chr(10)||
'  for c1 in (select trigger_body'||chr(10)||
''||chr(10)||
'             from sys.dba_triggers'||chr(10)||
''||chr(10)||
'             where table_name = :F4300_P250_TABLE_NAME'||chr(10)||
''||chr(10)||
'             and table_owner = :F4300_P240_TABLE_OWNER'||chr(10)||
''||chr(10)||
'             and trigger_type like ''%BEFORE%'''||chr(10)||
''||chr(10)||
'             and triggering_event like ''%INSERT%'')'||chr(10)||
''||chr(10)||
'  loop'||chr(10)||
''||chr(10)||
'     l_trigger_body := c1.trigger_body;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  -- get all not null columns'||chr(10)||
''||chr(10)||
'  for c1 in (select column_name'||chr(10)||
''||chr(10)||
'             from sys.dba_tab_columns'||chr(10)||
''||chr(10)||
'             where table_name = :F4300_P250_TABLE_NAME'||chr(10)||
''||chr(10)||
'             and owner = :F4300_P240_TABLE_OWNER'||chr(10)||
''||chr(10)||
'             and nullable = ''N'''||chr(10)||
''||chr(10)||
'             ) loop'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'      for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
''||chr(10)||
'        -- If column names user selected is equal to not null columns,'||chr(10)||
''||chr(10)||
'        -- user didn''t include to upload'||chr(10)||
''||chr(10)||
'        -- and the column doesn''t have trigger, raise an error.'||chr(10)||
''||chr(10)||
'        if (wwv_flow.g_f01(i) = c1.column_name) then'||chr(10)||
''||chr(10)||
'          if wwv_flow.g_f02(i) = ''N'' then'||chr(10)||
''||chr(10)||
'            if instr(nvl(UPPER(l_trigger_body),'' ''),c1.column_name) = 0 then'||chr(10)||
''||chr(10)||
'              l_not_null_error := l_not_null_error + 1;'||chr(10)||
''||chr(10)||
'              l_not_null_cols := l_not_null_cols||'',''||c1.column_name;'||chr(10)||
''||chr(10)||
'            end if;'||chr(10)||
''||chr(10)||
'          end if;'||chr(10)||
''||chr(10)||
'        else'||chr(10)||
''||chr(10)||
'          -- If user did not select not null columns,'||chr(10)||
''||chr(10)||
'          -- and the column doesn''t have trigger'||chr(10)||
''||chr(10)||
'          -- raise an error.'||chr(10)||
''||chr(10)||
'          if instr(l_columns,c1.column_name) = 0 then'||chr(10)||
''||chr(10)||
'            if instr(nvl(UPPER(l_trigger_body),'' ''),c1.column_name) = 0 then'||chr(10)||
''||chr(10)||
'              l_not_null_error := l_not_null_error + 1;'||chr(10)||
''||chr(10)||
'              l_not_null_cols := l_not_null_cols||'',''||c1.column_name;'||chr(10)||
''||chr(10)||
'            end if;'||chr(10)||
''||chr(10)||
'          end if;'||chr(10)||
''||chr(10)||
'        end if;'||chr(10)||
''||chr(10)||
'      end loop;'||chr(10)||
''||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'  if l_not_null_error > 0 then'||chr(10)||
''||chr(10)||
'      return false;'||chr(10)||
''||chr(10)||
'  else'||chr(10)||
''||chr(10)||
'      return true;'||chr(10)||
''||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'There are NOT NULL columns in &F4300_P240_TABLE_OWNER..&F4300_P250_TABLE_NAME..  Select to upload the data without an error.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 3467506794479066 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 260,
  p_validation_name => 'duplicate column names',
  p_validation_sequence=> 10,
  p_validation => 'declare'||chr(10)||
'  l_col       varchar2(32767) := null;'||chr(10)||
'  l_duplicate boolean := true;'||chr(10)||
''||chr(10)||
'begin'||chr(10)||
'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'    -- if column selected is to be uploaded, check for duplicate column selection'||chr(10)||
'    if wwv_flow.g_f02(i) = ''Y'' then'||chr(10)||
'        if instr('':''||nvl(l_col,'' '')||'':'','':''||wwv_flow.g_f01(i)||'':'') > 0 then'||chr(10)||
'          l_duplicate := false;'||chr(10)||
'        end if;'||chr(10)||
''||chr(10)||
'        if i > 1 then'||chr(10)||
'            l_col := '':'';'||chr(10)||
'        end if;'||chr(10)||
'        l_col := l_col||wwv_flow.g_f01(i);'||chr(10)||
'    end if;'||chr(10)||
'  end loop;'||chr(10)||
''||chr(10)||
'  return l_duplicate;'||chr(10)||
'end;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Duplicate column names selected.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare  '||chr(10)||
'  l_first_row_is_col_name boolean := false;'||chr(10)||
'  l_cnames                wwv_flow_global.vc_arr2;'||chr(10)||
'  --'||chr(10)||
'  l_data_types            wwv_flow_global.vc_arr2;'||chr(10)||
'  l_parsed_data_format    wwv_flow_global.vc_arr2;'||chr(10)||
'  j                       pls_integer := 0;'||chr(10)||
'  l_data                  clob := empty_clob();'||chr(10)||
'begin'||chr(10)||
'  if :F4300_P270_IS_FIELD_NAME = ''Y'' then'||chr(10)||
'    l_first_row_is_col_name := true;'||chr(10)||
'  end if;'||chr(10)||
''||chr(10)||
'';

p:=p||'  for i in 1..wwv_flow.g_f01.count loop'||chr(10)||
'    l_cnames(i) := wwv_flow.g_f01(i);'||chr(10)||
'    for c1 in (select data_type'||chr(10)||
'               from sys.dba_tab_columns'||chr(10)||
'               where owner = :F4300_P240_TABLE_OWNER'||chr(10)||
'               and table_name = upper(:F4300_P250_TABLE_NAME)'||chr(10)||
'               and column_name = wwv_flow.g_f01(i)'||chr(10)||
'               order by column_id)'||chr(10)||
'    loop'||chr(10)||
'       l_data_types(i) := c1.data_type; ';

p:=p||'   	'||chr(10)||
'    end loop;  '||chr(10)||
'  end loop;'||chr(10)||
'  '||chr(10)||
'  for c in (select * '||chr(10)||
'            from wwv_flow_collections '||chr(10)||
'            where collection_name=''EXCEL_IMPORT'') loop'||chr(10)||
'    j := j + 1;    '||chr(10)||
'    l_parsed_data_format(j) := c.c027;   '||chr(10)||
'  end loop; '||chr(10)||
''||chr(10)||
'  select clob001 into l_data from apex_collections where collection_name=''CLOB_CONTENT'';'||chr(10)||
''||chr(10)||
'  wwv_flow_load_excel_data.load_excel_data ('||chr(10)||
'   p_string      => l_data,'||chr(10)||
'   p_cnam';

p:=p||'es      => l_cnames,'||chr(10)||
'   p_upload      => wwv_flow.g_f02,'||chr(10)||
'   p_schema      => :F4300_P240_TABLE_OWNER,'||chr(10)||
'   p_table       => :F4300_P250_TABLE_NAME,'||chr(10)||
'   p_data_type   => l_data_types,'||chr(10)||
'   p_data_format => wwv_flow.g_f05,'||chr(10)||
'   p_parsed_data_format => l_parsed_data_format,'||chr(10)||
'   p_separator   => lower(nvl(:F4300_P270_SEPARATOR,''\t'')),'||chr(10)||
'   p_enclosed_by => :F4300_P270_ENCLOSED_BY,'||chr(10)||
'   p_first_row_is_col_name => ';

p:=p||'l_first_row_is_col_name,'||chr(10)||
'   p_load_to               => :F4300_P230_LOAD_TO,'||chr(10)||
'   p_currency              => :P270_CURRENCY,'||chr(10)||
'   p_numeric_chars         => :P270_DECIMAL_CHARACTER||:P270_GROUP_SEPARATOR,'||chr(10)||
'   p_load_type             => :F4300_P230_LOAD_TYPE'||chr(10)||
'   );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 3049733022649535 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 260,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'insert data',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error inserting data.',
  p_process_when_button_id=>205551327810322579 + wwv_flow_api.g_id_offset,
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_sw_api.check_priv(:F4300_P240_TABLE_OWNER);';

wwv_flow_api.create_page_process(
  p_id     => 72521532579869328 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 260,
  p_process_sequence=> 20,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Validate Schema',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Invalid Schema',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 260
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00270
prompt  ...PAGE 270: Load Data
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h:=h||'AEUTL/sql_utl_exprt.htm';

ph:=ph||'<script type="text/javascript">'||chr(10)||
'    var gTextArea = ''F4300_P270_EXCEL_DATA''; // set to textarea item name'||chr(10)||
''||chr(10)||
'    function data_set(){'||chr(10)||
'		var CLobTest = new apex.ajax.clob(function(){'||chr(10)||
'		$x(gTextArea).value=" ";'||chr(10)||
'		doSubmit(''NEXT'')});'||chr(10)||
'        CLobTest._set($x(gTextArea).value);'||chr(10)||
'    }'||chr(10)||
'</script>';

wwv_flow_api.create_page(
  p_id     => 270,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Load Data',
  p_step_title=> 'Load Data',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'NO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => '',
  p_group_id => 216780929601417380+ wwv_flow_api.g_id_offset,
  p_help_text => ' ',
  p_html_page_header => ' ',
  p_step_template => 4537010500402583+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => '',
  p_last_upd_yyyymmddhh24miss => '20080808125926',
  p_page_is_public_y_n=> 'N',
  p_page_comment  => '');
 
wwv_flow_api.set_page_help_text(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>270,p_text=>h);
wwv_flow_api.set_html_page_header(p_flow_id=>wwv_flow.g_flow_id,p_flow_step_id=>270,p_text=>ph);
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 22227711948926632 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 270,
  p_plug_name=> 'Globalization',
  p_region_name=>'',
  p_plug_template=> 22227029497924836+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 30,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 24415935915526789 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 270,
  p_plug_name=> 'Menu',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 1,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_08',
  p_plug_source=> s,
  p_plug_source_type=> 'M'|| to_char(7730219485466113 + wwv_flow_api.g_id_offset),
  p_menu_template_id=> 7732025850477443+ wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205575330388419595 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 270,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 104952229630958795+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 205578009331419608 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 270,
  p_plug_name=> 'Navigation',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 20,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_01',
  p_plug_source=> s,
  p_plug_source_type=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> '',
  p_plug_query_row_count_max => 500,
  p_plug_column_width => 'valign="top"',
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s:=s||'<p>Copy the data you want to import from a spreadsheet program, such as Microsoft Excel, and paste it into the Data field.</p>';

wwv_flow_api.create_page_plug (
  p_id=> 222574407225296287 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 270,
  p_plug_name=> 'Load Data',
  p_region_name=>'',
  p_plug_template=> 105315011844199945+ wwv_flow_api.g_id_offset,
  p_plug_display_sequence=> 40,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'REGION_POSITION_03',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_translate_title=> 'Y',
  p_plug_display_error_message=> '#SQLERRM#',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'QUERY_COLUMNS',
  p_plug_query_num_rows_type => 'NEXT_PREVIOUS_LINKS',
  p_plug_query_row_count_max => 500,
  p_plug_query_show_nulls_as => ' - ',
  p_plug_display_condition_type => '',
  p_pagination_display_position=>'BOTTOM_RIGHT',
  p_plug_customized=>'0',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
wwv_flow_api.create_page_button(
  p_id             => 205575510358419596 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 270,
  p_button_sequence=> 10,
  p_button_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_button_name    => 'Cancel',
  p_button_image_alt=> 'Cancel',
  p_button_position=> 'REGION_TEMPLATE_CLOSE',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'f?p=&APP_ID.:9:&FLOW_SESSION.',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205575817598419597 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 270,
  p_button_sequence=> 10,
  p_button_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_button_name    => 'Next',
  p_button_image_alt=> 'Next &gt;',
  p_button_position=> 'REGION_TEMPLATE_NEXT',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> 'javascript:data_set();',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_page_button(
  p_id             => 205576116516419599 + wwv_flow_api.g_id_offset,
  p_flow_id        => wwv_flow.g_flow_id,
  p_flow_step_id   => 270,
  p_button_sequence=> 10,
  p_button_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_button_name    => 'Previous',
  p_button_image_alt=> '&lt; Previous',
  p_button_position=> 'REGION_TEMPLATE_PREVIOUS',
  p_button_alignment=> 'RIGHT',
  p_button_redirect_url=> '',
  p_button_cattributes=>'class="button10"',
  p_required_patch => null + wwv_flow_api.g_id_offset);
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_branch(
  p_id=>205578335225419610 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_branch_action=> '260',
  p_branch_point=> 'AFTER_PROCESSING',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_sequence=> 10,
  p_branch_condition_type=> 'REQUEST_EQUALS_CONDITION',
  p_branch_condition=> 'NEXT',
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
wwv_flow_api.create_page_branch(
  p_id=>205578606495419612 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_branch_action=> '250',
  p_branch_point=> 'BEFORE_COMPUTATION',
  p_branch_type=> 'BRANCH_TO_STEP',
  p_branch_when_button_id=>205576116516419599+ wwv_flow_api.g_id_offset,
  p_branch_sequence=> 10,
  p_save_state_before_branch_yn=>'N',
  p_branch_comment=> '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Identify a column separator character. Use <strong>\t</strong> for tab separators.</p>';

wwv_flow_api.create_page_item(
  p_id=>5234111068681299 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'F4300_P270_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => ',',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Separator',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P230_LOAD_TYPE',
  p_display_when2=>'CSV',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_reference_id => 3832614597433912,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Identify optional enclosed by character.</p>';

wwv_flow_api.create_page_item(
  p_id=>5235906697689413 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'F4300_P270_ENCLOSED_BY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 40,
  p_item_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Enclosed By',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 2,
  p_cMaxlength=> 2,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_display_when=>'F4300_P230_LOAD_TYPE',
  p_display_when2=>'CSV',
  p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_reference_id => 3832902320433912,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>If your data contains international currency symbol, enter it here.</p>'||chr(10)||
'<p>For example, if your data has "&euro;1,234.56" or "&yen;1,234.56", enter "&euro;" or "&yen;".  Otherwise the data will not load correctly.</p>';

wwv_flow_api.create_page_item(
  p_id=>22228634804933221 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'P270_CURRENCY',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 60,
  p_item_plug_id => 22227711948926632+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'declare'||chr(10)||
'    l_return_val varchar2(30) := ''$'';'||chr(10)||
'begin'||chr(10)||
'    for c1 in (select value'||chr(10)||
'                 from nls_session_parameters'||chr(10)||
'                where parameter = ''NLS_CURRENCY'') loop'||chr(10)||
'        l_return_val := c1.value;'||chr(10)||
'        exit;'||chr(10)||
'    end loop;'||chr(10)||
'    --'||chr(10)||
'    return l_return_val;'||chr(10)||
'end;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Currency Symbol',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'YES',
  p_lov_translated=> 'N',
  p_lov_null_text=>'',
  p_lov_null_value=> '',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>A group separator is a character that separates integer groups, for example to show thousands and millions.</p>'||chr(10)||
'<p>Any character can be the group separator. The character specified must be single-byte, and the group separator must be different from any other decimal character. The character can be a space, but cannot be a numeric character or any of the following:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>';

h:=h||'plus (+)</li>'||chr(10)||
'<li>hyphen (-)</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>22915108415964565 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'P270_GROUP_SEPARATOR',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 70,
  p_item_plug_id => 22227711948926632+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_group_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Group Separator',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>The decimal character separates the integer and decimal parts of a number.</p>'||chr(10)||
'<p> Any character can be the decimal character. The character specified must be single-byte, and the decimal character must be different from group separator. The character can be a space, but cannot be any numeric character or any of the following characters:</p>'||chr(10)||
'<ul class="noIndent">'||chr(10)||
'<li>plus (+)</li>'||chr(10)||
'<li>hyphen (-';

h:=h||')</li> '||chr(10)||
'<li>less than sign (<)</li>'||chr(10)||
'<li>greater than sign (>)</li> '||chr(10)||
'</ul>';

wwv_flow_api.create_page_item(
  p_id=>22916914087975654 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'P270_DECIMAL_CHARACTER',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 80,
  p_item_plug_id => 22227711948926632+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'return wwv_flow.get_nls_decimal_separator;',
  p_item_default_type => 'PLSQL_FUNCTION_BODY',
  p_prompt=>'Decimal Character',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXT',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 1,
  p_cMaxlength=> 1,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'You can paste up to 30KB of data into this field.';

wwv_flow_api.create_page_item(
  p_id=>205576533950419601 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'F4300_P270_EXCEL_DATA',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_prompt=>'Data',
  p_source_type=> 'STATIC',
  p_display_as=> 'TEXTAREA',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 60,
  p_cMaxlength=> 32000,
  p_cHeight=> 10,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'ABOVE',
  p_field_alignment  => 'LEFT',
  p_field_template => 104962133386990472+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_protection_level => 'N',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
h := null;
h:=h||'<p>Select this box if your data contains column names in the first row.</p>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'<pre>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Name     Salary     Commission'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Clark    1000       10'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'Scott    2000       20'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
'</pre>';

wwv_flow_api.create_page_item(
  p_id=>205576834806419602 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'F4300_P270_IS_FIELD_NAME',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 50,
  p_item_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_item_default => 'Y',
  p_item_default_type => 'STATIC_TEXT_WITH_SUBSTITUTIONS',
  p_source_type=> 'STATIC',
  p_display_as=> 'CHECKBOX',
  p_named_lov=> 'ISCOLUMN.NAME.TEXT',
  p_lov => 'select ''<span class="instructiontext">''||'||chr(10)||
'wwv_flow_lang.system_message(''F4300_INSTRUCT_TEXT'')||''</span>'' d, ''Y'' r from dual',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> 1,
  p_cAttributes=> 'nowrap="nowrap"',
  p_tag_attributes  => 'class="fielddataboldl"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_lov_display_extra=>'NO',
  p_help_text   => h,
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>205577120401419604 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_name=>'F4300_P270_X',
  p_data_type=> 'VARCHAR',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 205575330388419595+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> 'YES',
  p_display_as=> 'STOP_AND_START_HTML_TABLE',
  p_lov_columns=> 1,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 30,
  p_cMaxlength=> 2000,
  p_cHeight=> null,
  p_cAttributes=> 'nowrap="nowrap"',
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

 
begin
 
wwv_flow_api.create_page_computation(
  p_id=> 50589030423549556 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 270,
  p_computation_sequence => 10,
  p_computation_item=> 'F4300_P270_IS_FIELD_NAME',
  p_computation_point=> 'AFTER_SUBMIT',
  p_computation_type=> 'STATIC_ASSIGNMENT',
  p_computation_processed=> 'REPLACE_EXISTING',
  p_computation=> 'N',
  p_compute_when => 'F4300_P270_IS_FIELD_NAME',
  p_compute_when_type=>'ITEM_IS_NULL');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 5238122065703308 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 270,
  p_validation_name => 'separator not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P270_SEPARATOR',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Separator must be specified.',
  p_validation_condition=> 'F4300_P230_LOAD_TYPE',
  p_validation_condition2=> 'CSV',
  p_validation_condition_type=> 'VAL_OF_ITEM_IN_COND_EQ_COND2',
  p_associated_item=> 5234111068681299 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 84644604744916146 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 270,
  p_validation_name => 'data cannot be > 30KB',
  p_validation_sequence=> 10,
  p_validation => 'if length(:F4300_P270_EXCEL_DATA) > 30000 then'||chr(10)||
'  return false;'||chr(10)||
'else'||chr(10)||
'  return true;'||chr(10)||
'end if;',
  p_validation_type => 'FUNC_BODY_RETURNING_BOOLEAN',
  p_error_message => 'Data pasted is greater than 30KB.  Save the file in a comma delimited (csv) or tab delimted format. Then upload the file to load the data.',
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_page_validation(
  p_id => 205579208360419614 + wwv_flow_api.g_id_offset,
  p_flow_id => wwv_flow.g_flow_id,
  p_flow_step_id => 270,
  p_validation_name => 'data not null',
  p_validation_sequence=> 10,
  p_validation => 'F4300_P270_EXCEL_DATA',
  p_validation_type => 'ITEM_NOT_NULL',
  p_error_message => 'Data must be specified.',
  p_associated_item=> 205576533950419601 + wwv_flow_api.g_id_offset,
  p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION',
  p_validation_comment=> '');
 
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare  '||chr(10)||
'  l_first_row_is_col_name boolean := false;'||chr(10)||
'  l_data clob := empty_clob();'||chr(10)||
'begin'||chr(10)||
'  select clob001 into l_data from apex_collections where collection_name=''CLOB_CONTENT'';'||chr(10)||
''||chr(10)||
'  if :F4300_P270_IS_FIELD_NAME = ''Y'' then'||chr(10)||
'    l_first_row_is_col_name := true;'||chr(10)||
'  end if;'||chr(10)||
'  wwv_flow_load_excel_data.get_table_info ('||chr(10)||
'   p_string                 => l_data,'||chr(10)||
'   p_separator              => lower(nvl(:F4300';

p:=p||'_P270_SEPARATOR,''\t'')),'||chr(10)||
'   p_enclosed_by            => :F4300_P270_ENCLOSED_BY,  '||chr(10)||
'   p_first_row_is_col_name  => l_first_row_is_col_name,'||chr(10)||
'   p_currency               => :P270_CURRENCY,'||chr(10)||
'   p_numeric_chars          => :P270_DECIMAL_CHARACTER||:P270_GROUP_SEPARATOR,'||chr(10)||
'   p_load_type              => ''EXCEL'''||chr(10)||
'   );'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 205579514485419616 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 270,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'create collection',
  p_process_sql_clob => p, 
  p_process_error_message=> 'Error loading excel data.',
  p_process_when=>'NEXT',
  p_process_when_type=>'REQUEST_EQUALS_CONDITION',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 270
--
 
begin
 
null;
end;
null;
 
end;
/

 
--application/pages/page_00280
prompt  ...PAGE 280: Login
--
 
begin
 
declare
    h varchar2(32767) := null;
    ph varchar2(32767) := null;
begin
h := null;
ph := null;
wwv_flow_api.create_page(
  p_id     => 280,
  p_flow_id=> wwv_flow.g_flow_id,
  p_tab_set=> '',
  p_name   => 'Login',
  p_alias  => 'LOGIN',
  p_step_title=> 'Login',
  p_step_sub_title_type => 'TEXT_WITH_SUBSTITUTIONS',
  p_first_item=> 'AUTO_FIRST_ITEM',
  p_include_apex_css_js_yn=>'Y',
  p_autocomplete_on_off => 'OFF',
  p_help_text => '',
  p_html_page_header => '',
  p_step_template => 1083321622345581+ wwv_flow_api.g_id_offset,
  p_required_patch=> null + wwv_flow_api.g_id_offset,
  p_last_updated_by => 'EXPIMP',
  p_last_upd_yyyymmddhh24miss => '20090806175931',
  p_page_is_public_y_n=> 'Y',
  p_page_comment  => 'This page was generated by the Login Page wizard');
 
end;
 
end;
/

declare
  s varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
s := null;
wwv_flow_api.create_page_plug (
  p_id=> 1069517206005200 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_page_id=> 280,
  p_plug_name=> 'Login Items',
  p_region_name=>'',
  p_plug_template=> 0,
  p_plug_display_sequence=> 10,
  p_plug_display_column=> 1,
  p_plug_display_point=> 'AFTER_SHOW_ITEMS',
  p_plug_source=> s,
  p_plug_source_type=> 'STATIC_TEXT',
  p_plug_query_row_template=> 1,
  p_plug_query_headings_type=> 'COLON_DELMITED_LIST',
  p_plug_query_row_count_max => 500,
  p_plug_display_condition_type => '',
  p_plug_caching=> 'NOT_CACHED',
  p_plug_comment=> '');
end;
/
 
begin
 
null;
 
end;
/

 
begin
 
null;
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>1069707945005203 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 280,
  p_name=>'P280_USERNAME',
  p_data_type=> '',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 10,
  p_item_plug_id => 1069517206005200+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> '',
  p_prompt=>'Username',
  p_display_as=> 'TEXT',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 20,
  p_cMaxlength=> 100,
  p_cHeight=> null,
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>1069921131005203 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 280,
  p_name=>'P280_PASSWORD',
  p_data_type=> '',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 20,
  p_item_plug_id => 1069517206005200+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> '',
  p_prompt=>'Password',
  p_display_as=> 'PASSWORD_WITH_SUBMIT_DNSS',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> 20,
  p_cMaxlength=> 100,
  p_cHeight=> null,
  p_begin_on_new_line => 'YES',
  p_begin_on_new_field=> 'YES',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'RIGHT',
  p_field_alignment  => 'LEFT',
  p_field_template => 104961228191988915+wwv_flow_api.g_id_offset,
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

declare
    h varchar2(32767) := null;
begin
wwv_flow_api.create_page_item(
  p_id=>1070101834005203 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id=> 280,
  p_name=>'P280_LOGIN',
  p_data_type=> '',
  p_accept_processing=> 'REPLACE_EXISTING',
  p_item_sequence=> 30,
  p_item_plug_id => 1069517206005200+wwv_flow_api.g_id_offset,
  p_use_cache_before_default=> '',
  p_item_default => 'Login',
  p_prompt=>'Login',
  p_source=>'LOGIN',
  p_source_type=> 'STATIC',
  p_display_as=> 'BUTTON',
  p_lov_columns=> null,
  p_lov_display_null=> 'NO',
  p_lov_translated=> 'N',
  p_cSize=> null,
  p_cMaxlength=> null,
  p_cHeight=> null,
  p_begin_on_new_line => 'NO',
  p_begin_on_new_field=> 'NO',
  p_colspan => 1,
  p_rowspan => 1,
  p_label_alignment  => 'LEFT',
  p_field_alignment  => 'LEFT',
  p_is_persistent=> 'Y',
  p_item_comment => '');
 
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'begin'||chr(10)||
'sys.owa_util.mime_header(''text/html'', FALSE);'||chr(10)||
'sys.owa_cookie.send(    name=>''LOGIN_USERNAME_COOKIE'','||chr(10)||
'    value=>lower(:P280_USERNAME));'||chr(10)||
'exception when others then null;'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 1070517654005204 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 280,
  p_process_sequence=> 10,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Set Username Cookie',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'wwv_flow_custom_auth_std.login('||chr(10)||
'    P_UNAME       => :P280_USERNAME,'||chr(10)||
'    P_PASSWORD    => :P280_PASSWORD,'||chr(10)||
'    P_SESSION_ID  => v(''APP_SESSION''),'||chr(10)||
'    P_FLOW_PAGE   => :APP_ID||'':1'''||chr(10)||
'    );';

wwv_flow_api.create_page_process(
  p_id     => 1070329822005203 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 280,
  p_process_sequence=> 20,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Login',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'280';

wwv_flow_api.create_page_process(
  p_id     => 1070723627005204 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 280,
  p_process_sequence=> 30,
  p_process_point=> 'AFTER_SUBMIT',
  p_process_type=> 'CLEAR_CACHE_FOR_PAGES',
  p_process_name=> 'Clear',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
declare
  p varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
p:=p||'declare    v varchar2(255) := null;'||chr(10)||
'    c sys.owa_cookie.cookie;'||chr(10)||
'begin   c := sys.owa_cookie.get(''LOGIN_USERNAME_COOKIE'');'||chr(10)||
'   :P280_USERNAME := c.vals(1);'||chr(10)||
'exception when others then null;'||chr(10)||
'end;';

wwv_flow_api.create_page_process(
  p_id     => 1070919862005204 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_flow_step_id => 280,
  p_process_sequence=> 10,
  p_process_point=> 'BEFORE_HEADER',
  p_process_type=> 'PLSQL',
  p_process_name=> 'Get Username Cookie',
  p_process_sql_clob => p, 
  p_process_error_message=> '',
  p_process_success_message=> '',
  p_process_is_stateful_y_n=>'N',
  p_process_comment=>'');
end;
null;
 
end;
/

 
begin
 
---------------------------------------
-- ...updatable report columns for page 280
--
 
begin
 
null;
end;
null;
 
end;
/

prompt  ...lists
--
--application/shared_components/navigation/lists/application_tabs
 
begin
 
wwv_flow_api.create_list (
  p_id=> 2503719680842491 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Application Tabs',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 20059219578187484 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 2504531800846002 + wwv_flow_api.g_id_offset,
  p_list_id=> 2503719680842491 + wwv_flow_api.g_id_offset,
  p_list_item_type=> '',
  p_list_item_status=> '',
  p_item_displayed=> '',
  p_list_item_display_sequence=>1,
  p_list_item_link_text=> 'Home',
  p_list_item_link_target=> 'f?p=4500:1000:&SESSION.',
  p_list_text_01=> '',
  p_list_item_current_type=> '',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 2504805612847866 + wwv_flow_api.g_id_offset,
  p_list_id=> 2503719680842491 + wwv_flow_api.g_id_offset,
  p_list_item_type=> '',
  p_list_item_status=> '',
  p_item_displayed=> '',
  p_list_item_display_sequence=>2,
  p_list_item_link_text=> 'Application Builder',
  p_list_item_link_target=> 'f?p=4000:1500:&SESSION.',
  p_list_text_01=> '',
  p_list_item_current_type=> '',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 232669713659998651 + wwv_flow_api.g_id_offset,
  p_list_id=> 2503719680842491 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>3,
  p_list_item_link_text=> 'Reporting Services',
  p_list_item_link_target=> 'f?p=4800:1:&SESSION.',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_required_patch   => 232668426688992969 + wwv_flow_api.g_id_offset,
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 2505111846849648 + wwv_flow_api.g_id_offset,
  p_list_id=> 2503719680842491 + wwv_flow_api.g_id_offset,
  p_list_item_type=> '',
  p_list_item_status=> '',
  p_item_displayed=> '',
  p_list_item_display_sequence=>4,
  p_list_item_link_text=> 'SQL Workshop',
  p_list_item_link_target=> 'f?p=4500:3002:&SESSION.',
  p_list_text_01=> '',
  p_list_item_current_type=> '',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 2505418425851537 + wwv_flow_api.g_id_offset,
  p_list_id=> 2503719680842491 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>5,
  p_list_item_link_text=> 'Utilities',
  p_list_item_link_target=> 'f?p=4500:1005:&SESSION.',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'ALWAYS',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/data_workshop_home_page_icons
 
begin
 
wwv_flow_api.create_list (
  p_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Data Workshop Home Page Icons',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 25613911889431320 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 3253923572338892 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>5,
  p_list_item_link_text=> 'Load',
  p_list_item_link_target=> 'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::',
  p_list_item_icon   => 'htmldb/builder/dw_import_ctrl.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4971716293382510 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Text Data',
  p_list_item_link_target=> 'f?p=&APP_ID.:230:&SESSION.::NO:13,18,19,21,22,23,24,25::',
  p_parent_list_item_id=> 3253923572338892 + wwv_flow_api.g_id_offset,
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4971404519379114 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>15,
  p_list_item_link_text=> 'Spreadsheet Data',
  p_list_item_link_target=> 'f?p=&APP_ID.:230:&SESSION.::&DEBUG.:200,210,220,230,240,250,260,270:::',
  p_parent_list_item_id=> 3253923572338892 + wwv_flow_api.g_id_offset,
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4972023219384496 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'XML Data',
  p_list_item_link_target=> 'f?p=&APP_ID.:14:&SESSION.::NO:14,16,17::',
  p_parent_list_item_id=> 3253923572338892 + wwv_flow_api.g_id_offset,
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 3254431191341119 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Unload',
  p_list_item_link_target=> 'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::',
  p_list_item_icon   => 'htmldb/builder/dw_export_ctrl.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4975021965393590 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'To Text',
  p_list_item_link_target=> 'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:150,160,170,180:::',
  p_parent_list_item_id=> 3254431191341119 + wwv_flow_api.g_id_offset,
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4975327852395255 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'To XML',
  p_list_item_link_target=> 'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:70,80,90:::',
  p_parent_list_item_id=> 3254431191341119 + wwv_flow_api.g_id_offset,
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 3258212060354534 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Repository',
  p_list_item_link_target=> 'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:::',
  p_list_item_icon   => 'htmldb/builder/dw_repository_ctrl.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 261074016260433817 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Import Repository',
  p_list_item_link_target=> 'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:::',
  p_parent_list_item_id=> 3258212060354534 + wwv_flow_api.g_id_offset,
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 261074522840435687 + wwv_flow_api.g_id_offset,
  p_list_id=> 3253511105335259 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Spreadsheet Imports',
  p_list_item_link_target=> 'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP:::',
  p_parent_list_item_id=> 3258212060354534 + wwv_flow_api.g_id_offset,
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/data_import
 
begin
 
wwv_flow_api.create_list (
  p_id=> 4700318156244396 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'data import',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 4534221079386110 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 221791316990678072 + wwv_flow_api.g_id_offset,
  p_list_id=> 4700318156244396 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Spreadsheet Import Repository',
  p_list_item_link_target=> 'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_EQUALS_CONDITION',
  p_list_item_disp_condition=> '8',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4705335387268326 + wwv_flow_api.g_id_offset,
  p_list_id=> 4700318156244396 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Text Data Import Repository',
  p_list_item_link_target=> 'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_EQUALS_CONDITION',
  p_list_item_disp_condition=> '11',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/plain_text_data_import
 
begin
 
wwv_flow_api.create_list (
  p_id=> 4983219175650688 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Plain Text Data Import',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 24383823751201815 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 4984112726658207 + wwv_flow_api.g_id_offset,
  p_list_id=> 4983219175650688 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'File Details',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '18,19,21,13',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '18',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4984724847661724 + wwv_flow_api.g_id_offset,
  p_list_id=> 4983219175650688 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Table Properties',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '18,19,21,13',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '19',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4985134197664460 + wwv_flow_api.g_id_offset,
  p_list_id=> 4983219175650688 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>40,
  p_list_item_link_text=> 'Primary Key',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '18,19,21,13',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '21',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/plain_text_data_import2
 
begin
 
wwv_flow_api.create_list (
  p_id=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Plain Text Data Import2',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 24383823751201815 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 4986419090669558 + wwv_flow_api.g_id_offset,
  p_list_id=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Schema',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '22',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4986723246670754 + wwv_flow_api.g_id_offset,
  p_list_id=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Table Name',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '23',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4987032596673483 + wwv_flow_api.g_id_offset,
  p_list_id=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>40,
  p_list_item_link_text=> 'File Details',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '24',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 4987305369675079 + wwv_flow_api.g_id_offset,
  p_list_id=> 4985609394666721 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>50,
  p_list_item_link_text=> 'Column Mapping',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '25',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/builder_tab_list
 
begin
 
wwv_flow_api.create_list (
  p_id=> 20150712595441212 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'builder.tab.list',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 20059219578187484 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 28397920817896531 + wwv_flow_api.g_id_offset,
  p_list_id=> 20150712595441212 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>1,
  p_list_item_link_text=> '&PRODUCT_NAME.',
  p_list_item_link_target=> 'f?p=4350:1:&SESSION.',
  p_list_item_disp_cond_type=> 'NEVER',
  p_list_item_disp_condition=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 20151223677444378 + wwv_flow_api.g_id_offset,
  p_list_id=> 20150712595441212 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Application&nbsp;Builder',
  p_list_item_link_target=> 'f?p=4000:1500:&SESSION.::&DEBUG.:::',
  p_list_item_disp_cond_type=> 'EXISTS',
  p_list_item_disp_condition=> 'select 1 from wwv_flows where security_group_id = :flow_security_group_id',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 20151531295446634 + wwv_flow_api.g_id_offset,
  p_list_id=> 20150712595441212 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'SQL&nbsp;Workshop',
  p_list_item_link_target=> 'f?p=4500:1000:&SESSION.',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'ALWAYS',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 20151809609449753 + wwv_flow_api.g_id_offset,
  p_list_id=> 20150712595441212 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>50,
  p_list_item_link_text=> 'Data&nbsp;Workshop',
  p_list_item_link_target=> 'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::',
  p_list_item_disp_cond_type=> 'NEVER',
  p_list_item_disp_condition=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'ALWAYS',
  p_list_item_current_for_pages=> 'f?p=4300:9:&SESSION.',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 28752105247894463 + wwv_flow_api.g_id_offset,
  p_list_id=> 20150712595441212 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>60,
  p_list_item_link_text=> 'Administration',
  p_list_item_link_target=> 'f?p=4350:1:&SESSION.',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/data_loading
 
begin
 
wwv_flow_api.create_list (
  p_id=> 75759075581086176 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Data Loading',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 339707508887552474 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 3689513576149988 + wwv_flow_api.g_id_offset,
  p_list_id=> 75759075581086176 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Load Text Data',
  p_list_item_link_target=> 'f?p=&APP_ID.:230:&SESSION.::&DEBUG.:18,19,21,22,23,24,25:F4300_P230_LOAD_FROM:UPLOAD:',
  p_list_item_icon   => 'htmldb/builder/abc_upload.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> 'Load data from structured flat files, such as files with comma separated data(cvs) or tab separated data.',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 127720709179699282 + wwv_flow_api.g_id_offset,
  p_list_id=> 75759075581086176 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>15,
  p_list_item_link_text=> 'Load Spreadsheet Data',
  p_list_item_link_target=> 'f?p=&APP_ID.:230:&SESSION.::&DEBUG.:200,210,220,230,240,250,260,270:::',
  p_list_item_icon   => 'htmldb/builder/load_excel.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> 'Convert Spreadsheets into database tables.',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 75761624797099570 + wwv_flow_api.g_id_offset,
  p_list_id=> 75759075581086176 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Load XML Data',
  p_list_item_link_target=> 'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:14,16,17:::',
  p_list_item_icon   => 'htmldb/builder/xml_upload2.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> 'Load data from XML in canonical format.',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/data_unloading
 
begin
 
wwv_flow_api.create_list (
  p_id=> 76637294131660469 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Data Unloading',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 339707508887552474 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 76665925230713955 + wwv_flow_api.g_id_offset,
  p_list_id=> 76637294131660469 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Unload to Text',
  p_list_item_link_target=> 'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:150,160,170,180:::',
  p_list_item_icon   => 'htmldb/builder/load_ascii.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> 'Export database data to a flat file.',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 76667822814719281 + wwv_flow_api.g_id_offset,
  p_list_id=> 76637294131660469 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Unload to XML',
  p_list_item_link_target=> 'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:70,80,90:::',
  p_list_item_icon   => 'htmldb/builder/load_xml.gif',
  p_list_item_icon_attributes=> 'width="100" height="75" title="#LIST_LABEL#" alt="#LIST_LABEL#"',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> 'Export database data to an XML document.',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/plain_text_data_export
 
begin
 
wwv_flow_api.create_list (
  p_id=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Plain Text Data Export',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 24383823751201815 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 105420519587016858 + wwv_flow_api.g_id_offset,
  p_list_id=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Schema',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '150',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 105421215489018791 + wwv_flow_api.g_id_offset,
  p_list_id=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Table Name',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '160',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 105421912039020320 + wwv_flow_api.g_id_offset,
  p_list_id=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Columns',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '170',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 105422609235021705 + wwv_flow_api.g_id_offset,
  p_list_id=> 105409615761684342 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>40,
  p_list_item_link_text=> 'Options',
  p_list_item_link_target=> '',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '180',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/xml_export
 
begin
 
wwv_flow_api.create_list (
  p_id=> 105468428380073513 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'XML Export',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 24383823751201815 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 105469924282075459 + wwv_flow_api.g_id_offset,
  p_list_id=> 105468428380073513 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Schema',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '70',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 105470621047076953 + wwv_flow_api.g_id_offset,
  p_list_id=> 105468428380073513 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Table Name',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '80',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 105471316734078948 + wwv_flow_api.g_id_offset,
  p_list_id=> 105468428380073513 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Columns',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '90',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/excel_data_import
 
begin
 
wwv_flow_api.create_list (
  p_id=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Excel Data Import',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 24383823751201815 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 205731718823756852 + wwv_flow_api.g_id_offset,
  p_list_id=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>5,
  p_list_item_link_text=> 'Target and Method',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '230',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 113771030606048831 + wwv_flow_api.g_id_offset,
  p_list_id=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Data',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '200,210,220,230',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '200',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 113771726509050799 + wwv_flow_api.g_id_offset,
  p_list_id=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Table Properties',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '200,210,220,230',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '210',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 118115311866905343 + wwv_flow_api.g_id_offset,
  p_list_id=> 113767907543044350 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Primary Key',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '200,210,220,230',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '220',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/xml_import
 
begin
 
wwv_flow_api.create_list (
  p_id=> 185325332067236431 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'XML Import',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 24383823751201815 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 185327127107238729 + wwv_flow_api.g_id_offset,
  p_list_id=> 185325332067236431 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Schema',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '14',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 185327924303240052 + wwv_flow_api.g_id_offset,
  p_list_id=> 185325332067236431 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Table Name',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '16',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 185328720205241952 + wwv_flow_api.g_id_offset,
  p_list_id=> 185325332067236431 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'File Name',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '17',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/lists/excel_data_import2
 
begin
 
wwv_flow_api.create_list (
  p_id=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Excel Data Import2',
  p_list_status=> 'PUBLIC',
  p_list_displayed=> 'BY_DEFAULT',
  p_display_row_template_id=> 24383823751201815 + wwv_flow_api.g_id_offset);
 
wwv_flow_api.create_list_item (
  p_id=> 205746924406784630 + wwv_flow_api.g_id_offset,
  p_list_id=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>10,
  p_list_item_link_text=> 'Type and Method',
  p_list_item_link_target=> '',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '230',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 205749415995788557 + wwv_flow_api.g_id_offset,
  p_list_id=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>20,
  p_list_item_link_text=> 'Schema',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '240,250,260,270',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '240',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 205750609310791690 + wwv_flow_api.g_id_offset,
  p_list_id=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>30,
  p_list_item_link_text=> 'Table Name',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '240,250,260,270',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '250',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 205753530001797227 + wwv_flow_api.g_id_offset,
  p_list_id=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>40,
  p_list_item_link_text=> 'Data',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '240,250,260,270',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '270',
  p_list_item_owner=> '');
 
wwv_flow_api.create_list_item (
  p_id=> 205762413610804861 + wwv_flow_api.g_id_offset,
  p_list_id=> 205745129150782488 + wwv_flow_api.g_id_offset,
  p_list_item_type=> 'LINK',
  p_list_item_status=> 'PUBLIC',
  p_item_displayed=> 'BY_DEFAULT',
  p_list_item_display_sequence=>50,
  p_list_item_link_text=> 'Column Mapping',
  p_list_item_link_target=> '',
  p_list_item_disp_cond_type=> 'CURRENT_PAGE_IN_CONDITION',
  p_list_item_disp_condition=> '240,250,260,270',
  p_list_countclicks_y_n=> 'N',
  p_list_text_01=> '',
  p_list_item_current_type=> 'COLON_DELIMITED_PAGE_LIST',
  p_list_item_current_for_pages=> '260',
  p_list_item_owner=> '');
 
null;
 
end;
/

--application/shared_components/navigation/breadcrumbs
prompt  ...breadcrumbs
--
 
begin
 
wwv_flow_api.create_menu (
  p_id=> 7730219485466113 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'dataworkshop.menu');
 
wwv_flow_api.create_menu_option (
  p_id=>3263017880365057 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>29539710354330068 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Data Load/Unload',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::',
  p_page_id=>1,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3263017880365057 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::',
  p_page_id=>4,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3263017880365057 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::',
  p_page_id=>9,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7733519632482131 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.:::',
  p_page_id=>230,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7738316169498927 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load XML Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::',
  p_page_id=>14,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7740706464503416 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload to XML',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::',
  p_page_id=>70,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7741935135505358 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload to Text',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:::',
  p_page_id=>150,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7744023921510531 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::',
  p_page_id=>200,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7745517451513542 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:::',
  p_page_id=>210,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7746511628516240 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:220:&SESSION.::&DEBUG.:::',
  p_page_id=>220,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7879435073524168 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::',
  p_page_id=>18,
  p_also_current_for_pages=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_menu_option (
  p_id=>7880819545531313 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::',
  p_page_id=>19,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7882013075534319 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::',
  p_page_id=>21,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7888524900574457 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3263017880365057 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Text Data Load Repository',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::',
  p_page_id=>8,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7894904615599101 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload to XML',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:::',
  p_page_id=>80,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7896031560601771 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload to XML',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:90:&SESSION.::&DEBUG.:::',
  p_page_id=>90,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7897621424606412 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload to Text',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:160:&SESSION.::&DEBUG.:::',
  p_page_id=>160,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7899014954609507 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload to Text',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:170:&SESSION.::&DEBUG.:::',
  p_page_id=>170,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>7900110641611504 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3277426038406896 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Unload to Text',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:180:&SESSION.::&DEBUG.:::',
  p_page_id=>180,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>10442004841110006 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>3263017880365057 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Spreadsheet Repository',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::',
  p_page_id=>11,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>24408121448467470 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::',
  p_page_id=>22,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>24409414547470667 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::',
  p_page_id=>23,
  p_also_current_for_pages=> '');
 
null;
 
end;
/

 
begin
 
wwv_flow_api.create_menu_option (
  p_id=>24410510234472698 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::',
  p_page_id=>24,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>24411932434477573 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::',
  p_page_id=>25,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>24414236063521477 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:240:&SESSION.::&DEBUG.:::',
  p_page_id=>240,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>24416124633526790 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:270:&SESSION.::&DEBUG.:::',
  p_page_id=>270,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>24417418810529499 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:260:&SESSION.::&DEBUG.:::',
  p_page_id=>260,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>76450535769547686 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7888524900574457 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Text Data Load Details',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::',
  p_page_id=>7,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>76452617007556352 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load XML Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::',
  p_page_id=>16,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>76454212909558251 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load XML Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::',
  p_page_id=>17,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>76456431228564956 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>7730735069470611 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Load Data',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:250:&SESSION.::&DEBUG.:::',
  p_page_id=>250,
  p_also_current_for_pages=> '');
 
wwv_flow_api.create_menu_option (
  p_id=>237968423117893501 + wwv_flow_api.g_id_offset,
  p_menu_id=>7730219485466113 + wwv_flow_api.g_id_offset,
  p_parent_id=>10442004841110006 + wwv_flow_api.g_id_offset,
  p_option_sequence=>10,
  p_short_name=>'Spreadsheet Load Details',
  p_long_name=>'',
  p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::',
  p_page_id=>2,
  p_also_current_for_pages=> '');
 
null;
 
end;
/

prompt  ...page templates for application: 101
--
--application/shared_components/user_interface/templates/page/4300_printer_friendly
prompt  ......Page template 1060517913932420
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<html lang="&BROWSER_LANGUAGE." xmlns="http://www.w3.org/1999/xhtml" xmlns:htmldb="http://htmldb.oracle.com" xmlns:apex="http://apex.oracle.com">'||chr(10)||
'<head><title>#TITLE#</title><link rel="icon" href="#IMAGE_PREFIX#favicon.ico" type="image/x-icon"><link rel="shortcut icon" href="#IMAGE_PREFIX#favicon.ico" type="image/x-icon">#HEAD#<link rel="stylesheet" href="#IMAGE_PREFIX#css/apex_builder_3_1.css" ty';

c1:=c1||'pe="text/css" /><!--[if IE]><link rel="stylesheet" href="#IMAGE_PREFIX#css/apex_builder_ie_3_1.css" type="text/css" /><![endif]--></head><body #ONLOAD#><noscript>&MSG_JSCRIPT.</noscript>#FORM_OPEN#<a name="PAGETOP"></a>';

c2:=c2||'</body>'||chr(10)||
'</html>';

c3:=c3||'<br />#BOX_BODY#';

wwv_flow_api.create_template(
  p_id=> 1060517913932420 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> '4300_printer-friendly',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="htmldbSuccessMessage" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#SUCCESS_MESSAGE#</div>',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="htmldbNotification" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#MESSAGE#</div>',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="2" width="100%"',
  p_theme_id  => 3,
  p_theme_class_id => 5,
  p_error_page_template => '<br />'||chr(10)||
'<br />'||chr(10)||
'<pre>#MESSAGE#</pre>'||chr(10)||
'<a href="#BACK_LINK#">#RETURN_TO_APPLICATION#</a>',
  p_reference_id=> 80874804748045950,
  p_translate_this_template => 'N',
  p_template_comment => '');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/login
prompt  ......Page template 1083321622345581
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<html lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
'<link rel="stylesheet" href="#IMAGE_PREFIX#themes/theme_12/theme_3_1.css" type="text/css" />'||chr(10)||
'#HEAD#'||chr(10)||
'</head>'||chr(10)||
'<body #ONLOAD#>#FORM_OPEN#';

c2:=c2||'#FORM_CLOSE#</body>'||chr(10)||
'</html>'||chr(10)||
'';

c3:=c3||'#NOTIFICATION_MESSAGE#'||chr(10)||
'<table class="t12Login" align="center" summary=""><tr><td class="t12Body">#BOX_BODY#</td></tr></table>'||chr(10)||
'';

wwv_flow_api.create_template(
  p_id=> 1083321622345581 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Login',
  p_body_title=> '#BODY_TITLE#',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="t12success" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#SUCCESS_MESSAGE#</div>',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="t12notification" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#MESSAGE#</div>',
  p_navigation_bar=> '',
  p_navbar_entry=> '',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> 'width="100%" border="0" cellpadding="0" cellspacing="0" summary="" ',
  p_theme_id  => 3,
  p_theme_class_id => 6,
  p_translate_this_template => 'N',
  p_template_comment => '');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/green_look_left_and_right_sidebars_from_4999
prompt  ......Page template 4537010500402583
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<html lang="&BROWSER_LANGUAGE." xmlns="http://www.w3.org/1999/xhtml" xmlns:htmldb="http://htmldb.oracle.com" xmlns:apex="http://apex.oracle.com">'||chr(10)||
'<head><title>#TITLE#</title><link rel="icon" href="#IMAGE_PREFIX#favicon.ico" type="image/x-icon"><link rel="shortcut icon" href="#IMAGE_PREFIX#favicon.ico" type="image/x-icon">#HEAD#<link rel="stylesheet" href="#IMAGE_PREFIX#css/apex_builder_3_1.css" ty';

c1:=c1||'pe="text/css" /><!--[if IE]><link rel="stylesheet" href="#IMAGE_PREFIX#css/apex_builder_ie_3_1.css" type="text/css" /><![endif]--></head><body #ONLOAD#><noscript>&MSG_JSCRIPT.</noscript>#FORM_OPEN#<a name="PAGETOP"></a>'||chr(10)||
'';

c2:=c2||'<div class="htmldbFlowL">&MSG_LANGUAGE.: &BROWSER_LANGUAGE.</div>'||chr(10)||
'<div class="htmldbFlowV">#FLOW_VERSION#</div>'||chr(10)||
'<div class="htmldbNewBottom">'||chr(10)||
''||chr(10)||
'<br />'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE#'||chr(10)||
'<a name="END"><br /></a>'||chr(10)||
'</body>'||chr(10)||
'</html>';

c3:=c3||'<table summary="" cellpadding="0" cellspacing="0" border="0" width="100%">'||chr(10)||
'<tr>'||chr(10)||
'<td align="left"><a id="htmldbLogo2" href="#HOME_LINK#">#LOGO#</a></td>'||chr(10)||
'<td valign="top" align="right" class="NavBar">#NAVIGATION_BAR#<td>'||chr(10)||
'</tr>'||chr(10)||
'<tr>'||chr(10)||
'<td valign="bottom" align="right" colspan="2"><div id="htmldbPageTabs">#REGION_POSITION_07#</div></td><td>'||chr(10)||
'</tr>'||chr(10)||
'</table>'||chr(10)||
'<div id="htmldbBreadcrumbTop"><br /></div>'||chr(10)||
'<div ';

c3:=c3||'class="htmldbBreadcrumbRegion"><div class="htmldbBreadcrumbs">#REGION_POSITION_08#<span id="htmldbCustomize">#CUSTOMIZE#</span></div></div>'||chr(10)||
'<div id="htmldbMessageHolder">#SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#</div>'||chr(10)||
'<div class="htmldbBodyMargin">'||chr(10)||
'<table summary="" cellpadding="0" cellspacing="0" border="0" height="70%" class="htmldbRightLeftSidebar">'||chr(10)||
'<tr>'||chr(10)||
'<td valign="top">#REG';

c3:=c3||'ION_POSITION_01#</td>'||chr(10)||
'<td class="htmldbColumnSep"><div class="htmldbColumnSep"><br /></div></td>'||chr(10)||
'<td valign="top" width="100%"><a name="SkipRepNav"></a><div>#REGION_POSITION_02##REGION_POSITION_04##BOX_BODY#</div></td>'||chr(10)||
'<td class="htmldbColumnSep"><div class="htmldbColumnSep"><br /></div></td>'||chr(10)||
'<td valign="top"><div syle="float:right;">#REGION_POSITION_03##REGION_POSITION_05#</div></td>'||chr(10)||
'</tr>'||chr(10)||
'</tabl';

c3:=c3||'e>'||chr(10)||
'</div>';

wwv_flow_api.create_template(
  p_id=> 4537010500402583 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Green Look (Left And Right SideBars) From 4999',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="htmldbSuccessMessage" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#SUCCESS_MESSAGE#</div>'||chr(10)||
'',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="htmldbNotification" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#MESSAGE#</div>'||chr(10)||
'',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<a href="#LINK#" class="htmldbNavLink">#TEXT#</a>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="2" width="100%"',
  p_breadcrumb_def_reg_pos => 'REGION_POSITION_08',
  p_theme_id  => 3,
  p_theme_class_id => 16,
  p_error_page_template => '<br />'||chr(10)||
'<br />'||chr(10)||
'<pre>#MESSAGE#</pre>'||chr(10)||
'<a href="#BACK_LINK#">#RETURN_TO_APPLICATION#</a>',
  p_reference_id=> 18525205721780073,
  p_template_comment => '<div class="htmldbNewBottom1"><span>&MSG_COMPANY.</span><span>&MSG_USER.: &USER.</span></div>'||chr(10)||
'<div class="htmldbNewBottom2">&MSG_COPYRIGHT.</div>');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/green_look_right_sidebar_from_4999
prompt  ......Page template 8556812635064095
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<html lang="&BROWSER_LANGUAGE." xmlns="http://www.w3.org/1999/xhtml" xmlns:htmldb="http://htmldb.oracle.com" xmlns:apex="http://apex.oracle.com">'||chr(10)||
'<head><title>#TITLE#</title><link rel="icon" href="#IMAGE_PREFIX#favicon.ico" type="image/x-icon"><link rel="shortcut icon" href="#IMAGE_PREFIX#favicon.ico" type="image/x-icon">#HEAD#<link rel="stylesheet" href="#IMAGE_PREFIX#css/apex_builder_3_1.css" ty';

c1:=c1||'pe="text/css" /><!--[if IE]><link rel="stylesheet" href="#IMAGE_PREFIX#css/apex_builder_ie_3_1.css" type="text/css" /><![endif]--></head><body #ONLOAD#><noscript>&MSG_JSCRIPT.</noscript>#FORM_OPEN#<a name="PAGETOP"></a>';

c2:=c2||'<div class="htmldbFlowL">&MSG_LANGUAGE.: &BROWSER_LANGUAGE.</div>'||chr(10)||
'<div class="htmldbFlowV">#FLOW_VERSION#</div>'||chr(10)||
'<div class="htmldbNewBottom">'||chr(10)||
''||chr(10)||
'<br />'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE#'||chr(10)||
'<a name="END"><br /></a>'||chr(10)||
'</body>'||chr(10)||
'</html>'||chr(10)||
'';

c3:=c3||'<table summary="" cellpadding="0" cellspacing="0" border="0" width="100%">'||chr(10)||
'<tr>'||chr(10)||
'<td align="left"><a id="htmldbLogo2" href="#HOME_LINK#">#LOGO#</a></td>'||chr(10)||
'<td valign="top" align="right" class="NavBar">#NAVIGATION_BAR#<td>'||chr(10)||
'</tr>'||chr(10)||
'<tr>'||chr(10)||
'<td valign="bottom" align="right" colspan="2"><div id="htmldbPageTabs">#REGION_POSITION_07#</div></td><td>'||chr(10)||
'</tr>'||chr(10)||
'</table>'||chr(10)||
'<div id="htmldbBreadcrumbTop"><br /></div>'||chr(10)||
'<div ';

c3:=c3||'class="htmldbBreadcrumbRegion"><div class="htmldbBreadcrumbs">#REGION_POSITION_08#<span id="htmldbCustomize">#CUSTOMIZE#</span></div></div>'||chr(10)||
'<a name="SkipRepNav"></a>'||chr(10)||
'<div id="htmldbMessageHolder">#SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#</div>'||chr(10)||
'<div class="htmldbBodyMargin">'||chr(10)||
'<div>#REGION_POSITION_01#</div>'||chr(10)||
'<table summary="" cellpadding="0" cellspacing="0" border="0" height="70%">';

c3:=c3||''||chr(10)||
'<tr>'||chr(10)||
'<td width="100%" valign="top">#REGION_POSITION_02##BOX_BODY#</td>'||chr(10)||
'<td class="htmldbColumnSep"><div class="htmldbColumnSep"><br /></div></td>'||chr(10)||
'<td valign="top"><div style="float:right">#REGION_POSITION_03##REGION_POSITION_05#</div></td>'||chr(10)||
'</tr>'||chr(10)||
'</table>'||chr(10)||
'<div>#REGION_POSITION_04#</div>'||chr(10)||
'</div>';

wwv_flow_api.create_template(
  p_id=> 8556812635064095 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Green Look (Right SideBar) From 4999',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="htmldbSuccessMessage" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#SUCCESS_MESSAGE#</div>'||chr(10)||
'',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="htmldbNotification" id="MESSAGE"><img src="#IMAGE_PREFIX#delete.gif" onclick="$x_Remove(''MESSAGE'')"  style="float:right;" class="pb" alt="" />#MESSAGE#</div>'||chr(10)||
'',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<a href="#LINK#" class="htmldbNavLink">#TEXT#</a>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="2" width="100%"',
  p_breadcrumb_def_reg_pos => 'REGION_POSITION_08',
  p_theme_id  => 3,
  p_theme_class_id => 1,
  p_error_page_template => '<br />'||chr(10)||
'<br />'||chr(10)||
'<pre>#MESSAGE#</pre>'||chr(10)||
'<a href="#BACK_LINK#">#RETURN_TO_APPLICATION#</a>',
  p_reference_id=> 18525411970780075,
  p_template_comment => '<div class="htmldbNewBottom1"><span>&MSG_COMPANY.</span><span>&MSG_USER.: &USER.</span></div>'||chr(10)||
'<div class="htmldbNewBottom2">&MSG_COPYRIGHT.</div>');
end;
 
null;
 
end;
/

prompt  ...button templates
--
---------------------------------------
prompt  ...region templates
--
--application/shared_components/user_interface/templates/region/gray_box
prompt  ......region template 1060517925932426
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table class="htmldbGBR" cellspacing="0" cellpadding="0" border="0" summary="" id="#REGION_STATIC_ID#"><thead><tr><th class="T">#TITLE#</th><th class="BT">#CLOSE#&nbsp;#EDIT##EXPAND##HELP##DELETE##COPY##CREATE#<img src="#IMAGE_PREFIX#up_arrow.gif" alt="&TOP." class="pb" onclick="uF()"/></th></tr></thead><tbody><tr><td colspan="2" class="B">#BODY#</td></tr></tbody></table>';

t2 := null;
wwv_flow_api.create_plug_template (
  p_id       => 1060517925932426 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'gray-box',
  p_plug_table_bgcolor     => '',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_plug_heading_bgcolor => '',
  p_plug_font_size => '',
  p_reference_id=> 17353903289599940,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 1060517925932426 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/tasks
prompt  ......region template 4528817837362977
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table cellspacing="0" cellpadding="0" border="0" class="htmldbTasks" summary="" id="#REGION_STATIC_ID#"><tbody><tr><th class="L"><br /></th><th class="C">#TITLE#</th><th class="R"><br /></th></tr><tr><td colspan="3" class="B">#BODY#</td></tr></tbody></table>';

t2:=t2||' ';

wwv_flow_api.create_plug_template (
  p_id       => 4528817837362977 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'Tasks',
  p_plug_table_bgcolor     => '#F7F7E7',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_plug_heading_bgcolor => '#F7F7E7',
  p_plug_font_size => '-1',
  p_reference_id=> 30436620668141833,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2:=t2||' ';

wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 4528817837362977 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/topbar
prompt  ......region template 4970025974596251
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table class="TopBarUIFix" cellpadding="0" cellspacing="0" border="0" summary="" id="#REGION_STATIC_ID#" width="100%"><tbody class="GreenBar"><tr><td width="10"><img src="#IMAGE_PREFIX#htmldb/builder/bar_top.png" width="10" height="8" alt="" /></td><td rowspan="3" valign="middle" class="L">#BODY#</td><td rowspan="3" width="30" class="C"><br /></td><td rowspan="3" valign="middle" class="R" align="r';

t:=t||'ight" style="white-space:nowrap;"><span style="margin-right:10px;">#CLOSE#</span>#COPY##DELETE##CHANGE##EDIT##PREVIOUS##NEXT##CREATE##EXPAND#</td></tr><tr><td style="background-image:url(#IMAGE_PREFIX#htmldb/builder/bar_bg.png)"><br /></td></tr><tr><td><img src="#IMAGE_PREFIX#htmldb/builder/bar_bottom.png" width="10" height="8"  alt="" /></td></tr></tbody></table>';

t2:=t2||' ';

wwv_flow_api.create_plug_template (
  p_id       => 4970025974596251 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'topBar',
  p_plug_table_bgcolor     => '',
  p_theme_id  => 3,
  p_theme_class_id => 21,
  p_plug_heading_bgcolor => '',
  p_plug_font_size => '',
  p_reference_id=> 17356300146599944,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2:=t2||' ';

wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 4970025974596251 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/show_hide
prompt  ......region template 22227029497924836
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table class="htmldbShowHide" cellpadding="0" cellspacing="0" border="0" summary="" id="#REGION_STATIC_ID#"><thead id="head#REGION_STATIC_ID#"><tr><th class="htmldbShowHide"><span onclick="htmldb_ToggleTableBody(''i#REGION_STATIC_ID#'',''body#REGION_STATIC_ID#'')"><img src="#IMAGE_PREFIX#htmldb/builder/rollup_plus_dgray.gif" class="pseudoButtonActive" id="i#REGION_STATIC_ID#" alt="" />#TITLE#</span></';

t:=t||'th></tr></thead><tbody style="display:none;" id="body#REGION_STATIC_ID#"><tr><td class="htmldbShowHide">#BODY#</td></tr></tbody></table>';

t2 := null;
wwv_flow_api.create_plug_template (
  p_id       => 22227029497924836 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'Show / Hide',
  p_plug_table_bgcolor     => '',
  p_theme_id  => 3,
  p_theme_class_id => 1,
  p_plug_heading_bgcolor => '',
  p_plug_font_size => '',
  p_reference_id=> 18662712241194598,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 22227029497924836 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/top_bar_white_collapsed
prompt  ......region template 29141618418030112
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table style="margin:0px;" cellpadding="0" cellspacing="0" border="0" summary="" id="#REGION_STATIC_ID#"><tbody><tr><td valign="middle" nowrap="nowrap" style="border:none;">#BODY#</th><th width="30"><br /></th><td valign="middle" nowrap="nowrap" style="border:none;" valign="middle">#CLOSE##EDIT##DELETE##CREATE##CREATE2##PREVIOUS##NEXT#</th></tr></tbody></table>';

t2:=t2||'class="htmldbInstruct"';

wwv_flow_api.create_plug_template (
  p_id       => 29141618418030112 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'Top Bar (white) (collapsed)',
  p_plug_table_bgcolor     => '#FFFFFF',
  p_theme_id  => 3,
  p_theme_class_id => 21,
  p_plug_heading_bgcolor => '#FFFFFF',
  p_plug_font_size => '-1',
  p_reference_id=> 17586323272111445,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2:=t2||'class="htmldbInstruct"';

wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 29141618418030112 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/report_region
prompt  ......region template 102787020102073196
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table class="htmldbRR" cellpadding="0" cellspacing="0" border="0" summary="" id="#REGION_STATIC_ID#"><thead><tr><th class="T">#TITLE#</th><th class="BT" valign="bottom">#CLOSE#&nbsp;&nbsp;#EDIT##DELETE##CREATE##CREATE2#&nbsp;&nbsp;&nbsp;#PREVIOUS##NEXT#</th></tr></thead><tbody><tr><td colspan="2" class="B">#BODY#</td></tr></tbody></table>';

t2:=t2||'class="htmldbInstruct"';

wwv_flow_api.create_plug_template (
  p_id       => 102787020102073196 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'Report Region',
  p_plug_table_bgcolor     => '#FFFFFF',
  p_theme_id  => 3,
  p_theme_class_id => 9,
  p_plug_heading_bgcolor => '#FFFFFF',
  p_plug_font_size => '-1',
  p_reference_id=> 17354512447599941,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2:=t2||'class="htmldbInstruct"';

wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 102787020102073196 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/wizard_box
prompt  ......region template 104952229630958795
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table class="htmldbWizard" summary="" cellpadding="0" cellspacing="0" border="0" id="#REGION_STATIC_ID#"><thead><tr><th class="H1">#TITLE#</th><th class="H2">#CLOSE#&nbsp;&nbsp;&nbsp;#DELETE##EDIT##CHANGE##PREVIOUS##NEXT##CREATE#</th></tr></thead><tbody><tr><td colspan="2" class="B">#BODY#</td></tr></tbody></table>';

t2 := null;
wwv_flow_api.create_plug_template (
  p_id       => 104952229630958795 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'Wizard Box',
  p_plug_table_bgcolor     => '',
  p_theme_id  => 3,
  p_theme_class_id => 12,
  p_plug_heading_bgcolor => '',
  p_plug_font_size => '',
  p_reference_id=> 18253116293565611,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 104952229630958795 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/info_c_htmldbinfo_from_4999
prompt  ......region template 105315011844199945
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table cellspacing="0" cellpadding="0" border="0" class="htmldbInfo" summary="" id="#REGION_STATIC_ID#"><thead><tr><th class="L"><br /></th><th class="C">#TITLE#</th><th class="R"><br /></th></tr></thead><tbody><tr><td colspan="3" class="B">#BODY#</td></tr></tbody></table>';

t2:=t2||' ';

wwv_flow_api.create_plug_template (
  p_id       => 105315011844199945 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'Info (c:htmldbInfo)  From 4999',
  p_plug_table_bgcolor     => '#F7F7E7',
  p_theme_id  => 3,
  p_theme_class_id => 2,
  p_plug_heading_bgcolor => '#F7F7E7',
  p_plug_font_size => '-1',
  p_reference_id=> 17355419405599943,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2:=t2||' ';

wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 105315011844199945 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/top_bar_panel_ui_fix_collapsed
prompt  ......region template 109257010113732748
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table class="TopBarUIFix" cellpadding="0" cellspacing="0" border="0" summary="" id="#REGION_STATIC_ID#"><tbody><tr><td><img src="#IMAGE_PREFIX#htmldb/builder/builder_find_top.png" width="10" height="8" alt="" /></td><td rowspan="3" class="TopBarUIFixC" valign="middle"><a href="javascript:popupURL(''f?p=4000:577:&SESSION.:&APP_PAGE_ID.'')">&nbsp;</a></td><td rowspan="3" class="TopBarUIFixL" valign="';

t:=t||'middle" style="">#BODY#</td><td rowspan="3" width="30"><br /></td><td rowspan="3" class="TopBarUIFixR" valign="middle"><span style="margin-right:10px;">#CLOSE#</span><span>#EDIT##DELETE##CREATE##CREATE2##PREVIOUS##NEXT#</span></td>'||chr(10)||
'</tr><tr><td style="background-image:url(#IMAGE_PREFIX#htmldb/builder/builder_find_bg.png)"><br /></td></tr><tr><td><img src="#IMAGE_PREFIX#htmldb/builder/builder_find_';

t:=t||'bottom.png" width="10" height="8"  alt="" /></td></tr></tbody></table>'||chr(10)||
'';

t2:=t2||'class="htmldbInstruct"';

wwv_flow_api.create_plug_template (
  p_id       => 109257010113732748 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> 'Top Bar (Panel, UI Fix) (collapsed)',
  p_plug_table_bgcolor     => '#FFFFFF',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_plug_heading_bgcolor => '#FFFFFF',
  p_plug_font_size => '-1',
  p_reference_id=> 107329211143388687,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2:=t2||'class="htmldbInstruct"';

wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 109257010113732748 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/done_wizard_box_collapse
prompt  ......region template 280800227642320099
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_length number := 1;
begin
t:=t||'<table style="width:auto;" class="htmldbWizard" summary="" cellpadding="0" cellspacing="0" border="0" id="#REGION_STATIC_ID#"><thead><tr><th class="H1" style="white-space:nowrap;">#TITLE#</th><th class="H2" style="white-space:nowrap;">#CLOSE#&nbsp;&nbsp;&nbsp;#DELETE##EDIT##CHANGE##PREVIOUS##NEXT##CREATE#</th></tr></thead><tbody id="body#REGION_ID#"><tr><td colspan="2" class="B">#BODY#</td></tr></';

t:=t||'tbody></table>';

t2 := null;
wwv_flow_api.create_plug_template (
  p_id       => 280800227642320099 + wwv_flow_api.g_id_offset,
  p_flow_id  => wwv_flow.g_flow_id,
  p_template => t,
  p_page_plug_template_name=> '(Done) Wizard Box (Collapse)',
  p_plug_table_bgcolor     => '',
  p_theme_id  => 3,
  p_theme_class_id => 12,
  p_plug_heading_bgcolor => '',
  p_plug_font_size => '',
  p_reference_id=> 236935712467247464,
  p_translate_this_template => 'N',
  p_template_comment       => '');
end;
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 280800227642320099 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

prompt  ...List Templates
--
--application/shared_components/user_interface/templates/list/new_nav_bar_tabs
prompt  ......list template 2502327332838424
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<td class="current"><div class="current"><br /></div><a href="#LINK#" title="#TEXT_ESC_SC#">#TEXT#</a></td>';

t2:=t2||'<td><div><br /></div><a href="#LINK#" title="#TEXT_ESC_SC#">#TEXT#</a></td>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>2502327332838424 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'New Nav Bar (Tabs)',
  p_theme_id  => 3,
  p_theme_class_id => 9,
  p_list_template_before_rows=>'<table border="0" cellspacing="0" cellpadding="0" summary="0"><tr>',
  p_list_template_after_rows=>'</tr></table>',
  p_reference_id=>1319831631286285,
  p_translate_this_template => 'N',
  p_list_template_comment=>'<td><a href="&LOGOUT_URL." class="logout" style="display:block;"><img src="#IMAGE_PREFIX#htmldb/icons/small_close.gif" alt="&LOGOUT."/></a></td></tr>');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/unordered_list
prompt  ......list template 4534221079386110
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<li><a href="#LINK#" title="#TEXT_ESC_SC#">#TEXT#</a></li>';

t2:=t2||'<li><a href="#LINK#" title="#TEXT_ESC_SC#">#TEXT#</a></li>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>4534221079386110 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'unordered list',
  p_theme_id  => 3,
  p_theme_class_id => 1,
  p_list_template_before_rows=>'<ul class="htmldbUl">',
  p_list_template_after_rows=>'</ul>',
  p_reference_id=>60219508156141083,
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/htmldb_tab_navigation
prompt  ......list template 20059219578187484
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<td class="OnL"><img src="#IMAGE_PREFIX#htmldb/misc/tabOnL.png" alt="" /></td>'||chr(10)||
'<td class="OnC"><a href="#LINK#" title="#TEXT_ESC_SC#">#TEXT#</a></td>'||chr(10)||
'<td class="OnR"><img src="#IMAGE_PREFIX#htmldb/misc/tabOnR.png" alt="" /></td>';

t2:=t2||'<td class="OffL"><img src="#IMAGE_PREFIX#htmldb/misc/tabOffL.png" alt="" /></td>'||chr(10)||
'<td class="OffC"><a href="#LINK#" title="#TEXT_ESC_SC#">#TEXT#</a></td>'||chr(10)||
'<td class="OffR"><img src="#IMAGE_PREFIX#htmldb/misc/tabOffR.png" alt="" /></td>'||chr(10)||
'';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>20059219578187484 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'htmldb_tab_navigation',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_list_template_before_rows=>'<table cellpadding="0" cellspacing="0" border="0" summary="" class="htmldbPageTabs">'||chr(10)||
'<tbody>'||chr(10)||
'<tr>'||chr(10)||
'',
  p_list_template_after_rows=>'</tr>'||chr(10)||
'</tbody>'||chr(10)||
'</table>',
  p_reference_id=>18977811338254211,
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/flowwizard
prompt  ......list template 24383823751201815
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<div class="htmldbWizCurrent">#TEXT#</div>';

t2:=t2||'<div class="htmldbWizNon">#TEXT#</div>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>24383823751201815 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'FlowWizard',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_list_template_before_rows=>'<div class="htmldbWizBar">',
  p_list_template_after_rows=>'</div>',
  p_between_items=>'<div class="htmldbWizArrow"><img src="#IMAGE_PREFIX#arrow_down.gif" width="7" height="6" alt="Down" /></div>',
  p_reference_id=>60218330803141060,
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/dhtml_list_image_with_sublist
prompt  ......list template 25613911889431320
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<div class="dhtmlMenuItem"><a href="#LINK#" title="#TEXT_ESC_SC#"><img src="#IMAGE_PREFIX##IMAGE#" #IMAGE_ATTR# /></a><img src="#IMAGE_PREFIX#htmldb/builder/green_icon_open.gif" width="22" height="75" class="dhtmlMenu" onclick="app_AppMenuMultiOpenBottom(this,''#LIST_ITEM_ID#'',false)" alt=""/><a href="#LINK#" class="dhtmlBottom" title="#TEXT_ESC_SC#">#TEXT#</a></div>';

t2:=t2||'<div class="dhtmlMenuItem"><a href="#LINK#" title="#TEXT_ESC_SC#"><img src="#IMAGE_PREFIX##IMAGE#" #IMAGE_ATTR# /></a><img src="#IMAGE_PREFIX#htmldb/builder/green_icon_open.gif" width="22" height="75" class="dhtmlMenu" onclick="app_AppMenuMultiOpenBottom(this,''#LIST_ITEM_ID#'',false)" alt="" /><a href="#LINK#" class="dhtmlBottom" title="#TEXT_ESC_SC#">#TEXT#</a></div>';

t3:=t3||'<li class="dhtmlMenuSep"><img src="#IMAGE_PREFIX#1px_trans.gif"  width="1" height="1" alt=""  class="dhtmlMenuSep" /></li>';

t4:=t4||'<li><a href="#LINK#" class="dhtmlSubMenuN" onmouseover="dhtml_CloseAllSubMenusL(this)" title="#TEXT_ESC_SC#">#TEXT#</a></li>';

t5 := null;
t6 := null;
t7:=t7||'<li class="dhtmlSubMenuS"><a href="#LINK#" class="dhtmlSubMenuS" onmouseover="dhtml_MenuOpen(this,''#LIST_ITEM_ID#'',true,''Left'')" title="#TEXT_ESC_SC#"><span>#TEXT#</span><img class="htmldbMIMG" alt="" src="#IMAGE_PREFIX#menu_open_right2.gif" /></a></li>';

t8:=t8||'<li class="dhtmlSubMenuS"><a href="#LINK#" class="dhtmlSubMenuS" onmouseover="dhtml_MenuOpen(this,''#LIST_ITEM_ID#'',true,''Left'')" title="#TEXT_ESC_SC#"><span>#TEXT#</span><img class="htmldbMIMG" alt="" src="#IMAGE_PREFIX#menu_open_right2.gif" /></a></li>';

wwv_flow_api.create_list_template (
  p_id=>25613911889431320 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'DHTML List (Image) with Sublist',
  p_theme_id  => 3,
  p_theme_class_id => 10,
  p_list_template_before_rows=>'<div class="dhtmlMenuLG">',
  p_list_template_after_rows=>'</div><br style="clear:both;"/><br style="clear:both;"/>',
  p_before_sub_list=>'<ul id="#PARENT_LIST_ITEM_ID#" htmldb:listlevel="#LEVEL#" class="dhtmlSubMenu" style="display:none;">'||chr(10)||
'<li class="dhtmlSubMenuP" onmouseover="dhtml_CloseAllSubMenusL(this)">#PARENT_TEXT#</li>',
  p_after_sub_list=>'</ul>',
  p_sub_list_item_current=> t3,
  p_sub_list_item_noncurrent=> t4,
  p_sub_templ_curr_w_child=> t7,
  p_sub_templ_noncurr_w_child=> t8,
  p_reference_id=>6245728734686542,
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/standard_list_w_link
prompt  ......list template 120886429240393865
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<tr><td class="htmldbStandardList1"><a href="#LINK#" class="itemLink" title="#TEXT_ESC_SC#">#TEXT#</a></td></tr>';

t2:=t2||'<tr><td class="htmldbStandardList2"><a href="#LINK#" class="itemLink" title="#TEXT_ESC_SC#">#TEXT#</a></td></tr>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>120886429240393865 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'standard-list-w-link',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_list_template_before_rows=>'<table class="htmldbStandardList" cellpadding="0" cellspacing="0" border="0" summary="">'||chr(10)||
'<tbody>',
  p_list_template_after_rows=>'</tbody></table>',
  p_reference_id=>17385324891888482,
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/horizontal_list_with_images_30px_c_htmldblistimages30px
prompt  ......list template 339707508887552474
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<td align="center" valign="top"><a href="#LINK#" title="#TEXT_ESC_SC#"><img src="#IMAGE_PREFIX##IMAGE#" #IMAGE_ATTR# class="htmldbGreenIcon" /></a><a href="#LINK#" class="noVisit" title="#TEXT_ESC_SC#">#TEXT#</a></td>';

t2:=t2||'<td align="center" valign="top"><a href="#LINK#" title="#TEXT_ESC_SC#"><img src="#IMAGE_PREFIX##IMAGE#" #IMAGE_ATTR# class="htmldbGreenIcon"/></a><a href="#LINK#" class="noVisit" title="#TEXT_ESC_SC#">#TEXT#</a></td>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>339707508887552474 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Horizontal List with Images 30px (c:htmldbListImages30px)',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_list_template_before_rows=>'<table cellspacing="0" cellpadding="0" border="0" class="htmldbListImages30px" summary=""><tr>',
  p_list_template_after_rows=>'</tr></table>',
  p_reference_id=>338219701416750315,
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

prompt  ...report templates
--
--application/shared_components/user_interface/templates/report/dhtml_automatic_ppr_pagination_report_from_4999_2
prompt  ......report template 11634930157712121
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'<td#ALIGNMENT# headers="#COLUMN_HEADER_NAME#">#COLUMN_VALUE#</td>';

c2 := null;
c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 11634930157712121 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> '(DHTML) Automatic PPR Pagination Report From 4999 (2)',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div id="report#REGION_ID#"><htmldb:#REGION_ID#><table cellpadding="0" cellspacing="0" class="htmldbStandard3"  border="0" summary="" id="#REGION_ID#" htmldb:href="p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:pg_R_#REGION_ID#:NO:">'||chr(10)||
'<tbody>',
  p_row_template_after_rows =>'</tbody>'||chr(10)||
'<tfoot>#PAGINATION#</tfoot>'||chr(10)||
'</table>'||chr(10)||
'<span class="htmldbCSV">#CSV_LINK#</span>'||chr(10)||
''||chr(10)||
'<script language=JavaScript type=text/javascript>'||chr(10)||
'<!--'||chr(10)||
'init_htmlPPRReport(''#REGION_ID#'');'||chr(10)||
''||chr(10)||
'//-->'||chr(10)||
'</script>'||chr(10)||
'</htmldb:#REGION_ID#>'||chr(10)||
'</div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'<th#ALIGNMENT# id="#COLUMN_HEADER_NAME#">#COLUMN_HEADER#</th>',
  p_row_template_display_cond1=>'0',
  p_row_template_display_cond2=>'0',
  p_row_template_display_cond3=>'0',
  p_row_template_display_cond4=>'0',
  p_pagination_template=>'#TEXT#'||chr(10)||
'',
  p_next_page_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-left:5px;"><img src="#IMAGE_PREFIX#jtfunexe.gif" alt="" /></a>',
  p_previous_page_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-right:5px;"><img src="#IMAGE_PREFIX#jtfupree.gif" alt=""/></a>',
  p_next_set_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-left:5px;"><img src="#IMAGE_PREFIX#jtfunexe.gif" alt="" /></a>',
  p_previous_set_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-right:5px;"><img src="#IMAGE_PREFIX#jtfupree.gif" alt=""/></a>',
  p_row_style_mouse_over=>'#CCCCCC',
  p_row_style_checked=>'#CCCCCC',
  p_theme_id  => 3,
  p_theme_class_id => 7,
  p_reference_id=> 6574616710304003,
  p_translate_this_template => 'N',
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 11634930157712121 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'<tr>',
  p_row_template_after_last =>'</tr>');
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/report/dhtml_automatic_ppr_pagination_report
prompt  ......report template 25585420365352950
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'<td#ALIGNMENT# headers="#COLUMN_HEADER_NAME#">#COLUMN_VALUE#</td>';

c2 := null;
c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 25585420365352950 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> '(DHTML) Automatic PPR Pagination Report',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div id="report#REGION_ID#"><htmldb:#REGION_ID#><table cellpadding="0" cellspacing="0" class="htmldbStandard3"  border="0" summary="" id="#REGION_ID#" htmldb:href="p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:pg_R_#REGION_ID#:NO:">'||chr(10)||
'<tbody>',
  p_row_template_after_rows =>'</tbody>'||chr(10)||
'<tfoot>#PAGINATION#</tfoot>'||chr(10)||
'</table>'||chr(10)||
'<span class="htmldbCSV">#CSV_LINK#</span>'||chr(10)||
''||chr(10)||
'<script language=JavaScript type=text/javascript>'||chr(10)||
'<!--'||chr(10)||
'init_htmlPPRReport(''#REGION_ID#'');'||chr(10)||
''||chr(10)||
'//-->'||chr(10)||
'</script>'||chr(10)||
'</htmldb:#REGION_ID#>'||chr(10)||
'</div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'<th#ALIGNMENT# id="#COLUMN_HEADER_NAME#">#COLUMN_HEADER#</th>',
  p_row_template_display_cond1=>'0',
  p_row_template_display_cond2=>'0',
  p_row_template_display_cond3=>'0',
  p_row_template_display_cond4=>'0',
  p_pagination_template=>'#TEXT#'||chr(10)||
'',
  p_next_page_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-left:5px;"><img src="#IMAGE_PREFIX#jtfunexe.gif" alt="" /></a>',
  p_previous_page_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-right:5px;"><img src="#IMAGE_PREFIX#jtfupree.gif" alt=""/></a>',
  p_next_set_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-left:5px;"><img src="#IMAGE_PREFIX#jtfunexe.gif" alt="" /></a>',
  p_previous_set_template=>'<a href="javascript:html_PPR_Report_Page(this,''#REGION_ID#'',''#LINK#'')" style="margin-right:5px;"><img src="#IMAGE_PREFIX#jtfupree.gif" alt=""/></a>',
  p_row_style_mouse_over=>'#CCCCCC',
  p_row_style_checked=>'#CCCCCC',
  p_theme_id  => 3,
  p_theme_class_id => 7,
  p_reference_id=> 6574616710304003,
  p_translate_this_template => 'N',
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 25585420365352950 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'<tr>',
  p_row_template_after_last =>'</tr>');
exception when others then null;
end;
null;
 
end;
/

prompt  ...label templates
--
--application/shared_components/user_interface/templates/label/formfield_nonrequired
prompt  ......label template 104961228191988915
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 104961228191988915 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'FormField_Nonrequired',
  p_template_body1=>'<label for="#CURRENT_ITEM_NAME#"><a class="htmldbLabelOptional" href="javascript:popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'',''&CLOSE.'')" tabindex="999">',
  p_template_body2=>'</a></label>',
  p_on_error_before_label=>'',
  p_on_error_after_label=>'',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_reference_id=> 17388415351892041,
  p_translate_this_template=> 'N',
  p_template_comment=> '');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/label/formfield_required
prompt  ......label template 104962133386990472
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 104962133386990472 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'FormField_Required',
  p_template_body1=>'<label for="#CURRENT_ITEM_NAME#"><a class="htmldbLabelRequired" href="javascript:popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'',''&CLOSE.'')" tabindex="999"><img src="#IMAGE_PREFIX#requiredicon_status2.gif" alt="" />',
  p_template_body2=>'</a></label>',
  p_on_error_before_label=>'',
  p_on_error_after_label=>'',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_reference_id=> 17388508175892042,
  p_translate_this_template=> 'N',
  p_template_comment=> '');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/label/copy_of_htmldb_greenarealabel_c_htmldbgalabel
prompt  ......label template 347635414377293549
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 347635414377293549 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'Copy of htmldb_GreenAreaLabel (c:htmldbGALabel)',
  p_template_body1=>'<label for="#CURRENT_ITEM_NAME#"><a class="htmldbGALabel" href="javascript:popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'',''&CLOSE.'')" tabindex="999">',
  p_template_body2=>'</a></label>',
  p_on_error_before_label=>'',
  p_on_error_after_label=>'',
  p_theme_id  => 3,
  p_theme_class_id => 0,
  p_reference_id=> 57728329098847875,
  p_translate_this_template=> 'N',
  p_template_comment=> '');
end;
null;
 
end;
/

prompt  ...breadcrumb templates
--
--application/shared_components/user_interface/templates/breadcrumb/breadcrumbs
prompt  ......template 7732025850477443
 
begin
 
begin
wwv_flow_api.create_menu_template (
  p_id=> 7732025850477443 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=>'breadcrumbs',
  p_before_first=>'',
  p_current_page_option=>'<span class="htmldbBreadcrumb">#NAME#</span>',
  p_non_current_page_option=>'<a href="#LINK#" class="htmldbBreadcrumb" title="#NAME#">#NAME#</a>',
  p_menu_link_attributes=>'',
  p_between_levels=>'<span class="htmldbBreadcrumbSep">&gt;</span>',
  p_after_last=>'',
  p_max_levels=>12,
  p_start_with_node=>'PARENT_TO_LEAF',
  p_theme_id  => 3,
  p_theme_class_id => 1,
  p_reference_id            => 60115300853820165,
  p_translate_this_template => 'N',
  p_template_comments=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/popuplov
prompt  ...popup list of values templates
--
prompt  ......template 15502309408409289
 
begin
 
begin
wwv_flow_api.create_popup_lov_template (
  p_id=> 15502309408409289 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_popup_icon=>'#IMAGE_PREFIX#htmldb/icons/view_small.gif',
  p_popup_icon_attr=>'width="18" height="18" alt="#LIST_OF_VALUES#" title="#LIST_OF_VALUES#"',
  p_popup_icon2=>'',
  p_popup_icon_attr2=>'',
  p_page_name=>'winlov',
  p_page_title=>'Search Dialog',
  p_page_html_head=>'<html lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<link rel="stylesheet" href="#IMAGE_PREFIX#css/apex_builder_3_1.css" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#javascript/apex_builder.js" type="text/javascript"></script>'||chr(10)||
'<style>a{font-size:12px;}</style>'||chr(10)||
'</head>',
  p_page_body_attr=>'onload="first_field()" class="htmldbPopup"',
  p_before_field_text=>'',
  p_page_heading_text=>'<div style="padding:2px;"><table><tr><td valign="top"><img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" /></td><td>',
  p_page_footer_text =>'</td></tr></table></div>',
  p_filter_width     =>'20',
  p_filter_max_width =>'100',
  p_filter_text_attr =>'',
  p_find_button_text =>'Search',
  p_find_button_image=>'',
  p_find_button_attr =>'',
  p_close_button_text=>'Close',
  p_close_button_image=>'',
  p_close_button_attr=>'',
  p_next_button_text =>'Next >',
  p_next_button_image=>'',
  p_next_button_attr =>'',
  p_prev_button_text =>'< Previous',
  p_prev_button_image=>'',
  p_prev_button_attr =>'',
  p_after_field_text=>'</div>',
  p_scrollbars=>'1',
  p_resizable=>'1',
  p_width =>'400',
  p_height=>'500',
  p_result_row_x_of_y=>'<br /><div style="padding:2px; font-size:8pt;">Row(s) #FIRST_ROW# - #LAST_ROW#</div><center>',
  p_result_rows_per_pg=>200,
  p_before_result_set=>'<div style="padding-left:6px;">',
  p_theme_id  => 3,
  p_theme_class_id => 1,
  p_reference_id       => 17343114994581872,
  p_translate_this_template => 'N',
  p_after_result_set   =>'</div>');
end;
null;
 
end;
/

prompt  ...calendar templates
--
prompt  ...application themes
--
--application/shared_components/user_interface/themes/green_2_0
prompt  ......theme 76178911037871019
begin
wwv_flow_api.create_theme (
  p_id =>76178911037871019 + wwv_flow_api.g_id_offset,
  p_flow_id =>wwv_flow.g_flow_id,
  p_theme_id  => 3,
  p_theme_name=>'Green 2.0',
  p_default_page_template=>4537010500402583 + wwv_flow_api.g_id_offset,
  p_error_template=>4537010500402583 + wwv_flow_api.g_id_offset,
  p_printer_friendly_template=>1060517913932420 + wwv_flow_api.g_id_offset,
  p_breadcrumb_display_point=>'',
  p_sidebar_display_point=>'',
  p_login_template=>null + wwv_flow_api.g_id_offset,
  p_default_button_template=>null + wwv_flow_api.g_id_offset,
  p_default_region_template=>1060517925932426 + wwv_flow_api.g_id_offset,
  p_default_chart_template =>null + wwv_flow_api.g_id_offset,
  p_default_form_template  =>null + wwv_flow_api.g_id_offset,
  p_default_reportr_template => null,
  p_default_tabform_template=>null + wwv_flow_api.g_id_offset,
  p_default_wizard_template=>null + wwv_flow_api.g_id_offset,
  p_default_menur_template=>null + wwv_flow_api.g_id_offset,
  p_default_listr_template=>null + wwv_flow_api.g_id_offset,
  p_default_report_template   =>11634930157712121 + wwv_flow_api.g_id_offset,
  p_default_label_template=>104961228191988915 + wwv_flow_api.g_id_offset,
  p_default_menu_template=>7732025850477443 + wwv_flow_api.g_id_offset,
  p_default_calendar_template=>null + wwv_flow_api.g_id_offset,
  p_default_list_template=>120886429240393865 + wwv_flow_api.g_id_offset,
  p_default_option_label=>null + wwv_flow_api.g_id_offset,
  p_default_required_label=>null + wwv_flow_api.g_id_offset);
end;
/
 
prompt  ...build options used by application 101
--
 
begin
 
--application/shared_components/logic/build_options/xml_publisher
wwv_flow_api.create_build_option (
  p_id=> 232668426688992969 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_build_option_name=> 'XML Publisher',
  p_build_option_status=> 'EXCLUDE',
  p_default_on_export=>'EXCLUDE',
  p_build_option_comment=> '');
 
end;
/

--application/shared_components/globalization/messages
prompt  ...messages used by application: 101
--
--application/shared_components/globalization/dyntranslations
prompt  ...dynamic translations used by application: 101
--
--application/shared_components/globalization/language
prompt  ...Language Maps for Application 101
--
 
begin
 
null;
 
end;
/

prompt  ...Shortcuts
--
--application/shared_components/user_interface/shortcuts/item_help
 
begin
 
declare
  c1 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<a href="javascript:popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'')" tabindex="999"><img src="#IMAGE_PREFIX#infoicon_status_gray.gif" width=16 height=16 border=0></a>';

wwv_flow_api.create_shortcut (
 p_id=> 181722329660119215 + wwv_flow_api.g_id_offset,
 p_flow_id=> wwv_flow.g_flow_id,
 p_shortcut_name=> 'ITEM_HELP',
 p_shortcut_type=> 'HTML_TEXT',
 p_error_text=> 'Unable to show help.',
 p_reference_id=> 24184979678,
 p_shortcut=> c1);
end;
null;
 
end;
/

prompt  ...web services (9iR2 or better)
--
prompt  ...shared queries
--
prompt  ...report layouts
--
prompt  ...authentication schemes
--
--application/shared_components/security/authentication/apex
prompt  ......scheme 1068017197849284
 
begin
 
declare
  s1 varchar2(32767) := null;
  s2 varchar2(32767) := null;
  s3 varchar2(32767) := null;
  s4 varchar2(32767) := null;
  s5 varchar2(32767) := null;
begin
s1 := null;
s2 := null;
s3 := null;
s4:=s4||'-BUILTIN-';

s5 := null;
wwv_flow_api.create_auth_setup (
  p_id=> 1068017197849284 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'APEX',
  p_description=>'Based on authentication scheme from gallery:Built-in Login Page: Use Application Express Account Credentials',
  p_page_sentry_function=> s1,
  p_sess_verify_function=> s2,
  p_pre_auth_process=> s3,
  p_auth_function=> s4,
  p_post_auth_process=> s5,
  p_invalid_session_page=>'',
  p_invalid_session_url=>'-BUILTIN-',
  p_cookie_name=>'',
  p_cookie_path=>'',
  p_cookie_domain=>'',
  p_use_secure_cookie_yn=>'N',
  p_ldap_host=>'',
  p_ldap_port=>'',
  p_ldap_string=>'',
  p_attribute_01=>'',
  p_attribute_02=>'wwv_flow_custom_auth_std.logout?p_this_flow=&APP_ID.&p_next_flow_page_sess=101:PUBLIC_PAGE',
  p_attribute_03=>'',
  p_attribute_04=>'',
  p_attribute_05=>'',
  p_attribute_06=>'',
  p_attribute_07=>'',
  p_attribute_08=>'',
  p_required_patch=>'');
end;
null;
 
end;
/

--application/shared_components/security/authentication/login
prompt  ......scheme 1071108219005204
 
begin
 
declare
  s1 varchar2(32767) := null;
  s2 varchar2(32767) := null;
  s3 varchar2(32767) := null;
  s4 varchar2(32767) := null;
  s5 varchar2(32767) := null;
begin
s1 := null;
s2 := null;
s3 := null;
s4:=s4||'-BUILTIN-';

s5 := null;
wwv_flow_api.create_auth_setup (
  p_id=> 1071108219005204 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Login',
  p_description=>'Based on authentication scheme from gallery:Newly Created Login Page: Use Application Express Account Credentials',
  p_page_sentry_function=> s1,
  p_sess_verify_function=> s2,
  p_pre_auth_process=> s3,
  p_auth_function=> s4,
  p_post_auth_process=> s5,
  p_invalid_session_page=>'280',
  p_invalid_session_url=>'',
  p_cookie_name=>'',
  p_cookie_path=>'',
  p_cookie_domain=>'',
  p_use_secure_cookie_yn=>'N',
  p_ldap_host=>'',
  p_ldap_port=>'',
  p_ldap_string=>'',
  p_attribute_01=>'',
  p_attribute_02=>'wwv_flow_custom_auth_std.logout?p_this_flow=&APP_ID.&p_next_flow_page_sess=&APP_ID.:208',
  p_attribute_03=>'',
  p_attribute_04=>'',
  p_attribute_05=>'',
  p_attribute_06=>'',
  p_attribute_07=>'',
  p_attribute_08=>'',
  p_required_patch=>'');
end;
null;
 
end;
/

--application/shared_components/security/authentication/internal
prompt  ......scheme 61923917721101853
 
begin
 
declare
  s1 varchar2(32767) := null;
  s2 varchar2(32767) := null;
  s3 varchar2(32767) := null;
  s4 varchar2(32767) := null;
  s5 varchar2(32767) := null;
begin
s1:=s1||'return wwv_flow_security.internal_page_sentry;';

s2 := null;
s3 := null;
s4:=s4||'-BUILTIN-';

s5 := null;
wwv_flow_api.create_auth_setup (
  p_id=> 61923917721101853 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> '$INTERNAL$',
  p_description=>'Common scheme for all internal flows using custom Login Page and account credentials verification',
  p_page_sentry_function=> s1,
  p_sess_verify_function=> s2,
  p_pre_auth_process=> s3,
  p_auth_function=> s4,
  p_post_auth_process=> s5,
  p_invalid_session_page=>'',
  p_invalid_session_url=>'f?p=4550:1:&SESSION.',
  p_cookie_name=>'ORA_WWV_USER',
  p_cookie_path=>'&CGI_SCRIPT_NAME.',
  p_cookie_domain=>'',
  p_use_secure_cookie_yn=>'',
  p_ldap_host=>'',
  p_ldap_port=>'',
  p_ldap_string=>'',
  p_attribute_01=>'',
  p_attribute_02=>'wwv_flow_custom_auth_std.logout?p_this_flow=&FLOW_ID.&p_next_flow_page_sess=4550:8:&SESSION.',
  p_attribute_03=>'',
  p_attribute_04=>'',
  p_attribute_05=>'',
  p_attribute_06=>'',
  p_attribute_07=>'',
  p_attribute_08=>'',
  p_reference_id=> 60856310633085148,
  p_required_patch=>'');
end;
null;
 
end;
/

--application/end_environment
commit;
commit;
begin 
execute immediate 'alter session set nls_numeric_characters='''||wwv_flow_api.g_nls_numeric_chars||'''';
end;
/
set verify on
set feedback on
prompt  ...done
