-- RUN AS SYS
-- If you created another user (not OLS) for Webshop, change the user OLS below to your newly created user name
GRANT EXECUTE ON OLS.OLS_PAYPAL_ACCEPT TO PUBLIC
/
GRANT EXECUTE ON OLS.OLS_GO_CANCEL_PAGE TO PUBLIC
/
GRANT EXECUTE ON utl_http TO OLS
/

begin
for i in (select max(username) flow_user from all_users where username like 'FLOWS_0%') loop

execute immediate '
create or replace synonym OLS.WWV_FLOW_CLICKTHRU_LOG_V 
for  ' ||i.flow_user||'.WWV_FLOW_CLICKTHRU_LOG_V';

execute immediate '
create or replace synonym OLS.WWV_FLOW_PAGE_PLUGS 
for  ' ||i.flow_user||'.WWV_FLOW_PAGE_PLUGS';

execute immediate 'GRANT SELECT ON ' ||i.flow_user||'.WWV_FLOW_CLICKTHRU_LOG_V TO OLS';

execute immediate 'GRANT SELECT on ' ||i.flow_user||'.WWV_FLOW_PAGE_PLUGS TO OLS';

if i.flow_user = 'FLOWS_020100' then
execute immediate 
'CREATE OR REPLACE FUNCTION ' ||i.flow_user||'.WWV_FLOW_EPG_INCLUDE_MOD_LOCAL (
    procedure_name in varchar2)
return boolean
is
begin
    --return false; -- remove this statement when you modify this function
    --
    -- Administrator note: the procedure_name input parameter may be in the format:
    --
    --    procedure
    --    schema.procedure
    --    package.procedure
    --    schema.package.procedure
    --
    -- If the expected input parameter is a procedure name only, the IN list code shown below
    -- can be modified to itemize the expected procedure names. Otherwise you must parse the
    -- procedure_name parameter and replace the simple code below with code that will evaluate
    -- all of the cases listed above.
    --
--    if upper(procedure_name) in (
--          '''') then
    if upper(procedure_name) like ''%PAYPAL_ACCEPT''
           or upper(procedure_name) like ''%GO_CANCEL_PAGE''  then
        return TRUE;
    else
        return FALSE;
    end if;
end wwv_flow_epg_include_mod_local;';
end if;
end loop;
end;
/
 
