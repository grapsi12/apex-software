--------------------------------------------------------
--  Create Webshop objects and data
--  Must be run under the user OLS (or your own user if you created other user)
--  First the sript drops the objects in case of reinstalling
--  Please ignore the messages "object does not exist" during drop statements execution   
--  Also messages "Warning: Function created with compilation errors." should be ignored if any
--  If you want you can compile invalid functions manually by running the following command in sqlplus:
--  EXEC DBMS_UTILITY.compile_schema(schema => 'OLS');
--  Anyway the invalid functions will be compiled by Oracle automatically on the first usage
--------------------------------------------------------
set define off;
--spool /home/dbswh/webshop_creation.log

  DROP TABLE "OLS_ADDRESS_BOOK" cascade constraints;
  DROP TABLE "OLS_ADDRESS_FORMAT" cascade constraints;
  DROP TABLE "OLS_ADD_IMAGES" cascade constraints;
  DROP TABLE "OLS_BANNERS" cascade constraints;
  DROP TABLE "OLS_CATEGORY" cascade constraints;
  DROP TABLE "OLS_CATEGORY_TRANS" cascade constraints;
  DROP TABLE "OLS_CAT_PRODUCT" cascade constraints;
  DROP TABLE "OLS_CONFIGURATION" cascade constraints;
  DROP TABLE "OLS_CONFIGURATION_GROUP" cascade constraints;
  DROP TABLE "OLS_COUNTER" cascade constraints;
  DROP TABLE "OLS_COUNTER_HISTORY" cascade constraints;
  DROP TABLE "OLS_COUNTRY" cascade constraints;
  DROP TABLE "OLS_CURRENCY" cascade constraints;
  DROP TABLE "OLS_CUSTOMER_DETAILS" cascade constraints;
  DROP TABLE "OLS_CUST_BILLING_DETAILS" cascade constraints;
  DROP TABLE "OLS_CUST_SHIPPING_DETAILS" cascade constraints;
  DROP TABLE "OLS_DISPLAY_VALUES" cascade constraints;
  DROP TABLE "OLS_ERRORS" cascade constraints;
  DROP TABLE "OLS_ESTIMATED_DELIVERY_TIME" cascade constraints;
  DROP TABLE "OLS_FAVORITES" cascade constraints;
  DROP TABLE "OLS_FILES" cascade constraints;
  DROP TABLE "OLS_GEO_ZONES" cascade constraints;
  DROP TABLE "OLS_IMAGES" cascade constraints;
  DROP TABLE "OLS_LANGUAGE" cascade constraints;
  DROP TABLE "OLS_LANGUAGE_CODES" cascade constraints;
  DROP TABLE "OLS_LINE_DOWNLOADS" cascade constraints;
  DROP TABLE "OLS_LINE_ITEMS" cascade constraints;
  DROP TABLE "OLS_LINE_ITEM_OPTIONS" cascade constraints;
  DROP TABLE "OLS_LOGS" cascade constraints;
  DROP TABLE "OLS_MANUFACTURER" cascade constraints;
  DROP TABLE "OLS_MESSAGES" cascade constraints;
  DROP TABLE "OLS_NEWS" cascade constraints;
  DROP TABLE "OLS_NEWSLETTER" cascade constraints;
  DROP TABLE "OLS_ORDER_STATUS" cascade constraints;
  DROP TABLE "OLS_PAYMENT_CC_TYPE" cascade constraints;
  DROP TABLE "OLS_PAYMENT_MODE_EX" cascade constraints;
  DROP TABLE "OLS_PAYMENT_MODE_IN" cascade constraints;
  DROP TABLE "OLS_PAYPAL_SESSION_MAP" cascade constraints;
  DROP TABLE "OLS_PAYPAL_TRANSACTIONS" cascade constraints;
  DROP TABLE "OLS_PRODUCT" cascade constraints;
  DROP TABLE "OLS_PRODUCT_OPTIONS" cascade constraints;
  DROP TABLE "OLS_PRODUCT_TO_PR_OPTIONS" cascade constraints;
  DROP TABLE "OLS_PRODUCT_TRANS" cascade constraints;
  DROP TABLE "OLS_REVIEWS" cascade constraints;
  DROP TABLE "OLS_SALES_ORDER" cascade constraints;
  DROP TABLE "OLS_SHIPPING_AMOUNT_RATES" cascade constraints;
  DROP TABLE "OLS_SHIPPING_PRICE_TYPES" cascade constraints;
  DROP TABLE "OLS_SHIPPING_TYPES" cascade constraints;
  DROP TABLE "OLS_SHOPPING_CART" cascade constraints;
  DROP TABLE "OLS_SO_PAY_DETAILS" cascade constraints;
  DROP TABLE "OLS_SPECIAL_CHARACTERS" cascade constraints;
  DROP TABLE "OLS_STATES" cascade constraints;
  DROP TABLE "OLS_TAX_CLASS" cascade constraints;
  DROP TABLE "OLS_TAX_RATES" cascade constraints;
  DROP TABLE "OLS_ZONES" cascade constraints;
  DROP SEQUENCE "OLS_CATEGORY_SEQ";
  DROP SEQUENCE "OLS_COUNTRY_SEQ";
  DROP SEQUENCE "OLS_ERRORS_SEQ";
  DROP SEQUENCE "OLS_FAVORITES_SEQ";
  DROP SEQUENCE "OLS_IMAGES_SEQ";
  DROP SEQUENCE "OLS_LINE_DOWNLOADS_SEQ";
  DROP SEQUENCE "OLS_LINE_ITEMS_SEQ";
  DROP SEQUENCE "OLS_LINE_ITEM_OPTIONS_SEQ";
  DROP SEQUENCE "OLS_LOGS_SEQ";
  DROP SEQUENCE "OLS_MESSAGES_SEQ";
  DROP SEQUENCE "OLS_NEWSLETTER_SEQ";
  DROP SEQUENCE "OLS_NEWS_SEQ";
  DROP SEQUENCE "OLS_PAYMENT_DETAILS_SEQ";
  DROP SEQUENCE "OLS_PAYMENT_MODE_SEQ";
  DROP SEQUENCE "OLS_PAYPAL_TRAN_ID_SEQ";
  DROP SEQUENCE "OLS_PRODUCT_SEQ";
  DROP SEQUENCE "OLS_REVIEW_SEQ";
  DROP SEQUENCE "OLS_SALES_ORDER_SEQ";
  DROP SEQUENCE "OLS_SO_PAY_DETAILS_SEQ";
  DROP SEQUENCE "OLS_STATES_SEQ";
  DROP SEQUENCE "OLS_USER_BILLING_DETAILS_SEQ";
  DROP SEQUENCE "OLS_USER_DETAILS_SEQ";
  DROP SEQUENCE "OLS_USER_SHIPPING_DETAILS_SEQ";
  DROP SEQUENCE "OLS_ZONES_SEQ";
  DROP VIEW "OLS_PAYMENT_MODE";
  DROP VIEW "OLS_SHOP_CART";
  DROP VIEW "OLS_VW_CAT_PRODUCT";
  DROP VIEW "OLS_VW_MAN_PRODUCT";
  DROP FUNCTION "OLS_CALCULATE_DELIVERY_DATE";
  DROP FUNCTION "OLS_CALCULATE_DEL_COST";
  DROP FUNCTION "OLS_CALCULATE_SUBTOTAL";
  DROP FUNCTION "OLS_CALCULATE_TAX";
  DROP FUNCTION "OLS_CALCULATE_TOTAL";
  DROP FUNCTION "OLS_CATEGORY_CHILD";
  DROP FUNCTION "OLS_CAT_PROD_COUNT";
  DROP FUNCTION "OLS_CC_VALIDATION";
  DROP FUNCTION "OLS_CHECK_STOCK_CHECKOUT";
  DROP FUNCTION "OLS_COUNT_SO";
  DROP FUNCTION "OLS_CUSTOM_ADD_USER";
  DROP FUNCTION "OLS_CUSTOM_HASH";
  DROP FUNCTION "OLS_ENTERED_BILL_SHIP_DETAILS";
  DROP FUNCTION "OLS_ENTERED_PAYMENT_DETAILS";
  DROP FUNCTION "OLS_ENTERED_PAYPAL_TRANS";
  DROP FUNCTION "OLS_ESTIMATE_DEL_COST";
  DROP FUNCTION "OLS_FIND_TAX";
  DROP FUNCTION "OLS_FIND_TAX_DESCRIPTION";
  DROP FUNCTION "OLS_ISVALIDUSER";
  DROP FUNCTION "OLS_IS_ADMIN";
  DROP FUNCTION "OLS_IS_POTENTIAL_SHOPPER";
  DROP FUNCTION "OLS_IS_SHIPPING_ENTERED";
  DROP FUNCTION "OLS_NODEBUG";
  DROP FUNCTION "OLS_ONLINESTORE_AUTH";
  DROP FUNCTION "OLS_PRINT_OPTIONS";
  DROP FUNCTION "OLS_PRINT_PRODUCTS";
  DROP FUNCTION "OLS_PRINT_SHIP_NOTICE";
  DROP FUNCTION "OLS_SHOW_DELIVERY_ADDRESS";
  DROP FUNCTION "OLS_SHOW_PRICE";
  DROP FUNCTION "OLS_SHOW_STOCK_AVAILABILITY";
  DROP FUNCTION "OLS_SHOW_TAX";
  DROP FUNCTION "OLS_SO_EXISTS";
  DROP FUNCTION "OLS_VALIDATE_FK";
  DROP FUNCTION "OLS_VALIDATE_LENGTH";
  DROP FUNCTION "OLS_VALIDATE_PASSWORD";
  DROP PACKAGE "OLS_CART";
  DROP PACKAGE "OLS_OPTIONS";
  DROP PACKAGE "OLS_PAYPAL_API";
  DROP PACKAGE "OLS_PRINT_SYLK_FORMAT";
  DROP PACKAGE "T";
  DROP PROCEDURE "OLS_DELETE_COLLECTIONS";
  DROP PROCEDURE "OLS_DELIVER_SO";
  DROP PROCEDURE "OLS_GETNAME";
  DROP PROCEDURE "OLS_GO_CANCEL_PAGE";
  DROP PROCEDURE "OLS_IMAGE_DISPLAY";
  DROP PROCEDURE "OLS_INSERT_LINE_ITEMS";
  DROP PROCEDURE "OLS_PAYPAL_ACCEPT";
  DROP PROCEDURE "OLS_PRINT_BILLING_ADDRESS";
  DROP PROCEDURE "OLS_PRINT_DELIVERY_ADDRESS";
  DROP PROCEDURE "OLS_PRINT_PAYPAL_BUTTON";
  DROP PROCEDURE "OLS_REFRESH_CAT_PRODUCT";
  DROP PROCEDURE "OLS_SEND_MAIL";
  DROP PROCEDURE "OLS_SET_DEFAULT_CURRENCY";
--------------------------------------------------------
--  DDL for Sequence OLS_CATEGORY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_CATEGORY_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 45 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_COUNTRY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_COUNTRY_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 242 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_ERRORS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_ERRORS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 671 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_FAVORITES_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_FAVORITES_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 71 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_IMAGES_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_IMAGES_SEQ"  MINVALUE 1 MAXVALUE 9999999 INCREMENT BY 1 START WITH 1 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_LINE_DOWNLOADS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_LINE_DOWNLOADS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 123 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_LINE_ITEMS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_LINE_ITEMS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 617 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_LINE_ITEM_OPTIONS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_LINE_ITEM_OPTIONS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 720 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_LOGS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_LOGS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 8963 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_MESSAGES_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_MESSAGES_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 814 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_NEWSLETTER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_NEWSLETTER_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 142 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_NEWS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_NEWS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 282 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_PAYMENT_DETAILS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_PAYMENT_DETAILS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 6 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_PAYMENT_MODE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_PAYMENT_MODE_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 13 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_PAYPAL_TRAN_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_PAYPAL_TRAN_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 69 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_PRODUCT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_PRODUCT_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 63067 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_REVIEW_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_REVIEW_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 75 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_SALES_ORDER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_SALES_ORDER_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 475 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_SO_PAY_DETAILS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_SO_PAY_DETAILS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 338 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_STATES_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_STATES_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_USER_BILLING_DETAILS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_USER_BILLING_DETAILS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 243 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_USER_DETAILS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_USER_DETAILS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 281 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_USER_SHIPPING_DETAILS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_USER_SHIPPING_DETAILS_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 249 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLS_ZONES_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OLS_ZONES_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 747 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Table OLS_ADDRESS_BOOK
--------------------------------------------------------

  CREATE TABLE "OLS_ADDRESS_BOOK" 
   (	"ID" NUMBER, 
	"CUSTOMER_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_ADDRESS_BOOK"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_ADDRESS_BOOK"."CUSTOMER_ID" IS 'Customer id. Refers to ols_customer_details.id column.';
 
   COMMENT ON TABLE "OLS_ADDRESS_BOOK"  IS 'Stores info on customers who want to receive newsletters.';
--------------------------------------------------------
--  DDL for Table OLS_ADDRESS_FORMAT
--------------------------------------------------------

  CREATE TABLE "OLS_ADDRESS_FORMAT" 
   (	"ID" NUMBER, 
	"ADDRESS_FORMAT" VARCHAR2(128)
   ) ;
 

   COMMENT ON COLUMN "OLS_ADDRESS_FORMAT"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_ADDRESS_FORMAT"."ADDRESS_FORMAT" IS 'Address format.';
 
   COMMENT ON TABLE "OLS_ADDRESS_FORMAT"  IS '1 - Default, 2 - USA, 3 - Spain, 4 - Singapore, 5 - Germany.';
--------------------------------------------------------
--  DDL for Table OLS_ADD_IMAGES
--------------------------------------------------------

  CREATE TABLE "OLS_ADD_IMAGES" 
   (	"PRODUCT_ID" NUMBER, 
	"IMAGE_ID" NUMBER, 
	"IMAGE_NAME" VARCHAR2(4000), 
	"MIME_TYPE" VARCHAR2(4000), 
	"IMAGE" BLOB
   ) ;
 

   COMMENT ON COLUMN "OLS_ADD_IMAGES"."PRODUCT_ID" IS 'Primary Key';
 
   COMMENT ON COLUMN "OLS_ADD_IMAGES"."IMAGE_ID" IS 'Primary Key';
 
   COMMENT ON COLUMN "OLS_ADD_IMAGES"."IMAGE_NAME" IS 'Stores the image name';
 
   COMMENT ON COLUMN "OLS_ADD_IMAGES"."MIME_TYPE" IS 'Stores the image type';
 
   COMMENT ON COLUMN "OLS_ADD_IMAGES"."IMAGE" IS 'Stores the image in the blob field';
 
   COMMENT ON TABLE "OLS_ADD_IMAGES"  IS 'Contains additional image details of the product added.';
--------------------------------------------------------
--  DDL for Table OLS_BANNERS
--------------------------------------------------------

  CREATE TABLE "OLS_BANNERS" 
   (	"ID" NUMBER, 
	"TITLE" VARCHAR2(64), 
	"URL" VARCHAR2(255), 
	"HTML_TEXT" VARCHAR2(64), 
	"VALIDITY_FROM" DATE, 
	"VALIDITY_TO" DATE, 
	"CREATED_DATE" DATE, 
	"MODIFIED_DATE" DATE, 
	"IMAGE_URL" VARCHAR2(255), 
	"WIDTH" NUMBER DEFAULT 0, 
	"HEIGHT" NUMBER DEFAULT 0
   ) ;
 

   COMMENT ON COLUMN "OLS_BANNERS"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."TITLE" IS 'Title of a banner.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."URL" IS 'Url that links to the advertised web site.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."HTML_TEXT" IS 'Alternate text in html.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."VALIDITY_FROM" IS 'Date from which the banner is shown.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."VALIDITY_TO" IS 'Date till which the banner is shown.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."CREATED_DATE" IS 'Created date.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."MODIFIED_DATE" IS 'Modified date.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."IMAGE_URL" IS 'Banner image url.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."WIDTH" IS 'Width of a banner in pixels.';
 
   COMMENT ON COLUMN "OLS_BANNERS"."HEIGHT" IS 'Height of a banner in pixels.';
 
   COMMENT ON TABLE "OLS_BANNERS"  IS 'Stores banners info.';
--------------------------------------------------------
--  DDL for Table OLS_CATEGORY
--------------------------------------------------------

  CREATE TABLE "OLS_CATEGORY" 
   (	"ID" NUMBER, 
	"CATEGORY_NAME" VARCHAR2(255), 
	"PARENT_ID" NUMBER, 
	"IMAGE_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_CATEGORY"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_CATEGORY"."CATEGORY_NAME" IS 'Stores category name.';
 
   COMMENT ON COLUMN "OLS_CATEGORY"."PARENT_ID" IS 'Parent category id.';
 
   COMMENT ON TABLE "OLS_CATEGORY"  IS 'Contains names of all categories of the products';
--------------------------------------------------------
--  DDL for Table OLS_CATEGORY_TRANS
--------------------------------------------------------

  CREATE TABLE "OLS_CATEGORY_TRANS" 
   (	"CAT_ID" NUMBER, 
	"LANG_ID" NUMBER, 
	"CATEGORY_NAME" VARCHAR2(255)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_CAT_PRODUCT
--------------------------------------------------------

  CREATE TABLE "OLS_CAT_PRODUCT" 
   (	"ID" NUMBER, 
	"CATEGORY_NAME" VARCHAR2(255), 
	"PARENT_ID" NUMBER, 
	"AMOUNT" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_CAT_PRODUCT"."ID" IS 'Primary key. Category id.';
 
   COMMENT ON COLUMN "OLS_CAT_PRODUCT"."CATEGORY_NAME" IS 'Category name.';
 
   COMMENT ON COLUMN "OLS_CAT_PRODUCT"."PARENT_ID" IS 'Parent category id.';
 
   COMMENT ON COLUMN "OLS_CAT_PRODUCT"."AMOUNT" IS 'Amount of available and active products under this category.';
 
   COMMENT ON TABLE "OLS_CAT_PRODUCT"  IS 'Snapshot of a view ols_vw_cat_product to improve performance. Populated by Db job.';
--------------------------------------------------------
--  DDL for Table OLS_CONFIGURATION
--------------------------------------------------------

  CREATE TABLE "OLS_CONFIGURATION" 
   (	"ID" NUMBER, 
	"TITLE" VARCHAR2(64), 
	"KEY" VARCHAR2(64), 
	"VALUE" VARCHAR2(255), 
	"DESCRIPTION" VARCHAR2(4000), 
	"GROUP_ID" NUMBER, 
	"SORT_ORDER" NUMBER, 
	"LAST_MODIFIED" DATE, 
	"DATE_ADDED" DATE
   ) ;
 

   COMMENT ON COLUMN "OLS_CONFIGURATION"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."TITLE" IS 'Configuration (setting) title.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."KEY" IS 'The key for the setting. By this key the value of a setting is fetched from the table.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."VALUE" IS 'Setting value. Depending on the value the system may perform or not perform some operation.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."DESCRIPTION" IS 'Description for a setting.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."GROUP_ID" IS 'The configurations (settings) are grouped into groups.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."SORT_ORDER" IS 'Sort order is used in GUI for sorting. ';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."LAST_MODIFIED" IS 'Last modified date.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION"."DATE_ADDED" IS 'Date created.';
 
   COMMENT ON TABLE "OLS_CONFIGURATION"  IS 'The configuration table for the whole system. ';
--------------------------------------------------------
--  DDL for Table OLS_CONFIGURATION_GROUP
--------------------------------------------------------

  CREATE TABLE "OLS_CONFIGURATION_GROUP" 
   (	"ID" NUMBER, 
	"TITLE" VARCHAR2(64), 
	"DESCRIPTION" VARCHAR2(255), 
	"SORT_ORDER" NUMBER, 
	"VISIBLE" NUMBER, 
	"IMAGE_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_CONFIGURATION_GROUP"."ID" IS 'Primary key. Group id.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION_GROUP"."TITLE" IS 'Title of a group. Used in GUI.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION_GROUP"."DESCRIPTION" IS 'Description.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION_GROUP"."SORT_ORDER" IS 'Sort order for GUI. ';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION_GROUP"."VISIBLE" IS 'If visible in GUI.';
 
   COMMENT ON COLUMN "OLS_CONFIGURATION_GROUP"."IMAGE_ID" IS 'Image id from ols_images to show group picture in GUI.';
 
   COMMENT ON TABLE "OLS_CONFIGURATION_GROUP"  IS 'Configurations (settings) are grouped into groups.';
--------------------------------------------------------
--  DDL for Table OLS_COUNTER
--------------------------------------------------------

  CREATE TABLE "OLS_COUNTER" 
   (	"STARTDATE" DATE, 
	"COUNTER" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_COUNTER"."STARTDATE" IS 'Start date when system was first accessed through web interface.';
 
   COMMENT ON COLUMN "OLS_COUNTER"."COUNTER" IS 'Visitors since start date.';
 
   COMMENT ON TABLE "OLS_COUNTER"  IS 'Stores starting date when system was first accessed through web interface and visitors since this date.';
--------------------------------------------------------
--  DDL for Table OLS_COUNTER_HISTORY
--------------------------------------------------------

  CREATE TABLE "OLS_COUNTER_HISTORY" 
   (	"MONTH" DATE, 
	"COUNTER" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_COUNTER_HISTORY"."MONTH" IS 'Shows the first date of each month.';
 
   COMMENT ON COLUMN "OLS_COUNTER_HISTORY"."COUNTER" IS 'Shows number of visitors per month defined in month column.';
 
   COMMENT ON TABLE "OLS_COUNTER_HISTORY"  IS 'Shows visitors per month.';
--------------------------------------------------------
--  DDL for Table OLS_COUNTRY
--------------------------------------------------------

  CREATE TABLE "OLS_COUNTRY" 
   (	"ID" NUMBER, 
	"COUNTRY_NAME" VARCHAR2(4000), 
	"ISO_CODE_1" VARCHAR2(2), 
	"ISO_CODE_2" VARCHAR2(3), 
	"ADDRESS_FORMAT_ID" NUMBER, 
	"ALLOW" VARCHAR2(1) DEFAULT 'Y'
   ) ;
 

   COMMENT ON COLUMN "OLS_COUNTRY"."ID" IS 'Primary Key. Country id.';
 
   COMMENT ON COLUMN "OLS_COUNTRY"."COUNTRY_NAME" IS 'Stores the country name, not null constraint on this column.';
 
   COMMENT ON COLUMN "OLS_COUNTRY"."ISO_CODE_1" IS 'Iso code 1. See standards.';
 
   COMMENT ON COLUMN "OLS_COUNTRY"."ISO_CODE_2" IS 'Iso code 2. See standards.';
 
   COMMENT ON COLUMN "OLS_COUNTRY"."ADDRESS_FORMAT_ID" IS 'Reference to ols_address_format.';
 
   COMMENT ON COLUMN "OLS_COUNTRY"."ALLOW" IS 'Shows if country can be used in Delivery and Billing addresses.';
 
   COMMENT ON TABLE "OLS_COUNTRY"  IS 'Contains names of countries and iso codes.';
--------------------------------------------------------
--  DDL for Table OLS_CURRENCY
--------------------------------------------------------

  CREATE TABLE "OLS_CURRENCY" 
   (	"ID" NUMBER, 
	"TITLE" VARCHAR2(32), 
	"CODE" CHAR(3), 
	"SYMBOL_LEFT" VARCHAR2(12), 
	"SYMBOL_RIGHT" VARCHAR2(12), 
	"DECIMAL_POINT" CHAR(1), 
	"THOUSANDS_POINT" CHAR(1), 
	"DECIMAL_PLACES" CHAR(1), 
	"VALUE" NUMBER(10,5), 
	"LAST_UPDATED" DATE
   ) ;
 

   COMMENT ON COLUMN "OLS_CURRENCY"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."TITLE" IS 'Title of currency.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."CODE" IS 'Code for the currency.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."SYMBOL_LEFT" IS 'Left symbol if currency code used in the left side.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."SYMBOL_RIGHT" IS 'Right symbol if currency code used in the right side.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."DECIMAL_POINT" IS 'Decimal separator.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."THOUSANDS_POINT" IS 'Thousand separator.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."DECIMAL_PLACES" IS 'Number of decimals.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."VALUE" IS 'Currency exchange rate relative to system default currency.';
 
   COMMENT ON COLUMN "OLS_CURRENCY"."LAST_UPDATED" IS 'Last updated.';
 
   COMMENT ON TABLE "OLS_CURRENCY"  IS 'Stores currency codes used in the system and their info.';
--------------------------------------------------------
--  DDL for Table OLS_CUSTOMER_DETAILS
--------------------------------------------------------

  CREATE TABLE "OLS_CUSTOMER_DETAILS" 
   (	"ID" NUMBER, 
	"FIRST_NAME" VARCHAR2(100), 
	"LAST_NAME" VARCHAR2(100), 
	"ADDRESS1" VARCHAR2(100), 
	"ADDRESS2" VARCHAR2(100), 
	"ADDRESS3" VARCHAR2(100), 
	"CITY" VARCHAR2(100), 
	"STATE" VARCHAR2(100), 
	"PIN" VARCHAR2(100), 
	"COUNTRY" NUMBER, 
	"EMAIL" VARCHAR2(100), 
	"CONTACT_NUMBER" VARCHAR2(100), 
	"LOGIN_ID" VARCHAR2(4000), 
	"PASSWORD" VARCHAR2(100), 
	"ADMIN" VARCHAR2(3) DEFAULT 'No'
   ) ;
 

   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."FIRST_NAME" IS 'Stores the first name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."LAST_NAME" IS 'Stores the last name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."ADDRESS1" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."ADDRESS2" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."ADDRESS3" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."CITY" IS 'Stores the city name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."STATE" IS 'Stores the state name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."PIN" IS 'Stores the zip code of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."COUNTRY" IS 'Stores the country ID of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."EMAIL" IS 'Stores the email address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."CONTACT_NUMBER" IS 'Stores the phone number of customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."LOGIN_ID" IS 'Stores email ID which is the login ID , unique constraint on this column.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."PASSWORD" IS 'Stores password for the customer.';
 
   COMMENT ON COLUMN "OLS_CUSTOMER_DETAILS"."ADMIN" IS 'If the customer is admin, then this column is set to "Yes" else "No".';
 
   COMMENT ON TABLE "OLS_CUSTOMER_DETAILS"  IS 'Contains customer information.';
--------------------------------------------------------
--  DDL for Table OLS_CUST_BILLING_DETAILS
--------------------------------------------------------

  CREATE TABLE "OLS_CUST_BILLING_DETAILS" 
   (	"ID" NUMBER, 
	"FIRST_NAME" VARCHAR2(100), 
	"LAST_NAME" VARCHAR2(100), 
	"ADDRESS1" VARCHAR2(100), 
	"ADDRESS2" VARCHAR2(100), 
	"ADDRESS3" VARCHAR2(100), 
	"CITY" VARCHAR2(100), 
	"STATE" VARCHAR2(100), 
	"PIN" VARCHAR2(100), 
	"COUNTRY" NUMBER, 
	"EMAIL" VARCHAR2(100), 
	"CONTACT_NUMBER" VARCHAR2(4000), 
	"CUSTOMER_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."FIRST_NAME" IS 'Stores the first name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."LAST_NAME" IS 'Stores the last name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."ADDRESS1" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."ADDRESS2" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."ADDRESS3" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."CITY" IS 'Stores the city name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."STATE" IS 'Stores the state name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."PIN" IS 'Stores the zip code of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."COUNTRY" IS 'Stores the country ID of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."EMAIL" IS 'Stores the email address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."CONTACT_NUMBER" IS 'Stores the phone number of customer.';
 
   COMMENT ON COLUMN "OLS_CUST_BILLING_DETAILS"."CUSTOMER_ID" IS 'Stores the customer Id of the customer.';
 
   COMMENT ON TABLE "OLS_CUST_BILLING_DETAILS"  IS 'Contains customer bill to address information.';
--------------------------------------------------------
--  DDL for Table OLS_CUST_SHIPPING_DETAILS
--------------------------------------------------------

  CREATE TABLE "OLS_CUST_SHIPPING_DETAILS" 
   (	"ID" NUMBER, 
	"FIRST_NAME" VARCHAR2(100), 
	"LAST_NAME" VARCHAR2(100), 
	"ADDRESS1" VARCHAR2(100), 
	"ADDRESS2" VARCHAR2(100), 
	"ADDRESS3" VARCHAR2(100), 
	"CITY" VARCHAR2(100), 
	"STATE" VARCHAR2(100), 
	"PIN" VARCHAR2(100), 
	"COUNTRY" NUMBER, 
	"EMAIL" VARCHAR2(100), 
	"CONTACT_NUMBER" VARCHAR2(4000), 
	"CUSTOMER_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."FIRST_NAME" IS 'Stores the first name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."LAST_NAME" IS 'Stores the last name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."ADDRESS1" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."ADDRESS2" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."ADDRESS3" IS 'Stores the address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."CITY" IS 'Stores the city name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."STATE" IS 'Stores the state name of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."PIN" IS 'Stores the zip code of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."COUNTRY" IS 'Stores the country ID of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."EMAIL" IS 'Stores the email address of the customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."CONTACT_NUMBER" IS 'Stores the phone number of customer.';
 
   COMMENT ON COLUMN "OLS_CUST_SHIPPING_DETAILS"."CUSTOMER_ID" IS 'Stores the customer Id of the customer.';
 
   COMMENT ON TABLE "OLS_CUST_SHIPPING_DETAILS"  IS 'Contains customer ship to address information.';
--------------------------------------------------------
--  DDL for Table OLS_DISPLAY_VALUES
--------------------------------------------------------

  CREATE TABLE "OLS_DISPLAY_VALUES" 
   (	"VALUE" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_DISPLAY_VALUES"."VALUE" IS 'Available values.';
 
   COMMENT ON TABLE "OLS_DISPLAY_VALUES"  IS 'Values used in LOV to display number of rows in reports.';
--------------------------------------------------------
--  DDL for Table OLS_ERRORS
--------------------------------------------------------

  CREATE TABLE "OLS_ERRORS" 
   (	"ID" NUMBER, 
	"ERROR" VARCHAR2(4000), 
	"CREATED_DATE" DATE DEFAULT sysdate
   ) ;
 

   COMMENT ON COLUMN "OLS_ERRORS"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_ERRORS"."ERROR" IS 'Error text.';
 
   COMMENT ON TABLE "OLS_ERRORS"  IS 'Errors encountered in the system. Helps to tracks possible errors.';
--------------------------------------------------------
--  DDL for Table OLS_ESTIMATED_DELIVERY_TIME
--------------------------------------------------------

  CREATE TABLE "OLS_ESTIMATED_DELIVERY_TIME" 
   (	"ID" NUMBER, 
	"DESCRIPTION" VARCHAR2(100), 
	"MIN_DAYS" NUMBER, 
	"MAX_DAYS" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_ESTIMATED_DELIVERY_TIME"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_ESTIMATED_DELIVERY_TIME"."DESCRIPTION" IS 'Description';
 
   COMMENT ON COLUMN "OLS_ESTIMATED_DELIVERY_TIME"."MIN_DAYS" IS 'Min business days.';
 
   COMMENT ON COLUMN "OLS_ESTIMATED_DELIVERY_TIME"."MAX_DAYS" IS 'Max business days.';
 
   COMMENT ON TABLE "OLS_ESTIMATED_DELIVERY_TIME"  IS 'Estimated delivery time.';
--------------------------------------------------------
--  DDL for Table OLS_FAVORITES
--------------------------------------------------------

  CREATE TABLE "OLS_FAVORITES" 
   (	"ID" NUMBER, 
	"PRODUCT_ID" NUMBER, 
	"CREATION_DATE" DATE, 
	"CUSTOMER_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_FAVORITES"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_FAVORITES"."PRODUCT_ID" IS 'Stores the product ID.';
 
   COMMENT ON COLUMN "OLS_FAVORITES"."CREATION_DATE" IS 'Stores the date when the product was added to favorites.';
 
   COMMENT ON COLUMN "OLS_FAVORITES"."CUSTOMER_ID" IS 'Stores the customer ID who added the product to favorites.';
 
   COMMENT ON TABLE "OLS_FAVORITES"  IS 'Contains customer favorite products information.';
--------------------------------------------------------
--  DDL for Table OLS_FILES
--------------------------------------------------------

  CREATE TABLE "OLS_FILES" 
   (	"PRODUCT_ID" NUMBER, 
	"FILE_ID" NUMBER, 
	"FILE_NAME" VARCHAR2(4000), 
	"MIME_TYPE" VARCHAR2(4000), 
	"FILE_BLOB" BLOB
   ) ;
 

   COMMENT ON COLUMN "OLS_FILES"."PRODUCT_ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_FILES"."FILE_ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_FILES"."FILE_NAME" IS 'Stores the file name.';
 
   COMMENT ON COLUMN "OLS_FILES"."MIME_TYPE" IS 'Stores the file type.';
 
   COMMENT ON COLUMN "OLS_FILES"."FILE_BLOB" IS 'Stores the file in the blob field.';
 
   COMMENT ON TABLE "OLS_FILES"  IS 'Contains additional file details of the product added.';
--------------------------------------------------------
--  DDL for Table OLS_GEO_ZONES
--------------------------------------------------------

  CREATE TABLE "OLS_GEO_ZONES" 
   (	"ID" NUMBER, 
	"DESCRIPTION" VARCHAR2(255), 
	"USED_IN" VARCHAR2(20)
   ) ;
 

   COMMENT ON COLUMN "OLS_GEO_ZONES"."ID" IS 'Primary key. Geo zone id.';
 
   COMMENT ON COLUMN "OLS_GEO_ZONES"."DESCRIPTION" IS 'Description field.';
 
   COMMENT ON TABLE "OLS_GEO_ZONES"  IS 'Stores Geo zones to define taxes and deliveries. ';
--------------------------------------------------------
--  DDL for Table OLS_IMAGES
--------------------------------------------------------

  CREATE TABLE "OLS_IMAGES" 
   (	"IMAGE_ID" NUMBER, 
	"IMAGE_NAME" VARCHAR2(4000), 
	"MIME_TYPE" VARCHAR2(4000), 
	"IMAGE" BLOB
   ) ;
 

   COMMENT ON COLUMN "OLS_IMAGES"."IMAGE_ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_IMAGES"."IMAGE_NAME" IS 'Stores the image name.';
 
   COMMENT ON COLUMN "OLS_IMAGES"."MIME_TYPE" IS 'Stores the image type.';
 
   COMMENT ON COLUMN "OLS_IMAGES"."IMAGE" IS 'Stores the image in the blob field.';
 
   COMMENT ON TABLE "OLS_IMAGES"  IS 'Contains image details of the product added.';
--------------------------------------------------------
--  DDL for Table OLS_LANGUAGE
--------------------------------------------------------

  CREATE TABLE "OLS_LANGUAGE" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(32), 
	"CODE" VARCHAR2(20), 
	"SORT_ORDER" NUMBER, 
	"ACTIVE" VARCHAR2(1) DEFAULT 'N'
   ) ;
 

   COMMENT ON COLUMN "OLS_LANGUAGE"."ID" IS 'Primary key. Language id.';
 
   COMMENT ON COLUMN "OLS_LANGUAGE"."NAME" IS 'Langauge name.';
 
   COMMENT ON COLUMN "OLS_LANGUAGE"."CODE" IS 'Language code.';
 
   COMMENT ON COLUMN "OLS_LANGUAGE"."SORT_ORDER" IS 'Gui sort order.';
 
   COMMENT ON COLUMN "OLS_LANGUAGE"."ACTIVE" IS 'If used in GUI. Values: Y, N.';
 
   COMMENT ON TABLE "OLS_LANGUAGE"  IS 'Stores languages used in the system.';
--------------------------------------------------------
--  DDL for Table OLS_LANGUAGE_CODES
--------------------------------------------------------

  CREATE TABLE "OLS_LANGUAGE_CODES" 
   (	"CODE" VARCHAR2(255), 
	"LANG_NAME" VARCHAR2(255)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_LINE_DOWNLOADS
--------------------------------------------------------

  CREATE TABLE "OLS_LINE_DOWNLOADS" 
   (	"ID" NUMBER, 
	"LINE_ID" NUMBER, 
	"DOWNLOAD_FILE_ID" NUMBER, 
	"DOWNLOAD_EXPIRE_DATE" DATE, 
	"DOWNLOAD_CLICK_COUNT" NUMBER
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_LINE_ITEMS
--------------------------------------------------------

  CREATE TABLE "OLS_LINE_ITEMS" 
   (	"ID" NUMBER, 
	"SALES_ORDER_ID" NUMBER, 
	"LINE_ITEM_NUM" NUMBER, 
	"PRODUCT_ID" NUMBER, 
	"TAX_AMT" NUMBER, 
	"UNIT_PRICE" NUMBER, 
	"QTY_ORD" NUMBER, 
	"BEF_TAX_TOTAL" NUMBER, 
	"AFTER_TAX_TOTAL" NUMBER, 
	"WEIGHT" NUMBER, 
	"WEIGHT_UNIT" VARCHAR2(20)
   ) ;
 

   COMMENT ON COLUMN "OLS_LINE_ITEMS"."ID" IS 'Primary Key';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."SALES_ORDER_ID" IS 'Stores the sales order ID';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."LINE_ITEM_NUM" IS 'Stores the line item number of the products in the sales order';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."PRODUCT_ID" IS 'Stores the product id';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."TAX_AMT" IS 'Stores the tax amount of the product';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."UNIT_PRICE" IS 'Stores the price of the product';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."QTY_ORD" IS 'Stores the product quantity';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."BEF_TAX_TOTAL" IS 'Stores the before tax total of each product';
 
   COMMENT ON COLUMN "OLS_LINE_ITEMS"."AFTER_TAX_TOTAL" IS 'Stores the after tax total of each product';
 
   COMMENT ON TABLE "OLS_LINE_ITEMS"  IS 'Contains product details of orders placed by the customer';
--------------------------------------------------------
--  DDL for Table OLS_LINE_ITEM_OPTIONS
--------------------------------------------------------

  CREATE TABLE "OLS_LINE_ITEM_OPTIONS" 
   (	"ID" NUMBER, 
	"LINE_ITEM_ID" NUMBER, 
	"PRODUCT_OPTION_ID" NUMBER, 
	"OPTION_VALUE" VARCHAR2(100)
   ) ;
 

   COMMENT ON COLUMN "OLS_LINE_ITEM_OPTIONS"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_LINE_ITEM_OPTIONS"."LINE_ITEM_ID" IS 'Reference to Item Id.';
 
   COMMENT ON COLUMN "OLS_LINE_ITEM_OPTIONS"."PRODUCT_OPTION_ID" IS 'Product option id.';
 
   COMMENT ON COLUMN "OLS_LINE_ITEM_OPTIONS"."OPTION_VALUE" IS 'Option Value.';
--------------------------------------------------------
--  DDL for Table OLS_LOGS
--------------------------------------------------------

  CREATE TABLE "OLS_LOGS" 
   (	"ID" NUMBER, 
	"QUERY_STRING" VARCHAR2(4000), 
	"HTTP_REFERER" VARCHAR2(4000), 
	"CREATED_DATE" DATE
   ) ;
 

   COMMENT ON TABLE "OLS_LOGS"  IS 'Stores visitors logs.';
--------------------------------------------------------
--  DDL for Table OLS_MANUFACTURER
--------------------------------------------------------

  CREATE TABLE "OLS_MANUFACTURER" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(32), 
	"IMAGE_ID" NUMBER, 
	"DATE_ADDED" DATE, 
	"LAST_MODIFIED" DATE, 
	"MANUFACTURER_URL" VARCHAR2(255)
   ) ;
 

   COMMENT ON COLUMN "OLS_MANUFACTURER"."ID" IS 'Primary key. Manufacturer id.';
 
   COMMENT ON COLUMN "OLS_MANUFACTURER"."NAME" IS 'Name of a manufacturer.';
 
   COMMENT ON COLUMN "OLS_MANUFACTURER"."IMAGE_ID" IS 'Image id. Image associtaed with a manufacturer.';
 
   COMMENT ON COLUMN "OLS_MANUFACTURER"."DATE_ADDED" IS 'Date the row is created.';
 
   COMMENT ON COLUMN "OLS_MANUFACTURER"."LAST_MODIFIED" IS 'Last date it is modified.';
 
   COMMENT ON COLUMN "OLS_MANUFACTURER"."MANUFACTURER_URL" IS 'Manufacturer url. Used in GUI to link to manufacturer web site.';
 
   COMMENT ON TABLE "OLS_MANUFACTURER"  IS 'Stores vendors (manufacturers) of products. ';
--------------------------------------------------------
--  DDL for Table OLS_MESSAGES
--------------------------------------------------------

  CREATE TABLE "OLS_MESSAGES" 
   (	"ID" NUMBER, 
	"CUSTOMER_ID" NUMBER, 
	"TITLE" VARCHAR2(255), 
	"TEXT" VARCHAR2(2000), 
	"CREATED_DATE" DATE, 
	"REPLIED_DATE" DATE, 
	"READ_DATE" DATE, 
	"FROM_EMAIL" VARCHAR2(100), 
	"REPLY_ON_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_MESSAGES"."REPLY_ON_ID" IS 'Tells the original message id';
--------------------------------------------------------
--  DDL for Table OLS_NEWS
--------------------------------------------------------

  CREATE TABLE "OLS_NEWS" 
   (	"ID" NUMBER, 
	"TITLE" VARCHAR2(255), 
	"TEXT" VARCHAR2(2000), 
	"MODULE" VARCHAR2(255), 
	"DATE_ADDED" DATE, 
	"DATE_SENT" DATE, 
	"ACTIVE" VARCHAR2(3), 
	"HTML_LINK" VARCHAR2(100), 
	"HTML_LINK_TEXT" VARCHAR2(100), 
	"HTML_PAR" VARCHAR2(20)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_NEWSLETTER
--------------------------------------------------------

  CREATE TABLE "OLS_NEWSLETTER" 
   (	"ID" NUMBER, 
	"TITLE" VARCHAR2(255), 
	"CONTENT" VARCHAR2(2000), 
	"CREATED_DATE" DATE, 
	"SENT_DATE" DATE, 
	"ACTIVE" VARCHAR2(1) DEFAULT 'N'
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_ORDER_STATUS
--------------------------------------------------------

  CREATE TABLE "OLS_ORDER_STATUS" 
   (	"STATUS" VARCHAR2(20), 
	"ID" NUMBER, 
	"ALLOWED_ORDER" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_ORDER_STATUS"."STATUS" IS 'Status of Order.';
 
   COMMENT ON COLUMN "OLS_ORDER_STATUS"."ALLOWED_ORDER" IS 'It is allowed to change the status of Order to greater or equal Status id than the current value of this field.';
--------------------------------------------------------
--  DDL for Table OLS_PAYMENT_CC_TYPE
--------------------------------------------------------

  CREATE TABLE "OLS_PAYMENT_CC_TYPE" 
   (	"ID" NUMBER, 
	"DESCRIPTION" VARCHAR2(4000), 
	"AVAILABLE" VARCHAR2(1) DEFAULT 'N', 
	"PRIORITY" NUMBER DEFAULT 1,
	"PAYPAL" VARCHAR2(1) DEFAULT 'N'
   ) ;
 

   COMMENT ON COLUMN "OLS_PAYMENT_CC_TYPE"."ID" IS 'Primary Key';
 
   COMMENT ON COLUMN "OLS_PAYMENT_CC_TYPE"."DESCRIPTION" IS 'Stores the credit card name.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_CC_TYPE"."AVAILABLE" IS 'If ''N'' no such CC is shown in webshop. ';
 
   COMMENT ON COLUMN "OLS_PAYMENT_CC_TYPE"."PRIORITY" IS 'The order in which credit cards are shown in GUI Select List for credit cards.';

   COMMENT ON COLUMN "OLS_PAYMENT_CC_TYPE"."PAYPAL" IS 'Tells if Acceptable by Paypal.';
 
   COMMENT ON TABLE "OLS_PAYMENT_CC_TYPE"  IS 'Contains details of various credit cards accepted for payment in the store';
--------------------------------------------------------
--  DDL for Table OLS_PAYMENT_MODE_EX
--------------------------------------------------------

  CREATE TABLE "OLS_PAYMENT_MODE_EX" 
   (	"ID" NUMBER, 
	"DESCRIPTION" VARCHAR2(1000), 
	"VENDOR_ID" VARCHAR2(200), 
	"PASSWORD" VARCHAR2(200), 
	"SIGNATURE" VARCHAR2(1000) DEFAULT NULL, 
	"AVAILABLE" VARCHAR2(1) DEFAULT 'N', 
	"SANDBOX" VARCHAR2(200), 
	"PRODUCTION" VARCHAR2(200), 
	"TESTMODE" VARCHAR2(1) DEFAULT 'Y', 
	"CHECKOUT_URL_P" VARCHAR2(200), 
	"KEY" VARCHAR2(10), 
	"CHECKOUT_URL_T" VARCHAR2(4000), 
	"BUTTON_URL" VARCHAR2(4000)
   ) ;
 

   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."VENDOR_ID" IS 'Vendor or merchant id.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."PASSWORD" IS 'Password or secret key.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."SIGNATURE" IS 'Signature.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."AVAILABLE" IS '''Y'' if available in webshop. Please note that the payment mode must be implemented in webshop.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."SANDBOX" IS 'Test system address.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."PRODUCTION" IS 'Production system address.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."TESTMODE" IS '''Y'' if sandbox should be used.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."CHECKOUT_URL_P" IS 'Checkout production address.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."KEY" IS 'Key used in the code to determine payment type.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."CHECKOUT_URL_T" IS 'Checkout test url.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_EX"."BUTTON_URL" IS 'Button Url.';
--------------------------------------------------------
--  DDL for Table OLS_PAYMENT_MODE_IN
--------------------------------------------------------

  CREATE TABLE "OLS_PAYMENT_MODE_IN" 
   (	"ID" NUMBER DEFAULT 1, 
	"DESCRIPTION" VARCHAR2(4000), 
	"AVAILABLE" VARCHAR2(1) DEFAULT 'N', 
	"PRIORITY" NUMBER DEFAULT 1, 
	"KEY" VARCHAR2(10)
   ) ;
 

   COMMENT ON COLUMN "OLS_PAYMENT_MODE_IN"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_IN"."DESCRIPTION" IS 'Stores the payment mode type names.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_IN"."AVAILABLE" IS 'If ''N'' no such mode is offered in the webshop at all.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_IN"."PRIORITY" IS 'Sorting order in GUI.';
 
   COMMENT ON COLUMN "OLS_PAYMENT_MODE_IN"."KEY" IS 'Key used in the code to fetch payment info.';
 
   COMMENT ON TABLE "OLS_PAYMENT_MODE_IN"  IS 'Contains details of various payment accepted in the onlinestore.';
--------------------------------------------------------
--  DDL for Table OLS_PAYPAL_SESSION_MAP
--------------------------------------------------------

  CREATE TABLE "OLS_PAYPAL_SESSION_MAP" 
   (	"SESSION_ID" NUMBER, 
	"APP_ID" NUMBER, 
	"PAGE_ID" NUMBER, 
	"PAYER_ID_ITEM" VARCHAR2(4000), 
	"SESSION_TOKEN" VARCHAR2(255)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_PAYPAL_TRANSACTIONS
--------------------------------------------------------

  CREATE TABLE "OLS_PAYPAL_TRANSACTIONS" 
   (	"SESSION_ID" NUMBER, 
	"SESSION_TOKEN" VARCHAR2(255), 
	"TRANSACTION_ID" VARCHAR2(30), 
	"ORDER_TIME" VARCHAR2(30), 
	"AMOUNT" NUMBER, 
	"FEE_AMOUNT" NUMBER, 
	"SETTLE_AMOUNT" NUMBER, 
	"PAYMENT_STATUS" VARCHAR2(30), 
	"PENDING_REASON" VARCHAR2(30), 
	"REASON_CODE" VARCHAR2(30), 
	"RESPONSE" VARCHAR2(4000)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_PRODUCT
--------------------------------------------------------

  CREATE TABLE "OLS_PRODUCT" 
   (	"ID" NUMBER, 
	"PRODUCT_NAME" VARCHAR2(255), 
	"SHORT_DESCRIPTION" VARCHAR2(500), 
	"LONG_DESCRIPTION" VARCHAR2(4000), 
	"CATEGORY_ID" NUMBER, 
	"LIST_PRICE" NUMBER(8,2) DEFAULT 0, 
	"TAX" NUMBER DEFAULT 0, 
	"SELLING_PRICE" NUMBER(8,2) DEFAULT 0, 
	"QOH" NUMBER DEFAULT 0, 
	"AVAILABILITY" VARCHAR2(3) DEFAULT 'No', 
	"HOT" VARCHAR2(3) DEFAULT 'No', 
	"WEIGHT" NUMBER(8,2) DEFAULT 0, 
	"DISCOUNT" NUMBER DEFAULT 0, 
	"POINTS" NUMBER, 
	"ACTIVATION_DATE" DATE, 
	"IMAGE_ID" NUMBER, 
	"PROMOTION" VARCHAR2(3) DEFAULT 'No', 
	"MANUFACTURER_ID" NUMBER, 
	"TAX_CLASS_ID" NUMBER, 
	"DOWNLOAD" VARCHAR2(1), 
	"CREATED_DATE" DATE, 
	"CREATED_BY_ID" VARCHAR2(100), 
	"MODIFIED_DATE" DATE, 
	"MODIFIED_BY_ID" VARCHAR2(4000), 
	"MORE" VARCHAR2(200), 
	"LICENSE" VARCHAR2(200), 
	"SKU" VARCHAR2(20)
   ) ;
 

   COMMENT ON COLUMN "OLS_PRODUCT"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."PRODUCT_NAME" IS 'Stores the product name.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."SHORT_DESCRIPTION" IS 'Stores the short description of the product.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."LONG_DESCRIPTION" IS 'Stores the detailed description of the product.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."CATEGORY_ID" IS 'Stores the category ID of the product.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."LIST_PRICE" IS 'Stores the list price of the product excluding tax.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."TAX" IS 'Stores the tax of the product.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."SELLING_PRICE" IS 'Stores the price of the proudct including tax.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."QOH" IS 'Stores the Quantity on hand, i.e the stock available.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."AVAILABILITY" IS 'If the product is available for sale, then this column is set to "Yes" else "No"';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."HOT" IS 'If the product is hot, then this column is set to "Yes" else "No".';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."WEIGHT" IS 'Weight in webshop default weight unit.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."DISCOUNT" IS 'Stores the discount available on each product in percentage (%).';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."POINTS" IS 'Stores the points assigned to each product when purchased by the customer.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."ACTIVATION_DATE" IS 'Stores the activation date of the product.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."IMAGE_ID" IS 'Stores the image id of the product.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."PROMOTION" IS 'If the product is setup for promotion then this column is set to "Yes" else "No".';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."MANUFACTURER_ID" IS 'Reference to ols_manufacturer.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."TAX_CLASS_ID" IS 'Default tax rate.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."DOWNLOAD" IS 'If product is of download delivery type.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."CREATED_DATE" IS 'Created date.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."CREATED_BY_ID" IS 'Id of a creator.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."MODIFIED_DATE" IS 'Modified date.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."MODIFIED_BY_ID" IS 'Id of the last who modified.';
 
   COMMENT ON COLUMN "OLS_PRODUCT"."SKU" IS 'SKU of a product. Internal use only.';
 
   COMMENT ON TABLE "OLS_PRODUCT"  IS 'Contains details of all the products.';
--------------------------------------------------------
--  DDL for Table OLS_PRODUCT_OPTIONS
--------------------------------------------------------

  CREATE TABLE "OLS_PRODUCT_OPTIONS" 
   (	"ID" NUMBER, 
	"OPTION_NAME" VARCHAR2(30), 
	"OPTION_VALUES" VARCHAR2(4000), 
	"COMMENTS" VARCHAR2(4000)
   ) ;
 

   COMMENT ON COLUMN "OLS_PRODUCT_OPTIONS"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_PRODUCT_OPTIONS"."OPTION_NAME" IS 'Option name.';
 
   COMMENT ON TABLE "OLS_PRODUCT_OPTIONS"  IS 'Stores product options such as Color, Size and etc.';
--------------------------------------------------------
--  DDL for Table OLS_PRODUCT_TO_PR_OPTIONS
--------------------------------------------------------

  CREATE TABLE "OLS_PRODUCT_TO_PR_OPTIONS" 
   (	"ID" NUMBER, 
	"PRODUCT_ID" NUMBER, 
	"PRODUCT_OPTION_ID" NUMBER
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_PRODUCT_TRANS
--------------------------------------------------------

  CREATE TABLE "OLS_PRODUCT_TRANS" 
   (	"PROD_ID" NUMBER, 
	"LANG_ID" NUMBER, 
	"PRODUCT_NAME" VARCHAR2(255), 
	"SHORT_DESCRIPTION" VARCHAR2(500), 
	"LONG_DESCRIPTION" VARCHAR2(4000)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_REVIEWS
--------------------------------------------------------

  CREATE TABLE "OLS_REVIEWS" 
   (	"ID" NUMBER, 
	"PRODUCT_ID" NUMBER, 
	"CUSTOMER_ID" NUMBER, 
	"TEXT" VARCHAR2(2000), 
	"REVIEW_RATING" NUMBER, 
	"DATE_ADDED" DATE, 
	"LAST_MODIFIED" DATE,
        "NAME" VARCHAR2(20)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_SALES_ORDER
--------------------------------------------------------

  CREATE TABLE "OLS_SALES_ORDER" 
   (	"ID" NUMBER, 
	"CUSTOMER_ID" NUMBER, 
	"BILL_TO_ID" NUMBER, 
	"SHIP_TO_ID" NUMBER, 
	"ORDER_DATE" DATE, 
	"CURRENCY" CHAR(3), 
	"TOT_ORDER_AMT" NUMBER, 
	"FREIGHT_CHARGE" NUMBER, 
	"TAX_AMT" NUMBER, 
	"DELIVERY_DATE" DATE, 
	"COMMENTS" VARCHAR2(4000), 
	"STATUS_ID" NUMBER, 
	"SESSION_ID" NUMBER, 
	"ACTUAL_DELIVERY_DATE" DATE, 
	"SHIPPING_TYPE_ID" NUMBER, 
	"SHIPPING_NOTICE" VARCHAR2(1000)
   ) ;
 

   COMMENT ON COLUMN "OLS_SALES_ORDER"."ID" IS 'Primary Key.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."CUSTOMER_ID" IS 'Stores the CUSTOMER ID.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."BILL_TO_ID" IS 'Stores the bill to ID of the customer.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."SHIP_TO_ID" IS 'Stores the ship to id of the customer.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."ORDER_DATE" IS 'Stores the order date of the sales order.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."CURRENCY" IS 'Stores the currency of the sales order.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."TOT_ORDER_AMT" IS 'Stores the total order amount of the SALES ORDER.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."FREIGHT_CHARGE" IS 'Stores the freight charge of the sales order (shipping).';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."TAX_AMT" IS 'Stores the tax amount of the SALES ORDER.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."DELIVERY_DATE" IS 'Stores the expected delivery date of the SALES ORDER calculated by the system.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."COMMENTS" IS 'Stores the comments of the customer pertaining to the sales order.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."STATUS_ID" IS 'Reference to ols_order_status.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."SESSION_ID" IS 'Apex session id.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."ACTUAL_DELIVERY_DATE" IS 'Actual delivery date.';
 
   COMMENT ON COLUMN "OLS_SALES_ORDER"."SHIPPING_TYPE_ID" IS 'The reference to shipping types.';
 
   COMMENT ON TABLE "OLS_SALES_ORDER"  IS 'Contains sales order details placed by the customer.';
--------------------------------------------------------
--  DDL for Table OLS_SHIPPING_AMOUNT_RATES
--------------------------------------------------------

  CREATE TABLE "OLS_SHIPPING_AMOUNT_RATES" 
   (	"ID" NUMBER, 
	"SHIPPING_TYPE_ID" NUMBER, 
	"AMOUNT" NUMBER, 
	"RATE" NUMBER(8,2), 
	"GEO_ZONE_ID" VARCHAR2(2000), 
	"BASED_ON" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_SHIPPING_AMOUNT_RATES"."GEO_ZONE_ID" IS 'Geo zone ids for the current rate.';
--------------------------------------------------------
--  DDL for Table OLS_SHIPPING_PRICE_TYPES
--------------------------------------------------------

  CREATE TABLE "OLS_SHIPPING_PRICE_TYPES" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(20)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_SHIPPING_TYPES
--------------------------------------------------------

  CREATE TABLE "OLS_SHIPPING_TYPES" 
   (	"ID" NUMBER, 
	"SHIPPING_NAME" VARCHAR2(100), 
	"DESCRIPTION" VARCHAR2(4000), 
	"ACTIVE" VARCHAR2(1) DEFAULT 'Y', 
	"MAX_WEIGHT" NUMBER, 
	"BASED_ON" NUMBER DEFAULT 1, 
	"ESTIMATED_SHIP_TIME_ID" NUMBER DEFAULT 1, 
	"FREE" VARCHAR2(1) DEFAULT 'N'
   ) ;
 

   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."ID" IS 'Primary key.';
 
   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."SHIPPING_NAME" IS 'Shipping name.';
 
   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."DESCRIPTION" IS 'Description.';
 
   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."ACTIVE" IS 'If active, i.e. allowed to use in the system.';
 
   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."MAX_WEIGHT" IS 'Maximum weight allowed to ship.';
 
   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."BASED_ON" IS 'Calculations are based on Total Weight, Order Amount or Quantity';
 
   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."ESTIMATED_SHIP_TIME_ID" IS 'Estimated shipping time. Reference to table estimated delivery time.';
 
   COMMENT ON COLUMN "OLS_SHIPPING_TYPES"."FREE" IS 'Flag: free or not. Values: N or Y';
 
   COMMENT ON TABLE "OLS_SHIPPING_TYPES"  IS 'Lists available shipping types.';
--------------------------------------------------------
--  DDL for Table OLS_SHOPPING_CART
--------------------------------------------------------

  CREATE TABLE "OLS_SHOPPING_CART" 
   (	"SESSION_ID" VARCHAR2(100), 
	"PRODUCT_ID" NUMBER, 
	"QUANTITY" NUMBER, 
	"OPTIONS" VARCHAR2(4000), 
	"OPTION_VALUES" VARCHAR2(4000), 
	"CREATED" DATE
   ) ;
 

   COMMENT ON COLUMN "OLS_SHOPPING_CART"."SESSION_ID" IS 'Stores user id, i.e. login (email).';
 
   COMMENT ON COLUMN "OLS_SHOPPING_CART"."QUANTITY" IS 'Qty of a product.';
 
   COMMENT ON COLUMN "OLS_SHOPPING_CART"."OPTIONS" IS 'Stores product options separated by comma.';
 
   COMMENT ON COLUMN "OLS_SHOPPING_CART"."OPTION_VALUES" IS 'Stores product option values separated by comma.';
 
   COMMENT ON TABLE "OLS_SHOPPING_CART"  IS 'Storing customer shopping carts.';
--------------------------------------------------------
--  DDL for Table OLS_SO_PAY_DETAILS
--------------------------------------------------------

  CREATE TABLE "OLS_SO_PAY_DETAILS" 
   (	"ID" NUMBER, 
	"SALES_ORDER_ID" NUMBER, 
	"CUSTOMER_ID" NUMBER, 
	"PAYMENT_ID" NUMBER, 
	"CREDIT_CARD_TYPE" VARCHAR2(100), 
	"CREDIT_CARD_NUM" NUMBER, 
	"EXPIRY_DATE" VARCHAR2(50), 
	"AMOUNT" NUMBER, 
	"CHEQUE_NO" VARCHAR2(100), 
	"CHEQUE_DATE" DATE, 
	"DEMANDDRAFT_NO" VARCHAR2(100), 
	"CVC" VARCHAR2(10), 
	"TRANSACTION_ID" VARCHAR2(30)
   ) ;
 

   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."ID" IS 'Primary Key';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."SALES_ORDER_ID" IS 'Stores the sales order ID';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."CUSTOMER_ID" IS 'Stores the customer id';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."PAYMENT_ID" IS 'Stores the payment ID';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."CREDIT_CARD_TYPE" IS 'Stores the credit card type if the payment is made by credit card';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."CREDIT_CARD_NUM" IS 'Stores the credit card number if the payment is made by credit card';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."EXPIRY_DATE" IS 'Stores the expiry date if the payment is made by credit card';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."AMOUNT" IS 'Stores the order amount of the sales order';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."CHEQUE_NO" IS 'Stores the cheque number if the payment is made by cheque';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."CHEQUE_DATE" IS 'Stores the cheque date if the payment is made by cheque';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."DEMANDDRAFT_NO" IS 'Stores the demand draft number if the payment is made by demand draft';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."CVC" IS 'Card verification code.';
 
   COMMENT ON COLUMN "OLS_SO_PAY_DETAILS"."TRANSACTION_ID" IS 'Paypal or any other external payment system transaction reference.';
 
   COMMENT ON TABLE "OLS_SO_PAY_DETAILS"  IS 'Contains payment details of each sales order placed by the customer';
--------------------------------------------------------
--  DDL for Table OLS_SPECIAL_CHARACTERS
--------------------------------------------------------

  CREATE TABLE "OLS_SPECIAL_CHARACTERS" 
   (	"CHARACTER" VARCHAR2(10)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_STATES
--------------------------------------------------------

  CREATE TABLE "OLS_STATES" 
   (	"ID" NUMBER, 
	"COUNTRY_ID" NUMBER, 
	"ST" VARCHAR2(30), 
	"STATE_NAME" VARCHAR2(30)
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_TAX_CLASS
--------------------------------------------------------

  CREATE TABLE "OLS_TAX_CLASS" 
   (	"ID" NUMBER, 
	"TITLE" VARCHAR2(32), 
	"DESCRIPTION" VARCHAR2(255), 
	"LAST_MODIFIED" DATE, 
	"DATE_ADDED" DATE
   ) ;
--------------------------------------------------------
--  DDL for Table OLS_TAX_RATES
--------------------------------------------------------

  CREATE TABLE "OLS_TAX_RATES" 
   (	"ID" NUMBER, 
	"GEO_ZONE_ID" NUMBER, 
	"CLASS_ID" NUMBER, 
	"RATE" NUMBER(7,4), 
	"DESCRIPTION" VARCHAR2(255), 
	"LAST_MODIFIED" DATE, 
	"DATE_ADDED" DATE
   ) ;
 

   COMMENT ON COLUMN "OLS_TAX_RATES"."GEO_ZONE_ID" IS 'Referes to ols_geo_zones for tax usage.';
 
   COMMENT ON COLUMN "OLS_TAX_RATES"."CLASS_ID" IS 'Referes to ols_tax_class.';
--------------------------------------------------------
--  DDL for Table OLS_ZONES
--------------------------------------------------------

  CREATE TABLE "OLS_ZONES" 
   (	"ID" NUMBER, 
	"COUNTRY_ID" NUMBER, 
	"CODE" VARCHAR2(32), 
	"NAME" VARCHAR2(32), 
	"GEO_ZONE_ID" NUMBER, 
	"TAX_GEO_ZONE_ID" NUMBER
   ) ;
 

   COMMENT ON COLUMN "OLS_ZONES"."CODE" IS 'Zone Code, typically State code like in USA. ';
 
   COMMENT ON COLUMN "OLS_ZONES"."GEO_ZONE_ID" IS 'Shipping Geo zone.';
 
   COMMENT ON COLUMN "OLS_ZONES"."TAX_GEO_ZONE_ID" IS 'Tax Geo zone.';


---------------------------------------------------
--   DATA FOR TABLE OLS_PRODUCT_TRANS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PRODUCT_TRANS

---------------------------------------------------
--   END DATA FOR TABLE OLS_PRODUCT_TRANS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_MANUFACTURER
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_MANUFACTURER

---------------------------------------------------
--   END DATA FOR TABLE OLS_MANUFACTURER
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_SHOPPING_CART
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_SHOPPING_CART

---------------------------------------------------
--   END DATA FOR TABLE OLS_SHOPPING_CART
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_LINE_DOWNLOADS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_LINE_DOWNLOADS

---------------------------------------------------
--   END DATA FOR TABLE OLS_LINE_DOWNLOADS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_TAX_CLASS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_TAX_CLASS
Insert into OLS_TAX_CLASS (ID,TITLE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (1,'Taxable Goods','The following types of products are included non-food, services, etc',to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_CLASS (ID,TITLE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (2,'Non-taxable','Products that are not taxable',to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_CLASS (ID,TITLE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (3,'Food Tax','Food',to_timestamp('02-OCT-08 05.51.12.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('11-JUN-08 02.44.04.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_CLASS (ID,TITLE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (4,'Books Tax','Public transport services, books and medicines',to_timestamp('02-OCT-08 05.51.12.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('03-AUG-08 08.55.55.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));

---------------------------------------------------
--   END DATA FOR TABLE OLS_TAX_CLASS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_REVIEWS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_REVIEWS

---------------------------------------------------
--   END DATA FOR TABLE OLS_REVIEWS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CONFIGURATION_GROUP
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CONFIGURATION_GROUP
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (1,'My Store','General information about my store',1,1,16996424103216807);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (2,'Minimum Values','The minimum values for data',2,1,11664606485480959);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (3,'Maximum Values','The maximum values for data',3,1,11665014796483319);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (4,'Images','Image parameters',4,1,9964723877676820);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (5,'Customer Details','Customer account configuration',5,1,10361805166074111);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (6,'Internal Options','Hidden from configuration',6,0,7188225170479451);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (7,'Shipping/Packaging','Shipping options available at my store',7,1,12723716902499794);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (8,'Product Listing','Product Listing  configuration',8,1,9928911130152775);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (9,'Stock','Stock configuration',9,1,12077823708277513);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (10,'Logging','Logging configuration options',10,1,11670630604554141);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (11,'Payment','Payment options available',11,1,9930318318173695);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (12,'E-Mail Options','General setting for email',12,1,9929914855172720);
Insert into OLS_CONFIGURATION_GROUP (ID,TITLE,DESCRIPTION,SORT_ORDER,VISIBLE,IMAGE_ID) values (13,'Download','Downloadable products options',13,1,12721123182179886);

---------------------------------------------------
--   END DATA FOR TABLE OLS_CONFIGURATION_GROUP
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_BANNERS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_BANNERS
Insert into OLS_BANNERS (ID,TITLE,URL,HTML_TEXT,VALIDITY_FROM,VALIDITY_TO,CREATED_DATE,MODIFIED_DATE,IMAGE_URL,WIDTH,HEIGHT) values (1,'Linux','http://www.linux.org','Linux',to_timestamp('23-MAY-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('31-DEC-12 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-MAY-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),'/i/linux_penguin_small.gif',45,53);
Insert into OLS_BANNERS (ID,TITLE,URL,HTML_TEXT,VALIDITY_FROM,VALIDITY_TO,CREATED_DATE,MODIFIED_DATE,IMAGE_URL,WIDTH,HEIGHT) values (2,'Oracle XE','http://www.oracle.com/technology/products/database/xe/index.html','Oracle XE',to_timestamp('12-MAY-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('31-DEC-12 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('12-MAY-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('19-JUL-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),'/i/htmldb/oracle_xe_logo.gif',300,31);
Insert into OLS_BANNERS (ID,TITLE,URL,HTML_TEXT,VALIDITY_FROM,VALIDITY_TO,CREATED_DATE,MODIFIED_DATE,IMAGE_URL,WIDTH,HEIGHT) values (3,'APEX','http://www.oracle.com/technology/products/database/application_express/index.html','Application Express',to_timestamp('04-MAY-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('31-DEC-12 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('29-MAY-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-JUL-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),'/i/htmldb/apex_logo.gif',300,31);

---------------------------------------------------
--   END DATA FOR TABLE OLS_BANNERS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_SO_PAY_DETAILS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_SO_PAY_DETAILS

---------------------------------------------------
--   END DATA FOR TABLE OLS_SO_PAY_DETAILS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_GEO_ZONES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_GEO_ZONES
Insert into OLS_GEO_ZONES (ID,DESCRIPTION,USED_IN) values (2,'European Union','SHIP_TAX');
Insert into OLS_GEO_ZONES (ID,DESCRIPTION,USED_IN) values (4,'Spain','SHIP_TAX');
Insert into OLS_GEO_ZONES (ID,DESCRIPTION,USED_IN) values (1,'USA','SHIP_TAX');
Insert into OLS_GEO_ZONES (ID,DESCRIPTION,USED_IN) values (5,'Non-EU','TAX');

---------------------------------------------------
--   END DATA FOR TABLE OLS_GEO_ZONES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_NEWS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_NEWS
Insert into OLS_NEWS (ID,TITLE,TEXT,MODULE,DATE_ADDED,DATE_SENT,ACTIVE,HTML_LINK,HTML_LINK_TEXT,HTML_PAR) values (222,'News','<br>is a rapid web application development tool for the Oracle database.','SCROLL',to_timestamp('28-JUL-07','DD-MON-RR HH.MI.SSXFF AM'),null,'Yes','http://www.oracle.com/technology/products/database/application_express/index.html','Oracle Application Express',null);
Insert into OLS_NEWS (ID,TITLE,TEXT,MODULE,DATE_ADDED,DATE_SENT,ACTIVE,HTML_LINK,HTML_LINK_TEXT,HTML_PAR) values (244,'News','<br />is free to develop, deploy, and simple to administer database based on the Oracle Database 10g.','SCROLL',to_timestamp('28-JUL-07','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('28-JUL-07','DD-MON-RR HH.MI.SSXFF AM'),'Yes','http://www.oracle.com/technology/products/database/xe/index.html','Oracle Database 10g Express Edition',null);
Insert into OLS_NEWS (ID,TITLE,TEXT,MODULE,DATE_ADDED,DATE_SENT,ACTIVE,HTML_LINK,HTML_LINK_TEXT,HTML_PAR) values (242,'News','<br />Comprehensive JavaScript tutorials and over 400+ free scripts!','SCROLL',to_timestamp('28-JUL-07','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('28-JUL-07','DD-MON-RR HH.MI.SSXFF AM'),'No','http://www.javascriptkit.com','JavaScript Kit',null);
Insert into OLS_NEWS (ID,TITLE,TEXT,MODULE,DATE_ADDED,DATE_SENT,ACTIVE,HTML_LINK,HTML_LINK_TEXT,HTML_PAR) values (243,'News','<br />is a free graphical tool for database development. You can browse database objects, run SQL and PL/SQL statements. ','SCROLL',to_timestamp('28-JUL-07','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('28-JUL-07','DD-MON-RR HH.MI.SSXFF AM'),'Yes','http://www.oracle.com/technology/products/database/sql_developer/index.html','Oracle SQL Developer',null);

---------------------------------------------------
--   END DATA FOR TABLE OLS_NEWS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CAT_PRODUCT
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CAT_PRODUCT

---------------------------------------------------
--   END DATA FOR TABLE OLS_CAT_PRODUCT
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_LINE_ITEM_OPTIONS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_LINE_ITEM_OPTIONS

---------------------------------------------------
--   END DATA FOR TABLE OLS_LINE_ITEM_OPTIONS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_COUNTRY
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_COUNTRY
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (226,'Uzbekistan','UZ','UZB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (227,'Vanuatu','VU','VUT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (228,'Vatican City State (Holy See)','VA','VAT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (229,'Venezuela','VE','VEN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (230,'Viet Nam','VN','VNM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (231,'Virgin Islands (British)','VG','VGB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (232,'Virgin Islands (U.S.)','VI','VIR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (233,'Wallis and Futuna Islands','WF','WLF',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (234,'Western Sahara','EH','ESH',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (235,'Yemen','YE','YEM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (236,'Yugoslavia','YU','YUG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (237,'Zaire','ZR','ZAR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (1,'Afghanistan','AF','AFG',1,'N');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (2,'Albania','AL','ALB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (3,'Algeria','DZ','DZA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (4,'American Samoa','AS','ASM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (5,'Andorra','AD','AND',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (6,'Angola','AO','AGO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (7,'Anguilla','AI','AIA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (8,'Antarctica','AQ','ATA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (9,'Antigua and Barbuda','AG','ATG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (10,'Argentina','AR','ARG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (11,'Armenia','AM','ARM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (12,'Aruba','AW','ABW',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (13,'Australia','AU','AUS',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (14,'Austria','AT','AUT',5,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (15,'Azerbaijan','AZ','AZE',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (16,'Bahamas','BS','BHS',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (17,'Bahrain','BH','BHR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (18,'Bangladesh','BD','BGD',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (19,'Barbados','BB','BRB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (20,'Belarus','BY','BLR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (21,'Belgium','BE','BEL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (22,'Belize','BZ','BLZ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (23,'Benin','BJ','BEN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (24,'Bermuda','BM','BMU',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (25,'Bhutan','BT','BTN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (26,'Bolivia','BO','BOL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (28,'Botswana','BW','BWA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (29,'Bouvet Island','BV','BVT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (30,'Brazil','BR','BRA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (32,'Brunei Darussalam','BN','BRN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (33,'Bulgaria','BG','BGR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (34,'Burkina Faso','BF','BFA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (35,'Burundi','BI','BDI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (36,'Cambodia','KH','KHM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (37,'Cameroon','CM','CMR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (38,'Canada','CA','CAN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (39,'Cape Verde','CV','CPV',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (40,'Cayman Islands','KY','CYM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (41,'Central African Republic','CF','CAF',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (42,'Chad','TD','TCD',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (43,'Chile','CL','CHL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (44,'China','CN','CHN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (45,'Christmas Island','CX','CXR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (46,'Cocos (Keeling) Islands','CC','CCK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (47,'Colombia','CO','COL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (48,'Comoros','KM','COM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (49,'Congo','CG','COG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (50,'Cook Islands','CK','COK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (51,'Costa Rica','CR','CRI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (52,'Cote D''Ivoire','CI','CIV',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (53,'Croatia','HR','HRV',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (54,'Cuba','CU','CUB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (55,'Cyprus','CY','CYP',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (56,'Czech Republic','CZ','CZE',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (57,'Denmark','DK','DNK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (58,'Djibouti','DJ','DJI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (59,'Dominica','DM','DMA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (60,'Dominican Republic','DO','DOM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (61,'East Timor','TP','TMP',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (62,'Ecuador','EC','ECU',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (63,'Egypt','EG','EGY',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (64,'El Salvador','SV','SLV',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (65,'Equatorial Guinea','GQ','GNQ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (66,'Eritrea','ER','ERI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (67,'Estonia','EE','EST',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (68,'Ethiopia','ET','ETH',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (69,'Falkland Islands (Malvinas)','FK','FLK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (70,'Faroe Islands','FO','FRO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (71,'Fiji','FJ','FJI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (72,'Finland','FI','FIN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (73,'France','FR','FRA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (74,'France, Metropolitan','FX','FXX',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (75,'French Guiana','GF','GUF',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (76,'French Polynesia','PF','PYF',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (77,'French Southern Territories','TF','ATF',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (78,'Gabon','GA','GAB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (79,'Gambia','GM','GMB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (80,'Georgia','GE','GEO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (81,'Germany','DE','DEU',5,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (82,'Ghana','GH','GHA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (83,'Gibraltar','GI','GIB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (84,'Greece','GR','GRC',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (85,'Greenland','GL','GRL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (86,'Grenada','GD','GRD',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (87,'Guadeloupe','GP','GLP',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (88,'Guam','GU','GUM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (89,'Guatemala','GT','GTM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (90,'Guinea','GN','GIN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (91,'Guinea-bissau','GW','GNB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (92,'Guyana','GY','GUY',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (93,'Haiti','HT','HTI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (94,'Heard and Mc Donald Islands','HM','HMD',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (95,'Honduras','HN','HND',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (96,'Hong Kong','HK','HKG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (97,'Hungary','HU','HUN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (98,'Iceland','IS','ISL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (99,'India','IN','IND',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (100,'Indonesia','ID','IDN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (101,'Iran (Islamic Republic of)','IR','IRN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (102,'Iraq','IQ','IRQ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (103,'Ireland','IE','IRL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (104,'Israel','IL','ISR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (105,'Italy','IT','ITA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (106,'Jamaica','JM','JAM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (107,'Japan','JP','JPN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (108,'Jordan','JO','JOR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (109,'Kazakhstan','KZ','KAZ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (110,'Kenya','KE','KEN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (111,'Kiribati','KI','KIR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (112,'Korea, Democratic People''s Republic of','KP','PRK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (113,'Korea, Republic of','KR','KOR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (114,'Kuwait','KW','KWT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (115,'Kyrgyzstan','KG','KGZ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (116,'Lao People''s Democratic Republic','LA','LAO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (117,'Latvia','LV','LVA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (118,'Lebanon','LB','LBN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (119,'Lesotho','LS','LSO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (120,'Liberia','LR','LBR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (121,'Libyan Arab Jamahiriya','LY','LBY',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (122,'Liechtenstein','LI','LIE',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (123,'Lithuania','LT','LTU',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (124,'Luxembourg','LU','LUX',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (125,'Macau','MO','MAC',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (126,'Macedonia, The Former Yugoslav Republic of','MK','MKD',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (127,'Madagascar','MG','MDG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (128,'Malawi','MW','MWI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (129,'Malaysia','MY','MYS',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (130,'Maldives','MV','MDV',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (131,'Mali','ML','MLI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (132,'Malta','MT','MLT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (133,'Marshall Islands','MH','MHL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (134,'Martinique','MQ','MTQ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (135,'Mauritania','MR','MRT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (136,'Mauritius','MU','MUS',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (137,'Mayotte','YT','MYT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (138,'Mexico','MX','MEX',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (139,'Micronesia, Federated States of','FM','FSM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (140,'Moldova, Republic of','MD','MDA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (141,'Monaco','MC','MCO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (142,'Mongolia','MN','MNG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (143,'Montserrat','MS','MSR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (144,'Morocco','MA','MAR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (145,'Mozambique','MZ','MOZ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (146,'Myanmar','MM','MMR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (147,'Namibia','NA','NAM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (148,'Nauru','NR','NRU',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (149,'Nepal','NP','NPL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (150,'Netherlands','NL','NLD',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (151,'Netherlands Antilles','AN','ANT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (152,'New Caledonia','NC','NCL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (153,'New Zealand','NZ','NZL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (154,'Nicaragua','NI','NIC',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (155,'Niger','NE','NER',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (156,'Nigeria','NG','NGA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (157,'Niue','NU','NIU',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (158,'Norfolk Island','NF','NFK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (159,'Northern Mariana Islands','MP','MNP',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (160,'Norway','NO','NOR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (161,'Oman','OM','OMN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (162,'Pakistan','PK','PAK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (163,'Palau','PW','PLW',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (164,'Panama','PA','PAN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (165,'Papua New Guinea','PG','PNG',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (166,'Paraguay','PY','PRY',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (167,'Peru','PE','PER',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (168,'Philippines','PH','PHL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (169,'Pitcairn','PN','PCN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (170,'Poland','PL','POL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (171,'Portugal','PT','PRT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (172,'Puerto Rico','PR','PRI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (173,'Qatar','QA','QAT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (174,'Reunion','RE','REU',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (175,'Romania','RO','ROM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (176,'Russian Federation','RU','RUS',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (177,'Rwanda','RW','RWA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (178,'Saint Kitts and Nevis','KN','KNA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (179,'Saint Lucia','LC','LCA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (180,'Saint Vincent and the Grenadines','VC','VCT',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (181,'Samoa','WS','WSM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (182,'San Marino','SM','SMR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (183,'Sao Tome and Principe','ST','STP',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (184,'Saudi Arabia','SA','SAU',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (185,'Senegal','SN','SEN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (186,'Seychelles','SC','SYC',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (187,'Sierra Leone','SL','SLE',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (188,'Singapore','SG','SGP',4,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (189,'Slovakia (Slovak Republic)','SK','SVK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (190,'Slovenia','SI','SVN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (191,'Solomon Islands','SB','SLB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (192,'Somalia','SO','SOM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (193,'South Africa','ZA','ZAF',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (194,'South Georgia and the South Sandwich Islands','GS','SGS',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (195,'Spain','ES','ESP',3,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (196,'Sri Lanka','LK','LKA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (197,'St. Helena','SH','SHN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (198,'St. Pierre and Miquelon','PM','SPM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (199,'Sudan','SD','SDN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (200,'Suriname','SR','SUR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (201,'Svalbard and Jan Mayen Islands','SJ','SJM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (202,'Swaziland','SZ','SWZ',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (203,'Sweden','SE','SWE',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (204,'Switzerland','CH','CHE',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (205,'Syrian Arab Republic','SY','SYR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (206,'Taiwan','TW','TWN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (207,'Tajikistan','TJ','TJK',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (208,'Tanzania, United Republic of','TZ','TZA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (209,'Thailand','TH','THA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (210,'Togo','TG','TGO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (211,'Tokelau','TK','TKL',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (212,'Tonga','TO','TON',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (213,'Trinidad and Tobago','TT','TTO',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (214,'Tunisia','TN','TUN',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (215,'Turkey','TR','TUR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (216,'Turkmenistan','TM','TKM',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (217,'Turks and Caicos Islands','TC','TCA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (218,'Tuvalu','TV','TUV',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (219,'Uganda','UG','UGA',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (220,'Ukraine','UA','UKR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (221,'United Arab Emirates','AE','ARE',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (222,'United Kingdom','GB','GBR',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (223,'United States','US','USA',2,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (224,'United States Minor Outlying Islands','UM','UMI',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (225,'Uruguay','UY','URY',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (238,'Zambia','ZM','ZMB',1,'Y');
Insert into OLS_COUNTRY (ID,COUNTRY_NAME,ISO_CODE_1,ISO_CODE_2,ADDRESS_FORMAT_ID,ALLOW) values (239,'Zimbabwe','ZW','ZWE',1,'Y');

---------------------------------------------------
--   END DATA FOR TABLE OLS_COUNTRY
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CURRENCY
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CURRENCY
Insert into OLS_CURRENCY (ID,TITLE,CODE,SYMBOL_LEFT,SYMBOL_RIGHT,DECIMAL_POINT,THOUSANDS_POINT,DECIMAL_PLACES,VALUE,LAST_UPDATED) values (1,'US Dollar','USD','$',null,'.',null,'2',1.297,to_timestamp('27-NOV-08 10.08.23.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CURRENCY (ID,TITLE,CODE,SYMBOL_LEFT,SYMBOL_RIGHT,DECIMAL_POINT,THOUSANDS_POINT,DECIMAL_PLACES,VALUE,LAST_UPDATED) values (2,'Euro','EUR',null,'€','.',',','2',1,to_timestamp('27-NOV-08 05.26.31.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CURRENCY (ID,TITLE,CODE,SYMBOL_LEFT,SYMBOL_RIGHT,DECIMAL_POINT,THOUSANDS_POINT,DECIMAL_PLACES,VALUE,LAST_UPDATED) values (5,'GB pound','GBP',null,'£',null,null,'2',0.8438,to_timestamp('27-NOV-08 10.08.23.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));

---------------------------------------------------
--   END DATA FOR TABLE OLS_CURRENCY
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_FAVORITES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_FAVORITES

---------------------------------------------------
--   END DATA FOR TABLE OLS_FAVORITES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_ADD_IMAGES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_ADD_IMAGES

---------------------------------------------------
--   END DATA FOR TABLE OLS_ADD_IMAGES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PRODUCT_OPTIONS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PRODUCT_OPTIONS

---------------------------------------------------
--   END DATA FOR TABLE OLS_PRODUCT_OPTIONS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_ESTIMATED_DELIVERY_TIME
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_ESTIMATED_DELIVERY_TIME
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (1,'1 business day',1,1);
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (2,'1-2 business days',1,2);
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (3,'1-5 business days',1,5);
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (4,'2-3 business days',2,3);
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (5,'2-7 business days',2,7);
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (7,'1-2 weeks',7,14);
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (10,'2-3 weeks',14,21);
Insert into OLS_ESTIMATED_DELIVERY_TIME (ID,DESCRIPTION,MIN_DAYS,MAX_DAYS) values (9,'3-5 business days',3,5);

---------------------------------------------------
--   END DATA FOR TABLE OLS_ESTIMATED_DELIVERY_TIME
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PAYMENT_CC_TYPE
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PAYMENT_CC_TYPE
Insert into OLS_PAYMENT_CC_TYPE (ID,DESCRIPTION,AVAILABLE,PRIORITY,PAYPAL) values (1,'Visa','Y',1,'Y');
Insert into OLS_PAYMENT_CC_TYPE (ID,DESCRIPTION,AVAILABLE,PRIORITY,PAYPAL) values (2,'MasterCard','Y',2,'Y');
Insert into OLS_PAYMENT_CC_TYPE (ID,DESCRIPTION,AVAILABLE,PRIORITY,PAYPAL) values (3,'Amex','Y',3,'Y');
Insert into OLS_PAYMENT_CC_TYPE (ID,DESCRIPTION,AVAILABLE,PRIORITY,PAYPAL) values (4,'Discover','Y',4,'Y');
Insert into OLS_PAYMENT_CC_TYPE (ID,DESCRIPTION,AVAILABLE,PRIORITY,PAYPAL) values (5,'DinersClub','Y',5,'Y');
Insert into OLS_PAYMENT_CC_TYPE (ID,DESCRIPTION,AVAILABLE,PRIORITY,PAYPAL) values (6,'JCB','Y',6,'N');


---------------------------------------------------
--   END DATA FOR TABLE OLS_PAYMENT_CC_TYPE
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PAYMENT_MODE_EX
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PAYMENT_MODE_EX
Insert into OLS_PAYMENT_MODE_EX (ID,DESCRIPTION,VENDOR_ID,PASSWORD,SIGNATURE,AVAILABLE,SANDBOX,PRODUCTION,TESTMODE,CHECKOUT_URL_P,KEY,CHECKOUT_URL_T,BUTTON_URL) values (8,'Paypal Express Checkout','YourVendorId','YourPassword','YourSignature','N','https://api-3t.sandbox.paypal.com/nvp','https://api-3t.paypal.com/nvp','Y','https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=','PEC','https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=',null);
Insert into OLS_PAYMENT_MODE_EX (ID,DESCRIPTION,VENDOR_ID,PASSWORD,SIGNATURE,AVAILABLE,SANDBOX,PRODUCTION,TESTMODE,CHECKOUT_URL_P,KEY,CHECKOUT_URL_T,BUTTON_URL) values (9,'Paypal Standard Payment','YourVendorId',null,null,'Y','https://www.sandbox.paypal.com/cgi-bin/webscr','https://www.paypal.com/cgi-bin/webscr','Y',null,'PSP',null,'https://www.paypal.com/en_US/i/btn/btn_buynow_LG.gif');
Insert into OLS_PAYMENT_MODE_EX (ID,DESCRIPTION,VENDOR_ID,PASSWORD,SIGNATURE,AVAILABLE,SANDBOX,PRODUCTION,TESTMODE,CHECKOUT_URL_P,KEY,CHECKOUT_URL_T,BUTTON_URL) values (7,'Paypal Direct Payment','YourVendorId','YourPassword','YourSignature','N','https://api-3t.sandbox.paypal.com/nvp','https://api-3t.paypal.com/nvp','Y','https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=','PDP','https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=',null);
Insert into OLS_PAYMENT_MODE_EX (ID,DESCRIPTION,VENDOR_ID,PASSWORD,SIGNATURE,AVAILABLE,SANDBOX,PRODUCTION,TESTMODE,CHECKOUT_URL_P,KEY,CHECKOUT_URL_T,BUTTON_URL) values (10,'Credit Card Payment','YourAthorizeNetApiLogin',null,'YourAthorizeNetTransactionKey','Y','https://test.authorize.net/gateway/transact.dll','https://secure.authorize.net/gateway/transact.dll','Y',null,'AUT',null,null);


---------------------------------------------------
--   END DATA FOR TABLE OLS_PAYMENT_MODE_EX
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_ADDRESS_FORMAT
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_ADDRESS_FORMAT
Insert into OLS_ADDRESS_FORMAT (ID,ADDRESS_FORMAT) values (1,'$firstname $lastname$cr$streets$cr$city, $postcode$cr$state $country');
Insert into OLS_ADDRESS_FORMAT (ID,ADDRESS_FORMAT) values (2,'$firstname $lastname$cr$streets$cr$city, $state    $postcode$cr$country');
Insert into OLS_ADDRESS_FORMAT (ID,ADDRESS_FORMAT) values (3,'$firstname $lastname$cr$streets$cr$city$cr$postcode - $state $country');
Insert into OLS_ADDRESS_FORMAT (ID,ADDRESS_FORMAT) values (4,'$firstname $lastname$cr$streets$cr$city ($postcode)$cr$country');
Insert into OLS_ADDRESS_FORMAT (ID,ADDRESS_FORMAT) values (5,'$firstname $lastname$cr$streets$cr$postcode $city$cr$country');

---------------------------------------------------
--   END DATA FOR TABLE OLS_ADDRESS_FORMAT
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CATEGORY
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CATEGORY

---------------------------------------------------
--   END DATA FOR TABLE OLS_CATEGORY
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PAYMENT_MODE_IN
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PAYMENT_MODE_IN
Insert into OLS_PAYMENT_MODE_IN (ID,DESCRIPTION,AVAILABLE,PRIORITY,KEY) values (1,'Credit Card','Y',1,'CC');
Insert into OLS_PAYMENT_MODE_IN (ID,DESCRIPTION,AVAILABLE,PRIORITY,KEY) values (2,'Check','Y',2,'CHECK');
Insert into OLS_PAYMENT_MODE_IN (ID,DESCRIPTION,AVAILABLE,PRIORITY,KEY) values (3,'Demand Draft','Y',3,'DD');
Insert into OLS_PAYMENT_MODE_IN (ID,DESCRIPTION,AVAILABLE,PRIORITY,KEY) values (4,'Cash On Delivery','Y',4,'COD');

---------------------------------------------------
--   END DATA FOR TABLE OLS_PAYMENT_MODE_IN
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CUST_BILLING_DETAILS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CUST_BILLING_DETAILS

---------------------------------------------------
--   END DATA FOR TABLE OLS_CUST_BILLING_DETAILS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PAYPAL_SESSION_MAP
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PAYPAL_SESSION_MAP

---------------------------------------------------
--   END DATA FOR TABLE OLS_PAYPAL_SESSION_MAP
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_ORDER_STATUS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_ORDER_STATUS
Insert into OLS_ORDER_STATUS (STATUS,ID,ALLOWED_ORDER) values ('Declined',1,4);
Insert into OLS_ORDER_STATUS (STATUS,ID,ALLOWED_ORDER) values ('Invoiced',2,2);
Insert into OLS_ORDER_STATUS (STATUS,ID,ALLOWED_ORDER) values ('Pending',3,1);
Insert into OLS_ORDER_STATUS (STATUS,ID,ALLOWED_ORDER) values ('Ordered',4,0);
Insert into OLS_ORDER_STATUS (STATUS,ID,ALLOWED_ORDER) values ('Cancelled',5,4);
Insert into OLS_ORDER_STATUS (STATUS,ID,ALLOWED_ORDER) values ('Delivered',6,3);

---------------------------------------------------
--   END DATA FOR TABLE OLS_ORDER_STATUS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PAYPAL_TRANSACTIONS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PAYPAL_TRANSACTIONS

---------------------------------------------------
--   END DATA FOR TABLE OLS_PAYPAL_TRANSACTIONS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_FILES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_FILES

---------------------------------------------------
--   END DATA FOR TABLE OLS_FILES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_IMAGES
--   FILTER = none used
---------------------------------------------------

---------------------------------------------------
--   END DATA FOR TABLE OLS_IMAGES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_MESSAGES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_MESSAGES

---------------------------------------------------
--   END DATA FOR TABLE OLS_MESSAGES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_SALES_ORDER
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_SALES_ORDER

---------------------------------------------------
--   END DATA FOR TABLE OLS_SALES_ORDER
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_NEWSLETTER
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_NEWSLETTER

---------------------------------------------------
--   END DATA FOR TABLE OLS_NEWSLETTER
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CUST_SHIPPING_DETAILS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CUST_SHIPPING_DETAILS

---------------------------------------------------
--   END DATA FOR TABLE OLS_CUST_SHIPPING_DETAILS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_COUNTER_HISTORY
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_COUNTER_HISTORY
Insert into OLS_COUNTER_HISTORY (MONTH,COUNTER) values (to_timestamp('01-DEC-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),2);
Insert into OLS_COUNTER_HISTORY (MONTH,COUNTER) values (to_timestamp('01-NOV-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),6);

---------------------------------------------------
--   END DATA FOR TABLE OLS_COUNTER_HISTORY
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_ERRORS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_ERRORS

---------------------------------------------------
--   END DATA FOR TABLE OLS_ERRORS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PRODUCT_TO_PR_OPTIONS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PRODUCT_TO_PR_OPTIONS

---------------------------------------------------
--   END DATA FOR TABLE OLS_PRODUCT_TO_PR_OPTIONS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_DISPLAY_VALUES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_DISPLAY_VALUES
Insert into OLS_DISPLAY_VALUES (VALUE) values (5000);
Insert into OLS_DISPLAY_VALUES (VALUE) values (1000);
Insert into OLS_DISPLAY_VALUES (VALUE) values (500);
Insert into OLS_DISPLAY_VALUES (VALUE) values (100);
Insert into OLS_DISPLAY_VALUES (VALUE) values (50);
Insert into OLS_DISPLAY_VALUES (VALUE) values (15);
Insert into OLS_DISPLAY_VALUES (VALUE) values (10);
Insert into OLS_DISPLAY_VALUES (VALUE) values (5);

---------------------------------------------------
--   END DATA FOR TABLE OLS_DISPLAY_VALUES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_STATES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_STATES
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (2,223,'AK','ALASKA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (3,223,'AL','ALABAMA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (4,223,'AR','ARKANSAS');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (5,223,'AZ','ARIZONA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (6,223,'CA','CALIFORNIA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (7,223,'CO','COLORADO');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (8,223,'CT','CONNECTICUT');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (9,223,'DC','DISTRICT OF COLUMBIA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (10,223,'DE','DELAWARE');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (11,223,'FL','FLORIDA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (12,223,'GA','GEORGIA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (13,223,'HI','HAWAII');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (14,223,'IA','IOWA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (15,223,'ID','IDAHO');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (16,223,'IL','ILLINOIS');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (17,223,'IN','INDIANA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (18,223,'KS','KANSAS');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (19,223,'KY','KENTUCKY');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (20,223,'LA','LOUISIANA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (21,223,'MA','MASSACHUSETTS');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (22,223,'MD','MARYLAND');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (23,223,'ME','MAINE');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (24,223,'MI','MICHIGAN');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (25,223,'MN','MINNESOTA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (26,223,'MO','MISSOURI');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (27,223,'MS','MISSISSIPPI');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (28,223,'MT','MONTANA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (29,223,'NC','NORTH CAROLINA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (30,223,'ND','NORTH DAKOTA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (31,223,'NE','NEBRASKA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (32,223,'NH','NEW HAMPSHIRE');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (33,223,'NJ','NEW JERSEY');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (34,223,'NM','NEW MEXICO');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (35,223,'NV','NEVADA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (36,223,'NY','NEW YORK');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (37,223,'OH','OHIO');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (38,223,'OK','OKLAHOMA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (39,223,'OR','OREGON');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (40,223,'PA','PENNSYLVANIA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (41,223,'RI','RHODE ISLAND');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (42,223,'SC','SOUTH CAROLINA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (43,223,'SD','SOUTH DAKOTA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (44,223,'TN','TENNESSEE');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (45,223,'TX','TEXAS');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (46,223,'UT','UTAH');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (47,223,'VA','VIRGINIA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (48,223,'VT','VERMONT');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (49,223,'WA','WASHINGTON');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (50,223,'WI','WISCONSIN');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (51,223,'WV','WEST VIRGINIA');
Insert into OLS_STATES (ID,COUNTRY_ID,ST,STATE_NAME) values (52,223,'WY','WYOMING');

---------------------------------------------------
--   END DATA FOR TABLE OLS_STATES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CUSTOMER_DETAILS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CUSTOMER_DETAILS
Insert into OLS_CUSTOMER_DETAILS (ID,FIRST_NAME,LAST_NAME,ADDRESS1,ADDRESS2,ADDRESS3,CITY,STATE,PIN,COUNTRY,EMAIL,CONTACT_NUMBER,LOGIN_ID,PASSWORD,ADMIN) values (0,'Administrator','Webshop','TBD',null,null,null,null,null,null,'webshopadmin',null,'WEBSHOPADMIN','CE88D33194DAA1C694357E61ABEC7B79','Yes');

---------------------------------------------------
--   END DATA FOR TABLE OLS_CUSTOMER_DETAILS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_LANGUAGE
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_LANGUAGE
Insert into OLS_LANGUAGE (ID,NAME,CODE,SORT_ORDER,ACTIVE) values (1,'English','en',1,'Y');
Insert into OLS_LANGUAGE (ID,NAME,CODE,SORT_ORDER,ACTIVE) values (2,'Deutsch','de',2,'N');
Insert into OLS_LANGUAGE (ID,NAME,CODE,SORT_ORDER,ACTIVE) values (3,'Español','es',3,'N');
Insert into OLS_LANGUAGE (ID,NAME,CODE,SORT_ORDER,ACTIVE) values (4,'Suomi','fi',5,'N');
Insert into OLS_LANGUAGE (ID,NAME,CODE,SORT_ORDER,ACTIVE) values (6,'Français','fr',4,'N');
Insert into OLS_LANGUAGE (ID,NAME,CODE,SORT_ORDER,ACTIVE) values (7,'Русский','ru',6,'N');

---------------------------------------------------
--   END DATA FOR TABLE OLS_LANGUAGE
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_LANGUAGE_CODES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_LANGUAGE_CODES
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('af','Afrikaans');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ar','Arabic');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('as','Assamese');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('be','Belarusian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('bg','Bulgarian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('bn','Bengali');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ca','Catalan');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('cs','Czech');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('da','Danish');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('de','German (Germany)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('el','Greek');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('en','English');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('es','Spanish (Traditional Sort)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('et','Estonian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('eu','Basque');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('fa','Farsi');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('fi','Finnish');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('fo','Faeroese');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('fr','French (France)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('gd','Gaelic');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('gl','Galician');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('gu','Gujarati');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('he','Hebrew');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('hi','Hindi');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('hr','Croatian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('hu','Hungarian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('id','Indonesian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('is','Icelandic');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('it','Italian (Italy)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ja','Japanese');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('kk','Kazakh');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('kn','Kannada');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ko','Korean');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('kz','Kyrgyz');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('lt','Lithuanian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('lv','Latvian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('mk','FYRO Macedonian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ml','Malayalam');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('mr','Marathi');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ms','Malay (Malaysia)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('mt','Maltese');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ne','Nepali (India)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('nl','Dutch (Netherlands)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('no','Norwegian (Bokmal)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('or','Oriya');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('pa','Punjabi');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('pl','Polish');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('pt','Portuguese (Portugal)');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ro','Romanian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ru','Russian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('sk','Slovak');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('sl','Slovenian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('sr','Serbian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('sv','Swedish');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ta','Tamil');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('te','Telugu');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('th','Thai');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('tr','Turkish');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('uk','Ukrainian');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('ur','Urdu');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('uz','Uzbek');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('vi','Vietnamese');
Insert into OLS_LANGUAGE_CODES (CODE,LANG_NAME) values ('zh','Chinese');

---------------------------------------------------
--   END DATA FOR TABLE OLS_LANGUAGE_CODES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_LOGS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_LOGS
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8966,'p=105:1:1928188631462639','http://localhost:8080/apex/f?p=105:75:220040491451520:',to_timestamp('30-NOV-08 12.30.59.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8969,'p=105:1:3189571950845069:::::','http://localhost:8080/apex/f?p=4000:57:3189571950845069:FLOW:NO:::&success_msg=Application 105 installed./9AD3C3A57A89981C9E618ABEE97A1BC1/',to_timestamp('01-DEC-08 08.57.08.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8963,'p=105:1:1138815289698686:::::','http://localhost:8080/apex/f?p=4000:57:1138815289698686:FLOW:NO:::&success_msg=Application 105 installed./3CC08406C6A6A200AC6D6A86704E6F97/',to_timestamp('29-NOV-08 10.55.20.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8964,'p=105::2529829588608063','http://localhost:8080/apex/f?p=105:77:2529829588608063::NO:::&success_msg=Password successfully modified./CE0A27A84FB3613CC6622CFE7286C668/',to_timestamp('30-NOV-08 12.12.41.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8965,'p=105:1:220040491451520','http://localhost:8080/apex/f?p=105:31:2529829588608063::NO:28::',to_timestamp('30-NOV-08 12.29.23.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8967,'p=105:1:2594891636939766',null,to_timestamp('30-NOV-08 07.44.56.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8968,'p=105:1:1528880614686207:::::',null,to_timestamp('30-NOV-08 07.48.11.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_LOGS (ID,QUERY_STRING,HTTP_REFERER,CREATED_DATE) values (8970,'p=105:75:1362858300672544','http://localhost:8080/apex/f?p=105:101:3189571950845069::NO:101::',to_timestamp('01-DEC-08 08.57.47.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));

---------------------------------------------------
--   END DATA FOR TABLE OLS_LOGS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CATEGORY_TRANS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CATEGORY_TRANS

---------------------------------------------------
--   END DATA FOR TABLE OLS_CATEGORY_TRANS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_LINE_ITEMS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_LINE_ITEMS

---------------------------------------------------
--   END DATA FOR TABLE OLS_LINE_ITEMS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_SHIPPING_PRICE_TYPES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_SHIPPING_PRICE_TYPES
Insert into OLS_SHIPPING_PRICE_TYPES (ID,NAME) values (1,'AMOUNT');
Insert into OLS_SHIPPING_PRICE_TYPES (ID,NAME) values (2,'QUANTITY');
Insert into OLS_SHIPPING_PRICE_TYPES (ID,NAME) values (3,'WEIGHT');

---------------------------------------------------
--   END DATA FOR TABLE OLS_SHIPPING_PRICE_TYPES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_SPECIAL_CHARACTERS
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_SPECIAL_CHARACTERS
Insert into OLS_SPECIAL_CHARACTERS (CHARACTER) values ('.');
Insert into OLS_SPECIAL_CHARACTERS (CHARACTER) values (',');

---------------------------------------------------
--   END DATA FOR TABLE OLS_SPECIAL_CHARACTERS
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_COUNTER
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_COUNTER


---------------------------------------------------
--   END DATA FOR TABLE OLS_COUNTER
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_ZONES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_ZONES
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (196,14,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (182,222,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (183,81,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (184,73,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (185,105,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (186,21,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (187,150,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (188,195,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (189,203,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (190,72,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (191,57,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (192,84,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (193,171,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (194,103,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (195,124,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (1,223,'AL','Alabama',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (2,223,'AK','Alaska',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (3,223,'AS','American Samoa',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (4,223,'AZ','Arizona',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (5,223,'AR','Arkansas',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (6,223,'AF','Armed Forces Africa',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (7,223,'AA','Armed Forces Americas',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (8,223,'AC','Armed Forces Canada',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (9,223,'AE','Armed Forces Europe',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (10,223,'AM','Armed Forces Middle East',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (11,223,'AP','Armed Forces Pacific',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (12,223,'CA','California',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (13,223,'CO','Colorado',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (14,223,'CT','Connecticut',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (15,223,'DE','Delaware',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (16,223,'DC','District of Columbia',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (17,223,'FM','Federated States Of Micronesia',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (18,223,'FL','Florida',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (19,223,'GA','Georgia',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (20,223,'GU','Guam',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (21,223,'HI','Hawaii',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (22,223,'ID','Idaho',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (23,223,'IL','Illinois',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (24,223,'IN','Indiana',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (25,223,'IA','Iowa',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (26,223,'KS','Kansas',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (27,223,'KY','Kentucky',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (28,223,'LA','Louisiana',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (29,223,'ME','Maine',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (30,223,'MH','Marshall Islands',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (31,223,'MD','Maryland',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (32,223,'MA','Massachusetts',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (33,223,'MI','Michigan',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (34,223,'MN','Minnesota',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (35,223,'MS','Mississippi',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (36,223,'MO','Missouri',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (37,223,'MT','Montana',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (38,223,'NE','Nebraska',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (39,223,'NV','Nevada',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (40,223,'NH','New Hampshire',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (41,223,'NJ','New Jersey',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (42,223,'NM','New Mexico',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (43,223,'NY','New York',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (44,223,'NC','North Carolina',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (45,223,'ND','North Dakota',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (46,223,'MP','Northern Mariana Islands',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (47,223,'OH','Ohio',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (48,223,'OK','Oklahoma',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (49,223,'OR','Oregon',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (50,223,'PW','Palau',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (51,223,'PA','Pennsylvania',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (52,223,'PR','Puerto Rico',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (53,223,'RI','Rhode Island',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (54,223,'SC','South Carolina',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (55,223,'SD','South Dakota',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (56,223,'TN','Tennessee',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (57,223,'TX','Texas',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (58,223,'UT','Utah',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (59,223,'VT','Vermont',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (60,223,'VI','Virgin Islands',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (61,223,'VA','Virginia',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (62,223,'WA','Washington',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (63,223,'WV','West Virginia',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (64,223,'WI','Wisconsin',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (65,223,'WY','Wyoming',1,1);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (66,38,'AB','Alberta',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (67,38,'BC','British Columbia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (68,38,'MB','Manitoba',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (69,38,'NF','Newfoundland',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (70,38,'NB','New Brunswick',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (71,38,'NS','Nova Scotia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (72,38,'NT','Northwest Territories',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (73,38,'NU','Nunavut',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (74,38,'ON','Ontario',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (75,38,'PE','Prince Edward Island',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (76,38,'QC','Quebec',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (77,38,'SK','Saskatchewan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (78,38,'YT','Yukon Territory',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (79,81,'NDS','Niedersachsen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (80,81,'BAW','Baden-Württemberg',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (81,81,'BAY','Bayern',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (82,81,'BER','Berlin',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (83,81,'BRG','Brandenburg',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (84,81,'BRE','Bremen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (85,81,'HAM','Hamburg',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (86,81,'HES','Hessen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (87,81,'MEC','Mecklenburg-Vorpommern',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (88,81,'NRW','Nordrhein-Westfalen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (89,81,'RHE','Rheinland-Pfalz',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (90,81,'SAR','Saarland',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (91,81,'SAS','Sachsen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (92,81,'SAC','Sachsen-Anhalt',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (93,81,'SCN','Schleswig-Holstein',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (94,81,'THE','Thüringen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (95,14,'WI','Wien',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (96,14,'NO','Niederösterreich',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (97,14,'OO','Oberösterreich',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (98,14,'SB','Salzburg',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (99,14,'KN','Kärnten',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (100,14,'ST','Steiermark',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (101,14,'TI','Tirol',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (102,14,'BL','Burgenland',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (103,14,'VB','Voralberg',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (104,204,'AG','Aargau',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (105,204,'AI','Appenzell Innerrhoden',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (106,204,'AR','Appenzell Ausserrhoden',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (107,204,'BE','Bern',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (108,204,'BL','Basel-Landschaft',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (109,204,'BS','Basel-Stadt',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (110,204,'FR','Freiburg',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (111,204,'GE','Genf',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (112,204,'GL','Glarus',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (113,204,'JU','Graubünden',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (114,204,'JU','Jura',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (115,204,'LU','Luzern',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (116,204,'NE','Neuenburg',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (117,204,'NW','Nidwalden',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (118,204,'OW','Obwalden',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (119,204,'SG','St. Gallen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (120,204,'SH','Schaffhausen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (121,204,'SO','Solothurn',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (122,204,'SZ','Schwyz',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (123,204,'TG','Thurgau',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (124,204,'TI','Tessin',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (125,204,'UR','Uri',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (126,204,'VD','Waadt',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (127,204,'VS','Wallis',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (128,204,'ZG','Zug',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (129,204,'ZH','Zürich',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (130,195,'A Coruña','A Coruña',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (131,195,'Alava','Alava',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (132,195,'Albacete','Albacete',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (133,195,'Alicante','Alicante',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (134,195,'Almeria','Almeria',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (135,195,'Asturias','Asturias',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (136,195,'Avila','Avila',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (137,195,'Badajoz','Badajoz',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (138,195,'Baleares','Baleares',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (139,195,'Barcelona','Barcelona',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (140,195,'Burgos','Burgos',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (141,195,'Caceres','Caceres',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (142,195,'Cadiz','Cadiz',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (143,195,'Cantabria','Cantabria',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (144,195,'Castellon','Castellon',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (145,195,'Ceuta','Ceuta',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (146,195,'Ciudad Real','Ciudad Real',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (147,195,'Cordoba','Cordoba',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (148,195,'Cuenca','Cuenca',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (149,195,'Girona','Girona',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (150,195,'Granada','Granada',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (151,195,'Guadalajara','Guadalajara',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (152,195,'Guipuzcoa','Guipuzcoa',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (153,195,'Huelva','Huelva',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (154,195,'Huesca','Huesca',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (155,195,'Jaen','Jaen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (156,195,'La Rioja','La Rioja',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (157,195,'Las Palmas','Las Palmas',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (158,195,'Leon','Leon',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (159,195,'Lleida','Lleida',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (160,195,'Lugo','Lugo',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (161,195,'Madrid','Madrid',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (162,195,'Malaga','Malaga',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (163,195,'Melilla','Melilla',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (164,195,'Murcia','Murcia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (165,195,'Navarra','Navarra',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (166,195,'Ourense','Ourense',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (167,195,'Palencia','Palencia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (168,195,'Pontevedra','Pontevedra',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (169,195,'Salamanca','Salamanca',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (170,195,'Santa Cruz de Tenerife','Santa Cruz de Tenerife',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (171,195,'Segovia','Segovia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (172,195,'Sevilla','Sevilla',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (173,195,'Soria','Soria',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (174,195,'Tarragona','Tarragona',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (175,195,'Teruel','Teruel',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (176,195,'Toledo','Toledo',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (177,195,'Valencia','Valencia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (178,195,'Valladolid','Valladolid',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (179,195,'Vizcaya','Vizcaya',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (180,195,'Zamora','Zamora',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (181,195,'Zaragoza','Zaragoza',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (527,226,'UZ','Uzbekistan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (528,227,'VU','Vanuatu',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (529,228,'VA','Vatican City State (Holy See)',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (530,229,'VE','Venezuela',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (531,230,'VN','Viet Nam',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (532,231,'VG','Virgin Islands (British)',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (533,232,'VI','Virgin Islands (U.S.)',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (534,233,'WF','Wallis and Futuna Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (535,234,'EH','Western Sahara',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (536,235,'YE','Yemen',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (537,236,'YU','Yugoslavia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (538,237,'ZR','Zaire',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (540,2,'AL','Albania',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (541,3,'DZ','Algeria',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (542,4,'AS','American Samoa',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (543,5,'AD','Andorra',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (544,6,'AO','Angola',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (545,7,'AI','Anguilla',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (546,8,'AQ','Antarctica',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (547,9,'AG','Antigua and Barbuda',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (548,10,'AR','Argentina',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (549,11,'AM','Armenia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (550,12,'AW','Aruba',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (551,13,'AU','Australia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (552,15,'AZ','Azerbaijan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (553,16,'BS','Bahamas',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (554,17,'BH','Bahrain',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (555,18,'BD','Bangladesh',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (556,19,'BB','Barbados',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (557,20,'BY','Belarus',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (558,22,'BZ','Belize',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (559,23,'BJ','Benin',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (560,24,'BM','Bermuda',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (561,25,'BT','Bhutan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (562,26,'BO','Bolivia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (563,28,'BW','Botswana',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (564,29,'BV','Bouvet Island',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (565,30,'BR','Brazil',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (566,32,'BN','Brunei Darussalam',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (567,33,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (568,34,'BF','Burkina Faso',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (569,35,'BI','Burundi',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (570,36,'KH','Cambodia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (571,37,'CM','Cameroon',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (572,39,'CV','Cape Verde',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (573,40,'KY','Cayman Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (574,41,'CF','Central African Republic',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (575,42,'TD','Chad',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (576,43,'CL','Chile',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (577,44,'CN','China',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (578,45,'CX','Christmas Island',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (579,46,'CC','Cocos (Keeling) Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (580,47,'CO','Colombia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (581,48,'KM','Comoros',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (582,49,'CG','Congo',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (583,50,'CK','Cook Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (584,51,'CR','Costa Rica',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (585,52,'CI','Cote D''Ivoire',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (586,53,'HR','Croatia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (587,54,'CU','Cuba',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (588,55,'CY','Cyprus',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (589,56,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (590,58,'DJ','Djibouti',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (591,59,'DM','Dominica',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (592,60,'DO','Dominican Republic',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (593,61,'TP','East Timor',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (594,62,'EC','Ecuador',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (595,63,'EG','Egypt',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (596,64,'SV','El Salvador',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (597,65,'GQ','Equatorial Guinea',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (598,66,'ER','Eritrea',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (599,67,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (600,68,'ET','Ethiopia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (601,69,'FK','Falkland Islands (Malvinas)',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (602,70,'FO','Faroe Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (603,71,'FJ','Fiji',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (604,74,'FX','France, Metropolitan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (605,75,'GF','French Guiana',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (606,76,'PF','French Polynesia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (607,77,'TF','French Southern Territories',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (608,78,'GA','Gabon',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (609,79,'GM','Gambia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (610,80,'GE','Georgia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (611,82,'GH','Ghana',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (612,83,'GI','Gibraltar',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (613,85,'GL','Greenland',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (614,86,'GD','Grenada',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (615,87,'GP','Guadeloupe',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (616,88,'GU','Guam',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (617,89,'GT','Guatemala',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (618,90,'GN','Guinea',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (619,91,'GW','Guinea-bissau',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (620,92,'GY','Guyana',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (621,93,'HT','Haiti',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (622,94,'HM','Heard and Mc Donald Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (623,95,'HN','Honduras',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (624,96,'HK','Hong Kong',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (625,97,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (626,98,'IS','Iceland',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (627,99,'IN','India',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (628,100,'ID','Indonesia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (629,101,'IR','Iran (Islamic Republic of)',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (630,102,'IQ','Iraq',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (631,104,'IL','Israel',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (632,106,'JM','Jamaica',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (633,107,'JP','Japan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (634,108,'JO','Jordan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (635,109,'KZ','Kazakhstan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (636,110,'KE','Kenya',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (637,111,'KI','Kiribati',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (638,112,'KP','Korea, Democratic People''s Repub',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (639,113,'KR','Korea, Republic of',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (640,114,'KW','Kuwait',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (641,115,'KG','Kyrgyzstan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (642,116,'LA','Lao People''s Democratic Republic',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (643,117,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (644,118,'LB','Lebanon',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (645,119,'LS','Lesotho',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (646,120,'LR','Liberia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (647,121,'LY','Libyan Arab Jamahiriya',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (648,122,'LI','Liechtenstein',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (649,123,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (650,125,'MO','Macau',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (651,126,'MK','Macedonia, The Former Yugoslav R',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (652,127,'MG','Madagascar',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (653,128,'MW','Malawi',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (654,129,'MY','Malaysia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (655,130,'MV','Maldives',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (656,131,'ML','Mali',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (657,132,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (658,133,'MH','Marshall Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (659,134,'MQ','Martinique',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (660,135,'MR','Mauritania',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (661,136,'MU','Mauritius',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (662,137,'YT','Mayotte',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (663,138,'MX','Mexico',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (664,139,'FM','Micronesia, Federated States of',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (665,140,'MD','Moldova, Republic of',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (666,141,'MC','Monaco',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (667,142,'MN','Mongolia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (668,143,'MS','Montserrat',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (669,144,'MA','Morocco',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (670,145,'MZ','Mozambique',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (671,146,'MM','Myanmar',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (672,147,'NA','Namibia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (673,148,'NR','Nauru',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (674,149,'NP','Nepal',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (675,151,'AN','Netherlands Antilles',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (676,152,'NC','New Caledonia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (677,153,'NZ','New Zealand',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (678,154,'NI','Nicaragua',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (679,155,'NE','Niger',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (680,156,'NG','Nigeria',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (681,157,'NU','Niue',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (682,158,'NF','Norfolk Island',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (683,159,'MP','Northern Mariana Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (684,160,'NO','Norway',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (685,161,'OM','Oman',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (686,162,'PK','Pakistan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (687,163,'PW','Palau',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (688,164,'PA','Panama',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (689,165,'PG','Papua New Guinea',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (690,166,'PY','Paraguay',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (691,167,'PE','Peru',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (692,168,'PH','Philippines',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (693,169,'PN','Pitcairn',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (694,170,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (695,172,'PR','Puerto Rico',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (696,173,'QA','Qatar',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (697,174,'RE','Reunion',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (698,175,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (699,176,'RU','Russian Federation',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (700,177,'RW','Rwanda',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (701,178,'KN','Saint Kitts and Nevis',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (702,179,'LC','Saint Lucia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (703,180,'VC','Saint Vincent and the Grenadines',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (704,181,'WS','Samoa',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (705,182,'SM','San Marino',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (706,183,'ST','Sao Tome and Principe',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (707,184,'SA','Saudi Arabia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (708,185,'SN','Senegal',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (709,186,'SC','Seychelles',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (710,187,'SL','Sierra Leone',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (711,188,'SG','Singapore',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (712,189,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (713,190,'EU','Europe',2,2);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (714,191,'SB','Solomon Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (715,192,'SO','Somalia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (716,193,'ZA','South Africa',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (717,194,'GS','South Georgia and the South Sand',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (718,196,'LK','Sri Lanka',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (719,197,'SH','St. Helena',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (720,198,'PM','St. Pierre and Miquelon',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (721,199,'SD','Sudan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (722,200,'SR','Suriname',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (723,201,'SJ','Svalbard and Jan Mayen Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (724,202,'SZ','Swaziland',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (725,205,'SY','Syrian Arab Republic',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (726,206,'TW','Taiwan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (727,207,'TJ','Tajikistan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (728,208,'TZ','Tanzania, United Republic of',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (729,209,'TH','Thailand',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (730,210,'TG','Togo',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (731,211,'TK','Tokelau',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (732,212,'TO','Tonga',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (733,213,'TT','Trinidad and Tobago',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (734,214,'TN','Tunisia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (735,215,'TR','Turkey',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (736,216,'TM','Turkmenistan',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (737,217,'TC','Turks and Caicos Islands',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (738,218,'TV','Tuvalu',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (739,219,'UG','Uganda',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (740,220,'UA','Ukraine',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (741,221,'AE','United Arab Emirates',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (742,224,'UM','United States Minor Outlying Isl',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (743,225,'UY','Uruguay',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (744,238,'ZM','Zambia',null,null);
Insert into OLS_ZONES (ID,COUNTRY_ID,CODE,NAME,GEO_ZONE_ID,TAX_GEO_ZONE_ID) values (745,239,'ZW','Zimbabwe',null,null);

---------------------------------------------------
--   END DATA FOR TABLE OLS_ZONES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_CONFIGURATION
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_CONFIGURATION
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (109,'Display Product Price','PRODUCT_PRICE','Y','Do you want to display the Product Price on Page 1. Values: Y or N.',8,1,to_timestamp('22-JUL-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (115,'Check stock level','STOCK_CHECK','Y','Check to see if sufficent stock is available. Values: Y or N.',9,1,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (116,'Subtract stock','STOCK_SUBSTRACT','Y','Subtract product in stock by product orders. Values: Y or N.',9,2,to_timestamp('22-JUL-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (117,'Allow Checkout','STOCK_ALLOW_CHECKOUT','N','Allow customer to checkout even if there is insufficient stock. Values: Y or N.',9,3,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (118,'Mark product out of stock','STOCK_MARK_PRODUCT_OUT_OF_STOCK','***','Display something on screen so customer can see which product has insufficient stock',9,4,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (119,'Stock Re-order level','STOCK_REORDER_LEVEL','5','Define when stock needs to be re-ordered. Email is sent to Administrator when the level is reached. The triggering of an email happens when Order is set to Delivered. It is enabled only if STOCK_SUBSTRACT is set to Y.',9,5,to_timestamp('22-JUL-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (147,'Display manufacturers','DISPLAY_MANUFACTURER','Y','If Y, then display Manufacturers on the first page. N - not display.',1,15,to_timestamp('28-JUL-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('28-JUL-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (148,'Use Subcategories','USE_SUBCATEGORIES','Y','If set Y, Home page shows the hierarchy of categories. If set N,   the hierarchy is disregarded. Please note that only categories that are linked to Available and Active products are shown.',1,17,to_timestamp('01-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('01-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (146,'Display The Activity Log Duration','DISPLAY_ACTIVITY_LOG_DURATION','7','Display activity log that is not older than the specified value (in days)',10,1,to_timestamp('20-JUN-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('20-JUN-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (150,'Display products horizontally','DISPLAY_PRODUCT_HOR','Y','Controls if home page products are displayed by default horizontally or vertically. Values Y or N. If entered Y, products are displayed horizontally, meaning several products per row. It is controlled by Product report Borderless report template. If entered N, the products are displayed one product per row.',1,18,to_timestamp('28-SEP-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('28-SEP-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (131,'Send E-Mails','SEND_EMAILS','Y','Send out e-mails to customers to notificate about orders been received and delivered.
It does not affect Internal emails sent to administrator email. Values Y or N.',12,1,to_timestamp('21-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (132,'Enable download','DOWNLOAD_ENABLED','Y','Enable the products download functions. Values: Y or N.',13,1,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (134,'Expiry delay (days)','DOWNLOAD_MAX_DAYS','7','Set number of days before the download link expires. 0 means no limit.',13,2,to_timestamp('10-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (135,'Maximum number of downloads','DOWNLOAD_MAX_COUNT','5','Set the maximum number of downloads. 0 means no limit.',13,3,to_timestamp('10-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (145,'Max random banners ','MAX_DISPLAY_RANDOM_BANNERS','3','Max number of random banners displayed in the footer randomly',3,10,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (149,'Calculate Pop-up size','CALCULATE_POPUP_SIZE','Y','Calculate Additional images Pop-Up window size based on size of images? Values: Y or N.',4,5,to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (1,'Store Name','STORE_NAME','Database Software Horizons','The name of the store. Used in the following cases: password sending email during ordering process and
email with reset password when user forgot the password.',1,1,to_timestamp('18-JUN-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (3,'E-Mail Address','STORE_OWNER_EMAIL_ADDRESS','info@dbswh.com','The e-mail address of the store owner. Emails are sent with From filed set to this email address.',1,3,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (5,'Country','STORE_COUNTRY','72','The country id my store is located in <br><br><b>Note: Please remember to update the store zone.</b>',1,4,to_timestamp('10-OCT-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (6,'Zone','STORE_ZONE','190','The zone my store is located in. This value is taken as an initial parameter to calculate
the product tax during product creation process.
Product selling price that is shown on Webshop front-page is calculated based
on product list price entered plus the tax calculated based on Store Country, Store Zone and
tax classification of the product.
When product is ordered its tax value is recalculated based on the country and zone of
shipping address.  ',1,5,to_timestamp('27-NOV-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (85,'Weight Unit','DEFAULT_WEIGHT_UNIT','kg','Default weight unit shown in reports and forms.',7,1,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (13,'Display Cart After Adding Product','DISPLAY_CART','Y','Display the shopping cart Navigation link and Region in the top part of the first page. Values Y or N.',1,6,to_timestamp('25-JUN-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (14,'Allow Guest To Tell A Friend','ALLOW_GUEST_TO_TELL_A_FRIEND','Y','Allow guests to tell a friend about a product. Values Y or N.',1,7,to_timestamp('25-SEP-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (15,'Display Advanced Search','DISPLAY_ADVANCED_SEARCH','Y','Display Advanced Search in Home page 1. Values Y or N.',1,8,to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (16,'Store Address and Phone','STORE_NAME_ADDRESS','Database Software Horizons<br>Kyllästämöntie 141<br>04240, Talma<br>Finland<br>+358405029209','This is the Store Name, Address and Phone used on printable documents and displayed online',1,9,to_timestamp('05-NOV-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (17,'Show Category Counts','SHOW_COUNTS','Y','Count how many products are in each category. The value is shown in Category region on Webshop front-page 1.  Values Y or N.',1,10,to_timestamp('22-JUN-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (20,'First Name','ENTRY_FIRST_NAME_MIN_LENGTH','4','Minimum length of first name',2,1,to_timestamp('01-SEP-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (21,'Last Name','ENTRY_LAST_NAME_MIN_LENGTH','2','Minimum length of last name',2,2,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (23,'E-Mail Address','ENTRY_EMAIL_ADDRESS_MIN_LENGTH','6','Minimum length of e-mail address',2,3,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (24,'Street Address','ENTRY_STREET_MIN_LENGTH','5','Minimum length of street address',2,4,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (26,'Post Code','ENTRY_POSTCODE_MIN_LENGTH','4','Minimum length of post code',2,5,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (27,'City','ENTRY_CITY_MIN_LENGTH','3','Minimum length of city',2,6,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (28,'State','ENTRY_STATE_MIN_LENGTH','2','Minimum length of state. Not used currently.',2,7,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (29,'Telephone Number','ENTRY_TELEPHONE_MIN_LENGTH','3','Minimum length of telephone number',2,8,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (33,'Review Text','REVIEW_TEXT_MIN_LENGTH','50','Minimum length of review text',2,9,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (35,'Also Purchased','MIN_DISPLAY_ALSO_PURCHASED','1','Minimum number of products to display in the ''This Customer Also Purchased'' box',2,10,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (37,'Search Results','MAX_DISPLAY_SEARCH_RESULTS','20','Amount of products to list',3,1,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (39,'Promotional Products','MAX_DISPLAY_PROMO_PRODUCTS','9','Maximum number of products on promotion to display',3,2,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (40,'Latest Products Module','MAX_DISPLAY_LATEST_PRODUCTS','9','Maximum number of latest products to display',3,3,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (44,'Length of Manufacturers Name','MAX_DISPLAY_MANUFACTURER_NAME_LEN','15','Used in manufacturers box; maximum length of manufacturers name to display',3,4,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (45,'New Reviews','MAX_DISPLAY_NEW_REVIEWS','6','Maximum number of new reviews to display',3,5,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (50,'Hot Products Listing','MAX_DISPLAY_PRODUCTS_HOT','10','Maximum number of hot products to display',3,6,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (51,'Top Sellers','MAX_DISPLAY_TOPSELLERS','10','Maximum number of top sellers to display',3,7,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (52,'Also Purchased','MAX_DISPLAY_ALSO_PURCHASED','6','Maximum number of products to display in the ''This Customer Also Purchased'' box',3,8,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (54,'Order History','MAX_DISPLAY_ORDER_HISTORY','10','Maximum number of orders to display in the order history page',3,9,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (55,'Image Width','IMAGE_WIDTH','100','The pixel width of images in windows except reports',4,1,to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (56,'Image Height','IMAGE_HEIGHT','80','The pixel height of images in windows except reports',4,2,to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (57,'Report Image Width','REPORT_IMAGE_WIDTH','57','The pixel width of images in reports',4,3,to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (58,'Report Image Height','REPORT_IMAGE_HEIGHT','40','The pixel height of images in reports',4,4,to_timestamp('02-AUG-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (67,'State','ACCOUNT_STATE','Y','Display state, province or region in the customer account info and during payment process(Delivery/Billing page 4). If it is set to N, State field is not shown and country can not be divided into several Zones/States. If it is set to Y, any country can be divided into many Zones/States. Zone names will be visible as List of values for States on Delivery/Billing Address page 4.',5,1,to_timestamp('25-JUN-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (152,'Administrator language','ADMIN_LANGUAGE','en','Administrator console default language code. See Languages Translations page for valid codes list.',1,2,to_timestamp('15-NOV-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('15-NOV-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (75,'Internal payment enabled','INTERNAL_PAYMENT_ENABLED','N','Tells if Internal payments are enabled. Values: Y or N. If Y, the internal payments are enabled and the Webshop is storing the customer payment information, for example credit card number and CVC, to process it by the administrator. If Y, the external system handles the payment (currently Paypal). In this case, Webshop is not storing credit card number and CVC. And Internal payments are not enabled.',11,1,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (86,'Default Currency','DEFAULT_CURRENCY','EUR','Default Currency',6,0,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (87,'Default Language','DEFAULT_LANGUAGE','en','Default Language',6,0,null,to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (88,'Default Order Status For New Orders','DEFAULT_ORDERS_STATUS_ID','4','When a new order is created, this order status will be assigned to it. It should be status id or zero. The following ids and statuses are available in the table ols_order_status:<br>
1-Declined<br>
2-Invoiced<br>
3-Pending<br>
4-Ordered<br>
5-Cancelled<br>
6-Delivered',1,11,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (89,'Display Shipping','DISPLAY_SHIPPING','Y','Do you want to display the order shipping cost on Checkout page? Values: Y or N.',1,12,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (94,'Display Sub-Total','DISPLAY_SUBTOTAL','Y','Do you want to display the order sub-total cost on Checkout page? Values: Y or N.',1,13,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (96,'Display Tax','DISPLAY_TAX','Y','Do you want to display the order tax value on Checkout page? Values: Y or N.',1,14,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (98,'Display Total','DISPLAY_TOTAL','Y','Do you want to display the total order value on Checkout page? Values: Y or N.',1,16,to_timestamp('08-OCT-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_CONFIGURATION (ID,TITLE,KEY,VALUE,DESCRIPTION,GROUP_ID,SORT_ORDER,LAST_MODIFIED,DATE_ADDED) values (151,'Display Category Image','DISPLAY_CATEGORY_IMAGE','Y','Display or not display images for categories on the first page. Values: Y or N.',1,19,to_timestamp('21-AUG-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('21-AUG-08 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));

---------------------------------------------------
--   END DATA FOR TABLE OLS_CONFIGURATION
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_TAX_RATES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_TAX_RATES
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (2,2,1,22,'22%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('03-DEC-07 10.48.48.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (1,2,3,7,'7.0%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('05-DEC-06 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (3,2,2,0,'0%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('04-MAY-07 12.00.00.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (4,2,4,17,'17.0%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('03-AUG-08 08.59.15.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (7,1,3,4,'4%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('26-SEP-08 07.15.21.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (8,5,1,0,'0%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('04-NOV-08 04.28.57.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (5,1,1,14,'14%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('23-AUG-08 01.06.09.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));
Insert into OLS_TAX_RATES (ID,GEO_ZONE_ID,CLASS_ID,RATE,DESCRIPTION,LAST_MODIFIED,DATE_ADDED) values (6,4,1,16,'16%',to_timestamp('22-NOV-08 10.11.50.000000000 PM','DD-MON-RR HH.MI.SS.FF AM'),to_timestamp('23-AUG-08 01.07.17.000000000 AM','DD-MON-RR HH.MI.SS.FF AM'));

---------------------------------------------------
--   END DATA FOR TABLE OLS_TAX_RATES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_PRODUCT
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_PRODUCT

---------------------------------------------------
--   END DATA FOR TABLE OLS_PRODUCT
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_SHIPPING_AMOUNT_RATES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_SHIPPING_AMOUNT_RATES
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (1,1,100,10,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (2,1,99999,5,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (4,6,1,10,'1:2',null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (5,6,30,20,'2',null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (11,4,50,9,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (12,5,99,10,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (6,2,100,8,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (7,2,99999,0,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (8,8,99999,5,'2',null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (9,3,100,10,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (10,3,99999,8,null,null);
Insert into OLS_SHIPPING_AMOUNT_RATES (ID,SHIPPING_TYPE_ID,AMOUNT,RATE,GEO_ZONE_ID,BASED_ON) values (13,5,99999,4,null,null);

---------------------------------------------------
--   END DATA FOR TABLE OLS_SHIPPING_AMOUNT_RATES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_SHIPPING_TYPES
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_SHIPPING_TYPES
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (2,'Economy','Economy','Y',50,1,7,'N');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (3,'Express','Express','Y',50,2,3,'N');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (4,'International Economy','International Economy','Y',50,3,7,'N');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (5,'International Express','International Express','Y',50,2,3,'N');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (6,'International Express Air','International Express Air','Y',50,3,2,'N');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (8,'Flat shipping','Flat shipping','Y',50,1,7,'N');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (0,'Download','Download','Y',99999,null,1,'Y');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (9,'Pick-up','Pick-up in the shop','Y',999,null,null,'Y');
Insert into OLS_SHIPPING_TYPES (ID,SHIPPING_NAME,DESCRIPTION,ACTIVE,MAX_WEIGHT,BASED_ON,ESTIMATED_SHIP_TIME_ID,FREE) values (1,'Air Service','Air Service','Y',50,1,1,'N');

---------------------------------------------------
--   END DATA FOR TABLE OLS_SHIPPING_TYPES
---------------------------------------------------

---------------------------------------------------
--   DATA FOR TABLE OLS_ADDRESS_BOOK
--   FILTER = none used
---------------------------------------------------
REM INSERTING into OLS_ADDRESS_BOOK

---------------------------------------------------
--   END DATA FOR TABLE OLS_ADDRESS_BOOK
---------------------------------------------------
--------------------------------------------------------
--  Constraints for Table OLS_ADDRESS_BOOK
--------------------------------------------------------

  ALTER TABLE "OLS_ADDRESS_BOOK" ADD CONSTRAINT "OLS_ADDRESS_BOOK_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_ADDRESS_BOOK" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ADDRESS_BOOK" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_ADDRESS_FORMAT
--------------------------------------------------------

  ALTER TABLE "OLS_ADDRESS_FORMAT" ADD CONSTRAINT "OLS_ADDRESS_FORMAT_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_ADDRESS_FORMAT" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ADDRESS_FORMAT" MODIFY ("ADDRESS_FORMAT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_ADD_IMAGES
--------------------------------------------------------

  ALTER TABLE "OLS_ADD_IMAGES" ADD CONSTRAINT "OLS_ADD_IMAGES_PK" PRIMARY KEY ("PRODUCT_ID", "IMAGE_ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_BANNERS
--------------------------------------------------------

  ALTER TABLE "OLS_BANNERS" ADD CONSTRAINT "OLS_BANNERS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_BANNERS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_BANNERS" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_BANNERS" MODIFY ("URL" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_BANNERS" MODIFY ("VALIDITY_FROM" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_BANNERS" MODIFY ("CREATED_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_BANNERS" MODIFY ("WIDTH" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_BANNERS" MODIFY ("HEIGHT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CATEGORY
--------------------------------------------------------

  ALTER TABLE "OLS_CATEGORY" ADD CONSTRAINT "OLS_CATEGORY_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_CATEGORY" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CATEGORY" MODIFY ("CATEGORY_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CATEGORY_TRANS
--------------------------------------------------------

  ALTER TABLE "OLS_CATEGORY_TRANS" ADD CONSTRAINT "OLS_CATEGORY_TRANS_PK" PRIMARY KEY ("CAT_ID", "LANG_ID") ENABLE;
 
  ALTER TABLE "OLS_CATEGORY_TRANS" MODIFY ("CAT_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CATEGORY_TRANS" MODIFY ("LANG_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CAT_PRODUCT
--------------------------------------------------------

  ALTER TABLE "OLS_CAT_PRODUCT" ADD CONSTRAINT "OLS_CAT_PRODUCT_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_CAT_PRODUCT" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CAT_PRODUCT" MODIFY ("CATEGORY_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CONFIGURATION
--------------------------------------------------------

  ALTER TABLE "OLS_CONFIGURATION" ADD CONSTRAINT "OLS_CONFIGURATION_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_CONFIGURATION" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION" MODIFY ("KEY" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION" MODIFY ("VALUE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION" MODIFY ("GROUP_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION" MODIFY ("DATE_ADDED" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CONFIGURATION_GROUP
--------------------------------------------------------

  ALTER TABLE "OLS_CONFIGURATION_GROUP" ADD CONSTRAINT "OLS_CONFIGURATION_GROUP_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_CONFIGURATION_GROUP" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION_GROUP" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CONFIGURATION_GROUP" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_COUNTER
--------------------------------------------------------

  ALTER TABLE "OLS_COUNTER" MODIFY ("STARTDATE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_COUNTER" MODIFY ("COUNTER" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_COUNTRY
--------------------------------------------------------

  ALTER TABLE "OLS_COUNTRY" ADD CONSTRAINT "OLS_COUNTRY_CHK1" CHECK (
allow in ('N','Y')
) ENABLE;
 
  ALTER TABLE "OLS_COUNTRY" ADD CONSTRAINT "OLS_COUNTRY_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_COUNTRY" ADD CONSTRAINT "OLS_COUNTRY_UK1" UNIQUE ("COUNTRY_NAME") ENABLE;
 
  ALTER TABLE "OLS_COUNTRY" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_COUNTRY" MODIFY ("COUNTRY_NAME" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_COUNTRY" MODIFY ("ISO_CODE_1" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_COUNTRY" MODIFY ("ISO_CODE_2" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_COUNTRY" MODIFY ("ADDRESS_FORMAT_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_COUNTRY" MODIFY ("ALLOW" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CURRENCY
--------------------------------------------------------

  ALTER TABLE "OLS_CURRENCY" ADD CONSTRAINT "OLS_CURRENCY_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_CURRENCY" ADD CONSTRAINT "OLS_CURRENCY_UK1" UNIQUE ("CODE") ENABLE;
 
  ALTER TABLE "OLS_CURRENCY" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CURRENCY" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CURRENCY" MODIFY ("CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CUSTOMER_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_CUSTOMER_DETAILS" ADD CONSTRAINT "OLS_CUSTOMER_DETAILS_CHK1" CHECK (
admin in ('Yes','No')
) ENABLE;
 
  ALTER TABLE "OLS_CUSTOMER_DETAILS" ADD CONSTRAINT "OLS_USER_DETAILS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_CUSTOMER_DETAILS" MODIFY ("LOGIN_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CUSTOMER_DETAILS" MODIFY ("PASSWORD" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_CUSTOMER_DETAILS" MODIFY ("ADMIN" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_CUST_BILLING_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_CUST_BILLING_DETAILS" ADD CONSTRAINT "OLS_USER_BILLING_DETAILS_PK" PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_CUST_SHIPPING_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_CUST_SHIPPING_DETAILS" ADD CONSTRAINT "OLS_USER_SHIPPING_DETAILS_PK" PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_ERRORS
--------------------------------------------------------

  ALTER TABLE "OLS_ERRORS" ADD CONSTRAINT "OLS_ERRORS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_ERRORS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ERRORS" MODIFY ("ERROR" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_ESTIMATED_DELIVERY_TIME
--------------------------------------------------------

  ALTER TABLE "OLS_ESTIMATED_DELIVERY_TIME" ADD CONSTRAINT "OSL_ESTIMATED_SHIP_TIME_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_ESTIMATED_DELIVERY_TIME" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ESTIMATED_DELIVERY_TIME" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ESTIMATED_DELIVERY_TIME" MODIFY ("MIN_DAYS" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ESTIMATED_DELIVERY_TIME" MODIFY ("MAX_DAYS" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_FAVORITES
--------------------------------------------------------

  ALTER TABLE "OLS_FAVORITES" ADD CONSTRAINT "OLS_FAVORITES_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_FAVORITES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_FAVORITES" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_FAVORITES" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_FAVORITES" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_FILES
--------------------------------------------------------

  ALTER TABLE "OLS_FILES" ADD CONSTRAINT "OLS_FILES_PK" PRIMARY KEY ("PRODUCT_ID", "FILE_ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_GEO_ZONES
--------------------------------------------------------

  ALTER TABLE "OLS_GEO_ZONES" ADD CONSTRAINT "OLS_GEO_ZONES_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_GEO_ZONES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_GEO_ZONES" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_IMAGES
--------------------------------------------------------

  ALTER TABLE "OLS_IMAGES" ADD CONSTRAINT "OLS_IMAGES_PK" PRIMARY KEY ("IMAGE_ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_LANGUAGE
--------------------------------------------------------

  ALTER TABLE "OLS_LANGUAGE" ADD CONSTRAINT "OLS_LANGUAGE_CHK1" CHECK (
active in ('N','Y')
) ENABLE;
 
  ALTER TABLE "OLS_LANGUAGE" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LANGUAGE" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LANGUAGE" MODIFY ("CODE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LANGUAGE" MODIFY ("ACTIVE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LANGUAGE" ADD PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_LANGUAGE_CODES
--------------------------------------------------------

  ALTER TABLE "OLS_LANGUAGE_CODES" ADD CONSTRAINT "OLS_LANGUAGE_CODES_PK" PRIMARY KEY ("CODE") ENABLE;
 
  ALTER TABLE "OLS_LANGUAGE_CODES" MODIFY ("CODE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LANGUAGE_CODES" MODIFY ("LANG_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_LINE_DOWNLOADS
--------------------------------------------------------

  ALTER TABLE "OLS_LINE_DOWNLOADS" ADD CONSTRAINT "OLS_LINE_DOWNLOADS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_LINE_DOWNLOADS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LINE_DOWNLOADS" MODIFY ("LINE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LINE_DOWNLOADS" MODIFY ("DOWNLOAD_FILE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_LINE_ITEMS
--------------------------------------------------------

  ALTER TABLE "OLS_LINE_ITEMS" ADD CONSTRAINT "OLS_LINE_ITEMS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_LINE_ITEMS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LINE_ITEMS" MODIFY ("SALES_ORDER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LINE_ITEMS" MODIFY ("LINE_ITEM_NUM" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LINE_ITEMS" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_LINE_ITEM_OPTIONS
--------------------------------------------------------

  ALTER TABLE "OLS_LINE_ITEM_OPTIONS" ADD CONSTRAINT "OLS_LINE_ITEM_PR_OP_VALUE_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_LINE_ITEM_OPTIONS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LINE_ITEM_OPTIONS" MODIFY ("LINE_ITEM_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_LINE_ITEM_OPTIONS" MODIFY ("PRODUCT_OPTION_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_LOGS
--------------------------------------------------------

  ALTER TABLE "OLS_LOGS" ADD CONSTRAINT "OLS_LOGS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_LOGS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_MANUFACTURER
--------------------------------------------------------

  ALTER TABLE "OLS_MANUFACTURER" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MANUFACTURER" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MANUFACTURER" MODIFY ("DATE_ADDED" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MANUFACTURER" MODIFY ("MANUFACTURER_URL" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MANUFACTURER" ADD PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_MESSAGES
--------------------------------------------------------

  ALTER TABLE "OLS_MESSAGES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MESSAGES" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MESSAGES" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MESSAGES" MODIFY ("TEXT" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MESSAGES" MODIFY ("CREATED_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_MESSAGES" ADD PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_NEWS
--------------------------------------------------------

  ALTER TABLE "OLS_NEWS" ADD CONSTRAINT "OLS_NEWS_CHK1" CHECK (
active in ('Yes','No')
) ENABLE;
 
  ALTER TABLE "OLS_NEWS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWS" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWS" MODIFY ("TEXT" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWS" MODIFY ("MODULE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWS" MODIFY ("DATE_ADDED" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWS" ADD PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_NEWSLETTER
--------------------------------------------------------

  ALTER TABLE "OLS_NEWSLETTER" ADD CONSTRAINT "OLS_NEWSLETTER_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_NEWSLETTER" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWSLETTER" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWSLETTER" MODIFY ("CONTENT" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_NEWSLETTER" MODIFY ("CREATED_DATE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_ORDER_STATUS
--------------------------------------------------------

  ALTER TABLE "OLS_ORDER_STATUS" ADD CONSTRAINT "OLS_ORDER_STATUS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_ORDER_STATUS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PAYMENT_CC_TYPE
--------------------------------------------------------

  ALTER TABLE "OLS_PAYMENT_CC_TYPE" ADD CONSTRAINT "OLS_PAYMENT_DETAILS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_PAYMENT_CC_TYPE" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_CC_TYPE" MODIFY ("AVAILABLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_CC_TYPE" MODIFY ("PRIORITY" NOT NULL ENABLE);

  ALTER TABLE "OLS_PAYMENT_CC_TYPE" MODIFY ("PAYPAL" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PAYMENT_MODE_EX
--------------------------------------------------------

  ALTER TABLE "OLS_PAYMENT_MODE_EX" ADD CONSTRAINT "OLS_PAYMENT_MODE_DETAILS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_PAYMENT_MODE_EX" ADD CONSTRAINT "OLS_PAYMENT_MODE_EX_UK1" UNIQUE ("KEY") ENABLE;
 
  ALTER TABLE "OLS_PAYMENT_MODE_EX" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_EX" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_EX" MODIFY ("VENDOR_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_EX" MODIFY ("AVAILABLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_EX" MODIFY ("TESTMODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PAYMENT_MODE_IN
--------------------------------------------------------

  ALTER TABLE "OLS_PAYMENT_MODE_IN" ADD CONSTRAINT "OLS_PAYMENT_MODE_IN_CHK1" CHECK (
available in ('Y','N')
) ENABLE;
 
  ALTER TABLE "OLS_PAYMENT_MODE_IN" ADD CONSTRAINT "OLS_PAYMENT_MODE_IN_CHK2" CHECK (
key in ('CC','CHECK','DD','COD')
) ENABLE;
 
  ALTER TABLE "OLS_PAYMENT_MODE_IN" ADD CONSTRAINT "OLS_PAYMENT_MODE_IN_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_PAYMENT_MODE_IN" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_IN" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_IN" MODIFY ("AVAILABLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_IN" MODIFY ("PRIORITY" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYMENT_MODE_IN" MODIFY ("KEY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PAYPAL_SESSION_MAP
--------------------------------------------------------

  ALTER TABLE "OLS_PAYPAL_SESSION_MAP" ADD CONSTRAINT "OLS_PAYPAL_SESSION_MAP_PK" PRIMARY KEY ("SESSION_ID", "SESSION_TOKEN") ENABLE;
 
  ALTER TABLE "OLS_PAYPAL_SESSION_MAP" MODIFY ("SESSION_TOKEN" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYPAL_SESSION_MAP" MODIFY ("SESSION_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYPAL_SESSION_MAP" MODIFY ("APP_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYPAL_SESSION_MAP" MODIFY ("PAGE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PAYPAL_TRANSACTIONS
--------------------------------------------------------

  ALTER TABLE "OLS_PAYPAL_TRANSACTIONS" ADD CONSTRAINT "OLS_PAYPAL_TRANSACTIONS_PK" PRIMARY KEY ("TRANSACTION_ID") ENABLE;
 
  ALTER TABLE "OLS_PAYPAL_TRANSACTIONS" MODIFY ("TRANSACTION_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PAYPAL_TRANSACTIONS" MODIFY ("SESSION_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PRODUCT
--------------------------------------------------------

  ALTER TABLE "OLS_PRODUCT" ADD CONSTRAINT "AVAL_CHK" CHECK (availability in ('Yes','No')) ENABLE;
 
  ALTER TABLE "OLS_PRODUCT" ADD CONSTRAINT "HOT_CHK" CHECK (
hot in ('Yes','No')
) ENABLE;
 
  ALTER TABLE "OLS_PRODUCT" ADD CONSTRAINT "OLS_PRODUCT_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_PRODUCT" ADD CONSTRAINT "PROMO_CHK" CHECK (
promotion in ('Yes','No')
) ENABLE;
 
  ALTER TABLE "OLS_PRODUCT" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PRODUCT" MODIFY ("PRODUCT_NAME" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PRODUCT" MODIFY ("TAX" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PRODUCT_OPTIONS
--------------------------------------------------------

  ALTER TABLE "OLS_PRODUCT_OPTIONS" ADD CONSTRAINT "OLS_PRODUCT_OPTIONS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_PRODUCT_OPTIONS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PRODUCT_OPTIONS" MODIFY ("OPTION_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PRODUCT_TO_PR_OPTIONS
--------------------------------------------------------

  ALTER TABLE "OLS_PRODUCT_TO_PR_OPTIONS" ADD CONSTRAINT "OLS_PRODUCT_TO_PR_OPTIONS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_PRODUCT_TO_PR_OPTIONS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_PRODUCT_TRANS
--------------------------------------------------------

  ALTER TABLE "OLS_PRODUCT_TRANS" ADD CONSTRAINT "OLS_PRODUCT_TRANS_PK" PRIMARY KEY ("PROD_ID", "LANG_ID") ENABLE;
 
  ALTER TABLE "OLS_PRODUCT_TRANS" MODIFY ("PROD_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_PRODUCT_TRANS" MODIFY ("LANG_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_REVIEWS
--------------------------------------------------------

  ALTER TABLE "OLS_REVIEWS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_REVIEWS" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_REVIEWS" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_REVIEWS" MODIFY ("TEXT" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_REVIEWS" ADD PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_SALES_ORDER
--------------------------------------------------------

  ALTER TABLE "OLS_SALES_ORDER" ADD CONSTRAINT "OLS_SALES_ORDER_ID" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_SALES_ORDER" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SALES_ORDER" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SALES_ORDER" MODIFY ("BILL_TO_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SALES_ORDER" MODIFY ("SHIP_TO_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SALES_ORDER" MODIFY ("ORDER_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SALES_ORDER" MODIFY ("CURRENCY" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SALES_ORDER" MODIFY ("STATUS_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_SHIPPING_AMOUNT_RATES
--------------------------------------------------------

  ALTER TABLE "OLS_SHIPPING_AMOUNT_RATES" ADD CONSTRAINT "OLS_SHIPPING_AMOUNT_RATES_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_SHIPPING_AMOUNT_RATES" MODIFY ("RATE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_AMOUNT_RATES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_AMOUNT_RATES" MODIFY ("SHIPPING_TYPE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_AMOUNT_RATES" MODIFY ("AMOUNT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_SHIPPING_PRICE_TYPES
--------------------------------------------------------

  ALTER TABLE "OLS_SHIPPING_PRICE_TYPES" ADD CONSTRAINT "OLS_SHIPPING_PRICE_TYPES_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_SHIPPING_PRICE_TYPES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_PRICE_TYPES" MODIFY ("NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_SHIPPING_TYPES
--------------------------------------------------------

  ALTER TABLE "OLS_SHIPPING_TYPES" ADD CONSTRAINT "OLS_DELIVERY_TYPE_DETAILS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_SHIPPING_TYPES" ADD CONSTRAINT "OLS_DELIVERY_TYPE_DETAIL_CHK1" CHECK (
active in ('Y','N')
) ENABLE;
 
  ALTER TABLE "OLS_SHIPPING_TYPES" ADD CONSTRAINT "OLS_SHIPPING_TYPES_FREE_CHK1" CHECK (
free in ('N','Y')
) ENABLE;
 
  ALTER TABLE "OLS_SHIPPING_TYPES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_TYPES" MODIFY ("SHIPPING_NAME" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_TYPES" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_TYPES" MODIFY ("ACTIVE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_TYPES" MODIFY ("MAX_WEIGHT" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHIPPING_TYPES" MODIFY ("FREE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_SHOPPING_CART
--------------------------------------------------------

  ALTER TABLE "OLS_SHOPPING_CART" ADD CONSTRAINT "OLS_SHOPPING_CART_PK" PRIMARY KEY ("SESSION_ID", "PRODUCT_ID") ENABLE;
 
  ALTER TABLE "OLS_SHOPPING_CART" MODIFY ("SESSION_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_SHOPPING_CART" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_SO_PAY_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_SO_PAY_DETAILS" ADD CONSTRAINT "OLS_SO_PAY_DETAILS_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_SO_PAY_DETAILS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_STATES
--------------------------------------------------------

  ALTER TABLE "OLS_STATES" ADD CONSTRAINT "OLS_STATES_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_STATES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_STATES" MODIFY ("COUNTRY_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_TAX_CLASS
--------------------------------------------------------

  ALTER TABLE "OLS_TAX_CLASS" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_CLASS" MODIFY ("TITLE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_CLASS" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_CLASS" MODIFY ("DATE_ADDED" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_CLASS" ADD PRIMARY KEY ("ID") ENABLE;
--------------------------------------------------------
--  Constraints for Table OLS_TAX_RATES
--------------------------------------------------------

  ALTER TABLE "OLS_TAX_RATES" ADD CONSTRAINT "OLS_TAX_RATES_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_TAX_RATES" ADD CONSTRAINT "OLS_TAX_RATES_UK1" UNIQUE ("GEO_ZONE_ID", "CLASS_ID") ENABLE;
 
  ALTER TABLE "OLS_TAX_RATES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_RATES" MODIFY ("GEO_ZONE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_RATES" MODIFY ("CLASS_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_RATES" MODIFY ("RATE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_RATES" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_TAX_RATES" MODIFY ("DATE_ADDED" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OLS_ZONES
--------------------------------------------------------

  ALTER TABLE "OLS_ZONES" ADD CONSTRAINT "OLS_ZONES_PK" PRIMARY KEY ("ID") ENABLE;
 
  ALTER TABLE "OLS_ZONES" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ZONES" MODIFY ("COUNTRY_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ZONES" MODIFY ("CODE" NOT NULL ENABLE);
 
  ALTER TABLE "OLS_ZONES" MODIFY ("NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table OLS_ADDRESS_BOOK
--------------------------------------------------------

  ALTER TABLE "OLS_ADDRESS_BOOK" ADD CONSTRAINT "OLS_ADDRESS_BOOK_OLS_CUST_FK1" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "OLS_CUSTOMER_DETAILS" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_CATEGORY
--------------------------------------------------------

  ALTER TABLE "OLS_CATEGORY" ADD CONSTRAINT "OLS_CATEGORY_OLS_CATEGORY_FK1" FOREIGN KEY ("PARENT_ID")
	  REFERENCES "OLS_CATEGORY" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_CATEGORY_TRANS
--------------------------------------------------------

  ALTER TABLE "OLS_CATEGORY_TRANS" ADD CONSTRAINT "OLS_CATEGORY_TRANS_OLS_CA_FK1" FOREIGN KEY ("CAT_ID")
	  REFERENCES "OLS_CATEGORY" ("ID") ON DELETE CASCADE ENABLE;
 
  ALTER TABLE "OLS_CATEGORY_TRANS" ADD CONSTRAINT "OLS_CATEGORY_TRANS_OLS_LA_FK1" FOREIGN KEY ("LANG_ID")
	  REFERENCES "OLS_LANGUAGE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_CONFIGURATION
--------------------------------------------------------

  ALTER TABLE "OLS_CONFIGURATION" ADD CONSTRAINT "OLS_CONFIGURATION_OLS_CON_FK1" FOREIGN KEY ("GROUP_ID")
	  REFERENCES "OLS_CONFIGURATION_GROUP" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_CUSTOMER_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_CUSTOMER_DETAILS" ADD CONSTRAINT "OLS_CUSTOMER_DETAILS_OLS__FK1" FOREIGN KEY ("COUNTRY")
	  REFERENCES "OLS_COUNTRY" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_CUST_BILLING_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_CUST_BILLING_DETAILS" ADD CONSTRAINT "OLS_CUST_BILLING_DETAILS__FK1" FOREIGN KEY ("COUNTRY")
	  REFERENCES "OLS_COUNTRY" ("ID") ENABLE;
 
  ALTER TABLE "OLS_CUST_BILLING_DETAILS" ADD CONSTRAINT "OLS_CUST_BILL_DET_FK_CUST_ID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "OLS_CUSTOMER_DETAILS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_CUST_SHIPPING_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_CUST_SHIPPING_DETAILS" ADD CONSTRAINT "OLS_CUST_SHIPPING_DETAILS_FK1" FOREIGN KEY ("COUNTRY")
	  REFERENCES "OLS_COUNTRY" ("ID") ENABLE;
 
  ALTER TABLE "OLS_CUST_SHIPPING_DETAILS" ADD CONSTRAINT "OLS_CUST_SHIP_DET_FK_CUST_ID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "OLS_CUSTOMER_DETAILS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_FAVORITES
--------------------------------------------------------

  ALTER TABLE "OLS_FAVORITES" ADD CONSTRAINT "OLS_FAVORITES_OLS_CUSTOME_FK1" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "OLS_CUSTOMER_DETAILS" ("ID") ON DELETE CASCADE ENABLE;
 
  ALTER TABLE "OLS_FAVORITES" ADD CONSTRAINT "OLS_FAVORITES_OLS_PRODUCT_FK1" FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "OLS_PRODUCT" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_LINE_DOWNLOADS
--------------------------------------------------------

  ALTER TABLE "OLS_LINE_DOWNLOADS" ADD CONSTRAINT "OLS_LINE_DOWNLOADS_OLS_LI_FK1" FOREIGN KEY ("LINE_ID")
	  REFERENCES "OLS_LINE_ITEMS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_LINE_ITEMS
--------------------------------------------------------

  ALTER TABLE "OLS_LINE_ITEMS" ADD CONSTRAINT "OLS_LINE_ITEMS_OLS_PRODUC_FK1" FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "OLS_PRODUCT" ("ID") ENABLE;
 
  ALTER TABLE "OLS_LINE_ITEMS" ADD CONSTRAINT "OLS_LINE_ITEMS_ORDER_FK1" FOREIGN KEY ("SALES_ORDER_ID")
	  REFERENCES "OLS_SALES_ORDER" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_LINE_ITEM_OPTIONS
--------------------------------------------------------

  ALTER TABLE "OLS_LINE_ITEM_OPTIONS" ADD CONSTRAINT "OLS_LINE_ITEM_OPTION_FK1" FOREIGN KEY ("LINE_ITEM_ID")
	  REFERENCES "OLS_LINE_ITEMS" ("ID") ENABLE;
 
  ALTER TABLE "OLS_LINE_ITEM_OPTIONS" ADD CONSTRAINT "OLS_LINE_ITEM_OPTION_FK2" FOREIGN KEY ("PRODUCT_OPTION_ID")
	  REFERENCES "OLS_PRODUCT_OPTIONS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_MESSAGES
--------------------------------------------------------

  ALTER TABLE "OLS_MESSAGES" ADD CONSTRAINT "OLS_MESSAGES_CUST_FK" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "OLS_CUSTOMER_DETAILS" ("ID") ENABLE;
 
  ALTER TABLE "OLS_MESSAGES" ADD CONSTRAINT "OLS_MESSAGES_OLS_MESSAGES_FK1" FOREIGN KEY ("REPLY_ON_ID")
	  REFERENCES "OLS_MESSAGES" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_PRODUCT
--------------------------------------------------------

  ALTER TABLE "OLS_PRODUCT" ADD CONSTRAINT "OLS_PRODUCT_CATEGORY_FK" FOREIGN KEY ("CATEGORY_ID")
	  REFERENCES "OLS_CATEGORY" ("ID") ENABLE;
 
  ALTER TABLE "OLS_PRODUCT" ADD CONSTRAINT "OLS_PRODUCT_MANUFACTURER_FK" FOREIGN KEY ("MANUFACTURER_ID")
	  REFERENCES "OLS_MANUFACTURER" ("ID") ENABLE;
 
  ALTER TABLE "OLS_PRODUCT" ADD CONSTRAINT "OLS_PRODUCT_OLS_TAX_CLASS_FK1" FOREIGN KEY ("TAX_CLASS_ID")
	  REFERENCES "OLS_TAX_CLASS" ("ID") DISABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_PRODUCT_TO_PR_OPTIONS
--------------------------------------------------------

  ALTER TABLE "OLS_PRODUCT_TO_PR_OPTIONS" ADD CONSTRAINT "OLS_PRODUCT_TO_PR_OPTIONS_FK1" FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "OLS_PRODUCT" ("ID") ON DELETE CASCADE ENABLE;
 
  ALTER TABLE "OLS_PRODUCT_TO_PR_OPTIONS" ADD CONSTRAINT "OLS_PRODUCT_TO_PR_OPTIONS_FK2" FOREIGN KEY ("PRODUCT_OPTION_ID")
	  REFERENCES "OLS_PRODUCT_OPTIONS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_PRODUCT_TRANS
--------------------------------------------------------

  ALTER TABLE "OLS_PRODUCT_TRANS" ADD CONSTRAINT "OLS_PRODUCT_TRANS_OLS_LAN_FK1" FOREIGN KEY ("LANG_ID")
	  REFERENCES "OLS_LANGUAGE" ("ID") ENABLE;
 
  ALTER TABLE "OLS_PRODUCT_TRANS" ADD CONSTRAINT "OLS_PRODUCT_TRANS_OLS_PRO_FK1" FOREIGN KEY ("PROD_ID")
	  REFERENCES "OLS_PRODUCT" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_REVIEWS
--------------------------------------------------------

  ALTER TABLE "OLS_REVIEWS" ADD CONSTRAINT "OLS_REVIEW_PROD_FK" FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "OLS_PRODUCT" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_SALES_ORDER
--------------------------------------------------------

  ALTER TABLE "OLS_SALES_ORDER" ADD CONSTRAINT "OLS_CUSTOMER_DETAILS_ID_FK" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "OLS_CUSTOMER_DETAILS" ("ID") ENABLE;
 
  ALTER TABLE "OLS_SALES_ORDER" ADD CONSTRAINT "OLS_SALES_ORDER_STATUS_FK1" FOREIGN KEY ("STATUS_ID")
	  REFERENCES "OLS_ORDER_STATUS" ("ID") ENABLE;
 
  ALTER TABLE "OLS_SALES_ORDER" ADD CONSTRAINT "OLS_SO_CUST_BILL_DETAILS_FK1" FOREIGN KEY ("BILL_TO_ID")
	  REFERENCES "OLS_CUST_BILLING_DETAILS" ("ID") ENABLE;
 
  ALTER TABLE "OLS_SALES_ORDER" ADD CONSTRAINT "OLS_SO_SHIP_DETAILS_FK1" FOREIGN KEY ("SHIP_TO_ID")
	  REFERENCES "OLS_CUST_SHIPPING_DETAILS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_SHIPPING_AMOUNT_RATES
--------------------------------------------------------

  ALTER TABLE "OLS_SHIPPING_AMOUNT_RATES" ADD CONSTRAINT "OLS_SHIPPING_AMOUNT_RATES_FK1" FOREIGN KEY ("SHIPPING_TYPE_ID")
	  REFERENCES "OLS_SHIPPING_TYPES" ("ID") ENABLE;
 
  ALTER TABLE "OLS_SHIPPING_AMOUNT_RATES" ADD CONSTRAINT "OLS_SHIPPING_AMOUNT_RATES_FK2" FOREIGN KEY ("BASED_ON")
	  REFERENCES "OLS_SHIPPING_PRICE_TYPES" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_SHIPPING_TYPES
--------------------------------------------------------

  ALTER TABLE "OLS_SHIPPING_TYPES" ADD CONSTRAINT "OLS_SHIPPING_TYPES_OLS_ES_FK1" FOREIGN KEY ("ESTIMATED_SHIP_TIME_ID")
	  REFERENCES "OLS_ESTIMATED_DELIVERY_TIME" ("ID") ENABLE;
 
  ALTER TABLE "OLS_SHIPPING_TYPES" ADD CONSTRAINT "OLS_SHIPPING_TYPES_OLS_SH_FK1" FOREIGN KEY ("BASED_ON")
	  REFERENCES "OLS_SHIPPING_PRICE_TYPES" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_SHOPPING_CART
--------------------------------------------------------

  ALTER TABLE "OLS_SHOPPING_CART" ADD CONSTRAINT "OLS_SHOPPING_CART_OLS_PRO_FK1" FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "OLS_PRODUCT" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_SO_PAY_DETAILS
--------------------------------------------------------

  ALTER TABLE "OLS_SO_PAY_DETAILS" ADD CONSTRAINT "OLS_SO_PAY_DETAILS_OLS_CU_FK1" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "OLS_CUSTOMER_DETAILS" ("ID") ENABLE;
 
  ALTER TABLE "OLS_SO_PAY_DETAILS" ADD CONSTRAINT "OLS_SO_PAY_DETAILS_OLS_SA_FK1" FOREIGN KEY ("SALES_ORDER_ID")
	  REFERENCES "OLS_SALES_ORDER" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_STATES
--------------------------------------------------------

  ALTER TABLE "OLS_STATES" ADD CONSTRAINT "OLS_STATES_OLS_COUNTRY_FK1" FOREIGN KEY ("COUNTRY_ID")
	  REFERENCES "OLS_COUNTRY" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_TAX_RATES
--------------------------------------------------------

  ALTER TABLE "OLS_TAX_RATES" ADD CONSTRAINT "OLS_TAX_RATES_GEO_ZONES_FK1" FOREIGN KEY ("GEO_ZONE_ID")
	  REFERENCES "OLS_GEO_ZONES" ("ID") ENABLE;
 
  ALTER TABLE "OLS_TAX_RATES" ADD CONSTRAINT "OLS_TAX_RATES_TAX_CLASS_FK1" FOREIGN KEY ("CLASS_ID")
	  REFERENCES "OLS_TAX_CLASS" ("ID") DISABLE;
--------------------------------------------------------
--  Ref Constraints for Table OLS_ZONES
--------------------------------------------------------

  ALTER TABLE "OLS_ZONES" ADD CONSTRAINT "OLS_ZONES_OLS_COUNTRY_FK1" FOREIGN KEY ("COUNTRY_ID")
	  REFERENCES "OLS_COUNTRY" ("ID") ENABLE;
 
  ALTER TABLE "OLS_ZONES" ADD CONSTRAINT "OLS_ZONES_OLS_GEO_ZONES_FK1" FOREIGN KEY ("GEO_ZONE_ID")
	  REFERENCES "OLS_GEO_ZONES" ("ID") ENABLE;
 
  ALTER TABLE "OLS_ZONES" ADD CONSTRAINT "OLS_ZONES_OLS_GEO_ZONES_FK2" FOREIGN KEY ("TAX_GEO_ZONE_ID")
	  REFERENCES "OLS_GEO_ZONES" ("ID") ENABLE;

--------------------------------------------------------
--  DDL for Index OLS_ADDRESS_BOOK_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_ADDRESS_BOOK_INDEX1" ON "OLS_ADDRESS_BOOK" ("CUSTOMER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_CATEGORY_NAME_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_CATEGORY_NAME_IDX" ON "OLS_CATEGORY" ("CATEGORY_NAME") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_CATEGORY_PARENT_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_CATEGORY_PARENT_IDX" ON "OLS_CATEGORY" ("PARENT_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_CONF_KEY_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OLS_CONF_KEY_IDX" ON "OLS_CONFIGURATION" ("KEY") 
  ;

--------------------------------------------------------
--  DDL for Index OLS_CUSTOMER_DETAILS_INDEX1
--------------------------------------------------------
  CREATE INDEX "OLS_CUSTOMER_DETAILS_INDEX1" ON "OLS_CUSTOMER_DETAILS" ("COUNTRY") 
  ;


--------------------------------------------------------
--  DDL for Index OLS_CUST_BILL_DET_CUSTID
--------------------------------------------------------

  CREATE INDEX "OLS_CUST_BILL_DET_CUSTID" ON "OLS_CUST_BILLING_DETAILS" ("CUSTOMER_ID") 
  ;
  CREATE INDEX "OLS_CUST_BILLING_DET_COUNTR" ON "OLS_CUST_BILLING_DETAILS" ("COUNTRY") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_CUST_SHIP_DET_CUSTID
--------------------------------------------------------

  CREATE INDEX "OLS_CUST_SHIP_DET_CUSTID" ON "OLS_CUST_SHIPPING_DETAILS" ("CUSTOMER_ID") 
  ;
  CREATE INDEX "OLS_CUST_SHIPPING_DET_COUNTR" ON "OLS_CUST_SHIPPING_DETAILS" ("COUNTRY") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_FAVORITES_CUSTID
--------------------------------------------------------

  CREATE INDEX "OLS_FAVORITES_CUSTID" ON "OLS_FAVORITES" ("CUSTOMER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_FAVORITES_PRODID
--------------------------------------------------------

  CREATE INDEX "OLS_FAVORITES_PRODID" ON "OLS_FAVORITES" ("PRODUCT_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_LINE_DOWNLOADS_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_LINE_DOWNLOADS_INDEX1" ON "OLS_LINE_DOWNLOADS" ("LINE_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_LINE_DOWNLOADS_INDEX2
--------------------------------------------------------

  CREATE INDEX "OLS_LINE_DOWNLOADS_INDEX2" ON "OLS_LINE_DOWNLOADS" ("DOWNLOAD_FILE_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_LINE_ITEMS_PRODID
--------------------------------------------------------

  CREATE INDEX "OLS_LINE_ITEMS_PRODID" ON "OLS_LINE_ITEMS" ("PRODUCT_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_LINE_ITEMS_SOID
--------------------------------------------------------

  CREATE INDEX "OLS_LINE_ITEMS_SOID" ON "OLS_LINE_ITEMS" ("SALES_ORDER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_LINE_ITEM_OPTIONS_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_LINE_ITEM_OPTIONS_INDEX1" ON "OLS_LINE_ITEM_OPTIONS" ("LINE_ITEM_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_LINE_ITEM_OPTIONS_INDEX2
--------------------------------------------------------

  CREATE INDEX "OLS_LINE_ITEM_OPTIONS_INDEX2" ON "OLS_LINE_ITEM_OPTIONS" ("PRODUCT_OPTION_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_MANUFACTURER_NAME_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_MANUFACTURER_NAME_IDX" ON "OLS_MANUFACTURER" ("NAME") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_MESSAGES_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_MESSAGES_INDEX1" ON "OLS_MESSAGES" ("CUSTOMER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_MESSAGES_INDEX2
--------------------------------------------------------

  CREATE INDEX "OLS_MESSAGES_INDEX2" ON "OLS_MESSAGES" ("REPLY_ON_ID") 
  ;

--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_ACTDATE_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_ACTDATE_IDX" ON "OLS_PRODUCT" ("ACTIVATION_DATE") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_CATID
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_CATID" ON "OLS_PRODUCT" ("CATEGORY_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_IMGID
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_IMGID" ON "OLS_PRODUCT" ("IMAGE_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_MAN_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_MAN_IDX" ON "OLS_PRODUCT" ("MANUFACTURER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_OPTIONS_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_OPTIONS_INDEX1" ON "OLS_PRODUCT_TO_PR_OPTIONS" ("PRODUCT_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_OPTIONS_INDEX2
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_OPTIONS_INDEX2" ON "OLS_PRODUCT_TO_PR_OPTIONS" ("PRODUCT_OPTION_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_PR_LONGD_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_PR_LONGD_IDX" ON "OLS_PRODUCT" ("LONG_DESCRIPTION") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_PR_NAME_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_PR_NAME_IDX" ON "OLS_PRODUCT" ("PRODUCT_NAME") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_PR_SHORTD_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_PR_SHORTD_IDX" ON "OLS_PRODUCT" ("SHORT_DESCRIPTION") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_PRODUCT_TAX_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_PRODUCT_TAX_INDEX1" ON "OLS_PRODUCT" ("TAX_CLASS_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_REVIEW_PROD_IDX
--------------------------------------------------------

  CREATE INDEX "OLS_REVIEW_PROD_IDX" ON "OLS_REVIEWS" ("PRODUCT_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_SALES_ORDER_BILLTO
--------------------------------------------------------

  CREATE INDEX "OLS_SALES_ORDER_BILLTO" ON "OLS_SALES_ORDER" ("BILL_TO_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_SALES_ORDER_CUSTID
--------------------------------------------------------

  CREATE INDEX "OLS_SALES_ORDER_CUSTID" ON "OLS_SALES_ORDER" ("CUSTOMER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_SALES_ORDER_SHIPTO
--------------------------------------------------------

  CREATE INDEX "OLS_SALES_ORDER_SHIPTO" ON "OLS_SALES_ORDER" ("SHIP_TO_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_SALES_ORDER_STATUS_IDX1
--------------------------------------------------------

  CREATE INDEX "OLS_SALES_ORDER_STATUS_IDX1" ON "OLS_SALES_ORDER" ("STATUS_ID") 
  ;

  CREATE INDEX "OLS_SHIPPING_AM_RATES_BASED" ON "OLS_SHIPPING_AMOUNT_RATES" ("BASED_ON") 
  ;
 
  CREATE INDEX "OLS_SHIPPING_AM_RATES_TYPE" ON "OLS_SHIPPING_AMOUNT_RATES" ("SHIPPING_TYPE_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_SO_PAY_DETAILS_CUSTID
--------------------------------------------------------

  CREATE INDEX "OLS_SO_PAY_DETAILS_CUSTID" ON "OLS_SO_PAY_DETAILS" ("CUSTOMER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_SO_PAY_DETAILS_PAYID
--------------------------------------------------------

  CREATE INDEX "OLS_SO_PAY_DETAILS_PAYID" ON "OLS_SO_PAY_DETAILS" ("PAYMENT_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_SO_PAY_DETAILS_SOID
--------------------------------------------------------

  CREATE INDEX "OLS_SO_PAY_DETAILS_SOID" ON "OLS_SO_PAY_DETAILS" ("SALES_ORDER_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_TAX_RATES_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_TAX_RATES_INDEX1" ON "OLS_TAX_RATES" ("GEO_ZONE_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_TAX_RATES_INDEX2
--------------------------------------------------------

  CREATE INDEX "OLS_TAX_RATES_INDEX2" ON "OLS_TAX_RATES" ("CLASS_ID") 
  ;

--------------------------------------------------------
--  DDL for Index OLS_ZONES_INDEX1
--------------------------------------------------------

  CREATE INDEX "OLS_ZONES_INDEX1" ON "OLS_ZONES" ("COUNTRY_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_ZONES_INDEX2
--------------------------------------------------------

  CREATE INDEX "OLS_ZONES_INDEX2" ON "OLS_ZONES" ("GEO_ZONE_ID") 
  ;
--------------------------------------------------------
--  DDL for Index OLS_ZONES_INDEX3
--------------------------------------------------------
  CREATE INDEX "OLS_ZONES_INDEX3" ON "OLS_ZONES" ("TAX_GEO_ZONE_ID")
  ; 
--------------------------------------------------------
--  DDL for Trigger OLS_BANNERS_INS_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_BANNERS_INS_UPD" 
 BEFORE INSERT or UPDATE ON OLS_BANNERS
 for each row
BEGIN
if inserting then
 if :new.created_date is null then
  :new.created_date := sysdate;
 end if;
 if :new.modified_date is null then
  :new.modified_date := sysdate;
 end if;
else
 if :new.modified_date is null then
  :new.modified_date := sysdate;
 end if;
end if;
END;

/
ALTER TRIGGER "OLS_BANNERS_INS_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_CATEGORY_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_CATEGORY_INS" 
  before insert on "OLS_CATEGORY"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_CATEGORY_SEQ".nextval into :NEW.ID from dual; 
end if;
end; 

/
ALTER TRIGGER "OLS_CATEGORY_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_COUNTER_INS_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_COUNTER_INS_UPD" 
 BEFORE INSERT OR UPDATE ON OLS_COUNTER 
FOR EACH ROW 
declare
n_count number;
begin

   select count(*)
   into n_count
   from ols_counter_history
   where month = trunc(sysdate,'MM');
   
   if n_count > 0 then
      update ols_counter_history
      set    counter = counter + 1
      where month = trunc(sysdate,'MM');
   else
       insert into ols_counter_history values (trunc(sysdate,'MM'), 1);
   end if;

end;

/
ALTER TRIGGER "OLS_COUNTER_INS_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_COUNTRY_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_COUNTRY_INS" 
  before insert on "OLS_COUNTRY"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_COUNTRY_SEQ".nextval into :NEW.ID from dual; 
end if;
:NEW.ISO_CODE_1 := upper(:NEW.ISO_CODE_1);
:NEW.ISO_CODE_2 := upper(:NEW.ISO_CODE_2);
end;

/
ALTER TRIGGER "OLS_COUNTRY_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_CURRENCY_INS_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_CURRENCY_INS_UPD" 
 BEFORE INSERT or UPDATE ON OLS_CURRENCY 
 for each row
BEGIN
  :new.last_updated := sysdate;
  :new.code := upper(:new.code);
END;

/
ALTER TRIGGER "OLS_CURRENCY_INS_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_FAVORITES_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_FAVORITES_INS" 
  before insert on "OLS_FAVORITES"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_FAVORITES_SEQ".nextval into :NEW.ID from dual; 
end if;
end;

/
ALTER TRIGGER "OLS_FAVORITES_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_LINE_ITEMS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_LINE_ITEMS_INS" 
  before insert on "OLS_LINE_ITEMS"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_LINE_ITEMS_SEQ".nextval into :NEW.ID from dual; 
end if;
-- update points of a product
UPDATE ols_product
SET points = nvl(points,0) + 1
WHERE id = :NEW.PRODUCT_ID;

end;             

/
ALTER TRIGGER "OLS_LINE_ITEMS_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_MANUFACTURER_INS_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_MANUFACTURER_INS_UPD" 
 BEFORE INSERT or UPDATE ON OLS_MANUFACTURER
 for each row
BEGIN
if inserting then
  if :new.id is null then
     select nvl(max(id),0) + 1
     into :new.id 
     from ols_manufacturer;
  end if;
  :new.date_added := sysdate;
  :new.last_modified := sysdate;
else
  :new.last_modified := sysdate;
end if;
END;

/
ALTER TRIGGER "OLS_MANUFACTURER_INS_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_MESSAGES_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_MESSAGES_INS" 
  before insert on OLS_MESSAGES
  for each row  
begin   
if :NEW.ID is null then
    select OLS_MESSAGES_SEQ.nextval into :NEW.ID from dual; 
end if;
if :NEW.CREATED_DATE is null then
    select SYSDATE into :NEW.CREATED_DATE from dual; 
end if;

end;

/
ALTER TRIGGER "OLS_MESSAGES_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_NEWSLETTER_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_NEWSLETTER_INS" 
  before insert on OLS_NEWSLETTER
  for each row  
begin   
if :NEW.ID is null then
    select OLS_NEWSLETTER_SEQ.nextval into :NEW.ID from dual; 
end if;
if :NEW.CREATED_DATE is null then
    select SYSDATE into :NEW.CREATED_DATE from dual; 
end if;
end;

/
ALTER TRIGGER "OLS_NEWSLETTER_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_NEWS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_NEWS_INS" 
  before insert on OLS_NEWS
  for each row  
begin   
if :NEW.ID is null then
    select OLS_NEWS_SEQ.nextval into :NEW.ID from dual; 
end if;
if :NEW.DATE_ADDED is null then
    select SYSDATE into :NEW.DATE_ADDED from dual; 
end if;
if :NEW.ACTIVE in ('YES') then
    select SYSDATE into :NEW.DATE_SENT from dual; 
end if;
end;

/
ALTER TRIGGER "OLS_NEWS_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_NEWS_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_NEWS_UPD" 
  before update on OLS_NEWS
  for each row  
begin   
if :OLD.ACTIVE in ('NO') AND :NEW.ACTIVE in ('YES') then
    select SYSDATE into :NEW.DATE_SENT from dual; 
end if;
end;

/
ALTER TRIGGER "OLS_NEWS_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_PAYMENT_CC_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_PAYMENT_CC_INS" 
  before insert on "OLS_PAYMENT_CC_TYPE"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_PAYMENT_DETAILS_SEQ".nextval into :NEW.ID from dual; 
end if;
end; 

/
ALTER TRIGGER "OLS_PAYMENT_CC_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_PAYMENT_MODE_EX_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_PAYMENT_MODE_EX_INS" 
  before insert on "OLS_PAYMENT_MODE_EX"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_PAYMENT_MODE_SEQ".nextval into :NEW.ID from dual; 
end if;
end; 

/
ALTER TRIGGER "OLS_PAYMENT_MODE_EX_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_PAYMENT_MODE_IN_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_PAYMENT_MODE_IN_INS" 
  before insert on "OLS_PAYMENT_MODE_IN"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_PAYMENT_MODE_SEQ".nextval into :NEW.ID from dual; 
end if;
end; 


/
ALTER TRIGGER "OLS_PAYMENT_MODE_IN_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_PRODUCT_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_PRODUCT_INS" 
  before insert on "OLS_PRODUCT"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_PRODUCT_SEQ".nextval into :NEW.ID from dual; 
end if;
if :NEW.CREATED_DATE is null then
    :NEW.CREATED_DATE := sysdate; 
end if;
if :NEW.MODIFIED_DATE is null then
    :NEW.MODIFIED_DATE := sysdate; 
end if;
if :NEW.CREATED_BY_ID is null then
    select user into :NEW.CREATED_BY_ID from dual; 
end if;
if :NEW.MODIFIED_BY_ID is null then
    select user into :NEW.MODIFIED_BY_ID from dual; 
end if;
end; 

/
ALTER TRIGGER "OLS_PRODUCT_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_PRODUCT_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_PRODUCT_UPD" 
 BEFORE UPDATE ON OLS_PRODUCT 
FOR EACH ROW 
BEGIN   
if :NEW.MODIFIED_DATE is null then
    :NEW.MODIFIED_DATE := sysdate; 
end if;
if :NEW.MODIFIED_BY_ID is null then
    select user into :NEW.MODIFIED_BY_ID from dual; 
end if;
END;

/
ALTER TRIGGER "OLS_PRODUCT_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_REVIEWS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_REVIEWS_INS" 
 BEFORE INSERT ON OLS_REVIEWS 
FOR EACH ROW 
BEGIN
if :NEW.ID is null then
    select "OLS_REVIEW_SEQ".nextval into :NEW.ID from dual; 
end if;
END;

/
ALTER TRIGGER "OLS_REVIEWS_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_SALES_ORDER_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_SALES_ORDER_INS" 
  before insert on "OLS_SALES_ORDER"               
  for each row  

begin   
if :NEW.ID is null then
   select "OLS_SALES_ORDER_SEQ".nextval into :NEW.ID from dual; 
end if;
end;   

/
ALTER TRIGGER "OLS_SALES_ORDER_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_SHOPPING_CART_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_SHOPPING_CART_INS" 
 BEFORE INSERT ON OLS_SHOPPING_CART 
FOR EACH ROW 
BEGIN
  :new.created := sysdate;
END;

/
ALTER TRIGGER "OLS_SHOPPING_CART_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_SO_PAY_DETAILS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_SO_PAY_DETAILS_INS" 
  before insert on "OLS_SO_PAY_DETAILS"               
  for each row  
begin  
if :NEW.ID is null then 
    select "OLS_SO_PAY_DETAILS_SEQ".nextval into :NEW.ID from dual; 
end if;
end;             

/
ALTER TRIGGER "OLS_SO_PAY_DETAILS_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_STATES_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_STATES_INS" 
  before insert on "OLS_STATES"               
  for each row  

begin   
if :NEW.ID is null then
   select "OLS_STATES_SEQ".nextval into :NEW.ID from dual; 
end if;
end;   

/
ALTER TRIGGER "OLS_STATES_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_TAX_CLASS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_TAX_CLASS_INS" 
 BEFORE INSERT ON OLS_TAX_CLASS 
 for each row
BEGIN
  :new.date_added := sysdate;
  :new.last_modified := sysdate;
END;

/
ALTER TRIGGER "OLS_TAX_CLASS_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_TAX_CLASS_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_TAX_CLASS_UPD" 
 BEFORE UPDATE ON OLS_TAX_CLASS 
 for each row
BEGIN
  :new.last_modified := sysdate;
END;

/
ALTER TRIGGER "OLS_TAX_CLASS_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_TAX_RATES_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_TAX_RATES_INS" 
 BEFORE INSERT ON OLS_TAX_RATES 
 for each row
BEGIN
  :new.date_added := sysdate;
  :new.last_modified := sysdate;
END;

/
ALTER TRIGGER "OLS_TAX_RATES_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_TAX_RATES_UPD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_TAX_RATES_UPD" 
 BEFORE UPDATE ON OLS_TAX_RATES 
 for each row
BEGIN
  :new.last_modified := sysdate;
END;

/
ALTER TRIGGER "OLS_TAX_RATES_UPD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_USER_BILLING_DETAILS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_USER_BILLING_DETAILS_INS" 
  before insert on "OLS_CUST_BILLING_DETAILS"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_USER_BILLING_DETAILS_SEQ".nextval into :NEW.ID from dual; 
end if;
end; 

/
ALTER TRIGGER "OLS_USER_BILLING_DETAILS_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_USER_DETAILS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_USER_DETAILS_INS" 
  before insert on "OLS_CUSTOMER_DETAILS"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_USER_DETAILS_SEQ".nextval into :NEW.ID from dual; 
end if;
end;        

/
ALTER TRIGGER "OLS_USER_DETAILS_INS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger OLS_USER_SHIPPING_DETAILS_INS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "OLS_USER_SHIPPING_DETAILS_INS" 
  before insert on "OLS_CUST_SHIPPING_DETAILS"               
  for each row  
begin   
if :NEW.ID is null then
    select "OLS_USER_SHIPPING_DETAILS_SEQ".nextval into :NEW.ID from dual; 
end if;
end;

/
ALTER TRIGGER "OLS_USER_SHIPPING_DETAILS_INS" ENABLE;
--------------------------------------------------------
--  DDL for View OLS_PAYMENT_MODE
--------------------------------------------------------

  CREATE OR REPLACE VIEW "OLS_PAYMENT_MODE" ("DESCRIPTION", "ID") AS 
  select description, id from ols_payment_mode_in 
where available = 'Y' and (
select value
from   ols_configuration
where  key = 'INTERNAL_PAYMENT_ENABLED') ='Y' 
union
select description, id from ols_payment_mode_ex 
where available = 'Y' and (
select value
from   ols_configuration
where  key = 'INTERNAL_PAYMENT_ENABLED') ='N' 
order by id
 
 ;
/
--------------------------------------------------------
--  DDL for View OLS_SHOP_CART
--------------------------------------------------------

  CREATE OR REPLACE VIEW "OLS_SHOP_CART" ("PRODUCT_NAME", "C001", "C002") AS 
  SELECT product_name, c001, c002
     FROM   ols_product prod,
            htmldb_collections sc
     WHERE prod.id = sc.c001
     AND collection_name = 'SCCOLLECTION'
 
 ;
/
--------------------------------------------------------
--  DDL for View OLS_VW_CAT_PRODUCT
--------------------------------------------------------

  CREATE OR REPLACE VIEW "OLS_VW_CAT_PRODUCT" ("ID", "CATEGORY_NAME", "PARENT_ID") AS 
  select distinct id, category_name, parent_id
from ols_category 
start with id in (
select cat.id
from ols_category cat, ols_product prod 
where cat.id = prod.category_id and prod.availability = 'Yes' 
and trunc(prod.activation_date) <= trunc(sysdate)
)
connect by prior parent_id=id
 
 ;
/
--------------------------------------------------------
--  DDL for View OLS_VW_MAN_PRODUCT
--------------------------------------------------------

  CREATE OR REPLACE VIEW "OLS_VW_MAN_PRODUCT" ("ID", "NAME") AS 
  SELECT 
    man.ID, 
    CASE 
      WHEN man.NAME IS NULL THEN 'MANUFACTURER_OTHER' 
      ELSE man.NAME 
    END AS NAME 
FROM 
    OLS_MANUFACTURER man, 
    OLS_PRODUCT prod 
WHERE 
    man.ID(+) = prod.MANUFACTURER_ID AND prod.AVAILABILITY = 'Yes' AND TRUNC(prod.ACTIVATION_DATE) <= TRUNC(sysdate)
 
 ;
/
--------------------------------------------------------
--  DDL for Function OLS_CALCULATE_DELIVERY_DATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CALCULATE_DELIVERY_DATE" 
    RETURN DATE
  AS
    l_del_date DATE;
  BEGIN
    FOR i IN
    (SELECT t.max_days
       FROM htmldb_collections h   ,
      ols_estimated_delivery_time t,
      ols_shipping_types s
      WHERE collection_name      = 'SHIPMENT'
    AND s.estimated_ship_time_id = t.id
    AND s.id                     = h.c001
    )
    LOOP
      l_del_date := sysdate + i.max_days;
    END LOOP;
    RETURN NVL(l_del_date, sysdate);
  END OLS_CALCULATE_DELIVERY_DATE;

/

--------------------------------------------------------
--  DDL for Function OLS_CALCULATE_DEL_COST
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CALCULATE_DEL_COST" (p_id number) RETURN NUMBER AS
l_del_cost number;
BEGIN
 if p_id is not null then
 for r in (
       select
       z.id zone_id, country
       from ols_cust_shipping_details sd, ols_zones z
       where sd.id = p_id and z.code (+) = sd.state and z.country_id(+) = sd.country) loop
      for i in (select c001, c002, c003, c004 from htmldb_collections 
          where collection_name = 'SHIPMENT') loop 
          l_del_cost := OLS_ESTIMATE_DEL_COST(i.c001, r.COUNTRY, r.zone_id, i.c002,
                               i.c003, i.c004);
       end loop;
     end loop;
  else
     for r in (select z.id zone_id, cust.C009 country
               from htmldb_collections cust, ols_zones z
               where collection_name = 'SHIPTOCOLLECTION'
               and z.code (+) = cust.c007 and z.country_id (+) = cust.c009) loop
       for i in (select c001, c002, c003, c004 from htmldb_collections 
          where collection_name = 'SHIPMENT') loop 
          l_del_cost := OLS_ESTIMATE_DEL_COST(i.c001, r.COUNTRY, r.zone_id, i.c002,
                               i.c003, i.c004);
       end loop;
     end loop;

  end if;
  return nvl(l_del_cost, 0);
END OLS_CALCULATE_DEL_COST;

 
 

/

--------------------------------------------------------
--  DDL for Function OLS_CALCULATE_SUBTOTAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CALCULATE_SUBTOTAL" RETURN NUMBER AS
l_amount NUMBER;
BEGIN
  FOR i IN
    (SELECT SUM(round(prod.list_price * (1 - prod.discount/100),2) *sc.c002) amount
     FROM ols_product prod,
       htmldb_collections sc
     WHERE prod.id = sc.c001
     AND collection_name = 'SCCOLLECTION')
  LOOP
    l_amount := i.amount;
  END LOOP;
  RETURN nvl(l_amount,0);
END OLS_CALCULATE_SUBTOTAL;

 

 

/

--------------------------------------------------------
--  DDL for Function OLS_CALCULATE_TAX
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CALCULATE_TAX" (p_id number) RETURN NUMBER AS
l_amount NUMBER;
l_state VARCHAR2(100);
l_country_id NUMBER;
BEGIN

if htmldb_collection.collection_exists('SHIPTOCOLLECTION') = FALSE and p_id is null then -- ship address not entered
  FOR i IN
    (SELECT sum(round(ols_find_tax(prod.id, null, null) * sc.c002,2) ) amount
     FROM ols_product prod,
          htmldb_collections sc
     WHERE prod.id = sc.c001
     AND collection_name = 'SCCOLLECTION'
      )
  LOOP
    l_amount := i.amount;
  END LOOP;
elsif htmldb_collection.collection_exists('SHIPTOCOLLECTION') and p_id is null then -- ship address entered
  SELECT z.id state, c009 country_id
  INTO l_state, l_country_id
  FROM htmldb_collections h, ols_zones z
  WHERE collection_name = 'SHIPTOCOLLECTION' 
  and z.code (+) = h.c007
  and z.country_id (+) = h.c009;
  FOR i IN
    (SELECT sum(round(ols_find_tax(prod.id, l_country_id, l_state) * sc.c002,2) ) amount
     FROM ols_product prod,
          htmldb_collections sc
     WHERE prod.id = sc.c001
     AND collection_name = 'SCCOLLECTION'
      )
  LOOP
    l_amount := i.amount;
  END LOOP;
else
  SELECT z.id state, country country_id
  INTO l_state, l_country_id
  FROM ols_cust_shipping_details bd, ols_zones z
  WHERE bd.id = p_id and z.code (+) = bd.state and z.country_id (+) = bd.country;
  FOR i IN
    (SELECT  sum(round(ols_find_tax(prod.id, l_country_id, l_state) * sc.c002,2) ) amount
     FROM ols_product prod,
          htmldb_collections sc
     WHERE prod.id = sc.c001
     AND collection_name = 'SCCOLLECTION'
      )
  LOOP
    l_amount := i.amount;
  END LOOP;
end if;

  RETURN nvl(l_amount,0);
END OLS_CALCULATE_TAX;

 

 

/

--------------------------------------------------------
--  DDL for Function OLS_CALCULATE_TOTAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CALCULATE_TOTAL" (p_ship_id number, p_bill_id number) RETURN NUMBER AS
l_amount NUMBER;
-- p_bill_id is left for any future needs
BEGIN
l_amount := ols_calculate_subtotal +  ols_calculate_tax(p_ship_id) + ols_calculate_del_cost(p_ship_id);
  RETURN nvl(l_amount,0);
END OLS_CALCULATE_TOTAL;

 

 

/

--------------------------------------------------------
--  DDL for Function OLS_CATEGORY_CHILD
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CATEGORY_CHILD" (p_child_id number, p_parent_id number)
RETURN NUMBER AS
-- Returns 1 if p_child_id is a child of p_parent_id in ols_category. Otherwise returns 0
l_count number;
BEGIN
  SElECT count(*)
  INTO l_count
  FROM ols_category
  WHERE id = p_child_id and p_child_id in
  (select id
   from ols_category
   start with id = P_PARENT_ID
   connect by prior id = parent_id);  
  
  RETURN l_count;
exception when others then
 return 0;

END OLS_CATEGORY_CHILD;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_CAT_PROD_COUNT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CAT_PROD_COUNT" 
( p_id IN ols_category.id%type
) RETURN NUMBER AS
-- Returns the number of valid products assigned to category p_id and all of its subcategories
l_count NUMBER;
BEGIN
  SElECT count(*)
  INTO l_count
  FROM OLS_PRODUCT
  WHERE CATEGORY_ID in
  (select id
   from ols_cat_product
   start with id = P_ID
   connect by prior id = parent_id)
   AND availability = 'Yes'
   AND availability is not null
   AND trunc(activation_date) <= trunc(sysdate) ;  
  
  RETURN l_count;
exception when others then
 return 0;
END OLS_CAT_PROD_COUNT;

 

 
/

--------------------------------------------------------
--  DDL for Function OLS_CC_VALIDATION
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CC_VALIDATION" (p_cc_no in varchar2,
p_cc_type in number)
return boolean
is
lsChar varchar2(100);
lnSum number :=0;
lnMultiplier number :=0;
lnTotal number := 0;
lsNumber number;
lnDigit number;
IsCreditCard number;
excep_no_cc exception;
begin
   if (trim(p_cc_no) is null or length(p_cc_no) not in (13,14,15,16)) then
      return FALSE;
   else
      for i in 1..length(p_cc_no)
        loop
 	           lsChar := substr(p_cc_no, i, 1);
             lsNumber := to_number(lsNumber || lsChar);
        end loop;   			
        -- ====
        -- Choose action based on Type of card
    	Case
    	    -- VISA
    	    WHEN p_cc_type = 1 THEN
	              if substr(lsNumber, 1, 1) <> 4 Then 
                    return FALSE;
                 end if;
    	   -- American Express
           WHEN p_cc_type = 3 THEN
	               if substr(lsNumber, 1, 2) not in (34,37) Then 
                    return FALSE;
                 end if;
    	   -- Mastercard
           WHEN p_cc_type = 2 THEN
	               if substr(lsNumber, 1, 1) <> 5 Then 
                    return FALSE;
                 end if;
    	   -- Discover
           WHEN p_cc_type = 4 THEN
	               if substr(lsNumber, 1, 1) <> 6 Then 
                    return FALSE;
                 end if;
    	   -- Diners
           WHEN p_cc_type = 5 THEN
	               if substr(lsNumber, 1, 1) <> 3 Then 
                    return FALSE;
                 end if;
    	   -- JCB
           WHEN p_cc_type = 6 THEN
	               if substr(lsNumber, 1, 2) <> 35 Then 
                    return FALSE;
                 end if;                 
    	End case;
        -- Luhn algorithm
    	For lnPosition in length(p_cc_no)..1
          loop
            lnDigit := substr(lsNumber, lnPosition, 1);
  	        lnMultiplier := 1 + Mod(lnPosition,2);
            lnSum := lnDigit * lnMultiplier;
 	          if lnSum > 9 Then 
               lnSum := lnSum - 9;
            end if;
            lnTotal := lnTotal + lnSum;
          end loop;    			
    	-- ====
    	IsCreditCard := Mod(lnTotal,10);
        IF IsCreditCard = 0 then
           return TRUE;
        Else
           return FALSE;
        End If;
   end if;
EXCEPTION
	WHEN OTHERS THEN return FALSE;
end;
 
 

/

--------------------------------------------------------
--  DDL for Function OLS_CHECK_STOCK_CHECKOUT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CHECK_STOCK_CHECKOUT" RETURN VARCHAR2 AS
l_dummy varchar2(4000);

BEGIN
  select upper(nvl(value,'N'))
  into l_dummy
  from ols_configuration
  where key = 'STOCK_ALLOW_CHECKOUT';
  if l_dummy = 'Y' then
     return null;
  else
    l_dummy := null;
    for r in (select '<b>'||prod.product_name||'</b>' product_name, 
                     sc.c002 qty, sc.c001 prodid, nvl(prod.qoh,0) qoh
              from ols_product prod, htmldb_collections sc
              where prod.id = to_number(sc.c001)
              and sc.collection_name = 'SCCOLLECTION') loop
       if r.qty > r.qoh then
          l_dummy := l_dummy || htmldb_lang.message('OUT_OF_STOCK_MSG', r.product_name, r.qty, r.qoh) || '<br>';
       end if;
    end loop;         
    return l_dummy;
  end if;
     
END OLS_CHECK_STOCK_CHECKOUT;

 

 
/

--------------------------------------------------------
--  DDL for Function OLS_COUNT_SO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_COUNT_SO" (p_id number) RETURN NUMBER AS
BEGIN
  for i in (select count(*) c from ols_sales_order where customer_id = p_id) loop
     return i.c;
  end loop;
  return 0;
END OLS_COUNT_SO;
 
 
/

--------------------------------------------------------
--  DDL for Function OLS_CUSTOM_ADD_USER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CUSTOM_ADD_USER" (p_login_name IN varchar2,p_password IN OUT VARCHAR2)
return BOOLEAN
is
  l_password varchar2(4000);
begin
-- Function to store password supplied by user during registration in encrypted format
-- This function would be called after form is submitted. 
 l_password := ols_custom_hash(p_login_name , p_password);
 if l_password != p_password then
   p_password := l_password;
   return true;
 else
   return false;
 end if;
end;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_CUSTOM_HASH
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_CUSTOM_HASH" (p_username in varchar2, p_password in varchar2)
return varchar2
is
  l_password varchar2(4000);
  l_salt varchar2(4000) := 'TN3ASQRJAWPBOLPS5NW81QBSDPL73P';
  
begin
-- To print random l_salt
--begin
--dbms_output.put_line(dbms_random.string('X',30));
--end;

-- This function should be wrapped, as the hash algorithm is exposed here.
-- You can change the value of l_salt or the method of which to call the
-- DBMS_OBFUSCATOIN toolkit, but you must reset all of your passwords
-- if you choose to do so.
l_password := utl_raw.cast_to_raw(dbms_obfuscation_toolkit.md5
  (input_string => p_password || substr(l_salt,10,13) || p_username ||
    substr(l_salt, 4,10)));
return l_password;
end;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_ENTERED_BILL_SHIP_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_ENTERED_BILL_SHIP_DETAILS" (p_user_login varchar2, 
                                       p_ship_to_id number,
                                       p_bill_to_id number) RETURN boolean AS
l_count number; l_count1 number;
begin
  select count(*) 
   into  l_count
   from  ols_customer_details
   where login_id = p_user_login
   and   admin ='Yes';
  if l_count > 0 then
     return true;
  end if;

  select count(*)
  into   l_count
  from   htmldb_collections cust, ols_country ctry
  where  collection_name = 'SHIPTOCOLLECTION'
  and    to_number(cust.c009) = ctry.id;

  select count(*)
  into   l_count1
  from   ols_cust_shipping_details cust, ols_country ctry
  where  cust.id = p_ship_to_id
  and    cust.COUNTRY = ctry.id;

if l_count = 0 and l_count1 = 0  then
   return false;
end if;

  select count(*)
  into  l_count
  from  htmldb_collections cust, ols_country ctry
  where collection_name = 'BILLTOCOLLECTION'
  and   to_number(cust.c009) = ctry.id;

  select count(*)
  into  l_count1
  from  ols_cust_billing_details cust, ols_country ctry
  where cust.id = p_bill_to_id
  and   cust.COUNTRY = ctry.id;

if l_count = 0 and l_count1 = 0  then
   return false;
end if;

  -- do not allow page 5 usage in case of Paypal Express Checkout
  -- it is handled via page 82
  for r in ( select 1 from 
             ols_configuration c,
             ols_payment_mode_ex p
             where p.key = 'PEC'
             and p.available = 'Y'
             and c.key = 'INTERNAL_PAYMENT_ENABLED'
             and c.value = 'N' ) loop
             
    return false;
  end loop;

   return true;

exception when others then
   return false;
   
END OLS_ENTERED_BILL_SHIP_DETAILS;

 
 

/

--------------------------------------------------------
--  DDL for Function OLS_ENTERED_PAYMENT_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_ENTERED_PAYMENT_DETAILS" (p_user_login varchar2) 
RETURN boolean AS
l_count number;
begin
  select count(*) 
   into  l_count
   from  ols_customer_details
   where login_id = p_user_login
   and   admin ='Yes';
  if l_count > 0 then
     return true;
  end if;

   select count(*)
   into  l_count
   from  htmldb_collections
   where collection_name = 'PAYMENTCOLLECTION';
  if l_count = 0 then
     return false;
  end if;
  -- do not allow page 6 usage in case of Paypal Express Checkout
  -- it is handled via page 82, page 7 is allowed
  if v('APP_PAGE_ID') = 6 then
     for r in ( select 1 from 
             ols_configuration c,
             ols_payment_mode_ex p
             where p.key = 'PEC'
             and p.available = 'Y'
             and c.key = 'INTERNAL_PAYMENT_ENABLED'
             and c.value = 'N' ) loop
             
       return false;
     end loop;
  end if;
return true;

exception when others then
   return false;

END OLS_ENTERED_PAYMENT_DETAILS;

 
 

/

--------------------------------------------------------
--  DDL for Function OLS_ENTERED_PAYPAL_TRANS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_ENTERED_PAYPAL_TRANS" (p_app_session number, p_token varchar2)
RETURN boolean AS
BEGIN
-- This function returns true in case Paypal Express Checkout was set Ok
-- by ols_paypal_api.set_express_checkout procedure

-- skip admin
 if OLS_IS_ADMIN(htmldb_application.g_user) then
    return true;
 end if;
 
FOR i in (select 1
          from ols_paypal_session_map
          where session_id = p_app_session
          and session_token = p_token)
LOOP
   RETURN true;
END LOOP;

RETURN false;
END OLS_ENTERED_PAYPAL_TRANS;

 
 

/

--------------------------------------------------------
--  DDL for Function OLS_ESTIMATE_DEL_COST
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_ESTIMATE_DEL_COST" (p_shipping_type number, p_country_id number, p_zone_id number, p_weight number, p_amount number, p_quantity number) RETURN NUMBER AS
l_value number;
l_geo_zone_id number;
BEGIN
  if p_country_id is not null and nvl(p_zone_id,0) = 0 then
     for i in (select * from ols_zones 
               where country_id = p_country_id 
               and geo_zone_id is not null) loop
        l_geo_zone_id := i.geo_zone_id;
     end loop;
  end if;
  
  if p_country_id is not null and nvl(p_zone_id,0) != 0 then
     for i in (select * from ols_zones 
               where country_id = p_country_id 
               and id = p_zone_id
               and geo_zone_id is not null) loop
        l_geo_zone_id := i.geo_zone_id;
     end loop;
  end if;
  -- nothing is defined in ols_zones for country and zone id, do not handle this: Not shipped
  if l_geo_zone_id is null then
     return null;
  end if;
  
  for i in (select pt.name, t.free, t.max_weight
           from ols_shipping_types t, ols_shipping_price_types pt
           where t.id = p_shipping_type
           and t.based_on = pt.id (+)
           ) loop
    -- too heavy - not shipped
     if i.max_weight < nvl(p_weight,0) then
        return null;
     end if;
     if i.free = 'Y' then
        return 0;
     end if;
     -- amount based
     if i.name = 'AMOUNT' then
        for r in (select * from ols_shipping_amount_rates where amount = (
               select min(amount) from ols_shipping_amount_rates 
               where p_amount <= amount 
               and shipping_type_id = p_shipping_type
               and (geo_zone_id = to_char(l_geo_zone_id) or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id) ||':%' or 
                    geo_zone_id like to_char(l_geo_zone_id) || ':%' or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id)
                    or geo_zone_id is null)
              ) and shipping_type_id = p_shipping_type
                and (geo_zone_id = to_char(l_geo_zone_id) or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id) ||':%' or 
                    geo_zone_id like to_char(l_geo_zone_id) || ':%' or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id)
                    or geo_zone_id is null)
              
              ) loop
          return r.rate;
        end loop;
     end if;
     -- weight based
     if i.name = 'WEIGHT' then
        for r in (select * from ols_shipping_amount_rates where amount = (
               select min(amount) from ols_shipping_amount_rates 
               where p_weight <= amount
               and shipping_type_id = p_shipping_type
               and (geo_zone_id = to_char(l_geo_zone_id) or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id) ||':%' or 
                    geo_zone_id like to_char(l_geo_zone_id) || ':%' or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id)
                    or geo_zone_id is null)
              ) and shipping_type_id = p_shipping_type
                and (geo_zone_id = to_char(l_geo_zone_id) or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id) ||':%' or 
                    geo_zone_id like to_char(l_geo_zone_id) || ':%' or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id)
                    or geo_zone_id is null)
              
              ) loop
          return r.rate;
        end loop;
     end if;
     -- quantity based
     if i.name = 'QUANTITY' then
        for r in (select * from ols_shipping_amount_rates where amount = (
               select min(amount) from ols_shipping_amount_rates 
               where p_quantity <= amount
               and shipping_type_id = p_shipping_type
               and (geo_zone_id = to_char(l_geo_zone_id) or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id) ||':%' or 
                    geo_zone_id like to_char(l_geo_zone_id) || ':%' or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id)
                    or geo_zone_id is null)
              ) and shipping_type_id = p_shipping_type
                and (geo_zone_id = to_char(l_geo_zone_id) or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id) ||':%' or 
                    geo_zone_id like to_char(l_geo_zone_id) || ':%' or 
                    geo_zone_id like '%:'|| to_char(l_geo_zone_id)
                    or geo_zone_id is null)
              
              ) loop
          return r.rate;
        end loop;
     end if; 
  end loop;     
     
return null;
END OLS_ESTIMATE_DEL_COST;
 

/

--------------------------------------------------------
--  DDL for Function OLS_FIND_TAX
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_FIND_TAX" 
    (
      p_id         NUMBER,
      p_country_id NUMBER,
      p_zone_id    NUMBER)
    RETURN NUMBER
  AS
    l_geo_zone_id NUMBER;
  BEGIN
    IF p_country_id IS NULL AND NVL(p_zone_id,0) = 0 THEN
      BEGIN
         SELECT tax_geo_zone_id
           INTO l_geo_zone_id
           FROM ols_zones
          WHERE id =
          (SELECT value FROM ols_configuration WHERE KEY = 'STORE_ZONE'
          )
        AND country_id =
          (SELECT value FROM ols_configuration WHERE KEY = 'STORE_COUNTRY'
          );
      EXCEPTION
      WHEN OTHERS THEN
         SELECT tax_geo_zone_id
           INTO l_geo_zone_id
           FROM ols_zones
          WHERE rownum = 1;
      END;
    END IF;
    IF p_country_id IS NOT NULL AND NVL(p_zone_id,0) = 0 THEN
      FOR i         IN
      (SELECT        *
         FROM ols_zones
        WHERE country_id   = p_country_id
      AND tax_geo_zone_id IS NOT NULL
      )
      LOOP
        l_geo_zone_id := i.tax_geo_zone_id;
      END LOOP;
    END IF;
    IF p_country_id IS NOT NULL AND NVL(p_zone_id,0) != 0 THEN
      FOR i         IN
      (SELECT        *
         FROM ols_zones
        WHERE country_id   = p_country_id
      AND id               = p_zone_id
      AND tax_geo_zone_id IS NOT NULL
      )
      LOOP
        l_geo_zone_id := i.tax_geo_zone_id;
      END LOOP;
    END IF;
    FOR i          IN
    (SELECT (t.rate * round(p.list_price * (1 - p.discount/100),2) * 0.01) tax
       FROM ols_product p,
      ols_tax_rates t
      WHERE t.geo_zone_id = l_geo_zone_id
    AND t.class_id        = p.tax_class_id
    AND p.id              = p_id
    )
    LOOP
      RETURN round(i.tax,2);
    END LOOP;
    --- default to store country if nothing found
    BEGIN
       SELECT tax_geo_zone_id
         INTO l_geo_zone_id
         FROM ols_zones
        WHERE id =
        (SELECT value FROM ols_configuration WHERE KEY = 'STORE_ZONE'
        )
      AND country_id =
        (SELECT value FROM ols_configuration WHERE KEY = 'STORE_COUNTRY'
        );
      
      FOR i          IN
      (SELECT (t.rate * round(p.list_price * (1 - p.discount/100), 2) * 0.01) tax
         FROM ols_product p,
        ols_tax_rates t
        WHERE t.geo_zone_id = l_geo_zone_id
      AND t.class_id        = p.tax_class_id
      AND p.id              = p_id
      )
      LOOP
        RETURN round(i.tax,2);
      END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
      -- if Store zone and country is not defined
      -- in configuration or ols_zones table does not have entry for Store country and Zone
      RETURN 0;
    END;
    -- if store country tax_geo_zone_id is not defined in tax_rates, return 0
    RETURN 0;
  END OLS_FIND_TAX;

/

--------------------------------------------------------
--  DDL for Function OLS_FIND_TAX_DESCRIPTION
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_FIND_TAX_DESCRIPTION" 
    (
      p_id         NUMBER,
      p_country_id NUMBER,
      p_zone_id    NUMBER)
    RETURN VARCHAR2
  AS
    l_geo_zone_id NUMBER;
  BEGIN
    IF p_country_id IS NULL AND NVL(p_zone_id,0) = 0 THEN
      BEGIN
         SELECT tax_geo_zone_id
           INTO l_geo_zone_id
           FROM ols_zones
          WHERE id =
          (SELECT value FROM ols_configuration WHERE KEY = 'STORE_ZONE'
          )
        AND country_id =
          (SELECT value FROM ols_configuration WHERE KEY = 'STORE_COUNTRY'
          );
      EXCEPTION
      WHEN OTHERS THEN
         SELECT tax_geo_zone_id
           INTO l_geo_zone_id
           FROM ols_zones
          WHERE rownum = 1;
      END;
    END IF;
    IF p_country_id IS NOT NULL AND NVL(p_zone_id,0) = 0 THEN
      FOR i         IN
      (SELECT        *
         FROM ols_zones
        WHERE country_id   = p_country_id
      AND tax_geo_zone_id IS NOT NULL
      )
      LOOP
        l_geo_zone_id := i.tax_geo_zone_id;
      END LOOP;
    END IF;
    IF p_country_id IS NOT NULL AND NVL(p_zone_id,0) != 0 THEN
      FOR i         IN
      (SELECT        *
         FROM ols_zones
        WHERE country_id   = p_country_id
      AND id               = p_zone_id
      AND tax_geo_zone_id IS NOT NULL
      )
      LOOP
        l_geo_zone_id := i.tax_geo_zone_id;
      END LOOP;
    END IF;
    FOR i         IN
    (SELECT t.description tax
       FROM ols_product p,
            ols_tax_rates t
      WHERE t.geo_zone_id = l_geo_zone_id
    AND t.class_id            = p.tax_class_id
    AND p.id                  = p_id
    )
    LOOP
      RETURN i.tax;
    END LOOP;
        --- default to store country if nothing found
    BEGIN
       SELECT tax_geo_zone_id
         INTO l_geo_zone_id
         FROM ols_zones
        WHERE id =
        (SELECT value FROM ols_configuration WHERE KEY = 'STORE_ZONE'
        )
      AND country_id =
        (SELECT value FROM ols_configuration WHERE KEY = 'STORE_COUNTRY'
        );
      
      FOR i          IN
      (SELECT t.description tax
         FROM ols_product p,
              ols_tax_rates t
        WHERE t.geo_zone_id = l_geo_zone_id
      AND t.class_id        = p.tax_class_id
      AND p.id              = p_id
      )
      LOOP
        RETURN i.tax;
      END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
      -- if Store zone and country is not defined
      -- in configuration or ols_zones table does not have entry for Store country and Zone
        return htmldb_lang.message('NO_TAX_DESCR');--'Tax description not found';
    END;
    -- if store country tax_geo_zone_id is not defined in tax_rates, return 0
  return htmldb_lang.message('NO_TAX_DESCR');--'Tax description not found';    
END OLS_FIND_TAX_DESCRIPTION;
 

 

/

--------------------------------------------------------
--  DDL for Function OLS_ISVALIDUSER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_ISVALIDUSER" (p_username in VARCHAR2) return BOOLEAN is l_id number default null; 
begin 
select 1 into l_id from dual 
where exists (select id from ols_customer_details 
              where login_id = upper(p_username)); 
if (l_id = 1 ) then 
   return true; 
else 
   return false; 
end if; 
exception when no_data_found then 
   return false; 
end;

 
 

/

--------------------------------------------------------
--  DDL for Function OLS_IS_ADMIN
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_IS_ADMIN" (p_user_login varchar2) RETURN boolean AS
 l_count number;
begin
select count(*) into l_count
  from ols_customer_details
 where login_id = p_user_login
   and admin ='Yes';
if l_count > 0 then
  return true;
else
  return false;
end if;

END OLS_IS_ADMIN;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_IS_POTENTIAL_SHOPPER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_IS_POTENTIAL_SHOPPER" (p_user varchar2) RETURN boolean AS
l_count number;
begin
  select count(*) 
   into l_count
   from ols_customer_details
   where login_id = p_user --:APP_USER
   and admin ='Yes';
  if l_count > 0 then
     return true;
  end if;

if not ols_options.validate then
   return false;
end if;

if OLS_CHECK_STOCK_CHECKOUT is not null then
   return false;
end if;

   select count(*) into l_count
   from ols_product prod, htmldb_collections sc
   where prod.id = sc.c001 and (nvl(prod.availability, 'No') = 'No' 
                                or trunc(nvl(prod.activation_date, sysdate)) > trunc(sysdate)
                                )
   and sc.collection_name = 'SCCOLLECTION';
  if l_count > 0 then
     return false;
  end if;

 select count(*) into l_count
  from ols_product prod, htmldb_collections sc
 where prod.id = to_number(sc.c001)
   and sc.collection_name = 'SCCOLLECTION';
  if l_count > 0 then
     return true;
  end if;

return false;

END OLS_IS_POTENTIAL_SHOPPER;

 

 
/

--------------------------------------------------------
--  DDL for Function OLS_IS_SHIPPING_ENTERED
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_IS_SHIPPING_ENTERED" RETURN boolean AS
l_count number;
begin
  select count(*) 
   into l_count
   from ols_customer_details
   where login_id = htmldb_application.g_user
   and admin ='Yes';
  if l_count > 0 then
     return true;
  end if;

 select count(*) into l_count
  from htmldb_collections sc
 where sc.collection_name = 'SHIPMENT';
  if l_count > 0 then
     return true;
  end if;

return false;

END  OLS_IS_SHIPPING_ENTERED;

 

/

--------------------------------------------------------
--  DDL for Function OLS_NODEBUG
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_NODEBUG" (P_DEBUG varchar2) RETURN boolean AS
l_count NUMBER;
begin

select count(*) into l_count
  from ols_customer_details
 where login_id = v('APP_USER')
   and admin ='Yes';
if l_count > 0 then
  return true;
end if;

if nvl(P_DEBUG,'NO') = 'YES' then
   return false;
end if;
return true;
end OLS_NODEBUG;

 

 
/

--------------------------------------------------------
--  DDL for Function OLS_ONLINESTORE_AUTH
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_ONLINESTORE_AUTH" (p_username in VARCHAR2, p_password in VARCHAR2)
return BOOLEAN
is
  l_password varchar2(4000);
  l_stored_password varchar2(4000);
  l_expires_on date;
  l_count number;
begin
-- First, check to see if the user is in the user table
select count(*) into l_count from ols_customer_details where login_id = p_username;
if l_count > 0 then
  select password into l_stored_password
    from ols_customer_details where login_id = p_username;
   l_password := ols_custom_hash(p_username, p_password);
   if l_password = l_stored_password then
      return true;
   else
      return false;
   end if;
else
  return false;
end if;
end;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_PRINT_OPTIONS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_PRINT_OPTIONS" (p_line_id number) RETURN VARCHAR2 AS
-- Used in page 53 to print Packing Slip
l_result varchar2(1000);
BEGIN
  FOR i in (SELECT option_name||': '||l.option_value||'<br>' opt
            FROM ols_line_item_options l, ols_product_options p
            WHERE l.line_item_id = p_line_id
            AND   l.product_option_id = p.id) LOOP
            l_result := l_result || i.opt;
  END LOOP;
  l_result := rtrim(l_result,'<br>');
  RETURN l_result;
END OLS_PRINT_OPTIONS;

/

--------------------------------------------------------
--  DDL for Function OLS_PRINT_PRODUCTS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_PRINT_PRODUCTS" RETURN VARCHAR2 AS
    l_product_name VARCHAR2(32000);
    l_currency VARCHAR2(10);
    l_option_ids  VARCHAR2(4000);
    l_values      VARCHAR2(4000);
    l_option_name VARCHAR2(4000);
    l_vc_arr1    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;
    l_vc_arr2    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;
BEGIN
  FOR r IN (SELECT value FROM ols_configuration WHERE key = 'DEFAULT_CURRENCY') 
  LOOP
     l_currency := r.value;
  END LOOP;
  
  l_currency := nvl(l_currency, 'USD');

  FOR i IN
    (SELECT prod.id, t.product_name(prod.id,v('LANG_ID')) product_name, sc.c002 quantity, round(list_price * (1 - prod.discount/100), 2)* sc.c002 total
     FROM ols_product prod,
       htmldb_collections sc
     WHERE prod.id = sc.c001
     AND collection_name = 'SCCOLLECTION')
  LOOP
      -- set options
    ols_options.collection_to_string(i.id, l_option_ids, l_values);
    if l_option_ids is not null then
         l_vc_arr1 := HTMLDB_UTIL.STRING_TO_TABLE(l_option_ids);
         for s in 1..l_vc_arr1.count loop
            select option_name into l_option_name
            from ols_product_options 
            where id = to_number(l_vc_arr1(s));
            l_vc_arr2(s) := l_option_name;
         end loop;
         l_option_ids := HTMLDB_UTIL.TABLE_TO_STRING(l_vc_arr2);
         l_values :=  'Item Options: ' || substr(l_option_ids ||' '|| l_values, 1, 127);
    end if;
    l_product_name := l_product_name || 'Item Name: ' || i.product_name
                      || chr(10) || l_values
                      || chr(10) || 'Item Number: ' || i.id
                      || chr(10) || 'Quantity: ' || i.quantity
                      || chr(10) || 'Total: ' 
                      || ols_show_price(i.total, l_currency) || chr(10) || chr(10);
  END LOOP;
  RETURN rtrim(l_product_name,chr(10));
END OLS_PRINT_PRODUCTS;

 

 

/

--------------------------------------------------------
--  DDL for Function OLS_PRINT_SHIP_NOTICE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_PRINT_SHIP_NOTICE" 
    (
      p_so_id NUMBER)
    RETURN VARCHAR2
  AS
    l_weight_unit VARCHAR2(20);
    l_weight VARCHAR2(100);
    l_result VARCHAR2(2000);
    l_sql VARCHAR2(2000);
    l_error VARCHAR2(2000);
  BEGIN
  
    l_weight  := htmldb_lang.message('WEIGHT');
    FOR i IN
    (SELECT value FROM ols_configuration WHERE KEY = 'DEFAULT_WEIGHT_UNIT'
    )
    LOOP
      l_weight_unit := i.value;
    END LOOP;
    IF p_so_id IS NULL THEN
      FOR i    IN
      (SELECT st.shipping_name,
              spt.name based_on,
              c002 weight            
         FROM ols_shipping_types st, ols_shipping_price_types spt,
        htmldb_collections c
        WHERE c.collection_name = 'SHIPMENT'
        AND   c.c001            = st.id
        AND   spt.id(+)         = st.based_on
      )
      LOOP
        IF i.based_on IS NULL THEN
          RETURN i.shipping_name;
        ELSIF i.based_on = 'WEIGHT' THEN
          l_result :=  i.shipping_name || ', ' || l_weight || ': ' || i.weight || l_weight_unit;
        ELSIF i.based_on = 'QUANTITY' THEN
          l_result := i.shipping_name || ', payment based on quantity';
        ELSIF i.based_on = 'AMOUNT' THEN
          l_result := i.shipping_name || ', payment based on amount';
        ELSE
          l_result := i.shipping_name || ', payment based on ' || lower(i.based_on);        
        END IF;
      END LOOP;
      RETURN l_result;
    ELSE
      FOR i IN
      (SELECT shipping_notice FROM ols_sales_order WHERE id = p_so_id
      )
      LOOP
        RETURN i.shipping_notice;
      END LOOP;
    END IF;
    
    RETURN NULL;

  END OLS_PRINT_SHIP_NOTICE;

/

--------------------------------------------------------
--  DDL for Function OLS_SHOW_DELIVERY_ADDRESS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_SHOW_DELIVERY_ADDRESS" RETURN BOOLEAN AS
l_count number;
BEGIN
  select count(*)
  into l_count
  from ols_product prod, htmldb_collections sc
  where prod.id = sc.c001 and nvl(prod.download,'N') = 'N'
  and sc.collection_name = 'SCCOLLECTION';
   
   return l_count > 0;
   
END OLS_SHOW_DELIVERY_ADDRESS;

 

 
/

--------------------------------------------------------
--  DDL for Function OLS_SHOW_PRICE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_SHOW_PRICE" (p_price number, p_currency_code varchar2, p_override_display_price varchar2 default 'N') RETURN VARCHAR2 AS
l_value   varchar2(100);
l_mask    varchar2(100);
l_decimal varchar2(100);
l_display_price boolean := true;
BEGIN
 for i in (select nvl(value,'N') from ols_configuration where key = 'PRODUCT_PRICE' and nvl(value,'N') = 'N') loop
    l_display_price := false;
 end loop;
 -- does not show price on page 1
 if htmldb_application.g_flow_step_id = 1 and not l_display_price and p_override_display_price = 'N' then
    return null;
 end if;
 for r in (select * from ols_currency where code = p_currency_code) loop
       
       r.decimal_places := nvl(r.decimal_places,2); 
       r.decimal_point := nvl(r.decimal_point,'.');
       r.thousands_point := nvl(r.thousands_point,',');
       select trim(lpad(' ',to_number(r.decimal_places)+1,'9'))
       into l_decimal
       from dual;
       l_mask := '99G999D' || l_decimal;
     if r.symbol_left is null then
        l_mask := l_mask || 'L';
        SELECT TO_CHAR(p_price * r.value, l_mask,
         'NLS_NUMERIC_CHARACTERS = ' || ''''|| r.decimal_point  || r.thousands_point 
         || '''' || '   NLS_CURRENCY = '''
         || r.symbol_right || '''')
        INTO l_value
        FROM dual;
     else
        l_mask := 'L' || l_mask;
        SELECT TO_CHAR(p_price * r.value, l_mask,
         'NLS_NUMERIC_CHARACTERS = ' || '''' || r.decimal_point || r.thousands_point 
         || '''' || '   NLS_CURRENCY = '''
         || r.symbol_left || '''')
        INTO l_value
        FROM dual;
     end if;
     return l_value;
  end loop;

 for r in (select c.* from ols_currency c, ols_configuration co
           where c.code = co.value and co.key = 'DEFAULT_CURRENCY') loop
       
       r.decimal_places := nvl(r.decimal_places,2); 
       r.decimal_point := nvl(r.decimal_point,'.');
       r.thousands_point := nvl(r.thousands_point,',');
       select trim(lpad(' ',to_number(r.decimal_places)+1,'9'))
       into l_decimal
       from dual;
       l_mask := '99G999D' || l_decimal;
     if r.symbol_left is null then
        l_mask := l_mask || 'L';
        SELECT TO_CHAR(p_price * r.value, l_mask,
         'NLS_NUMERIC_CHARACTERS = ' || ''''|| r.decimal_point  || r.thousands_point 
         || '''' || '   NLS_CURRENCY = '''
         || r.symbol_right || '''')
        INTO l_value
        FROM dual;
     else
        l_mask := 'L' || l_mask;
        SELECT TO_CHAR(p_price * r.value, l_mask,
         'NLS_NUMERIC_CHARACTERS = ' || '''' || r.decimal_point || r.thousands_point 
         || '''' || '   NLS_CURRENCY = '''
         || r.symbol_left || '''')
        INTO l_value
        FROM dual;
     end if;
     return l_value;
  end loop;
 
   SELECT TO_CHAR(p_price,'L99G999D99') 
   INTO l_value 
   FROM dual; 
   return  l_value;
END OLS_SHOW_PRICE;

 

 
/

--------------------------------------------------------
--  DDL for Function OLS_SHOW_STOCK_AVAILABILITY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_SHOW_STOCK_AVAILABILITY" (p_id number) RETURN VARCHAR2 AS
l_dummy varchar2(100);
l_qoh number;
BEGIN
  select upper(nvl(value,'N'))
  into l_dummy
  from ols_configuration
  where key = 'STOCK_CHECK';
  if l_dummy = 'Y' then
     select qoh 
     into  l_qoh 
     from  ols_product
     where id = p_id;
        
     if l_qoh <= 0 then
        select nvl(value,'***')
        into   l_dummy
        from   ols_configuration
        where  key = 'STOCK_MARK_PRODUCT_OUT_OF_STOCK';
        return l_dummy;
     else
        return 'Yes';
     end if;
  else
     return 'Yes';
  end if;
     
END OLS_SHOW_STOCK_AVAILABILITY;

 

 

/

--------------------------------------------------------
--  DDL for Function OLS_SHOW_TAX
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_SHOW_TAX" (p_id number) RETURN VARCHAR2 AS
BEGIN
  
  for r in (select rate from ols_tax_rates where id = p_id) loop
     return r.rate || '%';
  end loop;
  
END OLS_SHOW_TAX;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_SO_EXISTS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_SO_EXISTS" (p_so_id number, p_session_id number, p_login varchar2) RETURN BOOLEAN AS
BEGIN
 if OLS_IS_ADMIN(p_login) then
    return true;
 end if;
 for r in (select 1 from ols_sales_order 
           where id = p_so_id and session_id = p_session_id) loop
     RETURN true;
 end loop;
 
 for r in (select 1 from ols_sales_order so, ols_customer_details cd
           where so.id = p_so_id and so.customer_id = cd.id
           and cd.login_id = p_login  ) loop
     RETURN true;
 end loop;
 return false;
 exception when others then
    return false;
END OLS_SO_EXISTS;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_VALIDATE_FK
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_VALIDATE_FK" (p_table varchar2, p_pk_value number) 
  RETURN VARCHAR2 AS
  l_count number;
  l_error varchar2(4000);
BEGIN
  if p_pk_value is NULL then 
     RETURN NULL;
  end if;
  for c in (select * from user_constraints
            where table_name = p_table
            and   constraint_type = 'P') loop
    
      for r in (select ucc.* from user_constraints uc, user_cons_columns ucc
                where uc.r_constraint_name = c.constraint_name
                and uc.constraint_name = ucc.constraint_name
                and uc.status = 'ENABLED'
                and uc.constraint_type = 'R'
                and uc.delete_rule ='NO ACTION') loop
                
         execute immediate 'select count(*) from ' || r.table_name
                           || ' where ' || r.column_name || '=' 
                           || p_pk_value
                           into l_count;
         if l_count > 0 then
             l_error := l_error || '<br>'
                        || htmldb_lang.message('FK_VIOLATION', r.table_name);
          end if;
      end loop;
  end loop;
                
  RETURN ltrim(l_error, '<br>');
END OLS_VALIDATE_FK;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_VALIDATE_LENGTH
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_VALIDATE_LENGTH" (p_table varchar2, p_column varchar2, p_value clob) 
  RETURN VARCHAR2 AS

  l_error varchar2(4000);
BEGIN
  for c in (select * from user_tab_columns
            where table_name = upper(p_table)
            and   column_name = upper(p_column)
            and   length(trim(p_value)) > data_length)  loop
             l_error := htmldb_lang.message('LENGTH_VIOLATION', p_table,
                                               p_column, c.data_length, length(trim(p_value)));
  end loop;             
  RETURN l_error;
END OLS_VALIDATE_LENGTH;

 
 
/

--------------------------------------------------------
--  DDL for Function OLS_VALIDATE_PASSWORD
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "OLS_VALIDATE_PASSWORD" 
(p_user_name in VARCHAR2,
p_password in VARCHAR2)
return BOOLEAN
is
l_password varchar2(500);
l_success boolean;
l_old_password varchar2(500);
begin
l_old_password := p_password;
l_success := ols_custom_add_user(p_user_name,l_old_password);
if l_success  then
  select password into l_password from ols_customer_details where login_id = p_user_name;
  if (l_password = l_old_password ) then 
    return true;
  else
    return false;
  end if;
else
  return false;
end if;
exception 
  when no_data_found then
    return false;
end;

 
 
/

--------------------------------------------------------
--  DDL for Package OLS_CART
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "OLS_CART" AS

PROCEDURE ADD
( p_id htmldb_collections.c001%type
);

PROCEDURE DELETE
( p_id htmldb_collections.c001%type
);

PROCEDURE DELETE_ALL
;

PROCEDURE MOVE_TO_FAV( p_id htmldb_collections.c001%type,
p_customer_id number
);
END OLS_CART;

 
 
/

--------------------------------------------------------
--  DDL for Package OLS_OPTIONS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "OLS_OPTIONS" AS

PROCEDURE ADD
( p_id htmldb_collections.c001%type,
  p_option_id number,
  p_option_value varchar2
);

FUNCTION SHOW_LINK( p_id htmldb_collections.c001%type 
) RETURN VARCHAR2;

FUNCTION VALIDATE RETURN BOOLEAN;

PROCEDURE init_collection(p_login VARCHAR2);

PROCEDURE collection_to_string(p_id NUMBER, p_option_ids OUT VARCHAR2, p_values OUT VARCHAR2);

END OLS_OPTIONS;

 
 
/

--------------------------------------------------------
--  DDL for Package OLS_PAYPAL_API
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "OLS_PAYPAL_API" 
as

function do_post(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_method                in varchar2,
    p_parm01                in varchar2,
    p_parm02                in varchar2 default null,
    p_parm03                in varchar2 default null,
    p_parm04                in varchar2 default null,
    p_parm05                in varchar2 default null,
    p_parm06                in varchar2 default null,
    p_parm07                in varchar2 default null,
    p_parm08                in varchar2 default null,
    p_parm09                in varchar2 default null,
    p_parm10                in varchar2 default null )
    return varchar2;

function get_parameter(
    p_response              in varchar2,
    p_parameter             in varchar2 )
    return varchar2;

procedure set_express_checkout(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_return_page           in varchar2,
    p_payerid_item          in varchar2,
    p_redirect_url          in varchar2,
    p_return_url            in varchar2,
    p_cancel_url            in varchar2,
    p_amount                in varchar2,
    p_description           in varchar2,
    p_currency              in varchar2,
    p_token_item            out varchar2 );

procedure get_express_checkout_details(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_token                 in varchar2,
    p_email_item            out varchar2,
    p_fname_item            out varchar2,
    p_mname_item            out varchar2,
    p_lname_item            out varchar2,
    p_shiptoname_item       out varchar2,
    p_shiptostreet_item     out varchar2,
    p_shiptostreet2_item    out varchar2,
    p_shiptocity_item       out varchar2,
    p_shiptocc_item         out varchar2,
    p_shiptostate_item      out varchar2,
    p_shiptozip_item        out varchar2,
    p_phonenum_item         out varchar2 );

procedure do_express_checkout_payment(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_token                 in varchar2,
    p_payerid               in varchar2,
    p_amount                in varchar2,
    p_description           in varchar2,
    p_item_post             in varchar2,
    p_currency              in varchar2);

procedure do_direct_payment(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_ip_address            in varchar2,
    p_amount                in varchar2,
    p_creditcardtype        in varchar2,
    p_account               in varchar2,
    p_expire_date           in varchar2,
    p_first_name            in varchar2,
    p_last_name             in varchar2,
    p_description           in varchar2,
    p_currency              in varchar2,
    p_item_post             in varchar2,
    p_address               in varchar2,
    p_tran_id_item          out varchar2 );


end ols_paypal_api;


 
 

/

--------------------------------------------------------
--  DDL for Package OLS_PRINT_SYLK_FORMAT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "OLS_PRINT_SYLK_FORMAT" as
--
  type owaSylkArray is table of varchar2(2000);
--
  procedure show(
      p_query         in varchar2,
      p_parm_names    in owaSylkArray default owaSylkArray(),
      p_parm_values   in owaSylkArray default owaSylkArray(),
      p_sum_column    in owaSylkArray default owaSylkArray(),
      p_max_rows      in number     default 10000,
      p_show_null_as  in varchar2   default null,
      p_show_grid     in varchar2   default 'YES',
      p_show_col_headers in varchar2 default 'YES',
      p_font_name     in varchar2   default 'Courier New',
      p_widths        in owaSylkArray default owaSylkArray(),
      p_titles        in owaSylkArray default owaSylkArray(),
      p_strip_html    in varchar2   default 'YES' );
--
  procedure show(
      p_cursor        in integer,
      p_sum_column    in owaSylkArray  default owaSylkArray(),
      p_max_rows      in number     default 10000,
      p_show_null_as  in varchar2   default null,
      p_show_grid     in varchar2   default 'YES',
      p_show_col_headers in varchar2 default 'YES',
      p_font_name     in varchar2   default 'Courier New',
      p_widths        in owaSylkArray default owaSylkArray(),
      p_titles        in owaSylkArray default owaSylkArray(),
      p_strip_html    in varchar2   default 'YES' );
--
  PROCEDURE get_usable_sql (p_sql_in IN VARCHAR2, p_sql_out OUT VARCHAR2);
end ols_print_sylk_format;
 
 
/

--------------------------------------------------------
--  DDL for Package T
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "T" AS

  function category_name(p_id number, p_lang_id number) return VARCHAR2;
  function product_name(p_id number, p_lang_id number) return VARCHAR2;
  function short_description(p_id number, p_lang_id number) return VARCHAR2;
  function long_description(p_id number, p_lang_id number) return VARCHAR2;
  
END T;

/

--------------------------------------------------------
--  DDL for Package Body OLS_CART
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "OLS_CART" AS

PROCEDURE ADD
( p_id htmldb_collections.c001%type
) AS
l_prod_count number;
l_qty number;
l_seq number;
Begin 
  for i in (select 1 from ols_product pro
           where pro.id = p_id
           and pro.availability = 'Yes'
           and pro.activation_date <= trunc(sysdate) ) LOOP  
     if htmldb_collection.collection_exists( 'SCCOLLECTION') = FALSE then
        htmldb_collection.create_collection( p_collection_name => 'SCCOLLECTION' );
        commit;
     end if;

     select count(c001) into l_prod_count
     from htmldb_collections
     where collection_name = 'SCCOLLECTION'
      and c001 = P_ID;

     If l_prod_count > 0 then
       select c002, seq_id into l_qty, l_seq
         from htmldb_collections
        where c001 = P_ID
          and collection_name = 'SCCOLLECTION';
       
        l_qty := l_qty + 1;
       
        htmldb_collection.update_member(
        p_collection_name => 'SCCOLLECTION',
        p_seq             => l_seq,
        p_c001            => P_ID,
        p_c002            => l_qty);
        commit;

     else
       htmldb_collection.add_member(
            p_collection_name => 'SCCOLLECTION',
            p_c001            => P_ID,
            p_c002            => 1);
      commit;
    End IF;
  end loop;
END ADD;

PROCEDURE DELETE
( p_id htmldb_collections.c001%type
) AS
l_seq number;
begin
  select seq_id into l_seq
    from htmldb_collections
   where c001 = P_ID
     and collection_name = 'SCCOLLECTION';

    htmldb_collection.delete_member(
        p_collection_name => 'SCCOLLECTION',
        p_seq             => l_seq);

  for r in (select seq_id 
            from htmldb_collections
            where c001 = P_ID
            and collection_name = 'OPTIONS') loop
       htmldb_collection.delete_member(
        p_collection_name => 'OPTIONS',
        p_seq             => r.seq_id);
  end loop;
  commit;
exception when others then null;
end DELETE;

PROCEDURE DELETE_ALL
AS
begin
HTMLDB_COLLECTION.TRUNCATE_COLLECTION(
        p_collection_name => 'SCCOLLECTION');
 begin
    HTMLDB_COLLECTION.TRUNCATE_COLLECTION(
        p_collection_name => 'OPTIONS');  
    exception when others then null;
 end;

 begin
    HTMLDB_COLLECTION.TRUNCATE_COLLECTION(
        p_collection_name => 'SHIPMENT');  
    exception when others then null;
 end;
 
exception when others then null;
end;

PROCEDURE MOVE_TO_FAV( p_id htmldb_collections.c001%type,
p_customer_id number
) AS
l_seq number;
l_count number;
begin
  select seq_id into l_seq
    from htmldb_collections
   where c001 = p_id
     and collection_name = 'SCCOLLECTION';
  select count(*) into l_count
    from ols_favorites
   where product_id = p_id
     and customer_id = p_customer_id;
  if l_count = 0 then
     insert into 
     ols_favorites (product_id, creation_date, customer_id)
     values        (p_id, sysdate, p_customer_id);
  end if;   

ols_cart.DELETE( p_id);

  commit;
exception when others then null;
end;

END OLS_CART;

/

--------------------------------------------------------
--  DDL for Package Body OLS_OPTIONS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "OLS_OPTIONS" AS
PROCEDURE ADD
( p_id htmldb_collections.c001%type,
  p_option_id number,
  p_option_value varchar2
) AS
l_prod_count number;
l_seq number;
Begin 
  if htmldb_collection.collection_exists( 'OPTIONS') = FALSE then
     htmldb_collection.create_collection( p_collection_name => 'OPTIONS' );
     commit;
  end if;

   select count(c001) into l_prod_count
     from htmldb_collections
    where collection_name = 'OPTIONS'
      and c001 = P_ID
      and c002 = p_option_id;

     If l_prod_count > 0 then
       select seq_id into l_seq
         from htmldb_collections
        where c001 = P_ID
          and c002 = p_option_id
          and collection_name = 'OPTIONS';
       
       
     htmldb_collection.update_member(
        p_collection_name => 'OPTIONS',
        p_seq             => l_seq,
        p_c001            => P_ID,
        p_c002            => p_option_id,
        p_c003            => p_option_value);
    commit;

    else
       htmldb_collection.add_member(
            p_collection_name => 'OPTIONS',
            p_c001            => P_ID,
            p_c002            => p_option_id,
            p_c003            => p_option_value);
      commit;
    End IF;
END ADD;

FUNCTION SHOW_LINK( p_id htmldb_collections.c001%type
) RETURN VARCHAR2 AS
l_return varchar2(32000);
Begin 

   for r in (select option_name, c003 opt_val
             from htmldb_collections, ols_product_options
             where collection_name = 'OPTIONS'
              and c001 = P_ID and c002 = id order by option_name) loop
       l_return := l_return || r.option_name || ': '|| r.opt_val || '<br>';
    end loop;
    l_return := rtrim(l_return,'<br>');
    
   for r in (select 1
             from ols_product_to_pr_options
             where product_id = P_ID) loop
       if l_return is null then
          l_return := 'Add';
       end if;
       exit;
    end loop; 
    
    if l_return is not null then
       l_return := htf.anchor2 (
       curl => 'javascript:popUp2(''f?p='||v('APP_ID')||':34:'||v('SESSION')
       ||'::NO::P1_ID:'||P_ID||''',500,500)', 
       ctext => l_return, cname => null, ctarget => null, cattributes =>  null);
    end if;
    
    return l_return;
END SHOW_LINK;

FUNCTION VALIDATE RETURN BOOLEAN AS

Begin 

   for r in (select h1.c001
             from htmldb_collections h1, htmldb_collections h2, ols_product_to_pr_options po
             where h1.collection_name (+) = 'OPTIONS'
              and h2.collection_name = 'SCCOLLECTION'
              and h1.c001 (+) = h2.c001
              and h2.c001 = po.product_id
              ) loop
       if r.c001 is null then
          return false;
       end if;
    end loop;

    return true;
END VALIDATE;

PROCEDURE collection_to_string(p_id NUMBER, p_option_ids OUT VARCHAR2, p_values OUT VARCHAR2) AS

BEGIN
    p_option_ids := null;
    p_values := null; 
    for r in (select h1.c002 opt, h1.c003 val
             from htmldb_collections h1, htmldb_collections h2
             where h1.collection_name  = 'OPTIONS'
              and h2.collection_name = 'SCCOLLECTION'
              and h1.c001 = h2.c001
              and h2.c001 = p_id
              ) loop
       p_option_ids := p_option_ids||r.opt||':';
       p_values := p_values||r.val||':';
    end loop;
    p_option_ids := rtrim(p_option_ids,':');
    p_values := rtrim(p_values,':');    
END;

PROCEDURE init_collection(p_login VARCHAR2) AS
       l_vc_arr1    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;
       l_vc_arr2    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;       
BEGIN

   for r in (select * from ols_shopping_cart where session_id = p_login
              ) loop
       l_vc_arr1 := HTMLDB_UTIL.STRING_TO_TABLE(r.options);
       l_vc_arr2 := HTMLDB_UTIL.STRING_TO_TABLE(r.option_values);
       for i in 1..l_vc_arr1.count loop
          add(r.product_id, l_vc_arr1(i), l_vc_arr2(i));
       end loop;
    end loop;
    
END;

END OLS_OPTIONS;

/

--------------------------------------------------------
--  DDL for Package Body OLS_PAYPAL_API
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "OLS_PAYPAL_API" 
as

function do_post(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_method                in varchar2,
    p_parm01                in varchar2,
    p_parm02                in varchar2 default null,
    p_parm03                in varchar2 default null,
    p_parm04                in varchar2 default null,
    p_parm05                in varchar2 default null,
    p_parm06                in varchar2 default null,
    p_parm07                in varchar2 default null,
    p_parm08                in varchar2 default null,
    p_parm09                in varchar2 default null,
    p_parm10                in varchar2 default null )
    return varchar2
is
    l_http_req       utl_http.req;
    l_http_resp      utl_http.resp;
    l_response       varchar2(4000);
    l_post           varchar2(32000);
begin

    l_post := 'USER='||p_api_username||'&PWD='||p_api_password||'&SIGNATURE='||p_signature||
        '&'||p_parm01;

    if p_parm02 is not null then
        l_post := l_post||'&'||p_parm02;
    end if;
    if p_parm03 is not null then
        l_post := l_post||'&'||p_parm03;
    end if;
    if p_parm04 is not null then
        l_post := l_post||'&'||p_parm04;
    end if;
    if p_parm05 is not null then
        l_post := l_post||'&'||p_parm05;
    end if;
    if p_parm06 is not null then
        l_post := l_post||'&'||p_parm06;
    end if;
    if p_parm07 is not null then
        l_post := l_post||'&'||p_parm07;
    end if;
    if p_parm08 is not null then
        l_post := l_post||'&'||p_parm08;
    end if;
    if p_parm09 is not null then
        l_post := l_post||'&'||p_parm09;
    end if;
    if p_parm10 is not null then
        l_post := l_post||'&'||p_parm10;
    end if;

    l_post := l_post||'&VERSION=2.6&METHOD='||p_method;

    utl_http.set_proxy(htmldb_application.g_proxy_server, NULL);
    utl_http.set_persistent_conn_support(TRUE);
    utl_http.set_transfer_timeout(300);
    utl_http.set_wallet(p_wallet, p_wallet_pwd);
    l_http_req := utl_http.begin_request(p_api_url, 'POST');
    utl_http.set_header(l_http_req, 'Proxy-Connection', 'Keep-Alive');
    utl_http.set_header(l_http_req, 'Content-Type', 'application/x-www-form-urlencoded; charset=utf-8');
    utl_http.set_header(l_http_req, 'Content-Length', length(l_post));
    utl_http.write_text(l_http_req, l_post);
    l_http_resp := utl_http.get_response(l_http_req);
    utl_http.read_text(l_http_resp, l_response);

    utl_http.end_response (l_http_resp);

    return utl_url.unescape(l_response);

end do_post;

function get_parameter(
    p_response              in varchar2,
    p_parameter             in varchar2 )
    return varchar2
is
    l_start     number;
    l_end       number;

begin

    if instr(p_response,p_parameter||'=') = 0 then
        return null;
    end if;

    l_start := instr(p_response,p_parameter||'=') + length(p_parameter) + 1;
    l_end := instr(p_response,'&',l_start);

    if l_end != 0 then
        return substr(p_response,l_start,l_end - l_start);
    else
        return substr(p_response,l_start);
    end if;

end get_parameter;

procedure set_express_checkout(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_return_page           in varchar2,
    p_payerid_item          in varchar2,
    p_redirect_url          in varchar2,
    p_return_url            in varchar2,
    p_cancel_url            in varchar2,
    p_amount                in varchar2,
    p_description           in varchar2,
    p_currency              in varchar2,
    p_token_item            out varchar2 )
is
    l_response  varchar2(4000);
    l_token     varchar2(30);
    item_post varchar2(32767);
    i number := 0;
    l_option_ids  VARCHAR2(4000);
    l_values      VARCHAR2(4000);
    l_option_name VARCHAR2(4000);    
    l_vc_arr1    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;
    l_vc_arr2    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;
begin

       item_post := item_post 
      ||'ITEMAMT'||  '=' ||trim( TO_CHAR(ols_calculate_subtotal,  '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,''') )
      ||'&SHIPPINGAMT'|| '=' ||trim( TO_CHAR(ols_calculate_del_cost(null),  '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,''') )
      ||'&TAXAMT'|| '=' ||trim( TO_CHAR(ols_calculate_tax(null),  '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,'''));

  for r in (select prod.id, prod.product_name, sc.c002 quantity, 
            TO_CHAR(round(prod.list_price * (1 - prod.discount/100),2),  '99999D99' ,
              'NLS_NUMERIC_CHARACTERS = ''.,''') list_price,
            TO_CHAR(round(ols_find_tax(prod.id,  null, null),2),  '99999D99' ,
              'NLS_NUMERIC_CHARACTERS = ''.,''') tax
            from ols_product prod, htmldb_collections sc
            where prod.id = sc.c001
            and sc.COLLECTION_NAME = 'SCCOLLECTION') loop

       item_post := item_post 
      ||'&L_NAME'|| i || '=' || htmldb_util.url_encode(r.product_name) 
      ||'&L_QTY'|| i || '=' || r.quantity 
      ||'&L_AMT'|| i || '=' || trim(r.list_price) 
      ||'&L_TAXAMT'|| i || '=' || trim(r.tax) 
      ||'&L_NUMBER'|| i || '=' || r.id;
      -- set options
      ols_options.collection_to_string(r.id, l_option_ids, l_values);
      if l_option_ids is not null then
         l_vc_arr1 := HTMLDB_UTIL.STRING_TO_TABLE(l_option_ids);
         for s in 1..l_vc_arr1.count loop
            select option_name into l_option_name
            from ols_product_options 
            where id = to_number(l_vc_arr1(s));
            l_vc_arr2(s) := l_option_name;
         end loop;
         l_option_ids := HTMLDB_UTIL.TABLE_TO_STRING(l_vc_arr2);
         item_post := item_post 
           ||'&L_DESC'|| i || '=' || htmldb_util.url_encode(
                                      substr(l_option_ids ||' '|| l_values, 1, 127));
      end if;
      i := i + 1;
  end loop;
  
    l_response := do_post(
        p_api_url       => p_api_url,
        p_api_username  => p_api_username,
        p_api_password  => p_api_password,
        p_signature     => p_signature,
        p_wallet        => p_wallet,
        p_wallet_pwd    => p_wallet_pwd,
        p_method        => 'SetExpressCheckout',
        p_parm01        => 'RETURNURL='||p_return_url,
        p_parm02        => 'CANCELURL='||p_cancel_url,
        p_parm03        => 'AMT='||p_amount,
        p_parm04        => 'CURRENCYCODE='||p_currency,
        p_parm05        => 'DESC='||p_description,
        p_parm06       => item_post);

    if get_parameter(l_response,'ACK')  not like 'Success%'  then
        raise_application_error(-20001,'Error: '||l_response);
    end if;

    l_token := get_parameter(l_response,'TOKEN');

    p_token_item := l_token;

    delete from ols_paypal_session_map where session_id = p_session_id;

    insert into ols_paypal_session_map values (p_session_id, htmldb_application.g_flow_id, p_return_page, p_payerid_item, l_token);

    htmldb_application.g_unrecoverable_error := true;
    owa_util.redirect_url(p_redirect_url||l_token);

end set_express_checkout;

procedure get_express_checkout_details(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_token                 in varchar2,
    p_email_item            out varchar2,
    p_fname_item            out varchar2,
    p_mname_item            out varchar2,
    p_lname_item            out varchar2,
    p_shiptoname_item       out varchar2,
    p_shiptostreet_item     out varchar2,
    p_shiptostreet2_item    out varchar2,
    p_shiptocity_item       out varchar2,
    p_shiptocc_item         out varchar2,
    p_shiptostate_item      out varchar2,
    p_shiptozip_item        out varchar2,
    p_phonenum_item         out varchar2 )
is
    l_response  varchar2(4000);
begin

    l_response := do_post(
        p_api_url       => p_api_url,
        p_api_username  => p_api_username,
        p_api_password  => p_api_password,
        p_signature     => p_signature,
        p_wallet        => p_wallet,
        p_wallet_pwd    => p_wallet_pwd,
        p_method        => 'GetExpressCheckoutDetails',
        p_parm01        => 'TOKEN='||p_token );

    if get_parameter(l_response,'ACK')  not like 'Success%'  then
        raise_application_error(-20001,'Error: '||l_response);
    end if;

    p_email_item := get_parameter(l_response,'EMAIL');
    p_fname_item := get_parameter(l_response,'FIRSTNAME');
    p_mname_item := get_parameter(l_response,'MIDDLENAME');
    p_lname_item := get_parameter(l_response,'LASTNAME');
    p_shiptoname_item := get_parameter(l_response,'SHIPTONAME');
    p_shiptostreet_item := get_parameter(l_response,'SHIPTOSTREET');
    p_shiptostreet2_item := get_parameter(l_response,'SHIPTOSTREET2');
    p_shiptocity_item := get_parameter(l_response,'SHIPTOCITY');
    p_shiptocc_item := get_parameter(l_response,'SHIPTOCOUNTRYCODE');
    p_shiptostate_item := get_parameter(l_response,'SHIPTOSTATE');
    p_shiptozip_item := get_parameter(l_response,'SHIPTOZIP');
    p_phonenum_item := get_parameter(l_response,'PHONENUM');

end get_express_checkout_details;

procedure do_express_checkout_payment(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_token                 in varchar2,
    p_payerid               in varchar2,
    p_amount                in varchar2,
    p_description           in varchar2,
    p_item_post             in varchar2,
    p_currency              in varchar2)
is
    l_response  varchar2(4000);
begin

    l_response := do_post(
        p_api_url       => p_api_url,
        p_api_username  => p_api_username,
        p_api_password  => p_api_password,
        p_signature     => p_signature,
        p_wallet        => p_wallet,
        p_wallet_pwd    => p_wallet_pwd,
        p_method        => 'DoExpressCheckoutPayment',
        p_parm01        => 'TOKEN='||p_token,
        p_parm02        => 'PAYMENTACTION=Sale',
        p_parm03        => 'AMT='||p_amount,
        p_parm04        => 'PAYERID='||p_payerid,
        p_parm05        => 'DESC='||p_description,
        p_parm06        => p_item_post,
        p_parm07        => 'CURRENCYCODE='||p_currency);

    if get_parameter(l_response,'ACK')  not like 'Success%'  then
        raise_application_error(-20001,'Error: '||l_response);
    end if;

    insert into ols_paypal_transactions values (p_session_id, p_token, get_parameter(l_response,'TRANSACTIONID'),
        get_parameter(l_response,'ORDERTIME'), 
        to_number(get_parameter(l_response,'AMT'), '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,'''),
        to_number(get_parameter(l_response,'FEEAMT'), '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,'''),
        to_number(get_parameter(l_response,'SETTLEAMT'), '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,'''), 
        get_parameter(l_response,'PAYMENTSTATUS'), get_parameter(l_response,'PENDINGREASON'),
        get_parameter(l_response,'REASONCODE'), l_response);

end do_express_checkout_payment;

procedure do_direct_payment(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_api_password          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_ip_address            in varchar2,
    p_amount                in varchar2,
    p_creditcardtype        in varchar2,
    p_account               in varchar2,
    p_expire_date           in varchar2,
    p_first_name            in varchar2,
    p_last_name             in varchar2,
    p_description           in varchar2,
    p_currency              in varchar2,
    p_item_post             in varchar2,
    p_address               in varchar2,
    p_tran_id_item          out varchar2 )
is
    l_response          varchar2(4000);
    l_transaction_id    varchar2(30);
    l_ack               varchar2(30);
begin

    l_response := do_post(
        p_api_url       => p_api_url,
        p_api_username  => p_api_username,
        p_api_password  => p_api_password,
        p_signature     => p_signature,
        p_wallet        => p_wallet,
        p_wallet_pwd    => p_wallet_pwd,
        p_method        => 'DoDirectPayment',
        p_parm01        => 'PAYMENTACTION=Sale',
        p_parm02        => 'IPADDRESS='||p_ip_address,
        p_parm03        => 'AMT='||p_amount,
        p_parm04        => 'CREDITCARDTYPE='||p_creditcardtype,
        p_parm05        => 'ACCT='||p_account,
        p_parm06        => 'EXPDATE='||p_expire_date,
        p_parm07        => 'FIRSTNAME='||p_first_name,
        p_parm08        => 'LASTNAME='||p_last_name,
        p_parm09        => 'DESC='||p_description,
        p_parm10        => 'CURRENCYCODE='|| p_currency || '&' 
                           || p_item_post || '&' || p_address);

    l_ack := get_parameter(l_response,'ACK');
    
    if  l_ack not like 'Success%' then
        raise_application_error(-20001,'Error: '||l_response);
    end if;

    l_transaction_id := get_parameter(l_response,'TRANSACTIONID');

    insert into ols_paypal_transactions values 
    (p_session_id, null, l_transaction_id, to_char(sysdate,'YYYY-MM-DD HH24:SS:MI'), 
     to_number(  get_parameter(l_response,'AMT'),  '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,'''),
    null, null, l_ack, null, null, l_response);

    p_tran_id_item := l_transaction_id;

end do_direct_payment;

end ols_paypal_api;


/

--------------------------------------------------------
--  DDL for Package Body OLS_PRINT_SYLK_FORMAT
--------------------------------------------------------


  CREATE OR REPLACE PACKAGE "OLS_PRINT_SYLK_FORMAT" as
--
  type owaSylkArray is table of varchar2(2000);
--
  procedure show(
      p_query         in varchar2,
      p_parm_names    in owaSylkArray default owaSylkArray(),
      p_parm_values   in owaSylkArray default owaSylkArray(),
      p_sum_column    in owaSylkArray default owaSylkArray(),
      p_max_rows      in number     default 10000,
      p_show_null_as  in varchar2   default null,
      p_show_grid     in varchar2   default 'YES',
      p_show_col_headers in varchar2 default 'YES',
      p_font_name     in varchar2   default 'Courier New',
      p_widths        in owaSylkArray default owaSylkArray(),
      p_titles        in owaSylkArray default owaSylkArray(),
      p_strip_html    in varchar2   default 'YES' );
--
  procedure show(
      p_cursor        in integer,
      p_sum_column    in owaSylkArray  default owaSylkArray(),
      p_max_rows      in number     default 10000,
      p_show_null_as  in varchar2   default null,
      p_show_grid     in varchar2   default 'YES',
      p_show_col_headers in varchar2 default 'YES',
      p_font_name     in varchar2   default 'Courier New',
      p_widths        in owaSylkArray default owaSylkArray(),
      p_titles        in owaSylkArray default owaSylkArray(),
      p_strip_html    in varchar2   default 'YES' );
--
  PROCEDURE get_usable_sql (p_sql_in IN VARCHAR2, p_sql_out OUT VARCHAR2);
end ols_print_sylk_format;
 
 /
 

  CREATE OR REPLACE PACKAGE BODY "OLS_PRINT_SYLK_FORMAT" as
/*
  This package is modified according to the Webshop needs:
  Printing from Web page by htp.p procedure
*/
--
  g_cvalue  varchar2(32767);
  g_desc_t dbms_sql.desc_tab2;

  type vc_arr is table of varchar2(2000) index by binary_integer;
  g_lengths vc_arr;
  g_sums vc_arr;
--
--

  procedure p( p_str in varchar2 )
  is
  len NUMBER;
  begin
    htp.p(p_str);
    --dbms_output.put_line(p_str);
  exception
    when others then null;
  end;

  function build_cursor(
      q in varchar2,
      n in owaSylkArray,
      v in owaSylkArray ) return integer is
    c integer := dbms_sql.open_cursor;
    i number := 1;
  begin
    dbms_sql.parse (c, q, dbms_sql.native);
    loop
      dbms_sql.bind_variable( c, n(i), v(i) );
      i := i + 1;
    end loop;
    return c;
  exception
    when others then
      return c;
  end build_cursor;
--
--
  function str_html ( line in varchar2 ) return varchar2 is
    x       varchar2(32767) := null;
    in_html boolean         := FALSE;
    s       varchar2(3);
  begin
    if line is null then
      return line;
    end if;

    for i in 1 .. length( line ) loop
      s := substr( line, i, 1 );
      if in_html then
        if s = '>' then
          in_html := FALSE;
        end if;
      else
        if s = '<' then
          in_html := TRUE;
        end if;
      end if;
      if not in_html and s != '>' then
        x := x || s;
      end if;
    end loop;
    return x;
  end str_html;
--
  function ite( b boolean,
                t varchar2,
                f varchar2 ) return varchar2 is
  begin
    if b then
      return t;
    else
      return f;
    end if;
  end ite;
--
  procedure print_comment( p_comment varchar2 ) is
  begin
    return;
    p( ';' || chr(10) || '; ' || p_comment || chr(10) || ';' );
  end print_comment;
--
  procedure print_heading( font in varchar2, 
                           grid in varchar2, 
                           col_heading in varchar2, 
                           titles in owaSylkArray ) 
  is
    l_title varchar2(2000);
  begin
    p( 'ID;DBSWHWEBSHOP' );
    print_comment( 'Fonts' );
    p( 'P;F' || font || ';M200' );
    p( 'P;F' || font || ';M200;SB' );
    p( 'P;F' || font || ';M200;SUB' );
    --
    print_comment( 'Global Formatting' );
    --p( 'F;C1;FG0R;SM1' || 
    p( 'F;C1;FG0L;SM0' || 
           ite( upper(grid)='YES', '', ';G' ) || 
           ite( upper(col_heading)='YES', '', ';H' )  );
    for i in 1 .. g_desc_t.count loop
      --p( 'F;C' || to_char(i+1) || ';FG0R;SM0' );
      p( 'F;C' || to_char(i+1) || ';FG0L;SM0' );
    end loop;
    --
    print_comment( 'Title Row' );
    p( 'F;R1;FG0C;SM2' );
    for i in 1 .. g_desc_t.count loop
      g_lengths(i) := g_desc_t(i).col_name_len;
      g_sums(i) := 0;
      begin
        l_title := titles(i);
      exception
        when others then
          l_title := g_desc_t(i).col_name;
      end;
      if i = 1 then
        --p( 'C;Y1;X2;K"' || l_title || '"' );
        p( 'C;Y1;X1;K"' || l_title || '"' );
      else
        --p( 'C;X' || to_char(i+1) || ';K"' || l_title || '"' );
        p( 'C;X' || to_char(i) || ';K"' || l_title || '"' );
      end if;
    end loop;
  end print_heading;
--
  function print_rows(
      c            in integer,
      max_rows     in number,
      sum_columns  in owaSylkArray,
      show_null_as in varchar2,
      strip_html   in varchar2 ) return number is
    row_cnt number          := 0;
    line    varchar2(32767) := null;
    n       number;
  begin
    loop
      exit when ( row_cnt >= max_rows or
                  dbms_sql.fetch_rows( c ) <= 0 );
      row_cnt := row_cnt + 1;
      print_comment( 'Row ' || row_cnt );
      --
      p( 'C;Y' || to_char(row_cnt+1) );

      for i in 1 .. g_desc_t.count loop
        dbms_sql.column_value( c, i, g_cvalue );
        g_cvalue := trim( both chr(10) from g_cvalue);         
        g_cvalue := trim( both chr(13) from g_cvalue);     
        
        g_cvalue := translate( g_cvalue, 
                            chr(13)||chr(10)||chr(9)||';', '    ' ); 
        
                            
        g_cvalue := ite( upper( strip_html ) = 'YES',
                             str_html( g_cvalue ),
                             g_cvalue );
        g_lengths(i) := greatest( nvl(length(g_cvalue), 
                                  nvl(length(show_null_as),0)),
                                  g_lengths(i) );
        line := 'C;X' || to_char(i);
        line := line || ';K';
        begin
          n := to_number( g_cvalue );
          if upper( sum_columns(i)) = 'Y' then
            g_sums(i) := g_sums(i) + nvl(n,0);
          end if;
        exception
          when others then
            n := null;
        end;
        line := line || 
                 ite( n is null, 
                      ite( g_cvalue is null, 
                               '"'||show_null_as||
                                  '"', '"'||g_cvalue||'"' ), 
                             n );
        p( line );
      end loop;
      --
    end loop;
    return row_cnt;
  end print_rows;
--
  procedure print_sums(
      sum_columns  in owaSylkArray,
      row_cnt      in number ) is
  begin
    if sum_columns.count = 0 then
      return;
    end if;
    --
    print_comment( 'Totals Row' );
    p( 'C;Y' || to_char(row_cnt + 4) );
    p( 'C;X1;K"Totals:"' );
    --
    for i in 1 .. g_desc_t.count loop
      begin
        if upper(sum_columns(i)) = 'Y' then
          p( 'C;X' || to_char(i+1) || ';ESUM(R3C:R' || 
                  to_char(row_cnt+2) || 'C)' );
        end if;
      exception
        when others then
          null;
      end;
    end loop;
  end print_sums;
--
  procedure print_widths( widths owaSylkArray ) is
  begin
    print_comment( 'Format Column Widths' );
    --p( 'F;W1 1 7' );
    for i in 1 .. g_desc_t.count loop
      begin
        --p( 'F;W' || to_char(i+1) || ' ' || 
            --to_char(i+1) || ' ' || 
        p( 'F;W' || to_char(i) || ' ' || 
            to_char(i) || ' ' || 
            to_char(to_number(widths(i))) );
      exception
        when others then
          --p( 'F;W' || to_char(i+1) || ' ' || 
               --to_char(i+1) || ' ' ||
          p( 'F;W' || to_char(i) || ' ' || 
               to_char(i) || ' ' ||  
               greatest( g_lengths(i), length( g_sums(i) )));
      end;
    end loop;
    p( 'E' );
  end print_widths;
--
  procedure show(
      p_cursor        in integer,
      p_sum_column    in owaSylkArray default owaSylkArray(),
      p_max_rows      in number     default 10000,
      p_show_null_as  in varchar2   default null,
      p_show_grid     in varchar2   default 'YES',
      p_show_col_headers in varchar2 default 'YES',
      p_font_name     in varchar2   default 'Courier New',
      p_widths        in owaSylkArray default owaSylkArray(),
      p_titles        in owaSylkArray default owaSylkArray(),
      p_strip_html    in varchar2   default 'YES' ) is
  --
    l_row_cnt number;
    l_col_cnt number;
    l_status  number;
  begin
    
    dbms_sql.describe_columns2( p_cursor, l_col_cnt, g_desc_t );
    --
    for i in 1 .. g_desc_t.count loop
      dbms_sql.define_column( p_cursor, i, g_cvalue, 32765);
    end loop;
    --
    print_heading( p_font_name, 
                   p_show_grid, 
                   p_show_col_headers, 
                   p_titles );
    l_status := dbms_sql.execute( p_cursor );

    l_row_cnt := print_rows(
                   p_cursor, 
                   p_max_rows,
                   p_sum_column,
                   p_show_null_as,
                   p_strip_html );
    print_sums( p_sum_column, l_row_cnt );
    print_widths( p_widths );
  end show;
--
  procedure show(
      p_query         in varchar2,
      p_parm_names    in owaSylkArray default owaSylkArray(),
      p_parm_values   in owaSylkArray default owaSylkArray(),
      p_sum_column    in owaSylkArray default owaSylkArray(),
      p_max_rows      in number     default 10000,
      p_show_null_as  in varchar2   default null,
      p_show_grid     in varchar2   default 'YES',
      p_show_col_headers in varchar2 default 'YES',
      p_font_name     in varchar2   default 'Courier New',
      p_widths        in owaSylkArray default owaSylkArray(),
      p_titles        in owaSylkArray default owaSylkArray(),
      p_strip_html    in varchar2   default 'YES' ) is
  begin
    show( p_cursor => build_cursor( p_query, 
                                    p_parm_names, 
                                    p_parm_values ),
          p_sum_column => p_sum_column,
          p_max_rows => p_max_rows,
          p_show_null_as => p_show_null_as,
          p_show_grid => p_show_grid,
          p_show_col_headers => p_show_col_headers,
          p_font_name => p_font_name,
          p_widths => p_widths,
          p_titles => p_titles,
          p_strip_html => p_strip_html );
  end show;
--
   PROCEDURE get_usable_sql (p_sql_in IN VARCHAR2, p_sql_out OUT VARCHAR2)
   IS
      v_sql      VARCHAR2 (32767);
      v_names    DBMS_SQL.varchar2_table;
      v_pos      NUMBER;
      v_length   NUMBER;
      v_exit     NUMBER;
   BEGIN
      v_sql := p_sql_in;
      v_names := wwv_flow_utilities.get_binds (v_sql);

      FOR i IN 1 .. v_names.COUNT
      LOOP

         <<do_it_again>>
         v_pos := INSTR (LOWER (v_sql), LOWER (v_names (i)));
         v_length := LENGTH (LOWER (v_names (i)));
         v_sql :=
               SUBSTR (v_sql, 1, v_pos - 1)
            || v_names (i)
            || SUBSTR (v_sql, v_pos + v_length);
         v_sql :=
            REPLACE (v_sql,
                     UPPER (v_names (i)),
                        '(SELECT v('''
                     || LTRIM (v_names (i), ':')
                     || ''') FROM DUAL)'
                    );

         IF INSTR (LOWER (v_sql), LOWER (v_names (i))) > 0
         THEN
            GOTO do_it_again;
         END IF;
      END LOOP;

      p_sql_out := v_sql;
   END get_usable_sql;
   --
end ols_print_sylk_format;
/
 

--------------------------------------------------------
--  DDL for Package Body T
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "T" AS

  function category_name(p_id number, p_lang_id number) return VARCHAR2 AS
  l_category_name ols_category.category_name%type;
  BEGIN
  
    SELECT category_name
    INTO l_category_name
    FROM   ols_category_trans
    WHERE  cat_id = p_id
    AND    lang_id = p_lang_id;
    
    RETURN l_category_name;
  EXCEPTION WHEN OTHERS THEN
    SELECT category_name
    INTO l_category_name
    FROM   ols_category
    WHERE  id = p_id;
    
    RETURN l_category_name;     
  END category_name;

  function product_name(p_id number, p_lang_id number) return VARCHAR2 AS
  l_product_name ols_product.product_name%type;
  BEGIN
  
    SELECT product_name
    INTO l_product_name
    FROM   ols_product_trans
    WHERE  prod_id = p_id
    AND    lang_id = p_lang_id;
    
    RETURN l_product_name;
  EXCEPTION WHEN OTHERS THEN
    SELECT product_name
    INTO l_product_name
    FROM   ols_product
    WHERE  id = p_id;
    
    RETURN l_product_name; 
  END product_name;

  function short_description(p_id number, p_lang_id number) return VARCHAR2 AS
  l_short_description ols_product.short_description%type;
  BEGIN
  
    SELECT short_description
    INTO l_short_description
    FROM   ols_product_trans
    WHERE  prod_id = p_id
    AND    lang_id = p_lang_id;
    
    RETURN l_short_description;
  EXCEPTION WHEN OTHERS THEN
    SELECT short_description
    INTO l_short_description
    FROM   ols_product
    WHERE  id = p_id;
    
    RETURN l_short_description; 
  END short_description;

  function long_description(p_id number, p_lang_id number) return VARCHAR2 AS
  l_long_description ols_product.long_description%type;
  BEGIN
  
    SELECT long_description
    INTO l_long_description
    FROM   ols_product_trans
    WHERE  prod_id = p_id
    AND    lang_id = p_lang_id;
    
    RETURN l_long_description;
  EXCEPTION WHEN OTHERS THEN
    SELECT long_description
    INTO l_long_description
    FROM   ols_product
    WHERE  id = p_id;
    
    RETURN l_long_description;
  END long_description;

END T;

/

--------------------------------------------------------
--  DDL for Procedure OLS_DELETE_COLLECTIONS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_DELETE_COLLECTIONS" AS
BEGIN
-- Delete collections except Shopping cart collection SCCOLLECTION
BEGIN
  HTMLDB_COLLECTION.DELETE_COLLECTION (
    p_collection_name => 'BILLTOCOLLECTION' );
EXCEPTION WHEN OTHERS THEN 
NULL;
END;
BEGIN
  HTMLDB_COLLECTION.DELETE_COLLECTION (
    p_collection_name => 'SHIPTOCOLLECTION' );
EXCEPTION WHEN OTHERS THEN 
NULL;
END;
BEGIN
  HTMLDB_COLLECTION.DELETE_COLLECTION (
    p_collection_name => 'PAYMENTCOLLECTION' );
EXCEPTION WHEN OTHERS THEN 
NULL;
END;
BEGIN
  HTMLDB_COLLECTION.DELETE_COLLECTION (
    p_collection_name => 'SHIPMENT' );
EXCEPTION WHEN OTHERS THEN 
NULL;
END;
BEGIN
  HTMLDB_COLLECTION.DELETE_COLLECTION (
    p_collection_name => 'CUSTCOLLECTION' );

EXCEPTION WHEN OTHERS THEN 
NULL;
END;

END OLS_DELETE_COLLECTIONS;

/

--------------------------------------------------------
--  DDL for Procedure OLS_DELIVER_SO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_DELIVER_SO" (p_id number) AS
l_download_expire_date number := 0;
l_reorder_prod VARCHAR2(2000);
l_body VARCHAR2(2000);
l_reorder_val number := 0;
n number;
BEGIN
  FOR i in (select decode(value,0,9999,value) v from ols_configuration where key = 'DOWNLOAD_MAX_DAYS') loop
    l_download_expire_date := i.v;
  END LOOP;
  
  FOR i in (select value from ols_configuration where key = 'STOCK_REORDER_LEVEL') loop
     l_reorder_val := i.value;
  END LOOP;
  
  -- find download products and make them visible in page 55
  FOR r in (select * from ols_line_items where sales_order_id = p_id) LOOP
  
      FOR i in (select * from ols_files where product_id = r.product_id) LOOP
      
         insert into ols_line_downloads
         (id, line_id, download_file_id, download_expire_date, download_click_count) 
         values
         (ols_line_downloads_seq.nextval, r.id, i.file_id, trunc(sysdate + l_download_expire_date), 0);
      END LOOP;
      
  END LOOP;
  -- substract stock
  FOR i in (select 1 from ols_configuration where key = 'STOCK_SUBSTRACT' and nvl(value, 'N') = 'Y') LOOP
  
      FOR r in (select op.qoh - li.qty_ord new_qty,
                       op.id product_id, 
                       op.product_name
                from ols_line_items li, ols_product op
                where li.sales_order_id = p_id
                and   li.product_id = op.id
                and   nvl(op.download,'N') != 'Y') LOOP
      
         update ols_product set qoh = r.new_qty
         where  id = r.product_id;
         
            IF (r.new_qty - l_reorder_val) <= 0 THEN 
             
                l_reorder_prod := l_reorder_prod || r.product_id || '   ' 
                                   || r.product_name || '   ' || r.new_qty || chr(10);
             
             END IF;
      
      END LOOP;
  
  END LOOP;
  
  -- set the actual date of delivery
  update ols_sales_order
  set actual_delivery_date = trunc(sysdate)
  where id = P_ID;
  
  -- send email if any product requires reorder
  IF l_reorder_prod IS NOT NULL THEN
     l_body := 'The following products require reorder: ' || chr(10) || 'Id   Product name   In Stock' || chr(10) || l_reorder_prod;
     HTMLDB_MAIL.SEND(
        P_TO        => v('P_ADMIN_EMAIL'),
        P_FROM      => v('STORE_OWNER_EMAIL_ADDRESS'),
        P_BODY      => l_body,
        P_SUBJ      => 'Products require reorder');

/*     n := HTMLDB_PLSQL_JOB.submit_process
       (
        p_sql => '
          begin
          HTMLDB_MAIL.PUSH_QUEUE(''localhost'', 25);
          end;',
        p_when => sysdate,
        p_status => 'SUBMITTED'
        );
*/
   END IF;
END OLS_DELIVER_SO;

 

/

--------------------------------------------------------
--  DDL for Procedure OLS_GETNAME
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_GETNAME" 
(p_login_name IN VARCHAR2,
p_fullname IN OUT VARCHAR2)
is
l_fname varchar2(50);
l_lname varchar2(50);
begin
select first_name, last_name into l_fname,l_lname from ols_customer_details where login_id = p_login_name;
 p_fullname := initcap(l_fname) || ' ' || initcap(l_lname);
 if length(p_fullname) > 20 then
    p_fullname := initcap(l_fname);
 end if;
exception
 when no_data_found then
  p_fullname := 'Guest';
end;

 
 

/

--------------------------------------------------------
--  DDL for Procedure OLS_GO_CANCEL_PAGE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_GO_CANCEL_PAGE" (token varchar2) AS
BEGIN

    for c1 in (select session_id, app_id
                 from ols_paypal_session_map
                where session_token = token ) loop
        owa_util.redirect_url('f?p='||c1.app_id||':'||64||':'||c1.session_id);
        exit;
    end loop;

END OLS_GO_CANCEL_PAGE;

 
 

/

--------------------------------------------------------
--  DDL for Procedure OLS_IMAGE_DISPLAY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_IMAGE_DISPLAY" (p_image_id in number) 
as 
  l_mime varchar2(255); 
  l_length number; 
  l_file_name varchar2(2000); 
  lob_loc BLOB;
begin
select mime_type, image, image_name, dbms_lob.getlength(image) 
  into l_mime, lob_loc, l_file_name, l_length 
  from ols_images where image_id = p_image_id;
-- Set up HTTP header
-- Use an NVL around the mime type and  if it is a null, set it to
-- application/octect - which may launch a download window from windows 
owa_util.mime_header(nvl(l_mime,'application/octet'), FALSE ); 
-- Set the size so the browser knows how much to download 
htp.p('Content-length: ' || l_length); 
-- The filename will be used by the browser if the users does a "Save as" 
htp.p('Content-Disposition: filename="' || l_file_name || '"');
--htp.p('Expires: ' || 'Sun, 6 Jun 2020 20:00:00 GMT');
htp.p('Expires: ' || to_char(sysdate + 1/24, 'FMDy, DD Month YYYY HH24:MI:SS') || ' GMT');
-- Close the headers 
owa_util.http_header_close; 
-- Download the BLOB 
wpg_docload.download_file( Lob_loc ); 
end;

 
 
/

--------------------------------------------------------
--  DDL for Procedure OLS_INSERT_LINE_ITEMS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_INSERT_LINE_ITEMS" 
( P_SALES_ORDER_ID IN NUMBER
) AS
v_so_id ols_sales_order.id%type;
v_product_id ols_product.id%type;
v_taxamt number(8,2):= 0;
v_unit_price number(8,2);
v_qty number(4);
v_line_num number(4):=0;
v_bef_tax_total number(8,2):=0;
v_after_tax_total number(8,2):=0;
v_line_item_id number;

cursor c1 is
select sc.c001,
       sc.c002, 
       round(prod.list_price * (1 - prod.discount/100),2),
       round(sc.c002*(ols_find_tax(prod.id, sd.country, z.id)), 2)  tax, 
       sc.c002* round(prod.list_price * (1 - prod.discount/100),2),
       (sc.c002*prod.selling_price) total
from htmldb_collections sc, ols_product prod, ols_sales_order so, 
     ols_cust_shipping_details sd, ols_zones z
where collection_name = 'SCCOLLECTION'
 and sc.c001 = prod.id
 and so.id = p_sales_order_id
 and so.ship_to_id = sd.id
 and z.code (+) = sd.state
 and z.country_id (+) = sd.country;

BEGIN
  OPEN c1;
  LOOP
    FETCH c1 INTO v_product_id, v_qty, v_unit_price, v_taxamt, v_bef_tax_total, v_after_tax_total; 
    EXIT WHEN c1%NOTFOUND;
  v_line_num := v_line_num + 1;
  v_after_tax_total := v_bef_tax_total + v_taxamt;
  select ols_line_items_seq.nextval
  into v_line_item_id
  from dual;
  
  insert into ols_line_items(id, sales_order_id,line_item_num,product_id,tax_amt,unit_price,qty_ord,bef_tax_total,after_tax_total)
  values(v_line_item_id,P_SALES_ORDER_ID,v_line_num,v_product_id,v_taxamt,v_unit_price,v_qty,v_bef_tax_total,v_after_tax_total);

  for r in (select h1.c002 opt, h1.c003 val
             from htmldb_collections h1, htmldb_collections h2
             where h1.collection_name  = 'OPTIONS'
              and h2.collection_name = 'SCCOLLECTION'
              and h1.c001 = h2.c001
              and h2.c001 = v_product_id
              ) loop
     insert into ols_line_item_options(id,line_item_id,product_option_id,option_value)
     values(ols_line_item_options_seq.nextval,v_line_item_id,r.opt,r.val);

  end loop;
    
END LOOP;
CLOSE c1;
END OLS_INSERT_LINE_ITEMS;

 

 

/

--------------------------------------------------------
--  DDL for Procedure OLS_PAYPAL_ACCEPT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_PAYPAL_ACCEPT" 
  (token in varchar2,
   PayerId in varchar2)
as
begin

    for c1 in (select session_id, app_id,
                      page_id, payer_id_item
                 from ols_paypal_session_map
                where session_token = token ) loop
        owa_util.redirect_url('f?p='||c1.app_id||':'||c1.page_id||':'||c1.session_id||'::::'||c1.payer_id_item||':'||PayerId);
        exit;
    end loop;

end ols_paypal_accept;

 
 

/

--------------------------------------------------------
--  DDL for Procedure OLS_PRINT_BILLING_ADDRESS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_PRINT_BILLING_ADDRESS" (p_id number) AS
l_address varchar2(4000);
l_streets varchar2(4000);
BEGIN
 if p_id is not null then
 for r in (
       select
       bd.FIRST_NAME,
       bd.LAST_NAME,
       bd.ADDRESS1,
       bd.ADDRESS2,
       bd.ADDRESS3,
       bd.CITY,
       z.name STATE,
       bd.PIN,
       c.COUNTRY_NAME,
       bd.EMAIL,
       bd.CONTACT_NUMBER,
       f.address_format
       from ols_cust_billing_details bd, ols_country c, 
            ols_address_format f, ols_zones z,
            ols_customer_details cd
       where bd.id = p_id 
       and z.code (+) = bd.state       
       and z.country_id (+) = bd.country
       and bd.country = c.id 
       and f.id = c.address_format_id
       and cd.id = bd.customer_id
        ) loop
       l_address := r.address_format;
       l_address := replace(l_address, '$cr', '<br>');
       l_address := replace(l_address, '$firstname', r.first_name);
       l_address := replace(l_address, '$lastname', r.last_name); 
       l_streets := r.address1;
       if r.address2 is not null then
          l_streets := l_streets || '<br>' || r.address2 || '<br>';
       end if;
       if r.address3 is not null then
          l_streets := l_streets || '<br>' || r.address3 || '<br>';
       end if;       
       l_address := replace(l_address, '$streets', l_streets); 
       l_address := replace(l_address, '$state', r.state); 
       l_address := replace(l_address, '$city', r.city); 
       l_address := replace(l_address, '$country', r.country_name); 
       l_address := replace(l_address, '$postcode', r.pin);
       l_address := replace(l_address,'<br><br>','<br>');
     end loop;
  else
     for r in (select cust.C001 first_name, cust.C002 last_name, cust.C003 address1, 
                      cust.C004 address2, cust.C005 address3, cust.C006 city, 
                      z.name state, cust.C008 pin, cust.C009, 
                      cust.C010, cust.C011, ctry.country_name country_name,
                      f.address_format
               from htmldb_collections cust, ols_country ctry, ols_address_format f, ols_zones z
               where collection_name = 'BILLTOCOLLECTION'
               and to_number(cust.c009) = ctry.id  and f.id = ctry.address_format_id  
               and z.code (+) = cust.c007
               and z.country_id (+) = cust.c009 ) loop
       l_address := r.address_format;
       l_address := replace(l_address, '$cr', '<br>');
       l_address := replace(l_address, '$firstname', r.first_name);
       l_address := replace(l_address, '$lastname', r.last_name); 
       l_streets := r.address1;
       if r.address2 is not null then
          l_streets := l_streets || '<br>' || r.address2 || '<br>';
       end if;
       if r.address3 is not null then
          l_streets := l_streets || '<br>' || r.address3 || '<br>';
       end if;       
       l_address := replace(l_address, '$streets', l_streets); 
       l_address := replace(l_address, '$state', r.state); 
       l_address := replace(l_address, '$city', r.city); 
       l_address := replace(l_address, '$country', r.country_name); 
       l_address := replace(l_address, '$postcode', r.pin);
       l_address := replace(l_address,'<br><br>','<br>');
    end loop;
  end if;
  
  htp.p(l_address);
  
END OLS_PRINT_BILLING_ADDRESS;

 
 

/

--------------------------------------------------------
--  DDL for Procedure OLS_PRINT_DELIVERY_ADDRESS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_PRINT_DELIVERY_ADDRESS" (p_id number) AS
l_address varchar2(4000);
l_streets varchar2(4000);
BEGIN
 if p_id is not null then
 for r in (
       select
       sd.FIRST_NAME,sd.LAST_NAME,sd.ADDRESS1,
       sd.ADDRESS2,sd.ADDRESS3,sd.CITY,
       z.name STATE,sd.PIN,c.COUNTRY_NAME,
       sd.EMAIL, sd.CONTACT_NUMBER, f.address_format
       from ols_cust_shipping_details sd, ols_country c, 
       ols_address_format f, ols_zones z, 
       ols_customer_details cd
       where sd.id = p_id 
       and sd.country = c.id 
       and f.id = c.address_format_id  
       and z.code (+) = sd.state
       and z.country_id (+) = sd.country
       and cd.id = sd.customer_id
        ) loop
       l_address := r.address_format;
       l_address := replace(l_address, '$cr', '<br>');
       l_address := replace(l_address, '$firstname', r.first_name);
       l_address := replace(l_address, '$lastname', r.last_name); 
       l_streets := r.address1;
       if r.address2 is not null then
          l_streets := l_streets || '<br>' || r.address2 || '<br>';
       end if;
       if r.address3 is not null then
          l_streets := l_streets || '<br>' || r.address3 || '<br>';
       end if;       
       l_address := replace(l_address, '$streets', l_streets); 
       l_address := replace(l_address, '$state', r.state); 
       l_address := replace(l_address, '$city', r.city); 
       l_address := replace(l_address, '$country', r.country_name); 
       l_address := replace(l_address, '$postcode', r.pin);
       l_address := replace(l_address,'<br><br>','<br>');
     end loop;
  else
     for r in (select cust.C001 first_name, cust.C002 last_name, cust.C003 address1, 
                      cust.C004 address2, cust.C005 address3, cust.C006 city, 
                      z.name state, cust.C008 pin, cust.C009, 
                      cust.C010, cust.C011, ctry.country_name country_name,
                      f.address_format
               from htmldb_collections cust, ols_country ctry, ols_address_format f, ols_zones z
               where collection_name = 'SHIPTOCOLLECTION'
               and to_number(cust.c009) = ctry.id  and f.id = ctry.address_format_id  
               and z.code (+) = cust.c007
               and z.country_id (+) = cust.c009) loop
       l_address := r.address_format;
       l_address := replace(l_address, '$cr', '<br>');
       l_address := replace(l_address, '$firstname', r.first_name);
       l_address := replace(l_address, '$lastname', r.last_name); 
       l_streets := r.address1;
       if r.address2 is not null then
          l_streets := l_streets || '<br>' || r.address2 || '<br>';
       end if;
       if r.address3 is not null then
          l_streets := l_streets || '<br>' || r.address3 || '<br>';
       end if;       
       l_address := replace(l_address, '$streets', l_streets); 
       l_address := replace(l_address, '$state', r.state); 
       l_address := replace(l_address, '$city', r.city); 
       l_address := replace(l_address, '$country', r.country_name); 
       l_address := replace(l_address, '$postcode', r.pin);
       l_address := replace(l_address,'<br><br>','<br>');
    end loop;
  end if;
  
  htp.p(l_address);
  
END OLS_PRINT_DELIVERY_ADDRESS;

 
 

/

--------------------------------------------------------
--  DDL for Procedure OLS_PRINT_PAYPAL_BUTTON
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_PRINT_PAYPAL_BUTTON" (p_ship_id number, p_bill_id number) AS
button varchar2(32767);
i number := 0;
l_del_cost number;
l_tran_id number;
l_tax number;
l_return_url VARCHAR2(4000);
l_cancel_url VARCHAR2(4000);
l_v_del_cost VARCHAR2(20);
l_v_tax VARCHAR2(20);
l_option_ids  VARCHAR2(4000);
l_option_name VARCHAR2(4000);
l_values  VARCHAR2(4000);
l_vc_arr1    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;
l_vc_arr2    HTMLDB_APPLICATION_GLOBAL.VC_ARR2; 
BEGIN

  for r in (select decode(testmode,'Y', sandbox, production) value from ols_payment_mode_ex where key = 'PSP') loop
     button := '<form action="' || r.value ||'" method="post">';
  end loop;
  button := button || '<input type="hidden" name="cmd" value="_cart">';
  button := button || '<input type="hidden" name="upload" value="1">';
  for r in (select vendor_id value from ols_payment_mode_ex where key = 'PSP') loop
     button := button || '<input type="hidden" name="business" value="' || r.value || '">';
  end loop;

  
  for r in (select prod.id, prod.product_name, sc.c002 quantity, 
        TO_CHAR(round(prod.list_price * (1 - prod.discount/100),2), 
        '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,''') list_price
            from ols_product prod, htmldb_collections sc
            where prod.id = sc.c001
            and sc.COLLECTION_NAME = 'SCCOLLECTION') loop
       i := i + 1;
       button := button ||
      '<input type="hidden" name="item_number_'|| i || '" value="' || r.id || '">'
      ||'<input type="hidden" name="item_name_'|| i || '" value="' || r.product_name || '">'
      ||'<input type="hidden" name="quantity_'|| i || '" value="' || r.quantity || '">'
      ||'<input type="hidden" name="amount_'|| i || '" value="' || trim(r.list_price) || '">';
      -- set options
      ols_options.collection_to_string(r.id, l_option_ids, l_values);
      if l_option_ids is not null then
         l_vc_arr1 := HTMLDB_UTIL.STRING_TO_TABLE(l_option_ids);
         for s in 1..l_vc_arr1.count loop
            select option_name into l_option_name
            from ols_product_options where id = to_number(l_vc_arr1(s));
            l_vc_arr2(s) := l_option_name;            
         end loop;
         l_option_ids := HTMLDB_UTIL.TABLE_TO_STRING(l_vc_arr2);
         button := button ||
           '<input type="hidden" name="on0_'|| i || '" value="' || substr(l_option_ids,1,64) || '">'
           ||'<input type="hidden" name="os0_'|| i || '" value="' || substr(l_values, 1, 200) || '">';
      end if;
  end loop;
  -- in case of testing with empty htmldb collection
 -- if i = 0 then
 --    button := button ||
 --     '<input type="hidden" name="item_number_1" value="1">'
 --    ||'<input type="hidden" name="item_name_1" value="Test">'
 --    ||'<input type="hidden" name="quantity_1" value="2">'
 --    ||'<input type="hidden" name="amount_1" value="11">';  
 -- end if;
  IF nvl(v('P_ENABLE_HTTPS'),'N') = 'Y' THEN
     --l_return_url := 'https://'||v('P_HTTP_HOST')||'/apex/'||v('OWNER')||'.OLS_PAYPAL_ACCEPT';
       l_return_url := 'https://'||v('P_HTTP_HOST')||'/';
  ELSE
     --l_return_url := 'http://'||v('P_HTTP_HOST')||'/apex/'||v('OWNER')||'.OLS_PAYPAL_ACCEPT';
       l_return_url := 'http://'||v('P_HTTP_HOST')||'/';
  END IF;

  IF nvl(v('P_ENABLE_HTTPS'),'N') = 'Y' THEN
     --l_cancel_url := 'https://'||v('P_HTTP_HOST')||'/apex/'||v('OWNER')||'.OLS_GO_CANCEL_PAGE';
       l_cancel_url := 'https://'||v('P_HTTP_HOST')||'/apex/f?p='||v('APP_ID')||':64';
  ELSE
     --l_cancel_url := 'http://'||v('P_HTTP_HOST')||'/apex/'||v('OWNER')||'.OLS_GO_CANCEL_PAGE';
       l_cancel_url := 'http://'||v('P_HTTP_HOST')||'/apex/f?p='||v('APP_ID')||':64';     
  END IF;
  for r in (select value from ols_configuration where key = 'DEFAULT_CURRENCY') loop
     button := button || '<input type="hidden" name="currency_code" value="'|| r.value ||'">';
  end loop;
  l_del_cost := ols_calculate_del_cost(p_ship_id);
  l_tax := ols_calculate_tax(p_ship_id);
  select trim(TO_CHAR(l_del_cost,  '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,''')) 
  into l_v_del_cost
  from dual;
  select trim( TO_CHAR(l_tax,  '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,''')) 
  into l_v_tax
  from dual;
  button := button || '<input type="hidden" name="tax_cart" value="'|| l_v_tax || '">';
  if l_del_cost is not null then
     -- currently passing shipping on entire cart does not work properly in Paypal: button := button || '<input type="hidden" name="shipping" value="'|| l_del_cost || '">'; 
     -- because of that add shipping charges to first item
     button := button || '<input type="hidden" name="shipping_1" value="'|| l_del_cost || '">';  
  end if;
  button := button || '<input type="hidden" name="return" value="'||l_return_url||'">';    
  button := button || '<input type="hidden" name="cancel_return" value="'||l_cancel_url||'">';
  for i in (select
            c001 FIRST_NAME,
            c002 LAST_NAME,
            c003 ADDRESS1,
            c004 || case when c005 is null then null else ' ' || c005 end  ADDRESS2,
            c006 CITY,
            c007 STATE,
            c008 ZIP,
            c010 EMAIL,
            iso_code_1 COUNTRY,
            c011 phone
            from htmldb_collections h, ols_country c
            where collection_name = 'BILLTOCOLLECTION'
            and h.c009 = c.id and p_bill_id is null) loop
       button := button || '<input type="hidden" name="first_name" value="'|| i.first_name || '">';
       button := button || '<input type="hidden" name="last_name" value="'||i.last_name||'">';  
       button := button || '<input type="hidden" name="address1" value="'||i.address1||'">';    
       button := button || '<input type="hidden" name="address2" value="'||i.address2||'">';       
       button := button || '<input type="hidden" name="city" value="'|| i.city || '">';
       button := button || '<input type="hidden" name="zip" value="'||i.zip||'">';  
       button := button || '<input type="hidden" name="country" value="'||i.country||'">'; 
       button := button || '<input type="hidden" name="email" value="'||i.email||'">'; 
       if i.state is not null then
          button := button || '<input type="hidden" name="state" value="'||i.state||'">';
       end if;
       if i.phone is not null then
          button := button || '<input type="hidden" name="night_phone_a" value="'||substr(i.phone,1,3)||'">';
          button := button || '<input type="hidden" name="night_phone_b" value="'||substr(i.phone,4)||'">';
       end if;
  end loop;
  for i in (select
            FIRST_NAME,
            LAST_NAME,
            ADDRESS1,
            ADDRESS2 || case when ADDRESS3 is null then null else ' ' || ADDRESS3 end  ADDRESS2,
            CITY,
            STATE,
            PIN,
            EMAIL,
            iso_code_1 COUNTRY,
            contact_number phone
            from ols_cust_billing_details s, ols_country c
            where s.id = p_bill_id and p_bill_id is not null and s.country = c.id ) loop
       button := button || '<input type="hidden" name="first_name" value="'|| i.first_name || '">';
       button := button || '<input type="hidden" name="last_name" value="'||i.last_name||'">';  
       button := button || '<input type="hidden" name="address1" value="'||i.address1||'">';    
       button := button || '<input type="hidden" name="address2" value="'||i.address2||'">';       
       button := button || '<input type="hidden" name="city" value="'|| i.city || '">';
       button := button || '<input type="hidden" name="zip" value="'||i.pin||'">';  
       button := button || '<input type="hidden" name="country" value="'||i.country||'">'; 
       button := button || '<input type="hidden" name="email" value="'||i.email||'">'; 
       if i.state is not null then
          button := button || '<input type="hidden" name="state" value="'||i.state||'">';
       end if;
       if i.phone is not null then
          button := button || '<input type="hidden" name="night_phone_a" value="'||substr(i.phone,1,3)||'">';
          button := button || '<input type="hidden" name="night_phone_b" value="'||substr(i.phone,4)||'">';
       end if;
  end loop;
  
  SELECT ols_paypal_tran_id_seq.nextval
  INTO   l_tran_id
  FROM dual;
  
  if htmldb_collection.collection_exists( 'PAYPAL') = FALSE then
     htmldb_collection.create_collection( p_collection_name => 'PAYPAL' );
  else
       htmldb_collection.truncate_collection( p_collection_name => 'PAYPAL' );
  end if;

  htmldb_collection.add_member(
            p_collection_name => 'PAYPAL',
            p_c001            => l_tran_id);
  commit;

    
  button := button || '<input type="hidden" name="invoice" value="Trans: '||l_tran_id||'">';
  button := button || '<input type="image" src="';
  for r in (select button_url value from ols_payment_mode_ex where key = 'PSP') loop  
     button := button || r.value;
     -- http://www.paypal.com/en_US/i/btn/x-click-but01.gif
  end loop;
  button := button ||  '" onclick="javascript:process_paypal(this)" name="submit" alt="Make payments with PayPal - it''s fast, free and secure!"></form> ';
  
  htp.p(button);

END OLS_PRINT_PAYPAL_BUTTON;

 

 

/

--------------------------------------------------------
--  DDL for Procedure OLS_REFRESH_CAT_PRODUCT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_REFRESH_CAT_PRODUCT" AS
l_count number;
l_job number;
BEGIN
  execute immediate 'truncate table ols_cat_product';
  insert into ols_cat_product
  (id, category_name, parent_id)
  select id, category_name, parent_id
  from ols_vw_cat_product;
  commit;
  
  for i in (select rowid, a.id from ols_cat_product a) loop 
     select ols_cat_prod_count(i.id)
     into l_count
     from dual;
     update ols_cat_product
     set amount = l_count
     where rowid = i.rowid
     ;
  end loop;
  commit;
  
  select count(*)
  into l_count
  from all_jobs
  where what like 'OLS_REFRESH_CAT_PRODUCT%';
  if l_count = 0 then
     dbms_job.submit(job => l_job, 
       what => 'OLS_REFRESH_CAT_PRODUCT;',
       next_date => trunc(sysdate),
       interval => 'trunc(sysdate+1)');
  end if;
  commit;
END OLS_REFRESH_CAT_PRODUCT;

 

 

/

--------------------------------------------------------
--  DDL for Procedure OLS_SEND_MAIL
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_SEND_MAIL" ( p_to            in varchar2,
                         p_from          in varchar2,
                         p_body          in varchar2,
                         p_body_html     in varchar2 default NULL,
                         p_subj          in varchar2 default NULL,
                         p_cc            in varchar2 default NULL,
                         p_bcc           in varchar2 default NULL)
AS
CURSOR c IS
 SELECT value
 FROM   ols_configuration
 WHERE  key =  'SEND_EMAILS';
v_send_emails varchar2(1);

BEGIN
OPEN c;
FETCH C INTO v_send_emails;
CLOSE c;
if nvl(v_send_emails,'N') = 'Y' then
  HTMLDB_MAIL.SEND( p_to            ,
                    p_from          ,
                    p_body          ,
                    p_body_html     ,
                    p_subj          ,
                    p_cc            ,
                    p_bcc           );
end if;
END OLS_SEND_MAIL;

 
 

/

--------------------------------------------------------
--  DDL for Procedure OLS_SET_DEFAULT_CURRENCY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "OLS_SET_DEFAULT_CURRENCY" 
  (
    p_currency_id NUMBER)
AS
  l_value NUMBER;
  l_code  VARCHAR2(10);
BEGIN
   SELECT
    code, value
     INTO
    l_code, l_value
     FROM
    ols_currency
    WHERE
    id = p_currency_id;
   UPDATE ols_configuration SET value = l_code WHERE KEY = 'DEFAULT_CURRENCY';
   UPDATE ols_currency SET value = value/ l_value;
END OLS_SET_DEFAULT_CURRENCY;

/

--------------------------------------------------------
--  DDL for Package OLS_AUTHORIZENET_API
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PACKAGE "OLS_AUTHORIZENET_API" 
as

function do_post(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_method                in varchar2,
    p_parm01                in varchar2,
    p_parm02                in varchar2 default null,
    p_parm03                in varchar2 default null,
    p_parm04                in varchar2 default null,
    p_parm05                in varchar2 default null,
    p_parm06                in varchar2 default null,
    p_parm07                in varchar2 default null,
    p_parm08                in varchar2 default null,
    p_parm09                in varchar2 default null,
    p_parm10                in varchar2 default null )
    return varchar2;

procedure do_auth_payment(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_ip_address            in varchar2,
    p_amount                in varchar2,
    p_cardnum               in varchar2,
    p_cvc                   in varchar2,
    p_expire_date           in varchar2,
    p_first_name            in varchar2,
    p_last_name             in varchar2,
    p_description           in varchar2,
    p_invnum                in varchar2,
    p_item_post             in varchar2,
    p_address               in varchar2,
    p_tran_id_item          out varchar2);


end ols_AUTHORIZENET_api;

/
 

  CREATE OR REPLACE PACKAGE BODY "OLS_AUTHORIZENET_API" 
as

function do_post(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_method                in varchar2,
    p_parm01                in varchar2,
    p_parm02                in varchar2 default null,
    p_parm03                in varchar2 default null,
    p_parm04                in varchar2 default null,
    p_parm05                in varchar2 default null,
    p_parm06                in varchar2 default null,
    p_parm07                in varchar2 default null,
    p_parm08                in varchar2 default null,
    p_parm09                in varchar2 default null,
    p_parm10                in varchar2 default null )
    return varchar2
is
    l_http_req       utl_http.req;
    l_http_resp      utl_http.resp;
    l_response       varchar2(32000);
    l_post           varchar2(32000);
begin

    l_post := 'x_login='||p_api_username||'&x_tran_key='||p_signature||'&x_version=3.1&'||
        'x_delim_data=TRUE&x_delim_char=:&x_relay_response=FALSE&'||'x_type='||p_method||'&'||p_parm01;

    if p_parm02 is not null then
        l_post := l_post||'&'||p_parm02;
    end if;
    if p_parm03 is not null then
        l_post := l_post||'&'||p_parm03;
    end if;
    if p_parm04 is not null then
        l_post := l_post||'&'||p_parm04;
    end if;
    if p_parm05 is not null then
        l_post := l_post||'&'||p_parm05;
    end if;
    if p_parm06 is not null then
        l_post := l_post||'&'||p_parm06;
    end if;
    if p_parm07 is not null then
        l_post := l_post||'&'||p_parm07;
    end if;
    if p_parm08 is not null then
        l_post := l_post||'&'||p_parm08;
    end if;
    if p_parm09 is not null then
        l_post := l_post||'&'||p_parm09;
    end if;
    if p_parm10 is not null then
        l_post := l_post||'&'||p_parm10;
    end if;

    utl_http.set_proxy(htmldb_application.g_proxy_server, NULL);
    utl_http.set_persistent_conn_support(TRUE);
    utl_http.set_transfer_timeout(300);
    utl_http.set_wallet(p_wallet, p_wallet_pwd);
    l_http_req := utl_http.begin_request(p_api_url, 'POST');
    utl_http.set_header(l_http_req, 'Proxy-Connection', 'Keep-Alive');
    utl_http.set_header(l_http_req, 'Content-Type', 'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_req, 'Content-Length', length(l_post));
    utl_http.write_text(l_http_req, l_post);
 
    l_http_resp := utl_http.get_response(l_http_req);
    utl_http.read_text(l_http_resp, l_response);

    utl_http.end_response (l_http_resp);

    return utl_url.unescape(l_response);

end do_post;

procedure do_auth_payment(
    p_api_url               in varchar2,
    p_api_username          in varchar2,
    p_signature             in varchar2,
    p_wallet                in varchar2,
    p_wallet_pwd            in varchar2,
    p_session_id            in varchar2,
    p_ip_address            in varchar2,
    p_amount                in varchar2,
    p_cardnum               in varchar2,
    p_cvc                   in varchar2,
    p_expire_date           in varchar2,
    p_first_name            in varchar2,
    p_last_name             in varchar2,
    p_description           in varchar2,
    p_invnum                in varchar2,
    p_item_post             in varchar2,
    p_address               in varchar2,
    p_tran_id_item          out varchar2)
is
    l_response          varchar2(32000);
    l_transaction_id    varchar2(30);
    l_vc_arr1    HTMLDB_APPLICATION_GLOBAL.VC_ARR2;
begin

    l_response := do_post(
        p_api_url       => p_api_url,
        p_api_username  => p_api_username,
        p_signature     => p_signature,
        p_wallet        => p_wallet,
        p_wallet_pwd    => p_wallet_pwd,
        p_method        => 'AUTH_CAPTURE',
        p_parm01        => 'x_method=CC',
        p_parm02        => 'x_amount='||p_amount,
        p_parm03        => 'x_card_num='||p_cardnum,
        p_parm04        => 'x_exp_date='||p_expire_date,
        p_parm05        => 'x_card_code='||p_cvc,
        p_parm06        => 'x_customer_ip='||p_ip_address,
        p_parm07        => 'x_first_name='||p_first_name,
        p_parm08        => 'x_last_name='||p_last_name,
        p_parm09        => 'x_description='||substr(p_description,1,255),
        p_parm10        => 'x_invoice_num='|| p_invnum|| '&' 
                           ||p_item_post 
                           || '&' 
                           ||p_address 
                           );
        
        l_vc_arr1 := HTMLDB_UTIL.STRING_TO_TABLE(l_response);
        
    if  l_vc_arr1(1) != 1 then
        raise_application_error(-20001,'Error: '||l_vc_arr1(3)|| ' ' ||l_vc_arr1(4));
    end if;

    l_transaction_id := l_vc_arr1(7);

    insert into ols_paypal_transactions values 
    (p_session_id, null, l_transaction_id, to_char(sysdate,'YYYY-MM-DD HH24:SS:MI'), 
     to_number(l_vc_arr1(10),  '99999D99' , 'NLS_NUMERIC_CHARACTERS = ''.,'''),
    null, null, 'Approved', null, null, substr(l_response,1,4000));

    p_tran_id_item := l_transaction_id;

end do_auth_payment;

end ols_authorizenet_api;


 
 
/
 

--spool off;

