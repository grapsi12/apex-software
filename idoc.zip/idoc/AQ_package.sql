-----------------------------------------------------------------------------
--
-- This script creates AQ package which contains the stored procedures that
-- external application uses as the interface towards our AQ
-- Should be run as AQ_ADM user
-----------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE AQ IS

-----------------------------------------------------------------------------
-- AQ parameters
--
-- Please note in this context outbound means messages and acknowledgements
-- towards external application and inbound refers to messages and acknowledgements received
-- from external application
-----------------------------------------------------------------------------

---------------------------------------------------------------------
-- TODO:
-- - Set g_outbound_consumer to application specific value if you use
--   multi consumer queue
-- - Set g_inbound_consumer to application specific value if you use
--   multi consumer queue
-- - Set g_outbound_queue to application specific value
-- - Set g_inbound_queue to application specific value
-- - Set g_inbound_recipient_address to application specific value
--    Note: g_inbound_recipient_address is optional parameter
---------------------------------------------------------------------

   g_outbound_consumer           VARCHAR2(30) := 'CONSUMER';
   g_inbound_consumer            VARCHAR2(30) := 'MY_MSG_CONSUMER';
   g_outbound_queue              VARCHAR2(64) := 'AQ_ADM.OUT_QUEUE';
   g_inbound_queue               VARCHAR2(64) := 'AQ_ADM.IN_QUEUE';
   g_outbound_ack_queue          VARCHAR2(64) := 'AQ_ADM.ACK_OUT_QUEUE';
   g_inbound_ack_queue           VARCHAR2(64) := 'AQ_ADM.ACK_IN_QUEUE';
   g_inbound_recipient_address   VARCHAR2(64) := 'SCHEMA.QUEUE@DB';


   PROCEDURE enqueue(
      technicalId    IN    VARCHAR2,      -- Application specific unique ID for the messages (e.g. sequence number)
      businessId     IN    VARCHAR2,      -- Primary key for the data (e.g. Order ID, Person ID etc)
      docType        IN    VARCHAR2,      -- Document type (e.g. person message)
      docSubType     IN    VARCHAR2,      -- Sub type (e.g. ADD or DEL)
      receiver       IN    VARCHAR2,      -- Target application list
      sender         IN    VARCHAR2,      -- Source application code
      priority       IN    NUMBER,        -- Message priority (Note: This is not AQ priority)
      payload        IN    CLOB,          -- Message body
      app_specific   IN    VARCHAR2,      -- Generic field to transfer application specific header data
      msg_Id         OUT   VARCHAR2);     -- AQ message ID (used for tracing purposes only)

   PROCEDURE dequeue(
      wait           IN    NUMBER,        -- Number of seconds to wait if no messages in AQ
           filter         IN    VARCHAR2,      -- Filter to use for dequeueuing specific messages
      technicalId    OUT   VARCHAR2,      -- Application specific unique ID for the messages (e.g. sequence number)
      businessId     OUT   VARCHAR2,      -- Primary key for the data (e.g. Order ID, Person ID etc)
      docType        OUT   VARCHAR2,      -- Document type (e.g. person message)
      docSubType     OUT   VARCHAR2,      -- Sub type (e.g. ADD or DEL)
      receiver       OUT   VARCHAR2,      -- Target application list (can be used for routing by external application)
      sender         OUT   VARCHAR2,      -- Source application code (can be used for routing by external application)
      priority       OUT   NUMBER,        -- Message priority
      app_specific   OUT   VARCHAR2,      -- Generic field to transfer application specific header data
      payload        OUT   CLOB);         -- Message body

   PROCEDURE acknowledge(
      technicalId    IN    VARCHAR2,      -- Application specific unique ID for the messages (e.g. sequence number)
      businessId     IN    VARCHAR2,      -- Primary key for the data (e.g. Order ID, Person ID etc)
      docType        IN    VARCHAR2,      -- Document type (e.g. person message)
      docSubType     IN    VARCHAR2,      -- Sub type (e.g. ADD or DEL)
      receiver       IN    VARCHAR2,      -- Target application code
      sender         IN    VARCHAR2,      -- Source application code
      status         IN    VARCHAR2,      -- Status code. 0 = success, other values indicate application specific error code
      return_message IN    VARCHAR2,      -- Application specific error message
      retryCnt       IN    NUMBER,        -- Indicate how many times external application has tried to deliver the message
      maxRetryCnt    IN    NUMBER,        -- Indicate how many times external application will try to deliver the message
      app_specific   IN    VARCHAR2,      -- Generic field to transfer application specific header data
      msg_Id         OUT   VARCHAR2);     -- AQ message ID (used for tracing purposes only)

   PROCEDURE dequeue_ack(
      wait           IN    NUMBER,        -- Number of seconds to wait if no messages in AQ
      filter         IN    VARCHAR2,      -- Filter to use for dequeueuing specific messages
      technicalId    OUT   VARCHAR2,      -- Application specific unique ID for the messages (e.g. sequence number)
      businessId     OUT   VARCHAR2,      -- Primary key for the data (e.g. Order ID, Person ID etc)
      docType        OUT   VARCHAR2,      -- Document type (e.g. person message)
      docSubType     OUT   VARCHAR2,      -- Sub type (e.g. ADD or DEL)
      receiver       OUT   VARCHAR2,      -- Target application code
      sender         OUT   VARCHAR2,      -- Source application code
      status         OUT   VARCHAR2,      -- Status code. 0 = success, other values indicate application specific error code
      return_message OUT   VARCHAR2,      -- Application specific error message
      app_specific   OUT   VARCHAR2);     -- Generic field to transfer application specific header data

END;
/

CREATE OR REPLACE PACKAGE BODY AQ IS

/*
** Title  : API for external application
** Name   : AQ
**
** Desc   : Called by external application, to dequeue messages to external systems
**          and to enqueue ackwowledgement messages
**
*/

   PROCEDURE enqueue(
      technicalId    IN    VARCHAR2,
      businessId     IN    VARCHAR2,
      docType        IN    VARCHAR2,
      docSubType     IN    VARCHAR2,
      receiver       IN    VARCHAR2,
      sender         IN    VARCHAR2,
      priority       IN    NUMBER,
      payload        IN    CLOB,
      app_specific   IN    VARCHAR2,
      msg_Id         OUT   VARCHAR2)
   IS

   v_enqueue_options DBMS_AQ.enqueue_options_t;
   v_message_properties DBMS_AQ.message_properties_t;
   v_recipients DBMS_AQ.aq$_recipient_list_t;
   v_message_handle RAW(16);
   v_message PAYLOAD_T;

   BEGIN

      v_message := PAYLOAD_T(technicalId,
                             businessId,
                             docType,
                             docSubType,
                             receiver,
                             sender,
                             priority,
                             app_specific,
                             payload);

      DBMS_AQ.enqueue(queue_name => g_inbound_queue,
                      enqueue_options => v_enqueue_options,
                      message_properties => v_message_properties,
                      payload => v_message,
                      msgid => v_message_handle);

      msg_Id:=v_message_handle;
   END;
   
   PROCEDURE dequeue(
      wait           IN    NUMBER,
      filter         IN    VARCHAR2,
      technicalId    OUT   VARCHAR2,
      businessId     OUT   VARCHAR2,
      docType        OUT   VARCHAR2,
      docSubType     OUT   VARCHAR2,
      receiver       OUT   VARCHAR2,
      sender         OUT   VARCHAR2,
      priority       OUT   NUMBER,
      app_specific   OUT   VARCHAR2,
      payload        OUT   CLOB)
   IS

   dequeue_options dbms_aq.dequeue_options_t;
   message_properties dbms_aq.message_properties_t;
   message_handle RAW(16);
   message PAYLOAD_T;
   no_messages exception;
   pragma exception_init (no_messages, -25228);

   BEGIN

      -- If the wait parameter is null, we assume that no wait is required
      IF wait IS NULL THEN
         dequeue_options.wait := DBMS_AQ.NO_WAIT;
      ELSE
        dequeue_options.wait:=wait;
      END IF;

   -- If you use multi consumer queue, you must set the consumer name here
   --   dequeue_options.consumer_name := g_outbound_consumer;
      dequeue_options.navigation := DBMS_AQ.FIRST_MESSAGE;
      dequeue_options.deq_condition := filter;

      DBMS_AQ.dequeue(queue_name => g_outbound_queue,
                      dequeue_options => dequeue_options,
                      message_properties => message_properties,
                      payload => message,
                      msgid => message_handle);

      technicalId:=message.technicalId;
      businessId:=message.businessId;
      docType:=message.docType;
      docSubType:=message.docSubType;
      receiver:=message.receiver;
      sender:=message.sender;
      priority:=message.priority;
      app_specific:=message.app_specific;
      payload:=message.payload;

      EXCEPTION
      WHEN no_messages THEN
         technicalId:=NULL;
         businessId:=NULL;
         docType:=NULL;
         docSubType:=NULL;
         receiver:=NULL;
         sender:=NULL;
         priority:=NULL;
         payload:=NULL;
         app_specific:=NULL;


      WHEN OTHERS THEN
         -- If you want some internal error handling, place it here before RAISE statement
        RAISE;
   END;





   PROCEDURE acknowledge(
      technicalId    IN    VARCHAR2,
      businessId     IN    VARCHAR2,
      docType        IN    VARCHAR2,
      docSubType     IN    VARCHAR2,
      receiver       IN    VARCHAR2,
      sender         IN    VARCHAR2,
      status         IN    VARCHAR2,
      return_message IN    VARCHAR2,
      retryCnt       IN    NUMBER,
      maxRetryCnt    IN    NUMBER,
      app_specific   IN    VARCHAR2,
      msg_Id         OUT   VARCHAR2)
   IS

   v_enqueue_options DBMS_AQ.enqueue_options_t;
   v_message_properties DBMS_AQ.message_properties_t;
   v_recipients DBMS_AQ.aq$_recipient_list_t;
   v_message_handle RAW(16);
   v_message ACK_T;

   BEGIN


/*
** If you want to sanity check the input data, add something like this in here:
**
** IF technicalId IS NULL THEN
**    RAISE_APPLICATION_ERROR(-20101, 'technicalId is null');
** END IF;
*/


      v_message := ACK_T(technicalId,
                         businessId,
                         docType,
                         docSubType,
                         receiver,
                         sender,
                         status,
                         return_message);
   -- If inbound queue is multi receiver queue and recipient_list needs to be defined,
   -- do it here
   --   v_recipients(1) := sys.aq$_agent(g_inbound_consumer, g_inbound_recipient_address, NULL);
   --   v_message_properties.recipient_list := v_recipients;

      DBMS_AQ.enqueue(queue_name => g_inbound_ack_queue,
                      enqueue_options => v_enqueue_options,
                      message_properties => v_message_properties,
                      payload => v_message,
                      msgid => v_message_handle);

      msg_Id:=v_message_handle;
   END;





   PROCEDURE dequeue_ack(
      wait           IN    NUMBER,  
      filter         IN    VARCHAR2,
      technicalId    OUT   VARCHAR2,
      businessId     OUT   VARCHAR2,
      docType        OUT   VARCHAR2, 
      docSubType     OUT   VARCHAR2,
      receiver       OUT   VARCHAR2,
      sender         OUT   VARCHAR2,
      status         OUT   VARCHAR2,
      return_message OUT   VARCHAR2,
      app_specific   OUT   VARCHAR2)
   IS

   dequeue_options dbms_aq.dequeue_options_t;
   message_properties dbms_aq.message_properties_t;
   message_handle RAW(16);
   message ACK_T;
   no_messages exception;
   pragma exception_init (no_messages, -25228);

   BEGIN

      -- If the wait parameter is null, we assume that no wait is required
      IF wait IS NULL THEN
         dequeue_options.wait := DBMS_AQ.NO_WAIT;
      ELSE
        dequeue_options.wait:=wait;
      END IF;

   -- If you use multi consumer queue, you must set the consumer name here
   --   dequeue_options.consumer_name := g_outbound_consumer;
      dequeue_options.navigation := DBMS_AQ.FIRST_MESSAGE;
      dequeue_options.deq_condition := filter;

      DBMS_AQ.dequeue(queue_name => g_outbound_ack_queue,
                      dequeue_options => dequeue_options,
                      message_properties => message_properties,
                      payload => message,
                      msgid => message_handle);

      technicalId:=message.technicalId;
      businessId:=message.businessId;
      docType:=message.docType;
      docSubType:=message.docSubType;
      receiver:=message.receiver;
      sender:=message.sender;
      status:=message.status;
      return_message:=message.return_message;
      app_specific := NULL; -- Set this if required

      EXCEPTION
      WHEN no_messages THEN
         technicalId:=NULL;
         businessId:=NULL;
         docType:=NULL;
         docSubType:=NULL;
         receiver:=NULL;
         sender:=NULL;
         app_specific:=NULL;


      WHEN OTHERS THEN
         -- If you want some internal error handling, place it here before RAISE statement
        RAISE;
   END;


END AQ;
/
-- Give execute on the package to AQ_USER
grant execute on AQ to AQ_USER;
/