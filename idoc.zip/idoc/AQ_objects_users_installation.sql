﻿/* 
** First part of the script. Connect as system, run statements below till the second part.
** Two users are created:
** 1) AQ_ADM
**    - Creates the AQ objects (queues, message objects etc)
**    
**    
** 2) AQ_USER
**    - This is user account
**    - It has only permissions to enqueue/dequeue messages from the queueus
**
** Permissions are granted to role "AQ_USER_ROLE"
** 
*/


DROP USER AQ_ADM cascade;
DROP ROLE AQ_ADM_ROLE;

CREATE ROLE AQ_ADM_ROLE;
GRANT CONNECT, RESOURCE, CREATE VIEW, aq_administrator_role
   TO AQ_ADM_ROLE;
   
/*
** TODO: Set the tablespaces and quotas correctly.
** If you are not using AQ_ADM, please replace AQ_ADM with your own account
*/   
CREATE USER AQ_ADM IDENTIFIED BY AQ_ADM
    DEFAULT TABLESPACE users
    TEMPORARY TABLESPACE temp;
GRANT AQ_ADM_ROLE, UNLIMITED TABLESPACE TO AQ_ADM;
GRANT EXECUTE ON DBMS_AQ TO AQ_ADM;  




DROP USER AQ_USER cascade;
DROP ROLE AQ_ROLE;

/*
** TODO: Set the tablespaces and quotas correctly.
** If you are not using AQ_USER, please replace AQ_USER with your own account.
** Change the password for AQ_USER.
*/   
CREATE ROLE AQ_ROLE;
GRANT CREATE SESSION, aq_user_role TO AQ_ROLE;
CREATE USER AQ_USER IDENTIFIED BY AQ_USER
    DEFAULT TABLESPACE users
    TEMPORARY TABLESPACE temp;
GRANT AQ_ROLE TO AQ_USER;

BEGIN
DBMS_AQADM.GRANT_SYSTEM_PRIVILEGE('ENQUEUE_ANY','AQ_ROLE',FALSE);
END;
/

BEGIN
DBMS_AQADM.GRANT_SYSTEM_PRIVILEGE('DEQUEUE_ANY','AQ_ROLE',FALSE);
END;
/

/* 
** Econd part of the script. 
** Connect to your DB using AQ_ADM account created by the first part.
** 1) First drop AQ objects from AQ_ADM (in case the script already run).
**    - Ignore not existing objects error messages when objects are dropped
**    
**    
** 2) Create four queues IN_QUEUE, OUT_QUEUE, ACK_OUT_QUEUE, ACK_IN_QUEUE
**    - Create four corresponding queueu tables
**    - Create the type PAYLOAD_T for message object and type ACK_T for acknowledge message object
**    - Create views on queue tables
** 
*/

/***********************************************************************
** TODO: Connect to your DB using AQ_ADM account
*/   
   

/*
** Run these if something has gone wrong and you need to drop the queue objects
*/
BEGIN
DBMS_AQADM.STOP_QUEUE (
QUEUE_NAME => 'OUT_QUEUE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE (
queue_name => 'OUT_QUEUE');
END;
/
BEGIN
DBMS_AQADM.STOP_QUEUE (
QUEUE_NAME => 'IN_QUEUE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE (
queue_name => 'IN_QUEUE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE_TABLE (
QUEUE_TABLE => 'OUT_QUEUE_TABLE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE_TABLE (
QUEUE_TABLE => 'IN_QUEUE_TABLE');
END;
/


BEGIN
DBMS_AQADM.STOP_QUEUE (
QUEUE_NAME => 'ACK_OUT_QUEUE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE (
queue_name => 'ACK_OUT_QUEUE');
END;
/
BEGIN
DBMS_AQADM.STOP_QUEUE (
QUEUE_NAME => 'ACK_IN_QUEUE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE (
queue_name => 'ACK_IN_QUEUE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE_TABLE (
QUEUE_TABLE => 'ACK_OUT_QUEUE_TABLE');
END;
/
BEGIN
DBMS_AQADM.DROP_QUEUE_TABLE (
QUEUE_TABLE => 'ACK_IN_QUEUE_TABLE');
END;
/

drop type PAYLOAD_T;
drop type ACK_T;



/*
** This is were the DDL statements begin
*/   
CREATE OR REPLACE TYPE PAYLOAD_T as object ( 
technicalID    VARCHAR2(20),
businessID     VARCHAR2(20),  
docType        VARCHAR2(20),
docSubType     VARCHAR2(3),
receiver       VARCHAR2(512),
sender         VARCHAR2(20),
priority       NUMBER(1),
app_specific   VARCHAR2(256),
payload        CLOB);
/

CREATE OR REPLACE TYPE ACK_T as object ( 
technicalID    VARCHAR2(20),
businessID     VARCHAR2(20),  
docType        VARCHAR2(20),
docSubType     VARCHAR2(3),
receiver       VARCHAR2(512),
sender         VARCHAR2(20),
status         VARCHAR2(10),
return_message VARCHAR2(512));
/

grant all privileges on PAYLOAD_T to AQ_USER;
grant all privileges on ACK_T to AQ_USER;

BEGIN
DBMS_AQADM.CREATE_QUEUE_TABLE (
QUEUE_TABLE => 'OUT_QUEUE_TABLE',
MULTIPLE_CONSUMERS => FALSE,
SORT_LIST => 'PRIORITY,ENQ_TIME',
AUTO_COMMIT => TRUE,
COMPATIBLE => '8.1',
QUEUE_PAYLOAD_TYPE => 'PAYLOAD_T');
END;
/

BEGIN
DBMS_AQADM.CREATE_QUEUE_TABLE (
QUEUE_TABLE => 'IN_QUEUE_TABLE',
MULTIPLE_CONSUMERS => FALSE,
SORT_LIST => 'PRIORITY,ENQ_TIME',
AUTO_COMMIT => TRUE,
COMPATIBLE => '8.1',
QUEUE_PAYLOAD_TYPE => 'PAYLOAD_T');
END;
/

BEGIN
DBMS_AQADM.CREATE_QUEUE_TABLE (
QUEUE_TABLE => 'ACK_OUT_QUEUE_TABLE',
MULTIPLE_CONSUMERS => FALSE,
SORT_LIST => 'PRIORITY,ENQ_TIME',
AUTO_COMMIT => TRUE,
COMPATIBLE => '8.1',
QUEUE_PAYLOAD_TYPE => 'ACK_T');
END;
/

BEGIN
DBMS_AQADM.CREATE_QUEUE_TABLE (
QUEUE_TABLE => 'ACK_IN_QUEUE_TABLE',
MULTIPLE_CONSUMERS => FALSE,
SORT_LIST => 'PRIORITY,ENQ_TIME',
AUTO_COMMIT => TRUE,
COMPATIBLE => '8.1',
QUEUE_PAYLOAD_TYPE => 'ACK_T');
END;
/

BEGIN
DBMS_AQADM.CREATE_QUEUE (
queue_name => 'OUT_QUEUE',
retention_time => 3600,
auto_commit => true,
queue_table => 'OUT_QUEUE_TABLE');
END;
/

BEGIN
DBMS_AQADM.CREATE_QUEUE (
queue_name => 'IN_QUEUE',
retention_time => 3600,
auto_commit => true,
queue_table => 'IN_QUEUE_TABLE');
END;
/
BEGIN
DBMS_AQADM.CREATE_QUEUE (
queue_name => 'ACK_OUT_QUEUE',
retention_time => 3600,
auto_commit => true,
queue_table => 'ACK_OUT_QUEUE_TABLE');
END;
/

BEGIN
DBMS_AQADM.CREATE_QUEUE (
queue_name => 'ACK_IN_QUEUE',
retention_time => 3600,
auto_commit => true,
queue_table => 'ACK_IN_QUEUE_TABLE');
END;
/

BEGIN
DBMS_AQADM.START_QUEUE (
QUEUE_NAME => 'OUT_QUEUE',
ENQUEUE => TRUE,
DEQUEUE => TRUE);
END;
/

BEGIN
DBMS_AQADM.START_QUEUE (
QUEUE_NAME => 'IN_QUEUE',
ENQUEUE => TRUE,
DEQUEUE => TRUE);
END;
/
BEGIN
DBMS_AQADM.START_QUEUE (
QUEUE_NAME => 'ACK_OUT_QUEUE',
ENQUEUE => TRUE,
DEQUEUE => TRUE);
END;
/

BEGIN
DBMS_AQADM.START_QUEUE (
QUEUE_NAME => 'ACK_IN_QUEUE',
ENQUEUE => TRUE,
DEQUEUE => TRUE);
END;
/


create or replace view out_aq_vw as
select   q.user_data.technicalID technicalID, 
	      q.user_data.businessID businessID, 
	      q.user_data.docType docType, 
	      q.user_data.docSubType docSubType, 
	      q.user_data.receiver receiver, 
	      q.user_data.sender sender, 
	      q.user_data.app_specific app_specific, 
	      msg_state, 
	      enq_time, 
	      deq_time, 
	      msg_priority, 
	      q.user_data.payload payload
from AQ$OUT_QUEUE_TABLE q;

create or replace view in_aq_vw as
select   q.user_data.technicalID technicalID, 
	      q.user_data.businessID businessID, 
	      q.user_data.docType docType, 
	      q.user_data.docSubType docSubType, 
	      q.user_data.receiver receiver, 
	      q.user_data.sender sender, 
	      q.user_data.app_specific app_specific, 
	      msg_state, 
	      enq_time, 
	      deq_time, 
	      msg_priority, 
	      q.user_data.payload payload
from AQ$IN_QUEUE_TABLE q;

create or replace view ack_in_aq_vw as
select   q.user_data.technicalID technicalID, 
	      q.user_data.businessID businessID, 
	      q.user_data.docType docType, 
	      q.user_data.docSubType docSubType, 
	      q.user_data.receiver receiver, 
	      q.user_data.sender sender, 
	      msg_state, 
	      enq_time, 
	      deq_time, 
	      msg_priority, 
	      q.user_data.status status,
	      q.user_data.return_message return_message
from AQ$ACK_IN_QUEUE_TABLE q;

create or replace view ack_out_aq_vw as
select   q.user_data.technicalID technicalID, 
	      q.user_data.businessID businessID, 
	      q.user_data.docType docType, 
	      q.user_data.docSubType docSubType, 
	      q.user_data.receiver receiver, 
	      q.user_data.sender sender, 
	      msg_state, 
	      enq_time, 
	      deq_time, 
	      msg_priority, 
	      q.user_data.status status,
	      q.user_data.return_message return_message
from AQ$ACK_OUT_QUEUE_TABLE q;

